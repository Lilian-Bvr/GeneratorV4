window.InitUserScripts = function()
{
var player = GetPlayer();
var object = player.object;
var once = player.once;
var addToTimeline = player.addToTimeline;
var setVar = player.SetVar;
var getVar = player.GetVar;
var update = player.update;
var pointerX = player.pointerX;
var pointerY = player.pointerY;
var showPointer = player.showPointer;
var hidePointer = player.hidePointer;
var slideWidth = player.slideWidth;
var slideHeight = player.slideHeight;
window.Script12 = function()
{
  // ============================================================
// CHARGEMENT DES DONNÉES
// ============================================================

// Vérifie le mode debug
const debugMode = getVar("00_Debug");

// ============================================================
// FONCTION D’APPLICATION DES DONNÉES DU JSON
// ============================================================
function applyData(data) {
  // ============================================================
  // TITRE DU PARCOURS
  // ============================================================
  const titre = data.Chapter_Title || "";
  const titreMinuscule = titre.toLowerCase();

  setVar("0_Menu_Titre_Parcours", titre);
  setVar("0_Menu_Titre_Parcours_Minuscule", titreMinuscule);

  // ============================================================
  // VARIABLES DES SECTIONS (S1 à S4)
  // ============================================================
  for (let i = 1; i <= 4; i++) {
    const seqKey = `S${i}`;
    
    // --- Nombre total d'exos ---
    const total = data[`${seqKey}_Exo_Total`] || 0;
    setVar(`0_Menu_${seqKey}_Exo_Total`, total);

    // --- Affichage du zéro ---
    const zeroVar = `0_Menu_${seqKey}_Exo_Total_Zero`;
    setVar(zeroVar, total <= 9 ? "0" : "");

    // --- Initialisation Win/Lose ---
    const winLoseVar = `${seqKey}_Win_Lose`;
    let winLose = getVar(winLoseVar) || "";
    if (winLose.length < total) {
      winLose = "n".repeat(total);
      setVar(winLoseVar, winLose);
    }

    // ============================================================
    // ⏱️  NOUVELLE PARTIE : DURÉES PAR SECTION
    // ============================================================
    const durations = data.Durations || {};
    const durationValue = durations[seqKey] || 0;
    setVar(`0_Menu_${seqKey}_Duree`, durationValue);
  }
}

// ============================================================
// 🚀 CHARGEMENT DES DONNÉES
// ============================================================
if (debugMode) {
  const debugData = {
    Chapter_Title: "Parcours de test (debug)",
    S1_Exo_Total: 5,
    S2_Exo_Total: 13,
    S3_Exo_Total: 8,
    S4_Exo_Total: 4,
    Durations: { S1: 5, S2: 8, S3: 6, S4: 10 }
  };
  applyData(debugData);
} else {
  fetch("Ressources_Sequences/S0/variables.json")
    .then(r => r.json())
    .then(data => {
      applyData(data);
    })
    .catch(e => console.error("Erreur de chargement du JSON :", e));
}

}

window.Script13 = function()
{
  // ============================================================
// 🔢 AJOUT AUTOMATIQUE DU "0" D'ALIGNEMENT DANS LES COMPTEURS
// ============================================================

const sequences = ["S1", "S2", "S3", "S4"];

sequences.forEach(seqKey => {
  const reachedVar = `${seqKey}_Exo_Reached`;
  const reachedZeroVar = `0_Menu_${seqKey}_Exo_Reached_Zero`;
  // Lecture des valeurs actuelles
  const reached = parseInt(getVar(reachedVar) || 0, 10);
  // Calcul du "0" à afficher
  const reachedZero = reached <= 9 ? "0" : "";
  // Écriture dans Storyline
  setVar(reachedZeroVar, reachedZero);
});

}

window.Script14 = function()
{
  // ============================================================
// ⚙️ BARRE DE PROGRESSION — SYNCHRONISATION AVEC LA SÉQUENCE EN COURS
// ============================================================

// --------- Lecture de la séquence courante ---------
const seqPos = getVar("0_Position_Sequence");   // ex. 1 → S1
const seqKey = `S${seqPos}`;

// --------- Lecture des variables de la séquence correspondante ---------
const Exo_Reached = getVar("S0_Exo_Reached") || 0;
const Exo_Total = getVar("S0_Exo_Total") || 1;

// --------- Calcul du pourcentage ---------
const progress = Math.min(Exo_Reached / Exo_Total, 1); // clamp entre 0 et 1

// --------- Sélectionne l'objet Storyline ---------
const ProgressBar = document.querySelector(`[data-model-id="6a0gUoy1Utp"]`);

if (ProgressBar) {
  // --------- Sélectionne l'élément graphique principal ---------
  const shape = ProgressBar.querySelector("path");

  if (shape) {
    // Si ce n’est pas déjà fait, on garde la largeur d’origine
    if (!shape.dataset.fullWidth) {
      const bbox = shape.getBBox();
      shape.dataset.fullWidth = bbox.width;
    }

    // --------- Calcul de la largeur selon la progression ---------
    const fullWidth = parseFloat(shape.dataset.fullWidth);

    // --------- Application du remplissage via clip-path ---------
    shape.style.clipPath = `inset(0 ${100 - progress * 100}% 0 0 round 0px)`;
  }
}

}

window.Script15 = function()
{
  // ============================================================
// 🧪  DONNÉES DE TEST (MODE DEBUG)
// ============================================================

const debugData = {
  S1: {
    Duration: 7,
    EX1: {
      Type: "True or false",
      Consigne: "Vrai ou faux ?",
      Affirmation: "Un client prend rendez-vous avec son conseiller bancaire pour parler de son compte.",
      BonneReponse: "True",
      Feedback: {
        Type: "Simple",
        Texte_HTML: "<p><em>\"Prendre rendez-vous\"</em> signifie fixer une date et une heure pour rencontrer quelqu'un.</p>"
      },
      Tentatives: 1,
      Image: "Ressources_Sequences/S1/Images/S1_EX1.jpg",
      Audio_Enonce: "Ressources_Sequences/S1/Audios/S1_EX1_main.mp3"
    },
    EX2: {
      Type: "True or false",
      Consigne: "Vrai ou faux ?",
      Affirmation: "Le mot \"collègue\" désigne une personne qui travaille dans une autre banque.",
      BonneReponse: "False",
      Feedback: {
        Type: "Simple",
        Texte_HTML: "<p>Un <em>\"collègue\"</em> est une personne qui travaille <strong>dans la même entreprise.</strong></p>"
      },
      Tentatives: 1,
      Image: "Ressources_Sequences/S1/Images/S1_EX2.jpg",
      Audio_Enonce: null
    },
    EX3: {
      Type: "True or false",
      Consigne: "Vrai ou faux ?",
      Affirmation: "Dans un e-mail professionnel, on peut commencer par : \"Salut, ça va ?\"",
      BonneReponse: "False",
      Feedback: {
        Type: "Simple",
        Texte_HTML: "<p>Dans un contexte professionnel, on utilise des formules plus formelles comme <em>\"Bonjour\"</em> ou <em>\"Madame, Monsieur\"</em>.</p>"
      },
      Tentatives: 1,
      Image: null,
      Audio_Enonce: "Ressources_Sequences/S1/Audios/S1_EX3_main.mp3"
    },
    EX4: {
      Type: "True or false",
      Consigne: "Vrai ou faux ?",
      Affirmation: "Le verbe \"vérifier\" signifie \"contrôler si une information est correcte\".",
      BonneReponse: "True",
      Feedback: {
        Type: "Simple",
        Texte_HTML: "<p><em>\"Vérifier\"</em> est un verbe très utilisé au bureau et à la banque.</p>"
      },
      Tentatives: 1,
      Image: null,
      Audio_Enonce: null
    },
    Recap: {
      Type: "Minimaliste"
    }
  },
  S2: {
    Duration: 13,
    EX1: {
      Type: "QCU",
      Consigne: "Réponds à la question !",
      Question: "Que signifie l'expression \"prendre rendez-vous\" ?",
      Reponses: {
        A: "Fixer une date pour rencontrer quelqu'un",
        B: "Annuler une réunion",
        C: "Envoyer un document",
        D: "Attendre un client"
      },
      BonneReponse: "A",
      Feedback: {
        Type: "Simple",
        Texte_HTML: "<p><em>Prendre rendez-vous</em> signifie décider d'une date et d'une heure pour une rencontre.</p>"
      },
      Tentatives: 1,
      Image: "Ressources_Sequences/S2/Images/S2_EX1.jpg",
      Audio_Enonce: "Ressources_Sequences/S2/Audios/S2_EX1_main.mp3"
    },
    EX2: {
      Type: "QCU",
      Consigne: "Réponds à la question !",
      Question: "Quelle formule est la plus appropriée pour commencer un e-mail professionnel ?",
      Reponses: {
        A: "Bonjour Madame,",
        B: "Coucou",
        C: "Salut !",
        D: ""
      },
      BonneReponse: "A",
      Feedback: {
        Type: "Simple",
        Texte_HTML: "<p>En français professionnel, on utilise des formules polies et formelles.</p>"
      },
      Tentatives: 1,
      Image: "Ressources_Sequences/S2/Images/S2_EX2.jpg",
      Audio_Enonce: null
    },
    EX3: {
      Type: "QCU",
      Consigne: "Réponds à la question !",
      Question: "Que fait un employé quand il vérifie un document ?",
      Reponses: {
        A: "Il contrôle les informations",
        B: "Il le traduit",
        C: "",
        D: ""
      },
      BonneReponse: "A",
      Feedback: {
        Type: "Simple",
        Texte_HTML: "<p><em>Vérifier</em> signifie contrôler si les informations sont correctes.</p>"
      },
      Tentatives: 1,
      Image: null,
      Audio_Enonce: "Ressources_Sequences/S2/Audios/S2_EX3_main.mp3"
    },
    EX4: {
      Type: "QCU",
      Consigne: "Réponds à la question !",
      Question: "Quel mot correspond à une personne qui travaille avec vous dans la même entreprise ?",
      Reponses: {
        A: "Collègue",
        B: "Client",
        C: "Conseiller",
        D: "Directeur"
      },
      BonneReponse: "A",
      Feedback: {
        Type: "Simple",
        Texte_HTML: "<p>Un <em>collègue</em> est une personne avec qui on travaille.</p>"
      },
      Tentatives: 1,
      Image: null,
      Audio_Enonce: null
    },
    Recap: {
      Type: "Minimaliste"
    }
  },
  S3: {
    Duration: 8,
    EX1: {
      Type: "QCM",
      Consigne: "Sélectionne les bonnes réponses !",
      Question: "Quelles phrases sont correctes dans un e-mail professionnel ?",
      Reponses: {
        A: "Bonjour Monsieur,",
        B: "Salut, ça va ?",
        C: "Je vous remercie pour votre message.",
        D: "À plus !"
      },
      Corrections: [
        "A",
        "C"
      ],
      Feedback: {
        Type: "Simple",
        Texte_HTML: "<p>En français professionnel, on utilise des formules polies et formelles.</p>"
      },
      Tentatives: 1,
      Image: "Ressources_Sequences/S3/Images/S3_EX1.jpg",
      Audio_Enonce: "Ressources_Sequences/S3/Audios/S3_EX1_main.mp3"
    },
    EX2: {
      Type: "QCM",
      Consigne: "Sélectionne les bonnes réponses !",
      Question: "Quels mots sont liés au domaine de la banque ?",
      Reponses: {
        A: "Compte",
        B: "Virement",
        C: "Client",
        D: ""
      },
      Corrections: [
        "A",
        "B",
        "C"
      ],
      Feedback: {
        Type: "Simple",
        Texte_HTML: "<p><em>Compte</em>, <em>virement</em> et <em>client</em> sont des termes bancaires.</p>"
      },
      Tentatives: 1,
      Image: "Ressources_Sequences/S3/Images/S3_EX2.jpg",
      Audio_Enonce: null
    },
    EX3: {
      Type: "QCM",
      Consigne: "Sélectionne les bonnes réponses !",
      Question: "Quelles actions un employé peut-il faire au bureau ?",
      Reponses: {
        A: "Planter un arbre",
        B: "Prendre rendez-vous",
        C: "",
        D: ""
      },
      Corrections: [
        "B"
      ],
      Feedback: {
        Type: "Simple",
        Texte_HTML: "<p>Ces actions font partie du travail de bureau.</p>"
      },
      Tentatives: 1,
      Image: null,
      Audio_Enonce: "Ressources_Sequences/S3/Audios/S3_EX3_main.mp3"
    },
    EX4: {
      Type: "QCM",
      Consigne: "Sélectionne les bonnes réponses !",
      Question: "Quelles phrases montrent un registre formel ?",
      Reponses: {
        A: "Merci par avance.",
        B: "Je te tiens au courant.",
        C: "Je reste à votre disposition.",
        D: "Cordialement,"
      },
      Corrections: [
        "A",
        "C",
        "D"
      ],
      Feedback: {
        Type: "Simple",
        Texte_HTML: "<p>Ces expressions sont courantes dans la communication professionnelle.</p>"
      },
      Tentatives: 1,
      Image: null,
      Audio_Enonce: null
    },
    Recap: {
      Type: "Minimaliste"
    }
  },
  S4: {
    Duration: 14,
    EX1: {
      Type: "Matching",
      Consigne: "Associez chaque mot à sa définition.",
      Feedback: {
        Type: "Simple",
        Texte_HTML: "<p><em>Client</em> et <em>collègue</em> sont deux mots fréquents dans le vocabulaire professionnel.</p>"
      },
      Match_Type: "texte-texte",
      Tentatives: 9999,
      Audio_Enonce: "Ressources_Sequences/S4/Audios/S4_EX1_main.mp3",
      Paires: {
        P1: {
          Match_L1: "Client",
          Match_R1: "Personne qui utilise les services de la banque"
        },
        P2: {
          Match_L2: "Collègue",
          Match_R2: "Personne qui travaille dans la même entreprise"
        },
        P3: {
          Match_L3: "",
          Match_R3: ""
        },
        P4: {
          Match_L4: "",
          Match_R4: ""
        }
      }
    },
    EX2: {
      Type: "Matching",
      Consigne: "Associez chaque expression à sa signification.",
      Feedback: {
        Type: "Simple",
        Texte_HTML: "<p>Ces expressions sont très utilisées dans les e-mails et au bureau.</p>"
      },
      Match_Type: "texte-texte",
      Tentatives: 9999,
      Audio_Enonce: "Ressources_Sequences/S4/Audios/S4_EX2_main.mp3",
      Paires: {
        P1: {
          Match_L1: "Prendre rendez-vous",
          Match_R1: "Fixer une date et une heure"
        },
        P2: {
          Match_L2: "Vérifier un document",
          Match_R2: "Contrôler les informations"
        },
        P3: {
          Match_L3: "Ci-joint",
          Match_R3: "Envoyer un document"
        },
        P4: {
          Match_L4: "",
          Match_R4: ""
        }
      }
    },
    EX3: {
      Type: "Matching",
      Consigne: "Associez chaque phrase à la situation correspondante.",
      Feedback: {
        Type: "Simple",
        Texte_HTML: "<p>Ces phrases aident à reconnaître les <strong>fonctions communicatives</strong> en français professionnel.</p>"
      },
      Match_Type: "texte-texte",
      Tentatives: 9999,
      Audio_Enonce: "Ressources_Sequences/S4/Audios/S4_EX3_main.mp3",
      Paires: {
        P1: {
          Match_L1: "\"Je vous envoie le document ci-joint.\"",
          Match_R1: "Parler d'une pièce jointe"
        },
        P2: {
          Match_L2: "\"Pouvons-nous fixer un rendez-vous ?\"",
          Match_R2: "Proposer une rencontre"
        },
        P3: {
          Match_L3: "\"Bonjour Madame, comment puis-je vous aider ?\"",
          Match_R3: "Accueillir un client"
        },
        P4: {
          Match_L4: "\"Je reste à votre disposition.\"",
          Match_R4: "Terminer un e-mail professionnel"
        }
      }
    },
    Recap: {
      Type: "Minimaliste"
    }
  }
};

// ============================================================
// 🧹  RÉINITIALISATION DES VARIABLES D'EXERCICE
// ============================================================

const varsToReset = [
  "Ex_Consigne", "Ex_Image", "Ex_Video", "Ex_Type", "Ex_SubType", "0_Reponse", "Ex_Success",

  // True or false
  "0_Ex_Enonce", "0_Ex_Correction", "Ex_Audio_Enonce",

  // QCU et QCM
  "0_Choix_A", "0_Choix_B", "0_Choix_C", "0_Choix_D",
  
  // Complete
  "0_Complete_Choix_A", "0_Complete_Choix_B", "0_Complete_Choix_C", 
  "0_Complete_Choix_D", "0_Complete_Choix_E", "0_Complete_Choix_F",
  "0_Complete_Choix_Reponse", "0_Complete_Reponse_Temporaire",
  
  // Matching
  "0_Matching_Choix_A", "0_Matching_Choix_B", "0_Matching_Choix_C", "0_Matching_Choix_D",
  "0_Matching_Choix_1", "0_Matching_Choix_2", "0_Matching_Choix_3", "0_Matching_Choix_4",
  "0_Matching_Texte_A", "0_Matching_Texte_B", "0_Matching_Texte_C", "0_Matching_Texte_D",
  "0_Matching_Texte_1", "0_Matching_Texte_2", "0_Matching_Texte_3", "0_Matching_Texte_4",
  "0_Matching_Audio_A", "0_Matching_Audio_B", "0_Matching_Audio_C", "0_Matching_Audio_D",
  "0_Matching_Audio_1", "0_Matching_Audio_2", "0_Matching_Audio_3", "0_Matching_Audio_4",
  "0_Matching_Choix_Gauche", "0_Matching_Choix_Droit", "0_Complete_Trou",

  // Flashcard
  "0_Flashcard_Text_Front", "0_Flashcard_Text_Back",
  "Ex_Front_Audio", "Ex_Back_Audio",
  "Ex_Flashcard_Extra_Type", "Ex_Flashcard_Extra_Total",
  "0_Flashcard_Extra_Phrase_1", "0_Flashcard_Extra_Phrase_2", "0_Flashcard_Extra_Phrase_3",
  "0_Flashcard_Extra_Phrase_4", "0_Flashcard_Extra_Phrase_5",
  
  "0_Flashcard_Extra_Expression_1", "0_Flashcard_Extra_Expression_2", "0_Flashcard_Extra_Expression_3", 
  "0_Flashcard_Extra_Expression_4", "0_Flashcard_Extra_Expression_5",
  
  "0_Flashcard_Extra_Exemple_1", "0_Flashcard_Extra_Exemple_2", "0_Flashcard_Extra_Exemple_3", 
  "0_Flashcard_Extra_Exemple_4", "0_Flashcard_Extra_Exemple_5", 
  
  // Information
  "0_Information_Titre", "0_Information_Expression",
  "0_Information_Exemple", "0_Information_Exemple_Audio",
  
  // Dialogue
  "0_Dialogue_Script", "0_Dialogue_Audio",

  // Production orale - dictée
  "0_Production_Orale_Feedback", "0_Production_Orale_Score", "0_Production_Orale_Texte",

  // Feedback
  "Ex_Feedback_Type", "Ex_Feedback", "Ex_Feedback_Motivation", "Ex_Feedback_Audio",
  "Ex_Feedback_Complet_Correction", "Ex_Feedback_Complet_Phrase", "Ex_Feedback_Complet_Traduction",
  "Ex_Feedback_Simple_Texte"
];
varsToReset.forEach(v => setVar(v, ""));

// ============================================================
// ⚙️  CONFIGURATION GLOBALE
// ============================================================

const seqPos = getVar("0_Position_Sequence");
const exPos  = parseInt(getVar("0_Position_Exercice") || 0, 10);
const debugMode = getVar("00_Debug");
const seqKey = `S${seqPos}`;

setVar(`${seqKey}_Exo_Current`, exPos);
setVar("S0_Exo_Current", exPos);
window.sequenceCache = window.sequenceCache || {};

// ============================================================
// 🧮 FONCTION GÉNÉRIQUE DE MÉLANGE AVEC GRAINE
// ============================================================

function shuffleWithSeed(array, seed) {
  let a = [...array];
  let pseudoRandom = seed || 1;
  function seededRandom() {
    pseudoRandom = (pseudoRandom * 9301 + 49297) % 233280;
    return pseudoRandom / 233280;
  }
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(seededRandom() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

// ============================================================
// 🔧 FONCTION : colle la ponctuation orpheline avec un "_" invisible
// ============================================================

function fixFrenchPunctuation(text = "") {
  // Ponctuation double française qui nécessite une espace insécable avant
  const punctuationBefore = ["!", "?", ":", ";", "»", "%"];
  let result = text;

  punctuationBefore.forEach(p => {
    const escaped = p.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    // Remplace tout espace blanc précédant la ponctuation par un "_" blanc invisible
    result = result.replace(
      new RegExp(`\\s(${escaped})`, "g"),
      `<font color="#ffffff">_</font>$1`
    );
  });

  // Guillemet ouvrant : espace insécable après «
  result = result.replace(/«\s/g, `«<font color="#ffffff">_</font>`);

  return result;
}

// ============================================================
// 🧹 FONCTION DE NETTOYAGE DU HTML POUR STORYLINE
// ============================================================

function cleanHTMLforStoryline(html = "") {
  return fixFrenchPunctuation(
    html
      .replace(/<strong>/g, "<b>")
      .replace(/<\/strong>/g, "</b>")
      .replace(/<em>/g, "<i>")
      .replace(/<\/em>/g, "</i>")
      .replace(/<\/?p>/g, "")
      .trim()
  );
}

// ============================================================
// 🔧  FONCTION : applique les données d'un exercice à Storyline
// ============================================================

function applyExerciseData(seqData, exPos) {
  const exData = seqData[`EX${exPos}`];
  if (!exData) {
    console.warn(`⚠️ EX${exPos} non trouvé dans ${seqKey}`);
    return;
  }

  // ============================================================
  // 🎲 GESTION DES CLÉS DE MÉLANGE PAR SÉQUENCE (au bon moment)
  // ============================================================

  const shuffleKeyVar = `${seqKey}_Shuffle_Key`;
  let shuffleKey = getVar(shuffleKeyVar);
  let shuffleKeyData;

  if (!shuffleKey) {
    const seqExercises = Object.keys(seqData || {}).filter(k => /^EX\d+$/.test(k));
    const keys = seqExercises.map(() => Math.floor(Math.random() * 10000));
    setVar(shuffleKeyVar, JSON.stringify(keys));
    shuffleKeyData = keys;
  } else {
    shuffleKeyData = JSON.parse(shuffleKey);
  }

  // ============================================================
  // 💬 GESTION DES TENTATIVES ET VARIABLES COMMUNES
  // ============================================================

  const tentVar = `${seqKey}_Exo_Current_Tentatives`;
  const compteurTentativesVar = `${seqKey}_Exo_Current_Compteur_Tentatives`;
  
  let tentatives = parseInt(getVar(tentVar), 10);
  let compteur = parseInt(getVar(compteurTentativesVar), 10);
  
  // À la fin de chaque exo on passe tentatives à -10
  if (isNaN(tentatives) || tentatives === -10) {
    console.log("Tentatives : ", tentatives);
    tentatives = exData.Tentatives || 1;
    compteur = 0;
    setVar(tentVar, tentatives);
    setVar(compteurTentativesVar, compteur);
  }

  // ============================================================
  // 💬 GESTION DES FEEDBACKS
  // ============================================================

  const fb = exData.Feedback || {};
  const fbType = (fb.Type || "").trim();

  if (!fb || !fbType) {
    // aucun feedback
  } else if (fbType === "Simple") {
    // 🟢 Feedback simple → une phrase seulement
    setVar("Ex_Feedback_Type", "Simple");
    setVar("Ex_Feedback_Simple_Texte", cleanHTMLforStoryline(fb.Texte_HTML || ""));
    setVar("Ex_Feedback_Complet_Correction", "");
    setVar("Ex_Feedback_Complet_Traduction", "");
    setVar("Ex_Feedback_Complet_Phrase", "");
    setVar("Ex_Feedback_Audio", fb.Audio || "");
  } else if (fbType === "Complet") {
    // 🔵 Feedback complet → plusieurs champs
    setVar("Ex_Feedback_Type", "Complet");
    setVar("Ex_Feedback_Complet_Correction", cleanHTMLforStoryline(fb.Correction_HTML || ""));
    setVar("Ex_Feedback_Complet_Traduction", cleanHTMLforStoryline(fb.Traduction_HTML || ""));
    setVar("Ex_Feedback_Complet_Phrase", cleanHTMLforStoryline(fb.Phrase_HTML || ""));
    setVar("Ex_Feedback_Simple_Texte", "");
    setVar("Ex_Feedback_Audio", fb.Audio || "");
  } else {
    // ⚪ Cas non défini → on nettoie tout
    console.warn(`⚠️ Type de feedback inconnu pour EX${exPos} :`, fbType);
    setVar("Ex_Feedback_Type", "");
    setVar("Ex_Feedback_Simple_Texte", "");
    setVar("Ex_Feedback_Complet_Correction", "");
    setVar("Ex_Feedback_Complet_Traduction", "");
    setVar("Ex_Feedback_Complet_Phrase", "");
    setVar("Ex_Feedback_Audio", "");
  }

  setVar("Ex_Tentatives", tentatives);
  setVar("Ex_Compteur_Tentatives", compteur);
  setVar("Ex_Consigne", fixFrenchPunctuation(exData.Consigne || ""));
  setVar("Ex_Image", exData.Image || null);
  setVar("Ex_Video", exData.Video || null);

  // ============================================================
  // 🔄 TRAITEMENT SELON LE TYPE
  // ============================================================

  switch (exData.Type) {
    // ------------------------------------------------------------
    // 🔹 TRUE OR FALSE
    // ------------------------------------------------------------
    case "True or false": {
      setVar("0_Ex_Enonce", fixFrenchPunctuation(exData.Affirmation || ""));
      setVar("0_Ex_Correction", exData.BonneReponse?.toLowerCase() || "");
      setVar("Ex_Audio_Enonce", exData.Audio_Enonce || null);
      break;
    }

    // ------------------------------------------------------------
    // 🔹 QCU
    // ------------------------------------------------------------
    case "QCU": {
      setVar("0_Ex_Enonce", fixFrenchPunctuation(exData.Question || ""));
      setVar("Ex_Audio_Enonce", exData.Audio_Enonce || null);
    
      const entries = Object.entries(exData.Reponses || {}).filter(([k, v]) => v);
      const seed = shuffleKeyData[exPos - 1] || 1;
      const shuffled = shuffleWithSeed(entries, seed);
    
      ["A", "B", "C", "D"].forEach((lettre, i) =>
        setVar(`0_Choix_${lettre}`, fixFrenchPunctuation(shuffled[i]?.[1] || ""))
      );
    
      // 🔍 Détermination de la bonne lettre APRÈS le mélange
      const goodKey = exData.BonneReponse;
      const goodText = exData.Reponses[goodKey];
      const newGoodLetter = shuffled
        .map(([key, text], i) => (text === goodText ? ["A", "B", "C", "D"][i] : null))
        .filter(Boolean)[0] || "";
    
      setVar("0_Ex_Correction", newGoodLetter);
      break;
    }

    // ------------------------------------------------------------
    // 🔹 QCM
    // ------------------------------------------------------------
    case "QCM": {
      setVar("0_Ex_Enonce", fixFrenchPunctuation(exData.Question || ""));
      setVar("Ex_Audio_Enonce", exData.Audio_Enonce || null);

      const entries = Object.entries(exData.Reponses || {}).filter(([k, v]) => v);
      const seed = shuffleKeyData[exPos - 1] || 1;
      const shuffled = shuffleWithSeed(entries, seed);

      ["A", "B", "C", "D"].forEach((lettre, i) =>
        setVar(`0_Choix_${lettre}`, shuffled[i]?.[1] || "")
      );

      const goodKeys = exData.Corrections || [];
      const goodTexts = goodKeys.map(k => exData.Reponses[k]);

      const newGoodLetters = shuffled
        .map(([key, text], i) =>
          goodTexts.includes(text) ? ["A", "B", "C", "D"][i] : null
        )
        .filter(Boolean);

      const correctionFinale =
        newGoodLetters.length > 0 ? newGoodLetters.join("|") : "None";

      setVar("0_Ex_Correction", correctionFinale);
      break;
    }

    // ------------------------------------------------------------
    // 🔹 MATCHING
    // ------------------------------------------------------------
    case "Matching": {
      const matchType = exData.Match_Type || "texte-texte";
      const audio = exData.Audio_Enonce || null;
      setVar("Ex_Audio_Enonce", audio);
      setVar("Ex_SubType", matchType);

      const paires = exData.Paires || {};
      const pairKeys = Object.keys(paires).filter(k => {
        const p = paires[k];
        return (
          /^P\d+$/.test(k) &&
          (p.Match_L1 || p.Match_L2 || p.Match_L3 || p.Match_L4 || p.Match_R1 || p.Match_R2 || p.Match_R3 || p.Match_R4)
        );
      });

      const nbPaires = Math.min(pairKeys.length, 4);
      if (nbPaires === 0) break;

      const seed = shuffleKeyData[exPos - 1] || 1;
      const shuffledLeft = shuffleWithSeed(pairKeys, seed);
      const shuffledRight = shuffleWithSeed(pairKeys, seed + 999);

      const lettresGauche = ["A", "B", "C", "D"];
      const numerosDroite = ["1", "2", "3", "4"];

      for (let i = 0; i < 4; i++) {
        setVar(`0_Matching_Choix_${lettresGauche[i]}`, shuffledLeft[i] || "");
        setVar(`0_Matching_Choix_${numerosDroite[i]}`, shuffledRight[i] || "");
      }

      pairKeys.forEach(key => {
        const pair = paires[key];
        if (!pair) return;

        const leftContent =
          pair.Match_L1 || pair.Match_L2 || pair.Match_L3 || pair.Match_L4 || "";
        const rightContent =
          pair.Match_R1 || pair.Match_R2 || pair.Match_R3 || pair.Match_R4 || "";

        const leftIndex = shuffledLeft.indexOf(key);
        const rightIndex = shuffledRight.indexOf(key);

        if (matchType === "texte-texte") {
          if (leftIndex >= 0 && leftIndex < nbPaires)
            setVar(`0_Matching_Texte_${lettresGauche[leftIndex]}`, leftContent);
          if (rightIndex >= 0 && rightIndex < nbPaires)
            setVar(`0_Matching_Texte_${numerosDroite[rightIndex]}`, rightContent);
        } else if (matchType === "audio-texte") {
          if (leftIndex >= 0 && leftIndex < nbPaires)
            setVar(`0_Matching_Audio_${lettresGauche[leftIndex]}`, leftContent);
          if (rightIndex >= 0 && rightIndex < nbPaires)
            setVar(`0_Matching_Texte_${numerosDroite[rightIndex]}`, rightContent);
        } else if (matchType === "audio-audio") {
          if (leftIndex >= 0 && leftIndex < nbPaires)
            setVar(`0_Matching_Audio_${lettresGauche[leftIndex]}`, leftContent);
          if (rightIndex >= 0 && rightIndex < nbPaires)
            setVar(`0_Matching_Audio_${numerosDroite[rightIndex]}`, rightContent);
        }
      });
      break;
    }

    // ------------------------------------------------------------
    // 🔹 COMPLETE
    // ------------------------------------------------------------
    case "Complete": {
      const completeType = exData.Complete_Type || "options";
      setVar("Ex_SubType", completeType);
    
      let texteIncomplet = exData.Texte_Incomplet || "";
      const texteComplet = exData.Texte_Complet || "";
      const audio = exData.Audio_Enonce || null;
    
      const regexTirets = /_+/g;
      let id = 0;
    
      const texteBalise = texteIncomplet.replace(regexTirets, (match) => {
        id++;
        const len = match.length;
        return `<font class="complete_blank" data-id="${id}" data-length="${len}">${match}</font>`;
      });
    
      setVar("0_Ex_Enonce", fixFrenchPunctuation(texteBalise));
      setVar("0_Complete_IncompleteTexte", texteIncomplet);
      setVar("0_Ex_Correction", texteComplet);
      setVar("Ex_Audio_Enonce", audio);
    
      if (completeType === "options" || completeType === "reconstruit") {
        const opts = exData.Options || [];
        const seed = shuffleKeyData[exPos - 1] || 1;
        const shuffled = shuffleWithSeed(opts, seed);
        const lettres = ["A", "B", "C", "D", "E", "F"];
        lettres.forEach((l, i) => setVar(`0_Complete_Choix_${l}`, shuffled[i] || ""));
      } else {
        ["A", "B", "C", "D", "E", "F"].forEach(l => setVar(`0_Complete_Choix_${l}`, ""));
      }
    
      console.group(`✏️ COMPLETE — EX${exPos}`);
      console.log("Texte enrichi :", texteBalise);
      console.log("Nombre de trous détectés :", id);
      console.groupEnd();
    
      break;
    }

    // ------------------------------------------------------------
    // 🔹 FLASHCARD
    // ------------------------------------------------------------
    case "Flashcard": {
      setVar("Ex_SubType", exData.Flashcard_Type || "");
      setVar("0_Flashcard_Text_Front", fixFrenchPunctuation(exData.Front_Text || ""));
      setVar("0_Flashcard_Text_Back", fixFrenchPunctuation(exData.Back_Text || ""));
      setVar("Ex_Front_Audio", exData.Front_Audio || null);
      setVar("Ex_Back_Audio", exData.Back_Audio || null);
      setVar("Ex_Image", exData.Image || null);

      const extra = exData.Extra || null;

      if (extra && extra.Type && Array.isArray(extra.Elements)) {
        const extraType = extra.Type.trim();
        setVar("Ex_Flashcard_Extra_Type", extraType);

        if (extraType === "Phrases") {
          setVar("Ex_Flashcard_Extra_Total", extra.Elements.length);
          extra.Elements.forEach((phrase, i) => {
            setVar(`0_Flashcard_Extra_Phrase_${i + 1}`, fixFrenchPunctuation(phrase));
          });
          for (let j = extra.Elements.length + 1; j <= 5; j++) {
            setVar(`0_Flashcard_Extra_Phrase_${j}`, "");
          }
        } else if (extraType === "Expressions") {
          setVar("Ex_Flashcard_Extra_Total", extra.Elements.length);
          extra.Elements.forEach((el, i) => {
            const index = i + 1;
            setVar(`0_Flashcard_Extra_Expression_${index}`, fixFrenchPunctuation(el.Expression || ""));
            setVar(`0_Flashcard_Extra_Exemple_${index}`, fixFrenchPunctuation(el.Exemple || ""));
          });
          for (let j = extra.Elements.length + 1; j <= 5; j++) {
            setVar(`0_Flashcard_Extra_Expression_${j}`, "");
            setVar(`0_Flashcard_Extra_Exemple_${j}`, "");
          }
        } else {
          console.warn(`⚠️ Type d'extra non reconnu : ${extraType}`);
          setVar("Ex_Flashcard_Extra_Type", "");
        }
      } else {
        setVar("Ex_Flashcard_Extra_Type", "");
        setVar("Ex_Flashcard_Extra_Total", 0);
        for (let j = 1; j <= 5; j++) {
          setVar(`0_Flashcard_Extra_Phrase_${j}`, "");
          setVar(`0_Flashcard_Extra_Expression_${j}`, "");
          setVar(`0_Flashcard_Extra_Exemple_${j}`, "");
        }
      }

      break;
    }

    // ------------------------------------------------------------
    // 🔹 DIALOGUE
    // ------------------------------------------------------------
    case "Dialogue": {
      setVar("0_Dialogue_Script", cleanHTMLforStoryline(exData.Script_HTML || ""));
      setVar("0_Dialogue_Audio", exData.Audio_Enonce || "");
      setVar("Ex_Image", exData.Image || null);
      setVar("Ex_Video", exData.Video || null);
      break;
    }

    // ------------------------------------------------------------
    // 🔹 LEÇON
    // ------------------------------------------------------------
    case "Leçon": {
      const subType = exData.SubType || "simple";
      setVar("Ex_SubType", subType);
      setVar("Ex_Image", exData.Image || null);
      setVar("Ex_Video", exData.Video || null);
      setVar("Ex_Consigne", fixFrenchPunctuation(exData.Consigne || ""));

      if (subType === "simple") {
        setVar("0_Lesson_Expression_FR", fixFrenchPunctuation(exData.Expression_FR || ""));
        setVar("0_Lesson_Expression_EN", fixFrenchPunctuation(exData.Expression_EN || ""));
        setVar("0_Lesson_Exemple_FR", fixFrenchPunctuation(exData.Exemple_FR || ""));
        setVar("0_Lesson_Exemple_EN", fixFrenchPunctuation(exData.Exemple_EN || ""));
        setVar("0_Lesson_Audio_Expression", exData.Audio_Expression || "");
        setVar("0_Lesson_Audio_Exemple", exData.Audio_Exemple || "");
        setVar("0_Lesson_Texte_HTML", "");

        setVar("0_Lesson_Has_Header", false);
        setVar("0_Lesson_Columns_Total", 0);
        setVar("0_Lesson_Rows_Total", 0);
        for (let l = 1; l <= 3; l++) {
          for (let c = 1; c <= 2; c++) {
            setVar(`0_Lesson_Table_L${l}_C${c}_Texte`, "");
            setVar(`0_Lesson_Table_L${l}_C${c}_Audio`, "");
          }
        }
        setVar("0_Lesson_Header_1", "");
        setVar("0_Lesson_Header_2", "");

      } else if (subType === "complexe") {
        const cleanedTexte = cleanHTMLforStoryline(exData.Texte_HTML || "");
        setVar("0_Lesson_Texte_HTML", cleanedTexte);
        setVar("0_Lesson_Has_Header", !!exData.Has_Header);

        const headers = exData.Headers || [];
        const lignes = exData.Lignes || [];

        const rows = Math.min(lignes.length, 3);
        const columns = lignes[0]?.Colonnes?.length || 1;

        setVar("0_Lesson_Rows_Total", rows);
        setVar("0_Lesson_Columns_Total", columns);

        setVar("0_Lesson_Header_1", fixFrenchPunctuation(headers[0] || ""));
        setVar("0_Lesson_Header_2", fixFrenchPunctuation(headers[1] || ""));

        for (let l = 0; l < 3; l++) {
          const ligne = lignes[l];
          for (let c = 0; c < 2; c++) {
            const col = ligne?.Colonnes?.[c] || {};
            setVar(`0_Lesson_Table_L${l + 1}_C${c + 1}_Texte`, fixFrenchPunctuation(col.Texte || ""));
            setVar(`0_Lesson_Table_L${l + 1}_C${c + 1}_Audio`, col.Audio || "");
          }
        }

        setVar("0_Lesson_Expression_FR", "");
        setVar("0_Lesson_Expression_EN", "");
        setVar("0_Lesson_Exemple_FR", "");
        setVar("0_Lesson_Exemple_EN", "");
        setVar("0_Lesson_Audio_Exemple", "");

      } else {
        console.warn(`⚠️ Sous-type de Leçon inconnu : ${subType}`);
      }

      break;
    }

    // ------------------------------------------------------------
    // 🔹 INFORMATION (plus en activité)
    // ------------------------------------------------------------
    case "Information": {
      setVar("0_Information_Titre", fixFrenchPunctuation(exData.Titre || ""));
      setVar("0_Information_Expression", fixFrenchPunctuation(exData.Expression || ""));
      setVar("0_Information_Exemple", fixFrenchPunctuation(exData.Exemple || ""));
      setVar("0_Information_Exemple_Audio", exData.Exemple_Audio || null);
      setVar("Ex_Image", exData.Image || null);
      break;
    }

    // ------------------------------------------------------------
    // 🔹 PRODUCTION ORALE - DICTÉE
    // ------------------------------------------------------------
    case "Production orale - dictée": {
      setVar("0_Ex_Enonce", fixFrenchPunctuation(exData.Phrase || ""));
      setVar("Ex_Audio_Enonce", exData.Audio_Exemple || null);
      setVar("Ex_Image", exData.Image || null);
      break;
    }

    default:
      console.warn(`❔ Type inconnu : ${exData.Type}`);
      break;
  }

  setVar("Ex_Type", exData.Type || "");
}

// ============================================================
// 🚀  CHARGEMENT PRINCIPAL
// ============================================================

if (debugMode) {
  const localSeq = debugData[seqKey];
  if (localSeq) applyExerciseData(localSeq, exPos);
  else console.warn(`❌ Données debug manquantes pour ${seqKey}`);
} else {
  if (window.sequenceCache[seqKey]) {
    applyExerciseData(window.sequenceCache[seqKey], exPos);
  } else {
    fetch(`Ressources_Sequences/${seqKey}/variables.json`)
      .then(r => r.json())
      .then(json => {
        window.sequenceCache[seqKey] = json;
        applyExerciseData(json, exPos);
      })
      .catch(e => console.error("Erreur de chargement du JSON :", e));
  }
}
}

window.Script16 = function()
{
  // -------- Initialisation --------

// Récupère le numéro ou identifiant d'exercice (ex: "EX2")
const AudioPath = getVar("0_Audio_Lecteur");

// Si un audio était déjà en cours → on le stoppe et on remet au début
if (window.audioUnique) {
  window.audioUnique.pause();
  window.audioUnique.currentTime = 0;
}

// Crée un nouvel objet audio
window.audioUnique = new Audio(AudioPath);

// Lecture
window.audioUnique.play().catch(err => {
  console.log("Erreur lecture Back :", err);
});
}

window.Script17 = function()
{
  // ============================================================
// 🎯 MISE À JOUR DES VARIABLES Sx_Win_Lose SELON Ex_Success (texte)
// ============================================================

// -------- Lecture des variables Storyline --------
const seqPos  = getVar("0_Position_Sequence");
const exPos   = getVar("0_Position_Exercice");
const success = getVar("Ex_Success");

// -------- Construction du nom de la séquence --------
const seqKey     = `S${seqPos}`;
const winLoseVar = `${seqKey}_Win_Lose`;

// -------- Lecture actuelle de la variable Win_Lose --------
let winLose = getVar(winLoseVar) || "";

// -------- S’assure que la longueur correspond au nombre total d’exercices --------
const total = getVar(`0_Menu_${seqKey}_Exo_Total`);

// -------- Conversion en tableau pour modification --------
const chars = winLose.split("");

// -------- Mise à jour du caractère correspondant à l’exercice actuel --------
if (!(chars[exPos - 1] === "1" && success === "0")) {
    chars[exPos - 1] = success === "1" ? "1" : "0";
}
// Si l'exercice est déjà réussi, on garde la réussite.

// -------- Conversion inverse en chaîne --------
winLose = chars.join("");

// -------- Écriture dans Storyline --------
setVar(winLoseVar, winLose);

// ============================================================
// 🔁 SWITCH AUTOMATIQUE DE 0_Feedback_Switch
// ============================================================
let feedbackSwitch = getVar("0_Feedback_Switch");
feedbackSwitch = feedbackSwitch === true || feedbackSwitch === "true" ? false : true;
setVar("0_Feedback_Switch", feedbackSwitch);

}

window.Script18 = function()
{
  // ============================================================
// 🏁 SCRIPT DE FIN D’EXERCICE — MISE À JOUR PROGRESSION & TENTATIVES
// ============================================================

// -------- CONFIGURATION --------
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;

const exCurrent  = parseInt(getVar(`${seqKey}_Exo_Current`), 10);
const exReached  = parseInt(getVar(`${seqKey}_Exo_Reached`), 10);
const tentVar    = `${seqKey}_Exo_Current_Tentatives`;
// ============================================================
// 🧭 MISE À JOUR DE LA PROGRESSION
// ============================================================

// Si on avance (évite de revenir en arrière)
if (exCurrent > exReached) {
  setVar(`${seqKey}_Exo_Reached`, exCurrent);
  setVar("S0_Exo_Reached", exCurrent); 
}

// ============================================================
// 🧮 MARQUAGE DE L’EXERCICE TERMINÉ
// ============================================================

setVar(tentVar, -10);

}

window.Script19 = function()
{
  // ============================================================
// 🧠 SAUVEGARDE AUTOMATIQUE DES DONNÉES UTILISATEUR (GLOBAL)
// ============================================================
//
// 🔹 Ce script est appelé automatiquement après la validation d’un exercice.
// 🔹 Il détecte le type d’exercice et sauvegarde la réponse dans la variable JSON
//    correspondante (ex: S1_UserData)
//
// ============================================================

// ------------------------------------------------------------
// 🔧 Lecture des infos de contexte
// ------------------------------------------------------------
const seqPos = getVar("0_Position_Sequence");           // ex: "1"
const exPos = parseInt(getVar("0_Position_Exercice"), 10);
const seqKey = `S${seqPos}`;
const exType = getVar("Ex_Type");
const success = getVar("Ex_Success");
const tentativesRestantes = parseInt(getVar("Ex_Tentatives"), 10);

// Variable cible (ex: "S1_UserData")
const userDataVar = `${seqKey}_UserData`;

// ------------------------------------------------------------
// 🔧 Lecture du JSON existant
// ------------------------------------------------------------
let data = {};
try {
  const existing = getVar(userDataVar);
  data = existing ? JSON.parse(existing) : {};
} catch (err) {
  console.warn(`⚠️ JSON invalide dans ${userDataVar}, réinitialisation.`, err);
  data = {};
}

// ------------------------------------------------------------
// 🧮 Tentatives initiales (si dispo dans cache global)
// ------------------------------------------------------------
let tentativesInitiales = 0;
try {
  const exData = window.sequenceCache?.[seqKey]?.[`EX${exPos}`];
  tentativesInitiales = exData?.Tentatives || 1;
} catch {
  tentativesInitiales = 1;
}

const tentativesUtilisees = Math.max(0, tentativesInitiales - tentativesRestantes);

// ------------------------------------------------------------
// 🎯 Récupération de la réponse selon le type d’exercice
// ------------------------------------------------------------
let userResponseObj = {};

switch (exType) {
  // 🔹 QCU
  case "QCU": {
    const answerKey = getVar("0_Reponse");
    const answerText = getVar(`0_Choix_${answerKey}`) || "";
    userResponseObj = { [answerKey]: answerText };
    break;
  }

  // 🔹 QCM
  case "QCM": {
    const responseRaw = (getVar("0_Reponse") || "").split("|").filter(Boolean);
    responseRaw.forEach(k => {
      userResponseObj[k] = getVar(`0_Choix_${k}`) || "";
    });
    break;
  }

  // 🔹 True or false
  case "True or false": {
    const answer = (getVar("0_Reponse") || "").toLowerCase();
    userResponseObj = { unique: answer };
    break;
  }

  // 🔹 Complete
  case "Complete": {
    const answer = getVar("0_Ex_Enonce") || "";
    userResponseObj = { unique: answer };
    break;
  }

  // 🔹 Matching
  case "Matching": {
    const reponse = getVar("0_Reponse") || "";
    userResponseObj = { associations: reponse };
    break;
  }

  // 🔹 Flashcard
  case "Flashcard": {
    const answer = getVar("0_Reponse") || "";
    userResponseObj = { unique: answer };
    break;
  }

  // 🔹 Information
  case "Information": {
    userResponseObj = { info: "Aucune interaction" };
    break;
  }

  // 🔹 Production orale - dictée
  case "Production orale - dictée": {
    const raw = getVar("0_Reponse") || "{}";
    try {
      const parsed = JSON.parse(raw);
      userResponseObj = {
        score: parsed.score || 0,
        texte_brut: parsed.texte_brut || "",
        texte_color: parsed.texte_color || ""
      };
    } catch (err) {
      console.warn("⚠️ Erreur de parsing JSON pour Production orale :", err);
      userResponseObj = { erreur: "Format de réponse invalide", raw };
    }
    break;
  }

  // 🔹 Défaut
  default: {
    const raw = getVar("0_Reponse") || "";
    userResponseObj = { inconnu: raw };
    console.warn(`❓ Type d’exercice inconnu : ${exType}`);
    break;
  }
}

// ------------------------------------------------------------
// 💾 Enregistrement dans le JSON
// ------------------------------------------------------------
data[`EX${exPos}`] = {
  Type: exType,
  Reponses_Choisies: userResponseObj,
  Statut: success,
  Tentatives_Utilisees: tentativesUtilisees
};

setVar(userDataVar, JSON.stringify(data));

// ------------------------------------------------------------
// 🧾 Log de contrôle
// ------------------------------------------------------------
console.group(`💾 Données sauvegardées → ${userDataVar}`);
console.log("Exercice :", `EX${exPos}`);
console.log("Type :", exType);
console.log("Réponses :", userResponseObj);
console.log("Statut :", success);
console.log("Tentatives utilisées :", tentativesUtilisees);
console.log("JSON complet :", data);
console.groupEnd();

}

window.Script20 = function()
{
  // ============================================================
// 🎯 VÉRIFICATION DE LA RÉPONSE (QCU) + GESTION DES TENTATIVES
// ============================================================

// --------- Lecture des variables Storyline ---------
const userAnswer = (getVar("0_Reponse") || "").trim();
const correction  = (getVar("0_Ex_Correction") || "").trim();
let tentatives    = parseInt(getVar("Ex_Tentatives"), 10);
const seqPos      = getVar("0_Position_Sequence");
const seqKey      = `S${seqPos}`;
const tentVar     = `${seqKey}_Exo_Current_Tentatives`;

let CompteurTentatives    = parseInt(getVar("Ex_Compteur_Tentatives"), 10);
const CompteurTentativesVar = `${seqKey}_Exo_Current_Compteur_Tentatives`;

// --------- Lecture du succès actuel ---------
let success = getVar("Ex_Success") || "";

// ============================================================
// 🧮 VÉRIFICATION DE LA RÉPONSE
// ============================================================
if (userAnswer === correction) {
  success = "1";
} else {
  if (tentatives > 0) {
    tentatives -= 1;
  }
  if (tentatives <= 0) {
    success = "0";
  }
}
CompteurTentatives++;

// ============================================================
// 💾 MISE À JOUR DES VARIABLES PERSISTANTES
// ============================================================
setVar("Ex_Tentatives", tentatives);
setVar(tentVar, tentatives);

setVar("Ex_Compteur_Tentatives", CompteurTentatives);
setVar(CompteurTentativesVar, CompteurTentatives);

setVar("Ex_Success", success);

if (success === "1" || tentatives <= 0) {
  setVar(tentVar, -10);
}

}

window.Script21 = function()
{
  const Choix_C = object('6fD0Rv9tsJe');
const PositionBis = object('6Oqgelqohzj');

if (getVar("0_Choix_D")===""){
	Choix_C.x = PositionBis.x;
};
}

window.Script22 = function()
{
  // ============================================================
// 🎯 QCU — RESTAURATION / MISE À JOUR DES ÉTATS + CADRE SELECTED
// ============================================================

// -------- VARIABLES STORYLINE --------
const seqPos = getVar("0_Position_Sequence"); // ex: "1"
const exPos = parseInt(getVar("0_Position_Exercice") || 0, 10);
const seqKey = `S${seqPos}`;
const userDataVar = `${seqKey}_UserData`;

const correction = (getVar("0_Ex_Correction") || "").trim().toUpperCase();
let reponse = (getVar("0_Reponse") || "").trim().toUpperCase(); // priorité Storyline

// -------- SI AUCUNE RÉPONSE LOCALE, ON VA CHERCHER DANS USERDATA --------
if (!reponse) {
  try {
    const raw = getVar(userDataVar);
    if (raw) {
      const data = JSON.parse(raw);
      const exData = data[`EX${exPos}`];
      if (exData && exData.Type === "QCU") {
        const savedKey = Object.keys(exData.Reponses_Choisies || {})[0];
        if (savedKey) {
          reponse = savedKey.toUpperCase();
        }
      }
    }
  } catch (err) {
    console.warn(`⚠️ Lecture UserData échouée pour ${userDataVar}`, err);
  }
}

// -------- OBJETS STORYLINE --------
const choix_A_QCU = object('6pcjVF6XdkF');
const choix_B_QCU = object('5ceC8oOryyB');
const choix_C_QCU = object('6fD0Rv9tsJe');
const choix_D_QCU = object('6TGJEdAa8iH');
const selected = object('6FzImBiO39Y');

// -------- FONCTION UTILITAIRE --------
function setFeedbackState(obj, state) {
  if (!obj) return;
  if (obj.state !== state) obj.state = state;
}

// -------- MAPPING LETTRES → OBJETS --------
const mapping = {
  A: choix_A_QCU,
  B: choix_B_QCU,
  C: choix_C_QCU,
  D: choix_D_QCU
};

// ============================================================
// 🧠 APPLICATION DES ÉTATS VISUELS
// ============================================================
for (const key in mapping) {
  const obj = mapping[key];
  if (!obj) continue;

  if (key === correction) {
    setFeedbackState(obj, "Correct Answer");
  } else if (key === reponse && reponse !== correction) {
    setFeedbackState(obj, "Wrong Answer");
  } else {
    setFeedbackState(obj, "Normal");
  }
}

// ============================================================
// 🎯 POSITIONNEMENT DU CADRE SELECTED
// ============================================================
if (selected) {
  if (!reponse) {
    selected.state = "Caché";
    console.log("Aucune réponse sélectionnée → sélecteur masqué.");
  } else {
    const obj = mapping[reponse];
    if (obj) {
      selected.x = obj.x;
      selected.y = obj.y;
      selected.state = "Visible";
    } else {
      selected.state = "Caché";
      console.warn(`⚠️ Choix "${reponse}" introuvable — sélecteur masqué.`);
    }
  }
}

}

window.Script23 = function()
{
  // ============================================================
// 🎯 QCU — RESTAURATION VISUELLE : SEULE LA RÉPONSE CHOISIE CHANGE D’ÉTAT
// ============================================================

// -------- VARIABLES STORYLINE --------
const seqPos = getVar("0_Position_Sequence"); // ex: "1"
const exPos = parseInt(getVar("0_Position_Exercice") || 0, 10);
const seqKey = `S${seqPos}`;
const userDataVar = `${seqKey}_UserData`;

const correction = (getVar("0_Ex_Correction") || "").trim().toUpperCase(); // ex: "B"
let reponse = (getVar("0_Reponse") || "").trim().toUpperCase(); // ex: "C"

// ============================================================
// 🎨 OBJETS STORYLINE
// ============================================================
const choix_A_QCU = object('6pcjVF6XdkF');
const choix_B_QCU = object('5ceC8oOryyB');
const choix_C_QCU = object('6fD0Rv9tsJe');
const choix_D_QCU = object('6TGJEdAa8iH');

// -------- FONCTION UTILE --------
function setFeedbackState(obj, state) {
  if (!obj) return;
  if (obj.state !== state) obj.state = state;
}

// -------- MAPPING LETTRES → OBJETS --------
const mapping = {
  A: choix_A_QCU,
  B: choix_B_QCU,
  C: choix_C_QCU,
  D: choix_D_QCU
};

// ============================================================
// 🧠 APPLICATION DES ÉTATS VISUELS
// ============================================================

// 2️⃣ On applique l’état à la seule réponse choisie
if (reponse && mapping[reponse]) {
  if (reponse === correction) {
    setFeedbackState(mapping[reponse], "Correct Answer");
    console.log(`✅ Réponse "${reponse}" est correcte.`);
  } else {
    setFeedbackState(mapping[reponse], "Wrong Answer");
    console.log(`❌ Réponse "${reponse}" est incorrecte.`);
  }
} else {
  console.log("ℹ️ Aucune réponse sélectionnée.");
}

// ============================================================
// 🧾 LOG DE CONTRÔLE
// ============================================================
console.group(`💾 QCU — Affichage état unique EX${exPos}`);
console.log("Réponse choisie :", reponse || "(aucune)");
console.log("Correction attendue :", correction);
console.groupEnd();

}

window.Script24 = function()
{
  const Choix_C = object('63SKPe2gbiD');
const PositionBis = object('5mkdzvM86Uv');

if (getVar("0_Choix_D")===""){
	Choix_C.x = PositionBis.x;
};
}

window.Script25 = function()
{
  console.log("STOCKAGE QCU SANS Image ou vidéo réponse DATA")
// ============================================================
// 🎯 QCU — RESTAURATION / MISE À JOUR DES ÉTATS + CADRE SELECTED
// ============================================================

// -------- VARIABLES STORYLINE --------
const seqPos = getVar("0_Position_Sequence"); // ex: "1"
const exPos = parseInt(getVar("0_Position_Exercice") || 0, 10);
const seqKey = `S${seqPos}`;
const userDataVar = `${seqKey}_UserData`;

const correction = (getVar("0_Ex_Correction") || "").trim().toUpperCase();
let reponse = (getVar("0_Reponse") || "").trim().toUpperCase(); // priorité Storyline

// -------- SI AUCUNE RÉPONSE LOCALE, ON VA CHERCHER DANS USERDATA --------
if (!reponse) {
  try {
    const raw = getVar(userDataVar);
    if (raw) {
      const data = JSON.parse(raw);
      const exData = data[`EX${exPos}`];
      if (exData && exData.Type === "QCU") {
        const savedKey = Object.keys(exData.Reponses_Choisies || {})[0];
        if (savedKey) {
          reponse = savedKey.toUpperCase();
        }
      }
    }
  } catch (err) {
    console.warn(`⚠️ Lecture UserData échouée pour ${userDataVar}`, err);
  }
}

// -------- OBJETS STORYLINE --------
const choix_A_QCU = object('6aCJFVT7RG7');
const choix_B_QCU = object('5fvSomKIv4a');
const choix_C_QCU = object('63SKPe2gbiD');
const choix_D_QCU = object('5rIdSZs4KjO');
const selected = object('6A1BoU2cFpE');

// -------- FONCTION UTILITAIRE --------
function setFeedbackState(obj, state) {
  if (!obj) return;
  if (obj.state !== state) obj.state = state;
}

// -------- MAPPING LETTRES → OBJETS --------
const mapping = {
  A: choix_A_QCU,
  B: choix_B_QCU,
  C: choix_C_QCU,
  D: choix_D_QCU
};

// ============================================================
// 🧠 APPLICATION DES ÉTATS VISUELS
// ============================================================
for (const key in mapping) {
  const obj = mapping[key];
  if (!obj) continue;

  if (key === correction) {
    setFeedbackState(obj, "Correct Answer");
  } else if (key === reponse && reponse !== correction) {
    setFeedbackState(obj, "Wrong Answer");
  } else {
    setFeedbackState(obj, "Normal");
  }
}

// ============================================================
// 🎯 POSITIONNEMENT DU CADRE SELECTED
// ============================================================
if (selected) {
  if (!reponse) {
    selected.state = "Caché";
    console.log("Aucune réponse sélectionnée → sélecteur masqué.");
  } else {
    const obj = mapping[reponse];
    if (obj) {
      selected.x = obj.x;
      selected.y = obj.y;
      selected.state = "Visible";
    } else {
      selected.state = "Caché";
      console.warn(`⚠️ Choix "${reponse}" introuvable — sélecteur masqué.`);
    }
  }
}

}

window.Script26 = function()
{
  console.log("FEEDBACK VISUEL QCU SANS Image ou vidéo réponse DATA")
// ============================================================
// 🎯 QCU — RESTAURATION VISUELLE : SEULE LA RÉPONSE CHOISIE CHANGE D’ÉTAT
// ============================================================

// -------- VARIABLES STORYLINE --------
const seqPos = getVar("0_Position_Sequence"); // ex: "1"
const exPos = parseInt(getVar("0_Position_Exercice") || 0, 10);
const seqKey = `S${seqPos}`;
const userDataVar = `${seqKey}_UserData`;

const correction = (getVar("0_Ex_Correction") || "").trim().toUpperCase(); // ex: "B"
let reponse = (getVar("0_Reponse") || "").trim().toUpperCase(); // ex: "C"

// ============================================================
// 🎨 OBJETS STORYLINE
// ============================================================
const choix_A_QCU = object('6aCJFVT7RG7');
const choix_B_QCU = object('5fvSomKIv4a');
const choix_C_QCU = object('63SKPe2gbiD');
const choix_D_QCU = object('5rIdSZs4KjO');

// -------- FONCTION UTILE --------
function setFeedbackState(obj, state) {
  if (!obj) return;
  if (obj.state !== state) obj.state = state;
}

// -------- MAPPING LETTRES → OBJETS --------
const mapping = {
  A: choix_A_QCU,
  B: choix_B_QCU,
  C: choix_C_QCU,
  D: choix_D_QCU
};

// ============================================================
// 🧠 APPLICATION DES ÉTATS VISUELS
// ============================================================

// 2️⃣ On applique l’état à la seule réponse choisie
if (reponse && mapping[reponse]) {
  if (reponse === correction) {
    setFeedbackState(mapping[reponse], "Correct Answer");
    console.log(`✅ Réponse "${reponse}" est correcte.`);
  } else {
    setFeedbackState(mapping[reponse], "Wrong Answer");
    console.log(`❌ Réponse "${reponse}" est incorrecte.`);
  }
} else {
  console.log("ℹ️ Aucune réponse sélectionnée.");
}

// ============================================================
// 🧾 LOG DE CONTRÔLE
// ============================================================
console.group(`💾 QCU — Affichage état unique EX${exPos}`);
console.log("Réponse choisie :", reponse || "(aucune)");
console.log("Correction attendue :", correction);
console.groupEnd();

}

window.Script27 = function()
{
  // Récupère les objets Storyline
const carte  = document.querySelector('[data-model-id="6WOyyFcuLyH"]');
const bouton = document.querySelector('[data-model-id="5rCsry3VrNh"]');

// Points d'ancrage
carte.style.transformOrigin = "top left";
bouton.style.transformOrigin = "center";

// Timeline pour synchroniser
const tl = gsap.timeline();

tl.to(carte, {
  scale: 0,
  opacity: 0,
  duration: 0.5,
  ease: "power1.inOut"
}, 0);

// Rotation 90° du bouton en même temps
tl.to(bouton, {
  rotate: 0,          // ou "+=90" si tu veux ajouter 90° à chaque fois
  duration: 0.5,
  ease: "power1.inOut"
}, 0);

}

window.Script28 = function()
{
  // Récupère les objets Storyline
const carte  = document.querySelector('[data-model-id="6WOyyFcuLyH"]');
const bouton = document.querySelector('[data-model-id="5rCsry3VrNh"]');

// Points d'ancrage
carte.style.transformOrigin = "top left";
bouton.style.transformOrigin = "center";

// États initiaux
gsap.set(carte,  { scale: 0, opacity: 0 });
gsap.set(bouton, { rotate: 0 }); // ou 90 si tu veux qu'il démarre déjà tourné

// Timeline pour synchroniser
const tl = gsap.timeline();

tl.to(carte, {
  scale: 1,
  opacity: 1,
  duration: 0.5,
  ease: "power1.inOut"
}, 0);

// Rotation 90° du bouton en même temps
tl.to(bouton, {
  rotate: 45,          // ou "+=90" si tu veux ajouter 90° à chaque fois
  duration: 0.5,
  ease: "power1.inOut"
}, 0);

}

window.Script29 = function()
{
  // ============================================================
// 💬 FEEDBACK MOTIVATIONNEL — AVEC SUPPORT DU FORMAT "1101nn"
// ============================================================

// -------- VARIABLES DE BASE --------
let resultat = getVar("Ex_Success");
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;
const exCurrent = parseInt(getVar(`${seqKey}_Exo_Current`), 10);

// ============================================================
// 🔍 SI RESULTAT VIDE → CHERCHE DANS S1_Win_Lose ("1101nn")
// ============================================================
if (!resultat || resultat === "") {
  const historique = getVar(`${seqKey}_Win_Lose`) || "";
  const charAtIndex = historique.charAt(exCurrent - 1);

  if (charAtIndex === "1" || charAtIndex === "0") {
    resultat = charAtIndex;
  } else {
    console.log(`ℹ️ Aucun résultat valide trouvé dans ${seqKey}_Win_Lose à l’index ${exCurrent - 1}`);
  }
}

// ============================================================
// 💬 LISTES DE FEEDBACKS
// ============================================================
const feedbackCorrect = [
  "Bravo !",
  "Super !",
  "Bien joué !",
  "Excellent !"
];

const feedbackIncorrect = [
  "Pas exactement.",
  "Oups !",
  "La prochaine fois !"
];

const feedbackNeutre = [
  "Continue !"
];

// ============================================================
// 🎯 CHOIX DU FEEDBACK
// ============================================================
let liste;
switch (resultat) {
  case "1":
    liste = feedbackCorrect;
    break;
  case "0":
    liste = feedbackIncorrect;
    break;
  default:
    liste = feedbackNeutre;
    break;
}

// Sélection aléatoire dans la liste
const feedback = liste[Math.floor(Math.random() * liste.length)];

// ============================================================
// 🧾 MISE À JOUR STORYLINE
// ============================================================
setVar("Ex_Feedback_Motivation", feedback);

}

window.Script30 = function()
{
  // ============================================================
// 🔁 SCRIPT — ALLER AU PROCHAIN EXERCICE ÉCHOUÉ ("Réviser les erreurs")
// ============================================================

// -------- VARIABLES DE CONTEXTE --------
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;
const exCurrent = parseInt(getVar(`${seqKey}_Exo_Current`), 10);
const historique = getVar(`${seqKey}_Win_Lose`) || "";

// -------- SÉCURITÉ --------
if (!seqPos || !historique) {
  console.warn("⚠️ Impossible d'exécuter le script — séquence ou historique manquant.");
  return;
}

// ============================================================
// 🔍 RECHERCHE DU PROCHAIN ÉCHEC ("0")
// ============================================================

// On cherche le prochain "0" APRÈS la position actuelle
const nextFailIndex = historique.indexOf("0", exCurrent);

// ============================================================
// 🎯 MISE À JOUR OU FIN DE LA RÉVISION
// ============================================================

if (nextFailIndex === -1) {
  // Aucun autre exercice échoué trouvé → fin du mode révision
  setVar("S0_Revision_Erreurs", 2);

} else {
  // Prochain exercice échoué trouvé
  const nextExercise = nextFailIndex + 1; // index → position 1-based
  setVar("0_Position_Exercice", nextExercise);
}
}

window.Script31 = function()
{
  // ============================================================
// 🎯 ANIMATION DE JAUGE — Rotation + Oscillation continue + Feedback motivationnel + Indicateur visuel
// ============================================================

// -------- OBJETS STORYLINE --------
const pointer = object('5fZOHpnMbya');
const gauge = object('6nKxLAItMtB');

// -------- PARAMÈTRES --------
const minAngle = 0;
const maxAngle = 180;
const oscillationRange = 10;
const oscillationSpeed = 1.5;

// ============================================================
// 🧮 DETECTION DU RESULTAT + RECUPERATION VARIABLES STORYLINE
// ============================================================
let resultat = getVar("Ex_Success");
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;
const exCurrent = getVar(`${seqKey}_Exo_Current`);

// Si il n'y a pas de résultat direct, on tente de le retrouver dans Sx_Win_Lose
if (resultat === "") {
  const historique = getVar(`${seqKey}_Win_Lose`);
  const charAtIndex = historique.charAt(exCurrent - 1);
  if (charAtIndex === "1" || charAtIndex === "0") {
    resultat = charAtIndex;
  } else {
    console.log(`ℹ️ Aucun résultat valide trouvé dans ${seqKey}_Win_Lose à l’index ${exCurrent - 1}`);
    resultat = "";
  }
}

// ============================================================
// ⚙️ Changement couleur jauge
// ============================================================
if (resultat === "1") {
  gauge.state = "Correct" ;
} else if (resultat === "0") {
  gauge.state = "Incorrect" ;
}

// ============================================================
// ⚙️ CALCULS D’ANGLES
// ============================================================
const baseAngle = resultat * (maxAngle - minAngle) + minAngle;
const angleMin = baseAngle - oscillationRange;
const angleMax = baseAngle + oscillationRange;


const goingUp = resultat === "1";
const targetAngle = goingUp ? angleMax : angleMin;

// ============================================================
// 🧹 ARRÊTE LES ANIMATIONS EXISTANTES
// ============================================================
gsap.killTweensOf(pointer);

// ============================================================
// 🚀 ANIMATION DE L’AIGUILLE
// ============================================================
gsap.to(pointer, {
  rotation: targetAngle,
  duration: 1.2,
  ease: "power2.inOut",
  onComplete: () => {
    gsap.to(pointer, {
      rotation: goingUp ? angleMin : angleMax,
      duration: oscillationSpeed,
      ease: "sine.inOut",
      yoyo: true,
      repeat: -1
    });
  }
});

}

window.Script32 = function()
{
  const Btn_Affichage  = document.querySelector('[data-model-id="6geks01QgvK"]');
const temoin = object('6XIh2Zufqbt');

// (Optionnel mais recommandé) point d’ancrage de la rotation
Btn_Affichage.style.transformOrigin = "50% 50%";

// On lit l’état actuel puis on bascule
const isAffiche = (temoin.state === "Feedback_Affiche");

temoin.state = isAffiche ? "Feedback_Cache" : "Feedback_Affiche";

// Rotation GSAP (durée + easing ajustables)
gsap.to(Btn_Affichage, {
  rotation: isAffiche ? 180 : 0,
  duration: 0.45,
  ease: "power2.inOut",
  overwrite: "auto"
});

}

window.Script33 = function()
{
  // ============================================================
// 💬 FEEDBACK MOTIVATIONNEL — AVEC SUPPORT DU FORMAT "1101nn"
// ============================================================

// -------- VARIABLES DE BASE --------
let resultat = getVar("Ex_Success");
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;
const exCurrent = parseInt(getVar(`${seqKey}_Exo_Current`), 10);

// ============================================================
// 🔍 SI RESULTAT VIDE → CHERCHE DANS S1_Win_Lose ("1101nn")
// ============================================================
if (!resultat || resultat === "") {
  const historique = getVar(`${seqKey}_Win_Lose`) || "";
  const charAtIndex = historique.charAt(exCurrent - 1);

  if (charAtIndex === "1" || charAtIndex === "0") {
    resultat = charAtIndex;
  } else {
    console.log(`ℹ️ Aucun résultat valide trouvé dans ${seqKey}_Win_Lose à l’index ${exCurrent - 1}`);
  }
}

// ============================================================
// 💬 LISTES DE FEEDBACKS
// ============================================================
//const feedbackCorrect = [
//  "Bravo !",
//  "Super !",
//  "Bien joué !",
//  "Excellent !"
//];

//const feedbackIncorrect = [
//  "Pas exactement.",
//  "Oups !",
//  "La prochaine fois !"
//];

const feedbackCorrect = [
  "Bravo, c'est une bonne réponse !",
  "Super, tu es sur la bonne voie !",
  "Bien joué, tu progresses !",
  "Excellent, continue comme ça !"
];

const feedbackIncorrect = [
  "Ce n'est pas tout à fait ça.",
  "Oups, ce n'est pas la bonne réponse.",
  "Tu y arriveras la prochaine fois !",
  "Pas exactement. Encore un effort !"
];


const feedbackNeutre = [
  "Continue !"
];

// ============================================================
// 🎯 CHOIX DU FEEDBACK
// ============================================================
let liste;
switch (resultat) {
  case "1":
    liste = feedbackCorrect;
    break;
  case "0":
    liste = feedbackIncorrect;
    break;
  default:
    liste = feedbackNeutre;
    break;
}

// Sélection aléatoire dans la liste
const feedback = liste[Math.floor(Math.random() * liste.length)];

// ============================================================
// 🧾 MISE À JOUR STORYLINE
// ============================================================
setVar("Ex_Feedback_Motivation", feedback);

}

window.Script34 = function()
{
  // ============================================================
// 🔁 SCRIPT — ALLER AU PROCHAIN EXERCICE ÉCHOUÉ ("Réviser les erreurs")
// ============================================================

// -------- VARIABLES DE CONTEXTE --------
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;
const exCurrent = parseInt(getVar(`${seqKey}_Exo_Current`), 10);
const historique = getVar(`${seqKey}_Win_Lose`) || "";

// -------- SÉCURITÉ --------
if (!seqPos || !historique) {
  console.warn("⚠️ Impossible d'exécuter le script — séquence ou historique manquant.");
  return;
}

// ============================================================
// 🔍 RECHERCHE DU PROCHAIN ÉCHEC ("0")
// ============================================================

// On cherche le prochain "0" APRÈS la position actuelle
const nextFailIndex = historique.indexOf("0", exCurrent);

// ============================================================
// 🎯 MISE À JOUR OU FIN DE LA RÉVISION
// ============================================================

if (nextFailIndex === -1) {
  // Aucun autre exercice échoué trouvé → fin du mode révision
  setVar("S0_Revision_Erreurs", 2);

} else {
  // Prochain exercice échoué trouvé
  const nextExercise = nextFailIndex + 1; // index → position 1-based
  setVar("0_Position_Exercice", nextExercise);
}
}

window.Script35 = function()
{
  // ============================================================
// 🎯 ANIMATION DE JAUGE — Rotation + Oscillation continue + Feedback motivationnel + Indicateur visuel
// ============================================================

// -------- OBJETS STORYLINE --------
const pointer = object('61WVHrM0EGs');
//const gauge = object('5lezhyLYUu5'); Cet objet n'existe pas ?
const gauge = object('6rIRKS6iuFv');


// -------- PARAMÈTRES --------
const minAngle = 0;
const maxAngle = 180;
const oscillationRange = 10;
const oscillationSpeed = 1.5;

// ============================================================
// 🧮 DETECTION DU RESULTAT + RECUPERATION VARIABLES STORYLINE
// ============================================================
let resultat = getVar("Ex_Success");
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;
const exCurrent = getVar(`${seqKey}_Exo_Current`);

// Si il n'y a pas de résultat direct, on tente de le retrouver dans Sx_Win_Lose
if (resultat === "") {
  const historique = getVar(`${seqKey}_Win_Lose`);
  const charAtIndex = historique.charAt(exCurrent - 1);
  if (charAtIndex === "1" || charAtIndex === "0") {
    resultat = charAtIndex;
  } else {
    console.log(`ℹ️ Aucun résultat valide trouvé dans ${seqKey}_Win_Lose à l’index ${exCurrent - 1}`);
    resultat = "";
  }
}

// ============================================================
// ⚙️ Changement couleur jauge
// ============================================================
if (resultat === "1") {
  gauge.state = "Correct" ;
} else if (resultat === "0") {
  gauge.state = "Incorrect" ;
}

// ============================================================
// ⚙️ CALCULS D’ANGLES
// ============================================================
const baseAngle = resultat * (maxAngle - minAngle) + minAngle;
const angleMin = baseAngle - oscillationRange;
const angleMax = baseAngle + oscillationRange;


const goingUp = resultat === "1";
const targetAngle = goingUp ? angleMax : angleMin;

// ============================================================
// 🧹 ARRÊTE LES ANIMATIONS EXISTANTES
// ============================================================
gsap.killTweensOf(pointer);

// ============================================================
// 🚀 ANIMATION DE L’AIGUILLE
// ============================================================
gsap.to(pointer, {
  rotation: targetAngle,
  duration: 1.2,
  ease: "power2.inOut",
  onComplete: () => {
    gsap.to(pointer, {
      rotation: goingUp ? angleMin : angleMax,
      duration: oscillationSpeed,
      ease: "sine.inOut",
      yoyo: true,
      repeat: -1
    });
  }
});

}

window.Script36 = function()
{
  const Btn_Affichage  = document.querySelector('[data-model-id="6RRLU9ixx38"]');
const temoin = object('68ikzB1cq1L');

// (Optionnel mais recommandé) point d’ancrage de la rotation
Btn_Affichage.style.transformOrigin = "50% 50%";

// On lit l’état actuel puis on bascule
const isAffiche = (temoin.state === "Feedback_Affiche");

temoin.state = isAffiche ? "Feedback_Cache" : "Feedback_Affiche";

// Rotation GSAP (durée + easing ajustables)
gsap.to(Btn_Affichage, {
  rotation: isAffiche ? 180 : 0,
  duration: 0.45,
  ease: "power2.inOut",
  overwrite: "auto"
});

}

window.Script37 = function()
{
  // Récupère le résultat
let resultat = getVar("Ex_Success");

// Définit les listes de feedback
const feedbackCorrect = [
  "Bravo !",
  "Super !",
  "Bien joué !",
  "Excellent !"
];

const feedbackIncorrect = [
  "Pas exactement",
  "Oups !",
  "La prochaine fois !"
];

// Choisit la liste en fonction du résultat
let liste = (resultat === "1") ? feedbackCorrect : feedbackIncorrect;

// Sélectionne un élément aléatoire dans la liste
let feedback = liste[Math.floor(Math.random() * liste.length)];

// Met à jour la variable Storyline
setVar("Ex_Feedback_Motivation", feedback);

}

window.Script38 = function()
{
  // ============================================================
// 🎯 ANIMATION DE JAUGE — Rotation + Oscillation continue + Feedback motivationnel + Indicateur visuel
// ============================================================

// -------- OBJETS STORYLINE --------
const pointer = object('5Ux37gXcJcw');
const gauge = object('5enGetq7POY');

// -------- PARAMÈTRES --------
const minAngle = 0;
const maxAngle = 180;
const oscillationRange = 10;
const oscillationSpeed = 1.5;

// ============================================================
// 🧮 DETECTION DU RESULTAT + RECUPERATION VARIABLES STORYLINE
// ============================================================
let resultat = getVar("Ex_Success");
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;
const exCurrent = getVar(`${seqKey}_Exo_Current`);

// Si il n'y a pas de résultat direct, on tente de le retrouver dans Sx_Win_Lose
if (resultat === "") {
  const historique = getVar(`${seqKey}_Win_Lose`);
  const charAtIndex = historique.charAt(exCurrent - 1);
  if (charAtIndex === "1" || charAtIndex === "0") {
    resultat = charAtIndex;
  } else {
    console.log(`ℹ️ Aucun résultat valide trouvé dans ${seqKey}_Win_Lose à l’index ${exCurrent - 1}`);
    resultat = "";
  }
}

// ============================================================
// ⚙️ Changement couleur jauge
// ============================================================
if (resultat === "1") {
  gauge.state = "Correct" ;
} else if (resultat === "0") {
  gauge.state = "Incorrect" ;
}

// ============================================================
// ⚙️ CALCULS D’ANGLES
// ============================================================
const baseAngle = resultat * (maxAngle - minAngle) + minAngle;
const angleMin = baseAngle - oscillationRange;
const angleMax = baseAngle + oscillationRange;


const goingUp = resultat === "1";
const targetAngle = goingUp ? angleMax : angleMin;

// ============================================================
// 🧹 ARRÊTE LES ANIMATIONS EXISTANTES
// ============================================================
gsap.killTweensOf(pointer);

// ============================================================
// 🚀 ANIMATION DE L’AIGUILLE
// ============================================================
gsap.to(pointer, {
  rotation: targetAngle,
  duration: 1.2,
  ease: "power2.inOut",
  onComplete: () => {
    gsap.to(pointer, {
      rotation: goingUp ? angleMin : angleMax,
      duration: oscillationSpeed,
      ease: "sine.inOut",
      yoyo: true,
      repeat: -1
    });
  }
});

}

window.Script39 = function()
{
  // ============================================================
// 🔁 SCRIPT — ALLER AU PROCHAIN EXERCICE ÉCHOUÉ ("Réviser les erreurs")
// ============================================================

// -------- VARIABLES DE CONTEXTE --------
const seqPos = getVar("0_Position_Sequence"); // ex: "1", "2", "3", "4"
const seqKey = `S${seqPos}`;                  // ex: "S1"
const exCurrent = parseInt(getVar(`${seqKey}_Exo_Current`) || 0, 10); // ex: 3
const historique = getVar(`${seqKey}_Win_Lose`) || ""; // ex: "110010"

// -------- SÉCURITÉ --------
if (!seqPos || !historique) {
  console.warn("⚠️ Impossible d'exécuter le script — séquence ou historique manquant.");
  return;
}

// ============================================================
// 🔍 RECHERCHE DU PROCHAIN ÉCHEC ("0")
// ============================================================

// On cherche le prochain "0" APRÈS la position actuelle
const nextFailIndex = historique.indexOf("0", exCurrent);

// ============================================================
// 🎯 MISE À JOUR OU FIN DE LA RÉVISION
// ============================================================

if (nextFailIndex === -1) {
  // Aucun autre exercice échoué trouvé → fin du mode révision
  setVar("S0_Revision_Erreurs", 2);
  console.log("🎉 Tous les exercices échoués ont été revus — fin du mode révision (S0_Revision_Erreurs = 2).");
} else {
  // Prochain exercice échoué trouvé
  const nextExercise = nextFailIndex + 1; // index → position 1-based
  setVar("0_Position_Exercice", nextExercise);
  console.log(`🔁 Révision → Prochain exercice échoué : EX${nextExercise}`);
}

console.log(`(Séquence : ${seqKey}, Historique : "${historique}")`);

}

window.Script40 = function()
{
  // ============================================================
// 🎬 REMPLACEMENT DYNAMIQUE DE VIDÉO (version simplifiée)
// ============================================================
// Remplace directement la vidéo de l'objet Storyline (ID fixe)
// avec le chemin complet contenu dans la variable "Ex_Video".
// ============================================================

// -------- Lecture de la variable --------
const newVideoPath = getVar("Ex_Video"); // ex: "Ressources_Sequences/S1/Videos/S1_EX1.mp4"

// -------- Sécurité --------
if (!newVideoPath || newVideoPath.trim() === "") {
  console.warn("⚠️ Aucune vidéo spécifiée dans Ex_Video — remplacement annulé.");
  return;
}

// -------- Sélection directe de la vidéo --------
const videoElement = document.querySelector('[data-model-id="5pTX8N7gCDH"] video');
if (!videoElement) {
  console.error("❌ Impossible de trouver la vidéo avec data-model-id=5pTX8N7gCDH.");
  return;
}

// -------- Remplacement de la source --------
videoElement.setAttribute("xlink:href", newVideoPath);
videoElement.src = newVideoPath;
videoElement.load();

// -------- Suppression de la vignette (poster) --------
const container = videoElement.closest('[data-model-id="5pTX8N7gCDH"]');
if (container) {
  const poster = container.querySelector("img.video-player-poster");
  if (poster) {
    poster.remove();
    console.log("✅ Vignette (poster) supprimée — la 1ère image de la vidéo sera visible.");
  }
}
}

window.Script41 = function()
{
  // ============================================================
// 🖼️ REMPLACEMENT DYNAMIQUE D’IMAGE (version simplifiée)
// ============================================================
// Remplace directement l’image de l’objet Storyline (ID fixe)
// avec le chemin complet contenu dans la variable "Ex_Image".
// Aucun calcul de dossier ou de chemin n’est effectué.
// ============================================================

// -------- Lecture de la variable --------
const newImagePath = getVar("Ex_Image"); // ex: "Ressources_Sequences/S1/images/EX1.jpg"

// -------- Sécurité --------
if (!newImagePath || newImagePath.trim() === "") {
  console.warn("⚠️ Aucune image spécifiée dans Ex_Image — remplacement annulé.");
  return;
}

// -------- Sélection directe de l’image --------
const imageElement = document.querySelector('[data-model-id="6jUy2ox5l86"] image');
if (!imageElement) {
  console.error("❌ Impossible de trouver l’image avec data-model-id=6jUy2ox5l86.");
  return;
}

// -------- Remplacement du lien --------
imageElement.setAttributeNS("http://www.w3.org/1999/xlink", "xlink:href", newImagePath);

}

window.Script42 = function()
{
  // ============================================================
// 🖼️ REMPLACEMENT DYNAMIQUE D’IMAGE (version simplifiée)
// ============================================================
// Remplace directement l’image de l’objet Storyline (ID fixe)
// avec le chemin complet contenu dans la variable "Ex_Image".
// Aucun calcul de dossier ou de chemin n’est effectué.
// ============================================================

// -------- Lecture de la variable --------
const newImagePath = getVar("Ex_Image"); // ex: "Ressources_Sequences/S1/images/EX1.jpg"

// -------- Sécurité --------
if (!newImagePath || newImagePath.trim() === "") {
  console.warn("⚠️ Aucune image spécifiée dans Ex_Image — remplacement annulé.");
  return;
}

// -------- Sélection directe de l’image --------
const imageElement = document.querySelector('[data-model-id="6c22D92goAT"] image');
if (!imageElement) {
  console.error("❌ Impossible de trouver l’image avec data-model-id=6c22D92goAT.");
  return;
}

// -------- Remplacement du lien --------
imageElement.setAttributeNS("http://www.w3.org/1999/xlink", "xlink:href", newImagePath);

}

window.Script43 = function()
{
  // ============================================================
// ⚙️ BARRE DE PROGRESSION — SYNCHRONISATION AVEC LA SÉQUENCE EN COURS
// ============================================================

// --------- Lecture de la séquence courante ---------
const seqPos = getVar("0_Position_Sequence");   // ex. 1 → S1
const seqKey = `S${seqPos}`;

// --------- Lecture des variables de la séquence correspondante ---------
const Exo_Reached = getVar("S0_Exo_Reached") || 0;
const Exo_Total = getVar("S0_Exo_Total") || 1;

// --------- Calcul du pourcentage ---------
const progress = Math.min(Exo_Reached / Exo_Total, 1); // clamp entre 0 et 1

// --------- Sélectionne l'objet Storyline ---------
const ProgressBar = document.querySelector(`[data-model-id="6f561U28wA4"]`);

if (ProgressBar) {
  // --------- Sélectionne l'élément graphique principal ---------
  const shape = ProgressBar.querySelector("path");

  if (shape) {
    // Si ce n’est pas déjà fait, on garde la largeur d’origine
    if (!shape.dataset.fullWidth) {
      const bbox = shape.getBBox();
      shape.dataset.fullWidth = bbox.width;
    }

    // --------- Calcul de la largeur selon la progression ---------
    const fullWidth = parseFloat(shape.dataset.fullWidth);

    // --------- Application du remplissage via clip-path ---------
    shape.style.clipPath = `inset(0 ${100 - progress * 100}% 0 0 round 0px)`;
  }
}

}

window.Script44 = function()
{
  // ============================================================
// ⚙️ BARRE DE PROGRESSION ANIMÉE (AVEC INITIALISATION INTELLIGENTE)
// ============================================================

// Durée de l’animation en millisecondes (modifiable)
const animationDuration = 800; // 0.8s = fluide, 300 = rapide, 1500 = lente

function updateProgressBarAnimated() {
  // --------- Lecture de la séquence courante ---------
  const seqPos = getVar("0_Position_Sequence");
  const seqKey = `S${seqPos}`;

  // --------- Lecture des variables globales S0 ---------
  const Exo_Reached = getVar("S0_Exo_Reached") || 0;
  const Exo_Total = getVar("S0_Exo_Total") || 1;
  const progress = Math.min(Exo_Reached / Exo_Total, 1);

  // --------- Sélectionne l'objet Storyline ---------
  const ProgressBar = document.querySelector(`[data-model-id="6f561U28wA4"]`);
  if (!ProgressBar) return;

  const shape = ProgressBar.querySelector("path");
  if (!shape) return;

  // --------- Initialisation si nécessaire ---------
  if (!shape.dataset.fullWidth) {
    const bbox = shape.getBBox();
    shape.dataset.fullWidth = bbox.width;
  }

  // --------- Nouvelle logique : position initiale intelligente ---------
  let startProgress;

  if (shape.dataset.currentProgress !== undefined) {
    // On continue à partir de la progression actuelle
    startProgress = parseFloat(shape.dataset.currentProgress) || 0;
  } else if (Exo_Reached >= 1) {
    // Si aucune donnée mais au moins un exercice complété,
    // on démarre au niveau précédent
    startProgress = (Exo_Reached - 1) / Exo_Total;
  } else {
    // Sinon, tout au début
    startProgress = 0;
  }

  const startTime = performance.now();

  // --------- Fonction d'animation fluide ---------
  function animate(time) {
    const elapsed = time - startTime;
    const t = Math.min(elapsed / animationDuration, 1);
    const eased = t < 0.5 ? 2 * t * t : -1 + (4 - 2 * t) * t; // easeInOutQuad

    const currentProgress = startProgress + (progress - startProgress) * eased;
    shape.style.clipPath = `inset(0 ${100 - currentProgress * 100}% 0 0 round 0px)`;
    shape.dataset.currentProgress = currentProgress;

    if (t < 1) requestAnimationFrame(animate);
  }

  requestAnimationFrame(animate);
}

// ============================================================
// ▶️ APPEL DU SCRIPT (exécuté manuellement via trigger JS)
// ============================================================

updateProgressBarAnimated();

}

window.Script45 = function()
{
  // -------- Initialisation --------

// Récupère le numéro ou identifiant d'exercice (ex: "EX2")
const AudioPath = getVar("0_Audio_Lecteur");

// Si un audio était déjà en cours → on le stoppe et on remet au début
if (window.audioUnique) {
  window.audioUnique.pause();
  window.audioUnique.currentTime = 0;
}

// Crée un nouvel objet audio
window.audioUnique = new Audio(AudioPath);

// Lecture
window.audioUnique.play().catch(err => {
  console.log("Erreur lecture Back :", err);
});
}

window.Script46 = function()
{
  // ============================================================
// 🎯 MISE À JOUR DES VARIABLES Sx_Win_Lose SELON Ex_Success (texte)
// ============================================================

// -------- Lecture des variables Storyline --------
const seqPos  = getVar("0_Position_Sequence");
const exPos   = getVar("0_Position_Exercice");
const success = getVar("Ex_Success");

// -------- Construction du nom de la séquence --------
const seqKey     = `S${seqPos}`;
const winLoseVar = `${seqKey}_Win_Lose`;

// -------- Lecture actuelle de la variable Win_Lose --------
let winLose = getVar(winLoseVar) || "";

// -------- S’assure que la longueur correspond au nombre total d’exercices --------
const total = getVar(`0_Menu_${seqKey}_Exo_Total`);

// -------- Conversion en tableau pour modification --------
const chars = winLose.split("");

// -------- Mise à jour du caractère correspondant à l’exercice actuel --------
if (!(chars[exPos - 1] === "1" && success === "0")) {
    chars[exPos - 1] = success === "1" ? "1" : "0";
}
// Si l'exercice est déjà réussi, on garde la réussite.

// -------- Conversion inverse en chaîne --------
winLose = chars.join("");

// -------- Écriture dans Storyline --------
setVar(winLoseVar, winLose);

// ============================================================
// 🔁 SWITCH AUTOMATIQUE DE 0_Feedback_Switch
// ============================================================
let feedbackSwitch = getVar("0_Feedback_Switch");
feedbackSwitch = feedbackSwitch === true || feedbackSwitch === "true" ? false : true;
setVar("0_Feedback_Switch", feedbackSwitch);

}

window.Script47 = function()
{
  // ============================================================
// 🏁 SCRIPT DE FIN D’EXERCICE — MISE À JOUR PROGRESSION & TENTATIVES
// ============================================================

// -------- CONFIGURATION --------
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;

const exCurrent  = parseInt(getVar(`${seqKey}_Exo_Current`), 10);
const exReached  = parseInt(getVar(`${seqKey}_Exo_Reached`), 10);
const tentVar    = `${seqKey}_Exo_Current_Tentatives`;
// ============================================================
// 🧭 MISE À JOUR DE LA PROGRESSION
// ============================================================

// Si on avance (évite de revenir en arrière)
if (exCurrent > exReached) {
  setVar(`${seqKey}_Exo_Reached`, exCurrent);
  setVar("S0_Exo_Reached", exCurrent); 
}

// ============================================================
// 🧮 MARQUAGE DE L’EXERCICE TERMINÉ
// ============================================================

setVar(tentVar, -10);

}

window.Script48 = function()
{
  // ============================================================
// 🧠 SAUVEGARDE AUTOMATIQUE DES DONNÉES UTILISATEUR (GLOBAL)
// ============================================================
//
// 🔹 Ce script est appelé automatiquement après la validation d’un exercice.
// 🔹 Il détecte le type d’exercice et sauvegarde la réponse dans la variable JSON
//    correspondante (ex: S1_UserData)
//
// ============================================================

// ------------------------------------------------------------
// 🔧 Lecture des infos de contexte
// ------------------------------------------------------------
const seqPos = getVar("0_Position_Sequence");           // ex: "1"
const exPos = parseInt(getVar("0_Position_Exercice"), 10);
const seqKey = `S${seqPos}`;
const exType = getVar("Ex_Type");
const success = getVar("Ex_Success");
const tentativesRestantes = parseInt(getVar("Ex_Tentatives"), 10);

// Variable cible (ex: "S1_UserData")
const userDataVar = `${seqKey}_UserData`;

// ------------------------------------------------------------
// 🔧 Lecture du JSON existant
// ------------------------------------------------------------
let data = {};
try {
  const existing = getVar(userDataVar);
  data = existing ? JSON.parse(existing) : {};
} catch (err) {
  console.warn(`⚠️ JSON invalide dans ${userDataVar}, réinitialisation.`, err);
  data = {};
}

// ------------------------------------------------------------
// 🧮 Tentatives initiales (si dispo dans cache global)
// ------------------------------------------------------------
let tentativesInitiales = 0;
try {
  const exData = window.sequenceCache?.[seqKey]?.[`EX${exPos}`];
  tentativesInitiales = exData?.Tentatives || 1;
} catch {
  tentativesInitiales = 1;
}

const tentativesUtilisees = Math.max(0, tentativesInitiales - tentativesRestantes);

// ------------------------------------------------------------
// 🎯 Récupération de la réponse selon le type d’exercice
// ------------------------------------------------------------
let userResponseObj = {};

switch (exType) {
  // 🔹 QCU
  case "QCU": {
    const answerKey = getVar("0_Reponse");
    const answerText = getVar(`0_Choix_${answerKey}`) || "";
    userResponseObj = { [answerKey]: answerText };
    break;
  }

  // 🔹 QCM
  case "QCM": {
    const responseRaw = (getVar("0_Reponse") || "").split("|").filter(Boolean);
    responseRaw.forEach(k => {
      userResponseObj[k] = getVar(`0_Choix_${k}`) || "";
    });
    break;
  }

  // 🔹 True or false
  case "True or false": {
    const answer = (getVar("0_Reponse") || "").toLowerCase();
    userResponseObj = { unique: answer };
    break;
  }

  // 🔹 Complete
  case "Complete": {
    const answer = getVar("0_Ex_Enonce") || "";
    userResponseObj = { unique: answer };
    break;
  }

  // 🔹 Matching
  case "Matching": {
    const reponse = getVar("0_Reponse") || "";
    userResponseObj = { associations: reponse };
    break;
  }

  // 🔹 Flashcard
  case "Flashcard": {
    const answer = getVar("0_Reponse") || "";
    userResponseObj = { unique: answer };
    break;
  }

  // 🔹 Information
  case "Information": {
    userResponseObj = { info: "Aucune interaction" };
    break;
  }

  // 🔹 Production orale - dictée
  case "Production orale - dictée": {
    const raw = getVar("0_Reponse") || "{}";
    try {
      const parsed = JSON.parse(raw);
      userResponseObj = {
        score: parsed.score || 0,
        texte_brut: parsed.texte_brut || "",
        texte_color: parsed.texte_color || ""
      };
    } catch (err) {
      console.warn("⚠️ Erreur de parsing JSON pour Production orale :", err);
      userResponseObj = { erreur: "Format de réponse invalide", raw };
    }
    break;
  }

  // 🔹 Défaut
  default: {
    const raw = getVar("0_Reponse") || "";
    userResponseObj = { inconnu: raw };
    console.warn(`❓ Type d’exercice inconnu : ${exType}`);
    break;
  }
}

// ------------------------------------------------------------
// 💾 Enregistrement dans le JSON
// ------------------------------------------------------------
data[`EX${exPos}`] = {
  Type: exType,
  Reponses_Choisies: userResponseObj,
  Statut: success,
  Tentatives_Utilisees: tentativesUtilisees
};

setVar(userDataVar, JSON.stringify(data));

// ------------------------------------------------------------
// 🧾 Log de contrôle
// ------------------------------------------------------------
console.group(`💾 Données sauvegardées → ${userDataVar}`);
console.log("Exercice :", `EX${exPos}`);
console.log("Type :", exType);
console.log("Réponses :", userResponseObj);
console.log("Statut :", success);
console.log("Tentatives utilisées :", tentativesUtilisees);
console.log("JSON complet :", data);
console.groupEnd();

}

window.Script49 = function()
{
  // ============================================================
// 🎯 VÉRIFICATION DE LA RÉPONSE (QCM) + GESTION DES TENTATIVES
// ============================================================

// --------- Lecture des variables Storyline ---------
const userResponse = (getVar("0_Reponse") || "").trim();
const correctionRaw = (getVar("0_Ex_Correction") || "").trim();
let tentatives = parseInt(getVar("Ex_Tentatives"), 10);
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;
const tentVar = `${seqKey}_Exo_Current_Tentatives`;

let CompteurTentatives    = parseInt(getVar("Ex_Compteur_Tentatives"), 10);
const CompteurTentativesVar = `${seqKey}_Exo_Current_Compteur_Tentatives`;

// --------- Lecture du succès actuel ---------
let success = getVar("Ex_Success") || "";

// ============================================================
// 🧩 COMPARAISON DE LA RÉPONSE
// ============================================================

// Normalisation : on trie les deux listes pour ignorer l’ordre
const correctAnswers = correctionRaw.split("|").filter(Boolean).sort();
const userAnswers = userResponse.split("|").filter(Boolean).sort();

const isCorrect =
  correctAnswers.length === userAnswers.length &&
  correctAnswers.every((val, i) => val === userAnswers[i]);

// ============================================================
// 🧮 LOGIQUE DE RÉUSSITE / TENTATIVES
// ============================================================
if (isCorrect) {
  success = "1";
} else {
  if (tentatives > 0) {
    tentatives -= 1;
  }
  if (tentatives <= 0) {
    success = "0";
  }
}
CompteurTentatives++;

// ============================================================
// 💾 MISE À JOUR DES VARIABLES PERSISTANTES
// ============================================================

// Met à jour les variables locales et de séquence
setVar("Ex_Tentatives", tentatives);
setVar(tentVar, tentatives);

setVar("Ex_Compteur_Tentatives", CompteurTentatives);
setVar(CompteurTentativesVar, CompteurTentatives);

setVar("Ex_Success", success);

// Si l’exercice est terminé (succès ou plus de tentatives), on le marque comme "fini"
if (success === "1" || tentatives <= 0) {
  setVar(tentVar, -10);
}

}

window.Script50 = function()
{
  const Choix_C = object('6cwBNG0EDjg');
const PositionBis = object('5bKjkDa6h8j');


if (getVar("0_Choix_D")===""){
	Choix_C.x = PositionBis.x;
};
}

window.Script51 = function()
{
  // ============================================================
// 🧠 QCM — RESTAURATION DES ÉTATS ET DES CARTES SÉLECTIONNÉES
// ============================================================

// -------- VARIABLES STORYLINE --------
const seqPos = getVar("0_Position_Sequence"); // ex: "1"
const exPos = parseInt(getVar("0_Position_Exercice") || 0, 10);
const seqKey = `S${seqPos}`;
const userDataVar = `${seqKey}_UserData`;

const correctionRaw = (getVar("0_Ex_Correction") || "").trim().toUpperCase(); // ex: "A|C"
const corrections = correctionRaw.split("|").filter(Boolean); // tableau ex: ["A","C"]

let reponseRaw = (getVar("0_Reponse") || "").trim().toUpperCase(); // ex: "A|D"
let reponses = reponseRaw ? reponseRaw.split("|").filter(Boolean) : [];

// -------- SI AUCUNE RÉPONSE LOCALE, ON VA CHERCHER DANS USERDATA --------
if (reponses.length === 0) {
  try {
    const raw = getVar(userDataVar);
    if (raw) {
      const data = JSON.parse(raw);
      const exData = data[`EX${exPos}`];
      if (exData && exData.Type === "QCM") {
        reponses = Object.keys(exData.Reponses_Choisies || {});
        //console.log(`🧩 Réponses restaurées depuis ${userDataVar}:`, reponses);
      }
    }
  } catch (err) {
    console.warn(`⚠️ Lecture UserData échouée pour ${userDataVar}`, err);
  }
}

//console.log(`📥 Réponses finales utilisées :`, reponses);
//console.log(`✅ Corrections attendues :`, corrections);

// ============================================================
// 🎨 OBJETS STORYLINE
// ============================================================
const choix_A_QCM = object('6Lblihe3bjp');
const choix_B_QCM = object('6CkKIYhs8Tg');
const choix_C_QCM = object('6cwBNG0EDjg');
const choix_D_QCM = object('5ZRqJnIHkWf');

const selectedA = object('5iuP0RuzLAA');
const selectedB = object('6TzA87WBs3X');
const selectedC = object('6VKNea0Fbdu');
const selectedD = object('5elNpVLr8fn');

// -------- FONCTION UTILE --------
function setFeedbackState(obj, state) {
  if (!obj) return;
  if (obj.state !== state) obj.state = state;
}

// -------- MAPPING LETTRES → OBJETS --------
const mapping = {
  A: { choix: choix_A_QCM, sel: selectedA },
  B: { choix: choix_B_QCM, sel: selectedB },
  C: { choix: choix_C_QCM, sel: selectedC },
  D: { choix: choix_D_QCM, sel: selectedD }
};

// ============================================================
// 🧠 APPLICATION DES ÉTATS VISUELS
// ============================================================
for (const key in mapping) {
  const { choix, sel } = mapping[key];
  if (!choix || !sel) continue;

  // Bonnes réponses
  if (corrections.includes(key)) {
    setFeedbackState(choix, "Correct Answer");
  }
  // Mauvaises réponses sélectionnées
  else if (reponses.includes(key)) {
    setFeedbackState(choix, "Wrong Answer");
  }
  // Autres (non sélectionnées et non correctes)
  else {
    setFeedbackState(choix, "Normal");
  }

  // Positionnement du cadre de sélection
  if (reponses.includes(key)) {
    sel.x = choix.x;
    sel.y = choix.y;
    sel.state = "Visible";
  } else {
    sel.state = "Caché";
  }
}

// ============================================================
// 🧾 LOG DE CONTRÔLE
// ============================================================
//console.group(`💾 QCM — Restauration EX${exPos}`);
//console.log("Réponses sélectionnées :", reponses);
//console.log("Corrections :", corrections);
//console.groupEnd();

}

window.Script52 = function()
{
  
// ============================================================
// 🎯 QCM — RESTAURATION VISUELLE : SEULES LES RÉPONSES CHOISIES CHANGENT D’ÉTAT
// ============================================================

// -------- VARIABLES STORYLINE --------
const seqPos = getVar("0_Position_Sequence"); // ex: "1"
const exPos = parseInt(getVar("0_Position_Exercice") || 0, 10);
const seqKey = `S${seqPos}`;
const userDataVar = `${seqKey}_UserData`;

// --- Lecture des valeurs locales
const correctionRaw = (getVar("0_Ex_Correction") || "").trim().toUpperCase(); // ex: "A|C"
const userRaw = (getVar("0_Reponse") || "").trim().toUpperCase();             // ex: "A|D"

// --- Conversion en tableau (plus simple pour comparaison)
let corrections = correctionRaw.split("|").filter(Boolean);
let reponses = userRaw.split("|").filter(Boolean);

// -------- SI AUCUNE RÉPONSE LOCALE, ON VA CHERCHER DANS USERDATA --------
if (reponses.length === 0) {
  try {
    const raw = getVar(userDataVar);
    if (raw) {
      const data = JSON.parse(raw);
      const exData = data[`EX${exPos}`];
      if (exData && exData.Type === "QCM") {
        reponses = Object.keys(exData.Reponses_Choisies || {});
      }
    }
  } catch (err) {
    console.warn(`⚠️ Lecture UserData échouée pour ${userDataVar}`, err);
  }
}

// ============================================================
// 🎨 OBJETS STORYLINE
// ============================================================
const choix_A = object('6Lblihe3bjp');
const choix_B = object('6CkKIYhs8Tg');
const choix_C = object('6cwBNG0EDjg');
const choix_D = object('5ZRqJnIHkWf');

// -------- FONCTION UTILE --------
function setFeedbackState(obj, state) {
  if (!obj) return;
  if (obj.state !== state) obj.state = state;
}

// -------- MAPPING LETTRES → OBJETS --------
const mapping = {
  A: choix_A_QCM,
  B: choix_B_QCM,
  C: choix_C_QCM,
  D: choix_D_QCM
};

// ============================================================
// 🧠 APPLICATION DES ÉTATS VISUELS
// ============================================================

// 2️⃣ On applique l’état uniquement aux réponses choisies
reponses.forEach(rep => {
  const obj = mapping[rep];
  if (!obj) return;

  if (corrections.includes(rep)) {
    setFeedbackState(obj, "Correct Answer");
    console.log(`✅ Réponse "${rep}" correcte`);
  } else {
    setFeedbackState(obj, "Wrong Answer");
    console.log(`❌ Réponse "${rep}" incorrecte`);
  }
});

// ============================================================
// 🧾 LOG DE CONTRÔLE
// ============================================================
console.group(`💾 QCM — Affichage des réponses choisies EX${exPos}`);
console.log("Réponses choisies :", reponses);
console.log("Corrections :", corrections);
console.groupEnd();

}

window.Script53 = function()
{
  
// ============================================================
// 🧩 QCM — CONSTRUCTION DE LA VARIABLE "0_Reponse"
// ============================================================

// -------- OBJETS STORYLINE --------
const choix_A_QCM = object('6Lblihe3bjp');
const choix_B_QCM = object('6CkKIYhs8Tg');
const choix_C_QCM = object('6cwBNG0EDjg');
const choix_D_QCM = object('5ZRqJnIHkWf');

// -------- LOG DES ÉTATS ACTUELS --------
console.table({
  A: choix_A_QCM.state,
  B: choix_B_QCM.state,
  C: choix_C_QCM.state,
  D: choix_D_QCM.state
});

// -------- DÉTECTION DES CHOIX SÉLECTIONNÉS --------
const selected = [];

if (choix_A_QCM.state.includes("Selected")) selected.push("A");
if (choix_B_QCM.state.includes("Selected")) selected.push("B");
if (choix_C_QCM.state.includes("Selected")) selected.push("C");
if (choix_D_QCM.state.includes("Selected")) selected.push("D");

// -------- CONSTRUCTION DE LA VARIABLE --------
const userResponse = selected.length > 0 ? selected.join("|") : "None";
setVar("0_Reponse", userResponse);

// -------- LOGS --------
//console.log("🧩 QCM — Réponses sélectionnées :", selected);
//console.log(`💾 Variable 0_Reponse = "${userResponse}"`);

}

window.Script54 = function()
{
  const Choix_C = object('5qEvzx3pLMF');
const PositionBis = object('6nzDEP9uH8A');

if (getVar("0_Choix_D")===""){
	Choix_C.x = PositionBis.x;
};
}

window.Script55 = function()
{
  // ============================================================
// 🧠 QCM — RESTAURATION DES ÉTATS ET DES CARTES SÉLECTIONNÉES
// ============================================================

// -------- VARIABLES STORYLINE --------
const seqPos = getVar("0_Position_Sequence"); // ex: "1"
const exPos = parseInt(getVar("0_Position_Exercice") || 0, 10);
const seqKey = `S${seqPos}`;
const userDataVar = `${seqKey}_UserData`;

const correctionRaw = (getVar("0_Ex_Correction") || "").trim().toUpperCase(); // ex: "A|C"
const corrections = correctionRaw.split("|").filter(Boolean); // tableau ex: ["A","C"]

let reponseRaw = (getVar("0_Reponse") || "").trim().toUpperCase(); // ex: "A|D"
let reponses = reponseRaw ? reponseRaw.split("|").filter(Boolean) : [];

// -------- SI AUCUNE RÉPONSE LOCALE, ON VA CHERCHER DANS USERDATA --------
if (reponses.length === 0) {
  try {
    const raw = getVar(userDataVar);
    if (raw) {
      const data = JSON.parse(raw);
      const exData = data[`EX${exPos}`];
      if (exData && exData.Type === "QCM") {
        reponses = Object.keys(exData.Reponses_Choisies || {});
        //console.log(`🧩 Réponses restaurées depuis ${userDataVar}:`, reponses);
      }
    }
  } catch (err) {
    console.warn(`⚠️ Lecture UserData échouée pour ${userDataVar}`, err);
  }
}

//console.log(`📥 Réponses finales utilisées :`, reponses);
//console.log(`✅ Corrections attendues :`, corrections);

// ============================================================
// 🎨 OBJETS STORYLINE
// ============================================================
const choix_A_QCM = object('6SymANrqiFV');
const choix_B_QCM = object('6FtBgJ8sIHz');
const choix_C_QCM = object('5qEvzx3pLMF');
const choix_D_QCM = object('63blGWApyua');

const selectedA = object('6nsCDiBbiMB');
const selectedB = object('6qCn4UKunZs');
const selectedC = object('6kIbJVNutm6');
const selectedD = object('6UyKllFl9mZ');

// -------- FONCTION UTILE --------
function setFeedbackState(obj, state) {
  if (!obj) return;
  if (obj.state !== state) obj.state = state;
}

// -------- MAPPING LETTRES → OBJETS --------
const mapping = {
  A: { choix: choix_A_QCM, sel: selectedA },
  B: { choix: choix_B_QCM, sel: selectedB },
  C: { choix: choix_C_QCM, sel: selectedC },
  D: { choix: choix_D_QCM, sel: selectedD }
};

// ============================================================
// 🧠 APPLICATION DES ÉTATS VISUELS
// ============================================================
for (const key in mapping) {
  const { choix, sel } = mapping[key];
  if (!choix || !sel) continue;

  // Bonnes réponses
  if (corrections.includes(key)) {
    setFeedbackState(choix, "Correct Answer");
  }
  // Mauvaises réponses sélectionnées
  else if (reponses.includes(key)) {
    setFeedbackState(choix, "Wrong Answer");
  }
  // Autres (non sélectionnées et non correctes)
  else {
    setFeedbackState(choix, "Normal");
  }

  // Positionnement du cadre de sélection
  if (reponses.includes(key)) {
    sel.x = choix.x;
    sel.y = choix.y;
    sel.state = "Visible";
  } else {
    sel.state = "Caché";
  }
}

// ============================================================
// 🧾 LOG DE CONTRÔLE
// ============================================================
console.group(`💾 QCM — Restauration EX${exPos}`);
console.log("Réponses sélectionnées :", reponses);
console.log("Corrections :", corrections);
console.groupEnd();

}

window.Script56 = function()
{
  // ============================================================
// 🎯 QCM — RESTAURATION VISUELLE : SEULES LES RÉPONSES CHOISIES CHANGENT D’ÉTAT
// ============================================================

// -------- VARIABLES STORYLINE --------
const seqPos = getVar("0_Position_Sequence"); // ex: "1"
const exPos = parseInt(getVar("0_Position_Exercice") || 0, 10);
const seqKey = `S${seqPos}`;
const userDataVar = `${seqKey}_UserData`;

// --- Lecture des valeurs locales
const correctionRaw = (getVar("0_Ex_Correction") || "").trim().toUpperCase(); // ex: "A|C"
const userRaw = (getVar("0_Reponse") || "").trim().toUpperCase();             // ex: "A|D"

// --- Conversion en tableau (plus simple pour comparaison)
let corrections = correctionRaw.split("|").filter(Boolean);
let reponses = userRaw.split("|").filter(Boolean);

// -------- SI AUCUNE RÉPONSE LOCALE, ON VA CHERCHER DANS USERDATA --------
if (reponses.length === 0) {
  try {
    const raw = getVar(userDataVar);
    if (raw) {
      const data = JSON.parse(raw);
      const exData = data[`EX${exPos}`];
      if (exData && exData.Type === "QCM") {
        reponses = Object.keys(exData.Reponses_Choisies || {});
      }
    }
  } catch (err) {
    console.warn(`⚠️ Lecture UserData échouée pour ${userDataVar}`, err);
  }
}

// ============================================================
// 🎨 OBJETS STORYLINE
// ============================================================
const choix_A_QCM = object('6SymANrqiFV');
const choix_B_QCM = object('6FtBgJ8sIHz');
const choix_C_QCM = object('5qEvzx3pLMF');
const choix_D_QCM = object('63blGWApyua');

// -------- FONCTION UTILE --------
function setFeedbackState(obj, state) {
  if (!obj) return;
  if (obj.state !== state) obj.state = state;
}

// -------- MAPPING LETTRES → OBJETS --------
const mapping = {
  A: choix_A_QCM,
  B: choix_B_QCM,
  C: choix_C_QCM,
  D: choix_D_QCM
};

// ============================================================
// 🧠 APPLICATION DES ÉTATS VISUELS
// ============================================================

// 2️⃣ On applique l’état uniquement aux réponses choisies
reponses.forEach(rep => {
  const obj = mapping[rep];
  if (!obj) return;

  if (corrections.includes(rep)) {
    setFeedbackState(obj, "Correct Answer");
    console.log(`✅ Réponse "${rep}" correcte`);
  } else {
    setFeedbackState(obj, "Wrong Answer");
    console.log(`❌ Réponse "${rep}" incorrecte`);
  }
});

// ============================================================
// 🧾 LOG DE CONTRÔLE
// ============================================================
console.group(`💾 QCM — Affichage des réponses choisies EX${exPos}`);
console.log("Réponses choisies :", reponses);
console.log("Corrections :", corrections);
console.groupEnd();

}

window.Script57 = function()
{
  // ============================================================
// 🧩 QCM — CONSTRUCTION DE LA VARIABLE "0_Reponse"
// ============================================================

// -------- OBJETS STORYLINE --------
const choix_A_QCM = object('6SymANrqiFV');
const choix_B_QCM = object('6FtBgJ8sIHz');
const choix_C_QCM = object('5qEvzx3pLMF');
const choix_D_QCM = object('63blGWApyua');

// -------- LOG DES ÉTATS ACTUELS --------
console.table({
  A: choix_A_QCM.state,
  B: choix_B_QCM.state,
  C: choix_C_QCM.state,
  D: choix_D_QCM.state
});

// -------- DÉTECTION DES CHOIX SÉLECTIONNÉS --------
const selected = [];

if (choix_A_QCM.state.includes("Selected")) selected.push("A");
if (choix_B_QCM.state.includes("Selected")) selected.push("B");
if (choix_C_QCM.state.includes("Selected")) selected.push("C");
if (choix_D_QCM.state.includes("Selected")) selected.push("D");

// -------- CONSTRUCTION DE LA VARIABLE --------
const userResponse = selected.length > 0 ? selected.join("|") : "None";
setVar("0_Reponse", userResponse);

// -------- LOGS --------
//console.log("🧩 QCM — Réponses sélectionnées :", selected);
//console.log(`💾 Variable 0_Reponse = "${userResponse}"`);

}

window.Script58 = function()
{
  // Récupère les objets Storyline
const carte  = document.querySelector('[data-model-id="6WOyyFcuLyH"]');
const bouton = document.querySelector('[data-model-id="5rCsry3VrNh"]');

// Points d'ancrage
carte.style.transformOrigin = "top left";
bouton.style.transformOrigin = "center";

// Timeline pour synchroniser
const tl = gsap.timeline();

tl.to(carte, {
  scale: 0,
  opacity: 0,
  duration: 0.5,
  ease: "power1.inOut"
}, 0);

// Rotation 90° du bouton en même temps
tl.to(bouton, {
  rotate: 0,          // ou "+=90" si tu veux ajouter 90° à chaque fois
  duration: 0.5,
  ease: "power1.inOut"
}, 0);

}

window.Script59 = function()
{
  // Récupère les objets Storyline
const carte  = document.querySelector('[data-model-id="6WOyyFcuLyH"]');
const bouton = document.querySelector('[data-model-id="5rCsry3VrNh"]');

// Points d'ancrage
carte.style.transformOrigin = "top left";
bouton.style.transformOrigin = "center";

// États initiaux
gsap.set(carte,  { scale: 0, opacity: 0 });
gsap.set(bouton, { rotate: 0 }); // ou 90 si tu veux qu'il démarre déjà tourné

// Timeline pour synchroniser
const tl = gsap.timeline();

tl.to(carte, {
  scale: 1,
  opacity: 1,
  duration: 0.5,
  ease: "power1.inOut"
}, 0);

// Rotation 90° du bouton en même temps
tl.to(bouton, {
  rotate: 45,          // ou "+=90" si tu veux ajouter 90° à chaque fois
  duration: 0.5,
  ease: "power1.inOut"
}, 0);

}

window.Script60 = function()
{
  // ============================================================
// 💬 FEEDBACK MOTIVATIONNEL — AVEC SUPPORT DU FORMAT "1101nn"
// ============================================================

// -------- VARIABLES DE BASE --------
let resultat = getVar("Ex_Success");
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;
const exCurrent = parseInt(getVar(`${seqKey}_Exo_Current`), 10);

// ============================================================
// 🔍 SI RESULTAT VIDE → CHERCHE DANS S1_Win_Lose ("1101nn")
// ============================================================
if (!resultat || resultat === "") {
  const historique = getVar(`${seqKey}_Win_Lose`) || "";
  const charAtIndex = historique.charAt(exCurrent - 1);

  if (charAtIndex === "1" || charAtIndex === "0") {
    resultat = charAtIndex;
  } else {
    console.log(`ℹ️ Aucun résultat valide trouvé dans ${seqKey}_Win_Lose à l’index ${exCurrent - 1}`);
  }
}

// ============================================================
// 💬 LISTES DE FEEDBACKS
// ============================================================
const feedbackCorrect = [
  "Bravo !",
  "Super !",
  "Bien joué !",
  "Excellent !"
];

const feedbackIncorrect = [
  "Pas exactement.",
  "Oups !",
  "La prochaine fois !"
];

const feedbackNeutre = [
  "Continue !"
];

// ============================================================
// 🎯 CHOIX DU FEEDBACK
// ============================================================
let liste;
switch (resultat) {
  case "1":
    liste = feedbackCorrect;
    break;
  case "0":
    liste = feedbackIncorrect;
    break;
  default:
    liste = feedbackNeutre;
    break;
}

// Sélection aléatoire dans la liste
const feedback = liste[Math.floor(Math.random() * liste.length)];

// ============================================================
// 🧾 MISE À JOUR STORYLINE
// ============================================================
setVar("Ex_Feedback_Motivation", feedback);

}

window.Script61 = function()
{
  // ============================================================
// 🔁 SCRIPT — ALLER AU PROCHAIN EXERCICE ÉCHOUÉ ("Réviser les erreurs")
// ============================================================

// -------- VARIABLES DE CONTEXTE --------
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;
const exCurrent = parseInt(getVar(`${seqKey}_Exo_Current`), 10);
const historique = getVar(`${seqKey}_Win_Lose`) || "";

// -------- SÉCURITÉ --------
if (!seqPos || !historique) {
  console.warn("⚠️ Impossible d'exécuter le script — séquence ou historique manquant.");
  return;
}

// ============================================================
// 🔍 RECHERCHE DU PROCHAIN ÉCHEC ("0")
// ============================================================

// On cherche le prochain "0" APRÈS la position actuelle
const nextFailIndex = historique.indexOf("0", exCurrent);

// ============================================================
// 🎯 MISE À JOUR OU FIN DE LA RÉVISION
// ============================================================

if (nextFailIndex === -1) {
  // Aucun autre exercice échoué trouvé → fin du mode révision
  setVar("S0_Revision_Erreurs", 2);

} else {
  // Prochain exercice échoué trouvé
  const nextExercise = nextFailIndex + 1; // index → position 1-based
  setVar("0_Position_Exercice", nextExercise);
}
}

window.Script62 = function()
{
  // ============================================================
// 🎯 ANIMATION DE JAUGE — Rotation + Oscillation continue + Feedback motivationnel + Indicateur visuel
// ============================================================

// -------- OBJETS STORYLINE --------
const pointer = object('5fZOHpnMbya');
const gauge = object('6nKxLAItMtB');

// -------- PARAMÈTRES --------
const minAngle = 0;
const maxAngle = 180;
const oscillationRange = 10;
const oscillationSpeed = 1.5;

// ============================================================
// 🧮 DETECTION DU RESULTAT + RECUPERATION VARIABLES STORYLINE
// ============================================================
let resultat = getVar("Ex_Success");
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;
const exCurrent = getVar(`${seqKey}_Exo_Current`);

// Si il n'y a pas de résultat direct, on tente de le retrouver dans Sx_Win_Lose
if (resultat === "") {
  const historique = getVar(`${seqKey}_Win_Lose`);
  const charAtIndex = historique.charAt(exCurrent - 1);
  if (charAtIndex === "1" || charAtIndex === "0") {
    resultat = charAtIndex;
  } else {
    console.log(`ℹ️ Aucun résultat valide trouvé dans ${seqKey}_Win_Lose à l’index ${exCurrent - 1}`);
    resultat = "";
  }
}

// ============================================================
// ⚙️ Changement couleur jauge
// ============================================================
if (resultat === "1") {
  gauge.state = "Correct" ;
} else if (resultat === "0") {
  gauge.state = "Incorrect" ;
}

// ============================================================
// ⚙️ CALCULS D’ANGLES
// ============================================================
const baseAngle = resultat * (maxAngle - minAngle) + minAngle;
const angleMin = baseAngle - oscillationRange;
const angleMax = baseAngle + oscillationRange;


const goingUp = resultat === "1";
const targetAngle = goingUp ? angleMax : angleMin;

// ============================================================
// 🧹 ARRÊTE LES ANIMATIONS EXISTANTES
// ============================================================
gsap.killTweensOf(pointer);

// ============================================================
// 🚀 ANIMATION DE L’AIGUILLE
// ============================================================
gsap.to(pointer, {
  rotation: targetAngle,
  duration: 1.2,
  ease: "power2.inOut",
  onComplete: () => {
    gsap.to(pointer, {
      rotation: goingUp ? angleMin : angleMax,
      duration: oscillationSpeed,
      ease: "sine.inOut",
      yoyo: true,
      repeat: -1
    });
  }
});

}

window.Script63 = function()
{
  const Btn_Affichage  = document.querySelector('[data-model-id="6geks01QgvK"]');
const temoin = object('6XIh2Zufqbt');

// (Optionnel mais recommandé) point d’ancrage de la rotation
Btn_Affichage.style.transformOrigin = "50% 50%";

// On lit l’état actuel puis on bascule
const isAffiche = (temoin.state === "Feedback_Affiche");

temoin.state = isAffiche ? "Feedback_Cache" : "Feedback_Affiche";

// Rotation GSAP (durée + easing ajustables)
gsap.to(Btn_Affichage, {
  rotation: isAffiche ? 180 : 0,
  duration: 0.45,
  ease: "power2.inOut",
  overwrite: "auto"
});

}

window.Script64 = function()
{
  // ============================================================
// 💬 FEEDBACK MOTIVATIONNEL — AVEC SUPPORT DU FORMAT "1101nn"
// ============================================================

// -------- VARIABLES DE BASE --------
let resultat = getVar("Ex_Success");
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;
const exCurrent = parseInt(getVar(`${seqKey}_Exo_Current`), 10);

// ============================================================
// 🔍 SI RESULTAT VIDE → CHERCHE DANS S1_Win_Lose ("1101nn")
// ============================================================
if (!resultat || resultat === "") {
  const historique = getVar(`${seqKey}_Win_Lose`) || "";
  const charAtIndex = historique.charAt(exCurrent - 1);

  if (charAtIndex === "1" || charAtIndex === "0") {
    resultat = charAtIndex;
  } else {
    console.log(`ℹ️ Aucun résultat valide trouvé dans ${seqKey}_Win_Lose à l’index ${exCurrent - 1}`);
  }
}

// ============================================================
// 💬 LISTES DE FEEDBACKS
// ============================================================
//const feedbackCorrect = [
//  "Bravo !",
//  "Super !",
//  "Bien joué !",
//  "Excellent !"
//];

//const feedbackIncorrect = [
//  "Pas exactement.",
//  "Oups !",
//  "La prochaine fois !"
//];

const feedbackCorrect = [
  "Bravo, c'est une bonne réponse !",
  "Super, tu es sur la bonne voie !",
  "Bien joué, tu progresses !",
  "Excellent, continue comme ça !"
];

const feedbackIncorrect = [
  "Ce n'est pas tout à fait ça.",
  "Oups, ce n'est pas la bonne réponse.",
  "Tu y arriveras la prochaine fois !",
  "Pas exactement. Encore un effort !"
];


const feedbackNeutre = [
  "Continue !"
];

// ============================================================
// 🎯 CHOIX DU FEEDBACK
// ============================================================
let liste;
switch (resultat) {
  case "1":
    liste = feedbackCorrect;
    break;
  case "0":
    liste = feedbackIncorrect;
    break;
  default:
    liste = feedbackNeutre;
    break;
}

// Sélection aléatoire dans la liste
const feedback = liste[Math.floor(Math.random() * liste.length)];

// ============================================================
// 🧾 MISE À JOUR STORYLINE
// ============================================================
setVar("Ex_Feedback_Motivation", feedback);

}

window.Script65 = function()
{
  // ============================================================
// 🔁 SCRIPT — ALLER AU PROCHAIN EXERCICE ÉCHOUÉ ("Réviser les erreurs")
// ============================================================

// -------- VARIABLES DE CONTEXTE --------
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;
const exCurrent = parseInt(getVar(`${seqKey}_Exo_Current`), 10);
const historique = getVar(`${seqKey}_Win_Lose`) || "";

// -------- SÉCURITÉ --------
if (!seqPos || !historique) {
  console.warn("⚠️ Impossible d'exécuter le script — séquence ou historique manquant.");
  return;
}

// ============================================================
// 🔍 RECHERCHE DU PROCHAIN ÉCHEC ("0")
// ============================================================

// On cherche le prochain "0" APRÈS la position actuelle
const nextFailIndex = historique.indexOf("0", exCurrent);

// ============================================================
// 🎯 MISE À JOUR OU FIN DE LA RÉVISION
// ============================================================

if (nextFailIndex === -1) {
  // Aucun autre exercice échoué trouvé → fin du mode révision
  setVar("S0_Revision_Erreurs", 2);

} else {
  // Prochain exercice échoué trouvé
  const nextExercise = nextFailIndex + 1; // index → position 1-based
  setVar("0_Position_Exercice", nextExercise);
}
}

window.Script66 = function()
{
  // ============================================================
// 🎯 ANIMATION DE JAUGE — Rotation + Oscillation continue + Feedback motivationnel + Indicateur visuel
// ============================================================

// -------- OBJETS STORYLINE --------
const pointer = object('61WVHrM0EGs');
//const gauge = object('5lezhyLYUu5'); Cet objet n'existe pas ?
const gauge = object('6rIRKS6iuFv');


// -------- PARAMÈTRES --------
const minAngle = 0;
const maxAngle = 180;
const oscillationRange = 10;
const oscillationSpeed = 1.5;

// ============================================================
// 🧮 DETECTION DU RESULTAT + RECUPERATION VARIABLES STORYLINE
// ============================================================
let resultat = getVar("Ex_Success");
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;
const exCurrent = getVar(`${seqKey}_Exo_Current`);

// Si il n'y a pas de résultat direct, on tente de le retrouver dans Sx_Win_Lose
if (resultat === "") {
  const historique = getVar(`${seqKey}_Win_Lose`);
  const charAtIndex = historique.charAt(exCurrent - 1);
  if (charAtIndex === "1" || charAtIndex === "0") {
    resultat = charAtIndex;
  } else {
    console.log(`ℹ️ Aucun résultat valide trouvé dans ${seqKey}_Win_Lose à l’index ${exCurrent - 1}`);
    resultat = "";
  }
}

// ============================================================
// ⚙️ Changement couleur jauge
// ============================================================
if (resultat === "1") {
  gauge.state = "Correct" ;
} else if (resultat === "0") {
  gauge.state = "Incorrect" ;
}

// ============================================================
// ⚙️ CALCULS D’ANGLES
// ============================================================
const baseAngle = resultat * (maxAngle - minAngle) + minAngle;
const angleMin = baseAngle - oscillationRange;
const angleMax = baseAngle + oscillationRange;


const goingUp = resultat === "1";
const targetAngle = goingUp ? angleMax : angleMin;

// ============================================================
// 🧹 ARRÊTE LES ANIMATIONS EXISTANTES
// ============================================================
gsap.killTweensOf(pointer);

// ============================================================
// 🚀 ANIMATION DE L’AIGUILLE
// ============================================================
gsap.to(pointer, {
  rotation: targetAngle,
  duration: 1.2,
  ease: "power2.inOut",
  onComplete: () => {
    gsap.to(pointer, {
      rotation: goingUp ? angleMin : angleMax,
      duration: oscillationSpeed,
      ease: "sine.inOut",
      yoyo: true,
      repeat: -1
    });
  }
});

}

window.Script67 = function()
{
  const Btn_Affichage  = document.querySelector('[data-model-id="6RRLU9ixx38"]');
const temoin = object('68ikzB1cq1L');

// (Optionnel mais recommandé) point d’ancrage de la rotation
Btn_Affichage.style.transformOrigin = "50% 50%";

// On lit l’état actuel puis on bascule
const isAffiche = (temoin.state === "Feedback_Affiche");

temoin.state = isAffiche ? "Feedback_Cache" : "Feedback_Affiche";

// Rotation GSAP (durée + easing ajustables)
gsap.to(Btn_Affichage, {
  rotation: isAffiche ? 180 : 0,
  duration: 0.45,
  ease: "power2.inOut",
  overwrite: "auto"
});

}

window.Script68 = function()
{
  // Récupère le résultat
let resultat = getVar("Ex_Success");

// Définit les listes de feedback
const feedbackCorrect = [
  "Bravo !",
  "Super !",
  "Bien joué !",
  "Excellent !"
];

const feedbackIncorrect = [
  "Pas exactement",
  "Oups !",
  "La prochaine fois !"
];

// Choisit la liste en fonction du résultat
let liste = (resultat === "1") ? feedbackCorrect : feedbackIncorrect;

// Sélectionne un élément aléatoire dans la liste
let feedback = liste[Math.floor(Math.random() * liste.length)];

// Met à jour la variable Storyline
setVar("Ex_Feedback_Motivation", feedback);

}

window.Script69 = function()
{
  // ============================================================
// 🎯 ANIMATION DE JAUGE — Rotation + Oscillation continue + Feedback motivationnel + Indicateur visuel
// ============================================================

// -------- OBJETS STORYLINE --------
const pointer = object('5Ux37gXcJcw');
const gauge = object('5enGetq7POY');

// -------- PARAMÈTRES --------
const minAngle = 0;
const maxAngle = 180;
const oscillationRange = 10;
const oscillationSpeed = 1.5;

// ============================================================
// 🧮 DETECTION DU RESULTAT + RECUPERATION VARIABLES STORYLINE
// ============================================================
let resultat = getVar("Ex_Success");
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;
const exCurrent = getVar(`${seqKey}_Exo_Current`);

// Si il n'y a pas de résultat direct, on tente de le retrouver dans Sx_Win_Lose
if (resultat === "") {
  const historique = getVar(`${seqKey}_Win_Lose`);
  const charAtIndex = historique.charAt(exCurrent - 1);
  if (charAtIndex === "1" || charAtIndex === "0") {
    resultat = charAtIndex;
  } else {
    console.log(`ℹ️ Aucun résultat valide trouvé dans ${seqKey}_Win_Lose à l’index ${exCurrent - 1}`);
    resultat = "";
  }
}

// ============================================================
// ⚙️ Changement couleur jauge
// ============================================================
if (resultat === "1") {
  gauge.state = "Correct" ;
} else if (resultat === "0") {
  gauge.state = "Incorrect" ;
}

// ============================================================
// ⚙️ CALCULS D’ANGLES
// ============================================================
const baseAngle = resultat * (maxAngle - minAngle) + minAngle;
const angleMin = baseAngle - oscillationRange;
const angleMax = baseAngle + oscillationRange;


const goingUp = resultat === "1";
const targetAngle = goingUp ? angleMax : angleMin;

// ============================================================
// 🧹 ARRÊTE LES ANIMATIONS EXISTANTES
// ============================================================
gsap.killTweensOf(pointer);

// ============================================================
// 🚀 ANIMATION DE L’AIGUILLE
// ============================================================
gsap.to(pointer, {
  rotation: targetAngle,
  duration: 1.2,
  ease: "power2.inOut",
  onComplete: () => {
    gsap.to(pointer, {
      rotation: goingUp ? angleMin : angleMax,
      duration: oscillationSpeed,
      ease: "sine.inOut",
      yoyo: true,
      repeat: -1
    });
  }
});

}

window.Script70 = function()
{
  // ============================================================
// 🔁 SCRIPT — ALLER AU PROCHAIN EXERCICE ÉCHOUÉ ("Réviser les erreurs")
// ============================================================

// -------- VARIABLES DE CONTEXTE --------
const seqPos = getVar("0_Position_Sequence"); // ex: "1", "2", "3", "4"
const seqKey = `S${seqPos}`;                  // ex: "S1"
const exCurrent = parseInt(getVar(`${seqKey}_Exo_Current`) || 0, 10); // ex: 3
const historique = getVar(`${seqKey}_Win_Lose`) || ""; // ex: "110010"

// -------- SÉCURITÉ --------
if (!seqPos || !historique) {
  console.warn("⚠️ Impossible d'exécuter le script — séquence ou historique manquant.");
  return;
}

// ============================================================
// 🔍 RECHERCHE DU PROCHAIN ÉCHEC ("0")
// ============================================================

// On cherche le prochain "0" APRÈS la position actuelle
const nextFailIndex = historique.indexOf("0", exCurrent);

// ============================================================
// 🎯 MISE À JOUR OU FIN DE LA RÉVISION
// ============================================================

if (nextFailIndex === -1) {
  // Aucun autre exercice échoué trouvé → fin du mode révision
  setVar("S0_Revision_Erreurs", 2);
  console.log("🎉 Tous les exercices échoués ont été revus — fin du mode révision (S0_Revision_Erreurs = 2).");
} else {
  // Prochain exercice échoué trouvé
  const nextExercise = nextFailIndex + 1; // index → position 1-based
  setVar("0_Position_Exercice", nextExercise);
  console.log(`🔁 Révision → Prochain exercice échoué : EX${nextExercise}`);
}

console.log(`(Séquence : ${seqKey}, Historique : "${historique}")`);

}

window.Script71 = function()
{
  // ============================================================
// 🎬 REMPLACEMENT DYNAMIQUE DE VIDÉO (version simplifiée)
// ============================================================
// Remplace directement la vidéo de l'objet Storyline (ID fixe)
// avec le chemin complet contenu dans la variable "Ex_Video".
// ============================================================

// -------- Lecture de la variable --------
const newVideoPath = getVar("Ex_Video"); // ex: "Ressources_Sequences/S1/Videos/S1_EX1.mp4"

// -------- Sécurité --------
if (!newVideoPath || newVideoPath.trim() === "") {
  console.warn("⚠️ Aucune vidéo spécifiée dans Ex_Video — remplacement annulé.");
  return;
}

// -------- Sélection directe de la vidéo --------
const videoElement = document.querySelector('[data-model-id="5pTX8N7gCDH"] video');
if (!videoElement) {
  console.error("❌ Impossible de trouver la vidéo avec data-model-id=5pTX8N7gCDH.");
  return;
}

// -------- Remplacement de la source --------
videoElement.setAttribute("xlink:href", newVideoPath);
videoElement.src = newVideoPath;
videoElement.load();

// -------- Suppression de la vignette (poster) --------
const container = videoElement.closest('[data-model-id="5pTX8N7gCDH"]');
if (container) {
  const poster = container.querySelector("img.video-player-poster");
  if (poster) {
    poster.remove();
    console.log("✅ Vignette (poster) supprimée — la 1ère image de la vidéo sera visible.");
  }
}
}

window.Script72 = function()
{
  // ============================================================
// 🖼️ REMPLACEMENT DYNAMIQUE D’IMAGE (version simplifiée)
// ============================================================
// Remplace directement l’image de l’objet Storyline (ID fixe)
// avec le chemin complet contenu dans la variable "Ex_Image".
// Aucun calcul de dossier ou de chemin n’est effectué.
// ============================================================

// -------- Lecture de la variable --------
const newImagePath = getVar("Ex_Image"); // ex: "Ressources_Sequences/S1/images/EX1.jpg"

// -------- Sécurité --------
if (!newImagePath || newImagePath.trim() === "") {
  console.warn("⚠️ Aucune image spécifiée dans Ex_Image — remplacement annulé.");
  return;
}

// -------- Sélection directe de l’image --------
const imageElement = document.querySelector('[data-model-id="6jUy2ox5l86"] image');
if (!imageElement) {
  console.error("❌ Impossible de trouver l’image avec data-model-id=6jUy2ox5l86.");
  return;
}

// -------- Remplacement du lien --------
imageElement.setAttributeNS("http://www.w3.org/1999/xlink", "xlink:href", newImagePath);

}

window.Script73 = function()
{
  // ============================================================
// 🖼️ REMPLACEMENT DYNAMIQUE D’IMAGE (version simplifiée)
// ============================================================
// Remplace directement l’image de l’objet Storyline (ID fixe)
// avec le chemin complet contenu dans la variable "Ex_Image".
// Aucun calcul de dossier ou de chemin n’est effectué.
// ============================================================

// -------- Lecture de la variable --------
const newImagePath = getVar("Ex_Image"); // ex: "Ressources_Sequences/S1/images/EX1.jpg"

// -------- Sécurité --------
if (!newImagePath || newImagePath.trim() === "") {
  console.warn("⚠️ Aucune image spécifiée dans Ex_Image — remplacement annulé.");
  return;
}

// -------- Sélection directe de l’image --------
const imageElement = document.querySelector('[data-model-id="6c22D92goAT"] image');
if (!imageElement) {
  console.error("❌ Impossible de trouver l’image avec data-model-id=6c22D92goAT.");
  return;
}

// -------- Remplacement du lien --------
imageElement.setAttributeNS("http://www.w3.org/1999/xlink", "xlink:href", newImagePath);

}

window.Script74 = function()
{
  // ============================================================
// ⚙️ BARRE DE PROGRESSION — SYNCHRONISATION AVEC LA SÉQUENCE EN COURS
// ============================================================

// --------- Lecture de la séquence courante ---------
const seqPos = getVar("0_Position_Sequence");   // ex. 1 → S1
const seqKey = `S${seqPos}`;

// --------- Lecture des variables de la séquence correspondante ---------
const Exo_Reached = getVar("S0_Exo_Reached") || 0;
const Exo_Total = getVar("S0_Exo_Total") || 1;

// --------- Calcul du pourcentage ---------
const progress = Math.min(Exo_Reached / Exo_Total, 1); // clamp entre 0 et 1

// --------- Sélectionne l'objet Storyline ---------
const ProgressBar = document.querySelector(`[data-model-id="6f561U28wA4"]`);

if (ProgressBar) {
  // --------- Sélectionne l'élément graphique principal ---------
  const shape = ProgressBar.querySelector("path");

  if (shape) {
    // Si ce n’est pas déjà fait, on garde la largeur d’origine
    if (!shape.dataset.fullWidth) {
      const bbox = shape.getBBox();
      shape.dataset.fullWidth = bbox.width;
    }

    // --------- Calcul de la largeur selon la progression ---------
    const fullWidth = parseFloat(shape.dataset.fullWidth);

    // --------- Application du remplissage via clip-path ---------
    shape.style.clipPath = `inset(0 ${100 - progress * 100}% 0 0 round 0px)`;
  }
}

}

window.Script75 = function()
{
  // ============================================================
// ⚙️ BARRE DE PROGRESSION ANIMÉE (AVEC INITIALISATION INTELLIGENTE)
// ============================================================

// Durée de l’animation en millisecondes (modifiable)
const animationDuration = 800; // 0.8s = fluide, 300 = rapide, 1500 = lente

function updateProgressBarAnimated() {
  // --------- Lecture de la séquence courante ---------
  const seqPos = getVar("0_Position_Sequence");
  const seqKey = `S${seqPos}`;

  // --------- Lecture des variables globales S0 ---------
  const Exo_Reached = getVar("S0_Exo_Reached") || 0;
  const Exo_Total = getVar("S0_Exo_Total") || 1;
  const progress = Math.min(Exo_Reached / Exo_Total, 1);

  // --------- Sélectionne l'objet Storyline ---------
  const ProgressBar = document.querySelector(`[data-model-id="6f561U28wA4"]`);
  if (!ProgressBar) return;

  const shape = ProgressBar.querySelector("path");
  if (!shape) return;

  // --------- Initialisation si nécessaire ---------
  if (!shape.dataset.fullWidth) {
    const bbox = shape.getBBox();
    shape.dataset.fullWidth = bbox.width;
  }

  // --------- Nouvelle logique : position initiale intelligente ---------
  let startProgress;

  if (shape.dataset.currentProgress !== undefined) {
    // On continue à partir de la progression actuelle
    startProgress = parseFloat(shape.dataset.currentProgress) || 0;
  } else if (Exo_Reached >= 1) {
    // Si aucune donnée mais au moins un exercice complété,
    // on démarre au niveau précédent
    startProgress = (Exo_Reached - 1) / Exo_Total;
  } else {
    // Sinon, tout au début
    startProgress = 0;
  }

  const startTime = performance.now();

  // --------- Fonction d'animation fluide ---------
  function animate(time) {
    const elapsed = time - startTime;
    const t = Math.min(elapsed / animationDuration, 1);
    const eased = t < 0.5 ? 2 * t * t : -1 + (4 - 2 * t) * t; // easeInOutQuad

    const currentProgress = startProgress + (progress - startProgress) * eased;
    shape.style.clipPath = `inset(0 ${100 - currentProgress * 100}% 0 0 round 0px)`;
    shape.dataset.currentProgress = currentProgress;

    if (t < 1) requestAnimationFrame(animate);
  }

  requestAnimationFrame(animate);
}

// ============================================================
// ▶️ APPEL DU SCRIPT (exécuté manuellement via trigger JS)
// ============================================================

updateProgressBarAnimated();

}

window.Script76 = function()
{
  // -------- Initialisation --------

// Récupère le numéro ou identifiant d'exercice (ex: "EX2")
const AudioPath = getVar("0_Audio_Lecteur");

// Si un audio était déjà en cours → on le stoppe et on remet au début
if (window.audioUnique) {
  window.audioUnique.pause();
  window.audioUnique.currentTime = 0;
}

// Crée un nouvel objet audio
window.audioUnique = new Audio(AudioPath);

// Lecture
window.audioUnique.play().catch(err => {
  console.log("Erreur lecture Back :", err);
});
}

window.Script77 = function()
{
  // ============================================================
// 🎯 MISE À JOUR DES VARIABLES Sx_Win_Lose SELON Ex_Success (texte)
// ============================================================

// -------- Lecture des variables Storyline --------
const seqPos  = getVar("0_Position_Sequence");
const exPos   = getVar("0_Position_Exercice");
const success = getVar("Ex_Success");

// -------- Construction du nom de la séquence --------
const seqKey     = `S${seqPos}`;
const winLoseVar = `${seqKey}_Win_Lose`;

// -------- Lecture actuelle de la variable Win_Lose --------
let winLose = getVar(winLoseVar) || "";

// -------- S’assure que la longueur correspond au nombre total d’exercices --------
const total = getVar(`0_Menu_${seqKey}_Exo_Total`);

// -------- Conversion en tableau pour modification --------
const chars = winLose.split("");

// -------- Mise à jour du caractère correspondant à l’exercice actuel --------
if (!(chars[exPos - 1] === "1" && success === "0")) {
    chars[exPos - 1] = success === "1" ? "1" : "0";
}
// Si l'exercice est déjà réussi, on garde la réussite.

// -------- Conversion inverse en chaîne --------
winLose = chars.join("");

// -------- Écriture dans Storyline --------
setVar(winLoseVar, winLose);

// ============================================================
// 🔁 SWITCH AUTOMATIQUE DE 0_Feedback_Switch
// ============================================================
let feedbackSwitch = getVar("0_Feedback_Switch");
feedbackSwitch = feedbackSwitch === true || feedbackSwitch === "true" ? false : true;
setVar("0_Feedback_Switch", feedbackSwitch);

}

window.Script78 = function()
{
  // ============================================================
// 🏁 SCRIPT DE FIN D’EXERCICE — MISE À JOUR PROGRESSION & TENTATIVES
// ============================================================

// -------- CONFIGURATION --------
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;

const exCurrent  = parseInt(getVar(`${seqKey}_Exo_Current`), 10);
const exReached  = parseInt(getVar(`${seqKey}_Exo_Reached`), 10);
const tentVar    = `${seqKey}_Exo_Current_Tentatives`;
// ============================================================
// 🧭 MISE À JOUR DE LA PROGRESSION
// ============================================================

// Si on avance (évite de revenir en arrière)
if (exCurrent > exReached) {
  setVar(`${seqKey}_Exo_Reached`, exCurrent);
  setVar("S0_Exo_Reached", exCurrent); 
}

// ============================================================
// 🧮 MARQUAGE DE L’EXERCICE TERMINÉ
// ============================================================

setVar(tentVar, -10);

}

window.Script79 = function()
{
  // ============================================================
// 🧠 SAUVEGARDE AUTOMATIQUE DES DONNÉES UTILISATEUR (GLOBAL)
// ============================================================
//
// 🔹 Ce script est appelé automatiquement après la validation d’un exercice.
// 🔹 Il détecte le type d’exercice et sauvegarde la réponse dans la variable JSON
//    correspondante (ex: S1_UserData)
//
// ============================================================

// ------------------------------------------------------------
// 🔧 Lecture des infos de contexte
// ------------------------------------------------------------
const seqPos = getVar("0_Position_Sequence");           // ex: "1"
const exPos = parseInt(getVar("0_Position_Exercice"), 10);
const seqKey = `S${seqPos}`;
const exType = getVar("Ex_Type");
const success = getVar("Ex_Success");
const tentativesRestantes = parseInt(getVar("Ex_Tentatives"), 10);

// Variable cible (ex: "S1_UserData")
const userDataVar = `${seqKey}_UserData`;

// ------------------------------------------------------------
// 🔧 Lecture du JSON existant
// ------------------------------------------------------------
let data = {};
try {
  const existing = getVar(userDataVar);
  data = existing ? JSON.parse(existing) : {};
} catch (err) {
  console.warn(`⚠️ JSON invalide dans ${userDataVar}, réinitialisation.`, err);
  data = {};
}

// ------------------------------------------------------------
// 🧮 Tentatives initiales (si dispo dans cache global)
// ------------------------------------------------------------
let tentativesInitiales = 0;
try {
  const exData = window.sequenceCache?.[seqKey]?.[`EX${exPos}`];
  tentativesInitiales = exData?.Tentatives || 1;
} catch {
  tentativesInitiales = 1;
}

const tentativesUtilisees = Math.max(0, tentativesInitiales - tentativesRestantes);

// ------------------------------------------------------------
// 🎯 Récupération de la réponse selon le type d’exercice
// ------------------------------------------------------------
let userResponseObj = {};

switch (exType) {
  // 🔹 QCU
  case "QCU": {
    const answerKey = getVar("0_Reponse");
    const answerText = getVar(`0_Choix_${answerKey}`) || "";
    userResponseObj = { [answerKey]: answerText };
    break;
  }

  // 🔹 QCM
  case "QCM": {
    const responseRaw = (getVar("0_Reponse") || "").split("|").filter(Boolean);
    responseRaw.forEach(k => {
      userResponseObj[k] = getVar(`0_Choix_${k}`) || "";
    });
    break;
  }

  // 🔹 True or false
  case "True or false": {
    const answer = (getVar("0_Reponse") || "").toLowerCase();
    userResponseObj = { unique: answer };
    break;
  }

  // 🔹 Complete
  case "Complete": {
    const answer = getVar("0_Ex_Enonce") || "";
    userResponseObj = { unique: answer };
    break;
  }

  // 🔹 Matching
  case "Matching": {
    const reponse = getVar("0_Reponse") || "";
    userResponseObj = { associations: reponse };
    break;
  }

  // 🔹 Flashcard
  case "Flashcard": {
    const answer = getVar("0_Reponse") || "";
    userResponseObj = { unique: answer };
    break;
  }

  // 🔹 Information
  case "Information": {
    userResponseObj = { info: "Aucune interaction" };
    break;
  }

  // 🔹 Production orale - dictée
  case "Production orale - dictée": {
    const raw = getVar("0_Reponse") || "{}";
    try {
      const parsed = JSON.parse(raw);
      userResponseObj = {
        score: parsed.score || 0,
        texte_brut: parsed.texte_brut || "",
        texte_color: parsed.texte_color || ""
      };
    } catch (err) {
      console.warn("⚠️ Erreur de parsing JSON pour Production orale :", err);
      userResponseObj = { erreur: "Format de réponse invalide", raw };
    }
    break;
  }

  // 🔹 Défaut
  default: {
    const raw = getVar("0_Reponse") || "";
    userResponseObj = { inconnu: raw };
    console.warn(`❓ Type d’exercice inconnu : ${exType}`);
    break;
  }
}

// ------------------------------------------------------------
// 💾 Enregistrement dans le JSON
// ------------------------------------------------------------
data[`EX${exPos}`] = {
  Type: exType,
  Reponses_Choisies: userResponseObj,
  Statut: success,
  Tentatives_Utilisees: tentativesUtilisees
};

setVar(userDataVar, JSON.stringify(data));

// ------------------------------------------------------------
// 🧾 Log de contrôle
// ------------------------------------------------------------
console.group(`💾 Données sauvegardées → ${userDataVar}`);
console.log("Exercice :", `EX${exPos}`);
console.log("Type :", exType);
console.log("Réponses :", userResponseObj);
console.log("Statut :", success);
console.log("Tentatives utilisées :", tentativesUtilisees);
console.log("JSON complet :", data);
console.groupEnd();

}

window.Script80 = function()
{
  // ============================================================
// 🎯 VÉRIFICATION DE LA RÉPONSE (QCM) + GESTION DES TENTATIVES
// ============================================================

// --------- Lecture des variables Storyline ---------
const userResponse = (getVar("0_Reponse") || "").trim();
const correctionRaw = (getVar("0_Ex_Correction") || "").trim();
let tentatives = parseInt(getVar("Ex_Tentatives"), 10);
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;
const tentVar = `${seqKey}_Exo_Current_Tentatives`;

let CompteurTentatives    = parseInt(getVar("Ex_Compteur_Tentatives"), 10);
const CompteurTentativesVar = `${seqKey}_Exo_Current_Compteur_Tentatives`;

// --------- Lecture du succès actuel ---------
let success = getVar("Ex_Success") || "";

// ============================================================
// 🧩 COMPARAISON DE LA RÉPONSE
// ============================================================

// Normalisation : on trie les deux listes pour ignorer l’ordre
const correctAnswers = correctionRaw.split("|").filter(Boolean).sort();
const userAnswers = userResponse.split("|").filter(Boolean).sort();

const isCorrect =
  correctAnswers.length === userAnswers.length &&
  correctAnswers.every((val, i) => val === userAnswers[i]);

// ============================================================
// 🧮 LOGIQUE DE RÉUSSITE / TENTATIVES
// ============================================================
if (isCorrect) {
  success = "1";
} else {
  if (tentatives > 0) {
    tentatives -= 1;
  }
  if (tentatives <= 0) {
    success = "0";
  }
}
CompteurTentatives++;

// ============================================================
// 💾 MISE À JOUR DES VARIABLES PERSISTANTES
// ============================================================

// Met à jour les variables locales et de séquence
setVar("Ex_Tentatives", tentatives);
setVar(tentVar, tentatives);

setVar("Ex_Compteur_Tentatives", CompteurTentatives);
setVar(CompteurTentativesVar, CompteurTentatives);

setVar("Ex_Success", success);

// Si l’exercice est terminé (succès ou plus de tentatives), on le marque comme "fini"
if (success === "1" || tentatives <= 0) {
  setVar(tentVar, -10);
}

}

window.Script81 = function()
{
  const Choix_C = object('5rhPMKKSgZE');
const PositionBis = object('6bRMReQ7lWk');

if (getVar("0_Choix_D")===""){
	Choix_C.x = PositionBis.x;
};
}

window.Script82 = function()
{
  // ============================================================
// 🧠 QCM — RESTAURATION DES ÉTATS ET DES CARTES SÉLECTIONNÉES
// ============================================================

// -------- VARIABLES STORYLINE --------
const seqPos = getVar("0_Position_Sequence"); // ex: "1"
const exPos = parseInt(getVar("0_Position_Exercice") || 0, 10);
const seqKey = `S${seqPos}`;
const userDataVar = `${seqKey}_UserData`;

const correctionRaw = (getVar("0_Ex_Correction") || "").trim().toUpperCase(); // ex: "A|C"
const corrections = correctionRaw.split("|").filter(Boolean); // tableau ex: ["A","C"]

let reponseRaw = (getVar("0_Reponse") || "").trim().toUpperCase(); // ex: "A|D"
let reponses = reponseRaw ? reponseRaw.split("|").filter(Boolean) : [];

// -------- SI AUCUNE RÉPONSE LOCALE, ON VA CHERCHER DANS USERDATA --------
if (reponses.length === 0) {
  try {
    const raw = getVar(userDataVar);
    if (raw) {
      const data = JSON.parse(raw);
      const exData = data[`EX${exPos}`];
      if (exData && exData.Type === "QCM") {
        reponses = Object.keys(exData.Reponses_Choisies || {});
        //console.log(`🧩 Réponses restaurées depuis ${userDataVar}:`, reponses);
      }
    }
  } catch (err) {
    console.warn(`⚠️ Lecture UserData échouée pour ${userDataVar}`, err);
  }
}

//console.log(`📥 Réponses finales utilisées :`, reponses);
//console.log(`✅ Corrections attendues :`, corrections);

// ============================================================
// 🎨 OBJETS STORYLINE
// ============================================================
const choix_A_QCM = object('6Lr6srW0WaN');
const choix_B_QCM = object('5lGNaPD6TuI');
const choix_C_QCM = object('5rhPMKKSgZE');
const choix_D_QCM = object('6Hn42dGwrJh');

const selectedA = object('6gD9MPJSOIK');
const selectedB = object('6B7c3H6lR9l');
const selectedC = object('6IO3ElV3Q2n');
const selectedD = object('6IZxlXmuE70');

// -------- FONCTION UTILE --------
function setFeedbackState(obj, state) {
  if (!obj) return;
  if (obj.state !== state) obj.state = state;
}

// -------- MAPPING LETTRES → OBJETS --------
const mapping = {
  A: { choix: choix_A_QCM, sel: selectedA },
  B: { choix: choix_B_QCM, sel: selectedB },
  C: { choix: choix_C_QCM, sel: selectedC },
  D: { choix: choix_D_QCM, sel: selectedD }
};

// ============================================================
// 🧠 APPLICATION DES ÉTATS VISUELS
// ============================================================
for (const key in mapping) {
  const { choix, sel } = mapping[key];
  if (!choix || !sel) continue;

  // Bonnes réponses
  if (corrections.includes(key)) {
    setFeedbackState(choix, "Correct Answer");
  }
  // Mauvaises réponses sélectionnées
  else if (reponses.includes(key)) {
    setFeedbackState(choix, "Wrong Answer");
  }
  // Autres (non sélectionnées et non correctes)
  else {
    setFeedbackState(choix, "Normal");
  }

  // Positionnement du cadre de sélection
  if (reponses.includes(key)) {
    sel.x = choix.x;
    sel.y = choix.y;
    sel.state = "Visible";
  } else {
    sel.state = "Caché";
  }
}

// ============================================================
// 🧾 LOG DE CONTRÔLE
// ============================================================
//console.group(`💾 QCM — Restauration EX${exPos}`);
//console.log("Réponses sélectionnées :", reponses);
//console.log("Corrections :", corrections);
//console.groupEnd();

}

window.Script83 = function()
{
  // ============================================================
// 🎯 QCM — RESTAURATION VISUELLE : SEULES LES RÉPONSES CHOISIES CHANGENT D’ÉTAT
// ============================================================

// -------- VARIABLES STORYLINE --------
const seqPos = getVar("0_Position_Sequence"); // ex: "1"
const exPos = parseInt(getVar("0_Position_Exercice") || 0, 10);
const seqKey = `S${seqPos}`;
const userDataVar = `${seqKey}_UserData`;

// --- Lecture des valeurs locales
const correctionRaw = (getVar("0_Ex_Correction") || "").trim().toUpperCase(); // ex: "A|C"
const userRaw = (getVar("0_Reponse") || "").trim().toUpperCase();             // ex: "A|D"

// --- Conversion en tableau (plus simple pour comparaison)
let corrections = correctionRaw.split("|").filter(Boolean);
let reponses = userRaw.split("|").filter(Boolean);

// -------- SI AUCUNE RÉPONSE LOCALE, ON VA CHERCHER DANS USERDATA --------
if (reponses.length === 0) {
  try {
    const raw = getVar(userDataVar);
    if (raw) {
      const data = JSON.parse(raw);
      const exData = data[`EX${exPos}`];
      if (exData && exData.Type === "QCM") {
        reponses = Object.keys(exData.Reponses_Choisies || {});
      }
    }
  } catch (err) {
    console.warn(`⚠️ Lecture UserData échouée pour ${userDataVar}`, err);
  }
}

// ============================================================
// 🎨 OBJETS STORYLINE
// ============================================================
const choix_A_QCM = object('6Lr6srW0WaN');
const choix_B_QCM = object('5lGNaPD6TuI');
const choix_C_QCM = object('5rhPMKKSgZE');
const choix_D_QCM = object('6Hn42dGwrJh');

// -------- FONCTION UTILE --------
function setFeedbackState(obj, state) {
  if (!obj) return;
  if (obj.state !== state) obj.state = state;
}

// -------- MAPPING LETTRES → OBJETS --------
const mapping = {
  A: choix_A_QCM,
  B: choix_B_QCM,
  C: choix_C_QCM,
  D: choix_D_QCM
};

// ============================================================
// 🧠 APPLICATION DES ÉTATS VISUELS
// ============================================================

// 2️⃣ On applique l’état uniquement aux réponses choisies
reponses.forEach(rep => {
  const obj = mapping[rep];
  if (!obj) return;

  if (corrections.includes(rep)) {
    setFeedbackState(obj, "Correct Answer");
    console.log(`✅ Réponse "${rep}" correcte`);
  } else {
    setFeedbackState(obj, "Wrong Answer");
    console.log(`❌ Réponse "${rep}" incorrecte`);
  }
});

// ============================================================
// 🧾 LOG DE CONTRÔLE
// ============================================================
console.group(`💾 QCM — Affichage des réponses choisies EX${exPos}`);
console.log("Réponses choisies :", reponses);
console.log("Corrections :", corrections);
console.groupEnd();

}

window.Script84 = function()
{
  // ============================================================
// 🧩 QCM — CONSTRUCTION DE LA VARIABLE "0_Reponse"
// ============================================================

// -------- OBJETS STORYLINE --------
const choix_A_QCM = object('6Lr6srW0WaN');
const choix_B_QCM = object('5lGNaPD6TuI');
const choix_C_QCM = object('5rhPMKKSgZE');
const choix_D_QCM = object('6Hn42dGwrJh');

// -------- LOG DES ÉTATS ACTUELS --------
console.table({
  A: choix_A_QCM.state,
  B: choix_B_QCM.state,
  C: choix_C_QCM.state,
  D: choix_D_QCM.state
});

// -------- DÉTECTION DES CHOIX SÉLECTIONNÉS --------
const selected = [];

if (choix_A_QCM.state.includes("Selected")) selected.push("A");
if (choix_B_QCM.state.includes("Selected")) selected.push("B");
if (choix_C_QCM.state.includes("Selected")) selected.push("C");
if (choix_D_QCM.state.includes("Selected")) selected.push("D");

// -------- CONSTRUCTION DE LA VARIABLE --------
const userResponse = selected.length > 0 ? selected.join("|") : "None";
setVar("0_Reponse", userResponse);

// -------- LOGS --------
//console.log("🧩 QCM — Réponses sélectionnées :", selected);
//console.log(`💾 Variable 0_Reponse = "${userResponse}"`);

}

window.Script85 = function()
{
  const Choix_C = object('6HpR9SaAtJ5');
const PositionBis = object('5cnyBRNZCqj');

if (getVar("0_Choix_D")===""){
	Choix_C.x = PositionBis.x;
};
}

window.Script86 = function()
{
  // ============================================================
// 🧠 QCM — RESTAURATION DES ÉTATS ET DES CARTES SÉLECTIONNÉES
// ============================================================

// -------- VARIABLES STORYLINE --------
const seqPos = getVar("0_Position_Sequence"); // ex: "1"
const exPos = parseInt(getVar("0_Position_Exercice") || 0, 10);
const seqKey = `S${seqPos}`;
const userDataVar = `${seqKey}_UserData`;

const correctionRaw = (getVar("0_Ex_Correction") || "").trim().toUpperCase(); // ex: "A|C"
const corrections = correctionRaw.split("|").filter(Boolean); // tableau ex: ["A","C"]

let reponseRaw = (getVar("0_Reponse") || "").trim().toUpperCase(); // ex: "A|D"
let reponses = reponseRaw ? reponseRaw.split("|").filter(Boolean) : [];

// -------- SI AUCUNE RÉPONSE LOCALE, ON VA CHERCHER DANS USERDATA --------
if (reponses.length === 0) {
  try {
    const raw = getVar(userDataVar);
    if (raw) {
      const data = JSON.parse(raw);
      const exData = data[`EX${exPos}`];
      if (exData && exData.Type === "QCM") {
        reponses = Object.keys(exData.Reponses_Choisies || {});
        //console.log(`🧩 Réponses restaurées depuis ${userDataVar}:`, reponses);
      }
    }
  } catch (err) {
    console.warn(`⚠️ Lecture UserData échouée pour ${userDataVar}`, err);
  }
}

//console.log(`📥 Réponses finales utilisées :`, reponses);
//console.log(`✅ Corrections attendues :`, corrections);

// ============================================================
// 🎨 OBJETS STORYLINE
// ============================================================
const choix_A_QCM = object('6dojUYf7S7N');
const choix_B_QCM = object('6m00GA1y06s');
const choix_C_QCM = object('6HpR9SaAtJ5');
const choix_D_QCM = object('5eG1KkR4Mzy');

const selectedA = object('64YheE9yTpx');
const selectedB = object('6AktA2UAxRe');
const selectedC = object('6cnpgY7X4Uk');
const selectedD = object('6V8ZdCijyuc');

// -------- FONCTION UTILE --------
function setFeedbackState(obj, state) {
  if (!obj) return;
  if (obj.state !== state) obj.state = state;
}

// -------- MAPPING LETTRES → OBJETS --------
const mapping = {
  A: { choix: choix_A_QCM, sel: selectedA },
  B: { choix: choix_B_QCM, sel: selectedB },
  C: { choix: choix_C_QCM, sel: selectedC },
  D: { choix: choix_D_QCM, sel: selectedD }
};

// ============================================================
// 🧠 APPLICATION DES ÉTATS VISUELS
// ============================================================
for (const key in mapping) {
  const { choix, sel } = mapping[key];
  if (!choix || !sel) continue;

  // Bonnes réponses
  if (corrections.includes(key)) {
    setFeedbackState(choix, "Correct Answer");
  }
  // Mauvaises réponses sélectionnées
  else if (reponses.includes(key)) {
    setFeedbackState(choix, "Wrong Answer");
  }
  // Autres (non sélectionnées et non correctes)
  else {
    setFeedbackState(choix, "Normal");
  }

  // Positionnement du cadre de sélection
  if (reponses.includes(key)) {
    sel.x = choix.x;
    sel.y = choix.y;
    sel.state = "Visible";
  } else {
    sel.state = "Caché";
  }
}

// ============================================================
// 🧾 LOG DE CONTRÔLE
// ============================================================
console.group(`💾 QCM — Restauration EX${exPos}`);
console.log("Réponses sélectionnées :", reponses);
console.log("Corrections :", corrections);
console.groupEnd();

}

window.Script87 = function()
{
  // ============================================================
// 🎯 QCM — RESTAURATION VISUELLE : SEULES LES RÉPONSES CHOISIES CHANGENT D’ÉTAT
// ============================================================

// -------- VARIABLES STORYLINE --------
const seqPos = getVar("0_Position_Sequence"); // ex: "1"
const exPos = parseInt(getVar("0_Position_Exercice") || 0, 10);
const seqKey = `S${seqPos}`;
const userDataVar = `${seqKey}_UserData`;

// --- Lecture des valeurs locales
const correctionRaw = (getVar("0_Ex_Correction") || "").trim().toUpperCase(); // ex: "A|C"
const userRaw = (getVar("0_Reponse") || "").trim().toUpperCase();             // ex: "A|D"

// --- Conversion en tableau (plus simple pour comparaison)
let corrections = correctionRaw.split("|").filter(Boolean);
let reponses = userRaw.split("|").filter(Boolean);

// -------- SI AUCUNE RÉPONSE LOCALE, ON VA CHERCHER DANS USERDATA --------
if (reponses.length === 0) {
  try {
    const raw = getVar(userDataVar);
    if (raw) {
      const data = JSON.parse(raw);
      const exData = data[`EX${exPos}`];
      if (exData && exData.Type === "QCM") {
        reponses = Object.keys(exData.Reponses_Choisies || {});
      }
    }
  } catch (err) {
    console.warn(`⚠️ Lecture UserData échouée pour ${userDataVar}`, err);
  }
}

// ============================================================
// 🎨 OBJETS STORYLINE
// ============================================================
const choix_A_QCM = object('6dojUYf7S7N');
const choix_B_QCM = object('6m00GA1y06s');
const choix_C_QCM = object('6HpR9SaAtJ5');
const choix_D_QCM = object('5eG1KkR4Mzy');

// -------- FONCTION UTILE --------
function setFeedbackState(obj, state) {
  if (!obj) return;
  if (obj.state !== state) obj.state = state;
}

// -------- MAPPING LETTRES → OBJETS --------
const mapping = {
  A: choix_A_QCM,
  B: choix_B_QCM,
  C: choix_C_QCM,
  D: choix_D_QCM
};

// ============================================================
// 🧠 APPLICATION DES ÉTATS VISUELS
// ============================================================

// 2️⃣ On applique l’état uniquement aux réponses choisies
reponses.forEach(rep => {
  const obj = mapping[rep];
  if (!obj) return;

  if (corrections.includes(rep)) {
    setFeedbackState(obj, "Correct Answer");
    console.log(`✅ Réponse "${rep}" correcte`);
  } else {
    setFeedbackState(obj, "Wrong Answer");
    console.log(`❌ Réponse "${rep}" incorrecte`);
  }
});

// ============================================================
// 🧾 LOG DE CONTRÔLE
// ============================================================
console.group(`💾 QCM — Affichage des réponses choisies EX${exPos}`);
console.log("Réponses choisies :", reponses);
console.log("Corrections :", corrections);
console.groupEnd();

}

window.Script88 = function()
{
  // ============================================================
// 🧩 QCM — CONSTRUCTION DE LA VARIABLE "0_Reponse"
// ============================================================

// -------- OBJETS STORYLINE --------
const choix_A_QCM = object('6dojUYf7S7N');
const choix_B_QCM = object('6m00GA1y06s');
const choix_C_QCM = object('6HpR9SaAtJ5');
const choix_D_QCM = object('5eG1KkR4Mzy');

// -------- LOG DES ÉTATS ACTUELS --------
console.table({
  A: choix_A_QCM.state,
  B: choix_B_QCM.state,
  C: choix_C_QCM.state,
  D: choix_D_QCM.state
});

// -------- DÉTECTION DES CHOIX SÉLECTIONNÉS --------
const selected = [];

if (choix_A_QCM.state.includes("Selected")) selected.push("A");
if (choix_B_QCM.state.includes("Selected")) selected.push("B");
if (choix_C_QCM.state.includes("Selected")) selected.push("C");
if (choix_D_QCM.state.includes("Selected")) selected.push("D");

// -------- CONSTRUCTION DE LA VARIABLE --------
const userResponse = selected.length > 0 ? selected.join("|") : "None";
setVar("0_Reponse", userResponse);

// -------- LOGS --------
//console.log("🧩 QCM — Réponses sélectionnées :", selected);
//console.log(`💾 Variable 0_Reponse = "${userResponse}"`);

}

window.Script89 = function()
{
  // Récupère les objets Storyline
const carte  = document.querySelector('[data-model-id="6WOyyFcuLyH"]');
const bouton = document.querySelector('[data-model-id="5rCsry3VrNh"]');

// Points d'ancrage
carte.style.transformOrigin = "top left";
bouton.style.transformOrigin = "center";

// Timeline pour synchroniser
const tl = gsap.timeline();

tl.to(carte, {
  scale: 0,
  opacity: 0,
  duration: 0.5,
  ease: "power1.inOut"
}, 0);

// Rotation 90° du bouton en même temps
tl.to(bouton, {
  rotate: 0,          // ou "+=90" si tu veux ajouter 90° à chaque fois
  duration: 0.5,
  ease: "power1.inOut"
}, 0);

}

window.Script90 = function()
{
  // Récupère les objets Storyline
const carte  = document.querySelector('[data-model-id="6WOyyFcuLyH"]');
const bouton = document.querySelector('[data-model-id="5rCsry3VrNh"]');

// Points d'ancrage
carte.style.transformOrigin = "top left";
bouton.style.transformOrigin = "center";

// États initiaux
gsap.set(carte,  { scale: 0, opacity: 0 });
gsap.set(bouton, { rotate: 0 }); // ou 90 si tu veux qu'il démarre déjà tourné

// Timeline pour synchroniser
const tl = gsap.timeline();

tl.to(carte, {
  scale: 1,
  opacity: 1,
  duration: 0.5,
  ease: "power1.inOut"
}, 0);

// Rotation 90° du bouton en même temps
tl.to(bouton, {
  rotate: 45,          // ou "+=90" si tu veux ajouter 90° à chaque fois
  duration: 0.5,
  ease: "power1.inOut"
}, 0);

}

window.Script91 = function()
{
  // ============================================================
// 💬 FEEDBACK MOTIVATIONNEL — AVEC SUPPORT DU FORMAT "1101nn"
// ============================================================

// -------- VARIABLES DE BASE --------
let resultat = getVar("Ex_Success");
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;
const exCurrent = parseInt(getVar(`${seqKey}_Exo_Current`), 10);

// ============================================================
// 🔍 SI RESULTAT VIDE → CHERCHE DANS S1_Win_Lose ("1101nn")
// ============================================================
if (!resultat || resultat === "") {
  const historique = getVar(`${seqKey}_Win_Lose`) || "";
  const charAtIndex = historique.charAt(exCurrent - 1);

  if (charAtIndex === "1" || charAtIndex === "0") {
    resultat = charAtIndex;
  } else {
    console.log(`ℹ️ Aucun résultat valide trouvé dans ${seqKey}_Win_Lose à l’index ${exCurrent - 1}`);
  }
}

// ============================================================
// 💬 LISTES DE FEEDBACKS
// ============================================================
const feedbackCorrect = [
  "Bravo !",
  "Super !",
  "Bien joué !",
  "Excellent !"
];

const feedbackIncorrect = [
  "Pas exactement.",
  "Oups !",
  "La prochaine fois !"
];

const feedbackNeutre = [
  "Continue !"
];

// ============================================================
// 🎯 CHOIX DU FEEDBACK
// ============================================================
let liste;
switch (resultat) {
  case "1":
    liste = feedbackCorrect;
    break;
  case "0":
    liste = feedbackIncorrect;
    break;
  default:
    liste = feedbackNeutre;
    break;
}

// Sélection aléatoire dans la liste
const feedback = liste[Math.floor(Math.random() * liste.length)];

// ============================================================
// 🧾 MISE À JOUR STORYLINE
// ============================================================
setVar("Ex_Feedback_Motivation", feedback);

}

window.Script92 = function()
{
  // ============================================================
// 🔁 SCRIPT — ALLER AU PROCHAIN EXERCICE ÉCHOUÉ ("Réviser les erreurs")
// ============================================================

// -------- VARIABLES DE CONTEXTE --------
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;
const exCurrent = parseInt(getVar(`${seqKey}_Exo_Current`), 10);
const historique = getVar(`${seqKey}_Win_Lose`) || "";

// -------- SÉCURITÉ --------
if (!seqPos || !historique) {
  console.warn("⚠️ Impossible d'exécuter le script — séquence ou historique manquant.");
  return;
}

// ============================================================
// 🔍 RECHERCHE DU PROCHAIN ÉCHEC ("0")
// ============================================================

// On cherche le prochain "0" APRÈS la position actuelle
const nextFailIndex = historique.indexOf("0", exCurrent);

// ============================================================
// 🎯 MISE À JOUR OU FIN DE LA RÉVISION
// ============================================================

if (nextFailIndex === -1) {
  // Aucun autre exercice échoué trouvé → fin du mode révision
  setVar("S0_Revision_Erreurs", 2);

} else {
  // Prochain exercice échoué trouvé
  const nextExercise = nextFailIndex + 1; // index → position 1-based
  setVar("0_Position_Exercice", nextExercise);
}
}

window.Script93 = function()
{
  // ============================================================
// 🎯 ANIMATION DE JAUGE — Rotation + Oscillation continue + Feedback motivationnel + Indicateur visuel
// ============================================================

// -------- OBJETS STORYLINE --------
const pointer = object('5fZOHpnMbya');
const gauge = object('6nKxLAItMtB');

// -------- PARAMÈTRES --------
const minAngle = 0;
const maxAngle = 180;
const oscillationRange = 10;
const oscillationSpeed = 1.5;

// ============================================================
// 🧮 DETECTION DU RESULTAT + RECUPERATION VARIABLES STORYLINE
// ============================================================
let resultat = getVar("Ex_Success");
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;
const exCurrent = getVar(`${seqKey}_Exo_Current`);

// Si il n'y a pas de résultat direct, on tente de le retrouver dans Sx_Win_Lose
if (resultat === "") {
  const historique = getVar(`${seqKey}_Win_Lose`);
  const charAtIndex = historique.charAt(exCurrent - 1);
  if (charAtIndex === "1" || charAtIndex === "0") {
    resultat = charAtIndex;
  } else {
    console.log(`ℹ️ Aucun résultat valide trouvé dans ${seqKey}_Win_Lose à l’index ${exCurrent - 1}`);
    resultat = "";
  }
}

// ============================================================
// ⚙️ Changement couleur jauge
// ============================================================
if (resultat === "1") {
  gauge.state = "Correct" ;
} else if (resultat === "0") {
  gauge.state = "Incorrect" ;
}

// ============================================================
// ⚙️ CALCULS D’ANGLES
// ============================================================
const baseAngle = resultat * (maxAngle - minAngle) + minAngle;
const angleMin = baseAngle - oscillationRange;
const angleMax = baseAngle + oscillationRange;


const goingUp = resultat === "1";
const targetAngle = goingUp ? angleMax : angleMin;

// ============================================================
// 🧹 ARRÊTE LES ANIMATIONS EXISTANTES
// ============================================================
gsap.killTweensOf(pointer);

// ============================================================
// 🚀 ANIMATION DE L’AIGUILLE
// ============================================================
gsap.to(pointer, {
  rotation: targetAngle,
  duration: 1.2,
  ease: "power2.inOut",
  onComplete: () => {
    gsap.to(pointer, {
      rotation: goingUp ? angleMin : angleMax,
      duration: oscillationSpeed,
      ease: "sine.inOut",
      yoyo: true,
      repeat: -1
    });
  }
});

}

window.Script94 = function()
{
  const Btn_Affichage  = document.querySelector('[data-model-id="6geks01QgvK"]');
const temoin = object('6XIh2Zufqbt');

// (Optionnel mais recommandé) point d’ancrage de la rotation
Btn_Affichage.style.transformOrigin = "50% 50%";

// On lit l’état actuel puis on bascule
const isAffiche = (temoin.state === "Feedback_Affiche");

temoin.state = isAffiche ? "Feedback_Cache" : "Feedback_Affiche";

// Rotation GSAP (durée + easing ajustables)
gsap.to(Btn_Affichage, {
  rotation: isAffiche ? 180 : 0,
  duration: 0.45,
  ease: "power2.inOut",
  overwrite: "auto"
});

}

window.Script95 = function()
{
  // ============================================================
// 💬 FEEDBACK MOTIVATIONNEL — AVEC SUPPORT DU FORMAT "1101nn"
// ============================================================

// -------- VARIABLES DE BASE --------
let resultat = getVar("Ex_Success");
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;
const exCurrent = parseInt(getVar(`${seqKey}_Exo_Current`), 10);

// ============================================================
// 🔍 SI RESULTAT VIDE → CHERCHE DANS S1_Win_Lose ("1101nn")
// ============================================================
if (!resultat || resultat === "") {
  const historique = getVar(`${seqKey}_Win_Lose`) || "";
  const charAtIndex = historique.charAt(exCurrent - 1);

  if (charAtIndex === "1" || charAtIndex === "0") {
    resultat = charAtIndex;
  } else {
    console.log(`ℹ️ Aucun résultat valide trouvé dans ${seqKey}_Win_Lose à l’index ${exCurrent - 1}`);
  }
}

// ============================================================
// 💬 LISTES DE FEEDBACKS
// ============================================================
//const feedbackCorrect = [
//  "Bravo !",
//  "Super !",
//  "Bien joué !",
//  "Excellent !"
//];

//const feedbackIncorrect = [
//  "Pas exactement.",
//  "Oups !",
//  "La prochaine fois !"
//];

const feedbackCorrect = [
  "Bravo, c'est une bonne réponse !",
  "Super, tu es sur la bonne voie !",
  "Bien joué, tu progresses !",
  "Excellent, continue comme ça !"
];

const feedbackIncorrect = [
  "Ce n'est pas tout à fait ça.",
  "Oups, ce n'est pas la bonne réponse.",
  "Tu y arriveras la prochaine fois !",
  "Pas exactement. Encore un effort !"
];


const feedbackNeutre = [
  "Continue !"
];

// ============================================================
// 🎯 CHOIX DU FEEDBACK
// ============================================================
let liste;
switch (resultat) {
  case "1":
    liste = feedbackCorrect;
    break;
  case "0":
    liste = feedbackIncorrect;
    break;
  default:
    liste = feedbackNeutre;
    break;
}

// Sélection aléatoire dans la liste
const feedback = liste[Math.floor(Math.random() * liste.length)];

// ============================================================
// 🧾 MISE À JOUR STORYLINE
// ============================================================
setVar("Ex_Feedback_Motivation", feedback);

}

window.Script96 = function()
{
  // ============================================================
// 🔁 SCRIPT — ALLER AU PROCHAIN EXERCICE ÉCHOUÉ ("Réviser les erreurs")
// ============================================================

// -------- VARIABLES DE CONTEXTE --------
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;
const exCurrent = parseInt(getVar(`${seqKey}_Exo_Current`), 10);
const historique = getVar(`${seqKey}_Win_Lose`) || "";

// -------- SÉCURITÉ --------
if (!seqPos || !historique) {
  console.warn("⚠️ Impossible d'exécuter le script — séquence ou historique manquant.");
  return;
}

// ============================================================
// 🔍 RECHERCHE DU PROCHAIN ÉCHEC ("0")
// ============================================================

// On cherche le prochain "0" APRÈS la position actuelle
const nextFailIndex = historique.indexOf("0", exCurrent);

// ============================================================
// 🎯 MISE À JOUR OU FIN DE LA RÉVISION
// ============================================================

if (nextFailIndex === -1) {
  // Aucun autre exercice échoué trouvé → fin du mode révision
  setVar("S0_Revision_Erreurs", 2);

} else {
  // Prochain exercice échoué trouvé
  const nextExercise = nextFailIndex + 1; // index → position 1-based
  setVar("0_Position_Exercice", nextExercise);
}
}

window.Script97 = function()
{
  // ============================================================
// 🎯 ANIMATION DE JAUGE — Rotation + Oscillation continue + Feedback motivationnel + Indicateur visuel
// ============================================================

// -------- OBJETS STORYLINE --------
const pointer = object('61WVHrM0EGs');
//const gauge = object('5lezhyLYUu5'); Cet objet n'existe pas ?
const gauge = object('6rIRKS6iuFv');


// -------- PARAMÈTRES --------
const minAngle = 0;
const maxAngle = 180;
const oscillationRange = 10;
const oscillationSpeed = 1.5;

// ============================================================
// 🧮 DETECTION DU RESULTAT + RECUPERATION VARIABLES STORYLINE
// ============================================================
let resultat = getVar("Ex_Success");
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;
const exCurrent = getVar(`${seqKey}_Exo_Current`);

// Si il n'y a pas de résultat direct, on tente de le retrouver dans Sx_Win_Lose
if (resultat === "") {
  const historique = getVar(`${seqKey}_Win_Lose`);
  const charAtIndex = historique.charAt(exCurrent - 1);
  if (charAtIndex === "1" || charAtIndex === "0") {
    resultat = charAtIndex;
  } else {
    console.log(`ℹ️ Aucun résultat valide trouvé dans ${seqKey}_Win_Lose à l’index ${exCurrent - 1}`);
    resultat = "";
  }
}

// ============================================================
// ⚙️ Changement couleur jauge
// ============================================================
if (resultat === "1") {
  gauge.state = "Correct" ;
} else if (resultat === "0") {
  gauge.state = "Incorrect" ;
}

// ============================================================
// ⚙️ CALCULS D’ANGLES
// ============================================================
const baseAngle = resultat * (maxAngle - minAngle) + minAngle;
const angleMin = baseAngle - oscillationRange;
const angleMax = baseAngle + oscillationRange;


const goingUp = resultat === "1";
const targetAngle = goingUp ? angleMax : angleMin;

// ============================================================
// 🧹 ARRÊTE LES ANIMATIONS EXISTANTES
// ============================================================
gsap.killTweensOf(pointer);

// ============================================================
// 🚀 ANIMATION DE L’AIGUILLE
// ============================================================
gsap.to(pointer, {
  rotation: targetAngle,
  duration: 1.2,
  ease: "power2.inOut",
  onComplete: () => {
    gsap.to(pointer, {
      rotation: goingUp ? angleMin : angleMax,
      duration: oscillationSpeed,
      ease: "sine.inOut",
      yoyo: true,
      repeat: -1
    });
  }
});

}

window.Script98 = function()
{
  const Btn_Affichage  = document.querySelector('[data-model-id="6RRLU9ixx38"]');
const temoin = object('68ikzB1cq1L');

// (Optionnel mais recommandé) point d’ancrage de la rotation
Btn_Affichage.style.transformOrigin = "50% 50%";

// On lit l’état actuel puis on bascule
const isAffiche = (temoin.state === "Feedback_Affiche");

temoin.state = isAffiche ? "Feedback_Cache" : "Feedback_Affiche";

// Rotation GSAP (durée + easing ajustables)
gsap.to(Btn_Affichage, {
  rotation: isAffiche ? 180 : 0,
  duration: 0.45,
  ease: "power2.inOut",
  overwrite: "auto"
});

}

window.Script99 = function()
{
  // Récupère le résultat
let resultat = getVar("Ex_Success");

// Définit les listes de feedback
const feedbackCorrect = [
  "Bravo !",
  "Super !",
  "Bien joué !",
  "Excellent !"
];

const feedbackIncorrect = [
  "Pas exactement",
  "Oups !",
  "La prochaine fois !"
];

// Choisit la liste en fonction du résultat
let liste = (resultat === "1") ? feedbackCorrect : feedbackIncorrect;

// Sélectionne un élément aléatoire dans la liste
let feedback = liste[Math.floor(Math.random() * liste.length)];

// Met à jour la variable Storyline
setVar("Ex_Feedback_Motivation", feedback);

}

window.Script100 = function()
{
  // ============================================================
// 🎯 ANIMATION DE JAUGE — Rotation + Oscillation continue + Feedback motivationnel + Indicateur visuel
// ============================================================

// -------- OBJETS STORYLINE --------
const pointer = object('5Ux37gXcJcw');
const gauge = object('5enGetq7POY');

// -------- PARAMÈTRES --------
const minAngle = 0;
const maxAngle = 180;
const oscillationRange = 10;
const oscillationSpeed = 1.5;

// ============================================================
// 🧮 DETECTION DU RESULTAT + RECUPERATION VARIABLES STORYLINE
// ============================================================
let resultat = getVar("Ex_Success");
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;
const exCurrent = getVar(`${seqKey}_Exo_Current`);

// Si il n'y a pas de résultat direct, on tente de le retrouver dans Sx_Win_Lose
if (resultat === "") {
  const historique = getVar(`${seqKey}_Win_Lose`);
  const charAtIndex = historique.charAt(exCurrent - 1);
  if (charAtIndex === "1" || charAtIndex === "0") {
    resultat = charAtIndex;
  } else {
    console.log(`ℹ️ Aucun résultat valide trouvé dans ${seqKey}_Win_Lose à l’index ${exCurrent - 1}`);
    resultat = "";
  }
}

// ============================================================
// ⚙️ Changement couleur jauge
// ============================================================
if (resultat === "1") {
  gauge.state = "Correct" ;
} else if (resultat === "0") {
  gauge.state = "Incorrect" ;
}

// ============================================================
// ⚙️ CALCULS D’ANGLES
// ============================================================
const baseAngle = resultat * (maxAngle - minAngle) + minAngle;
const angleMin = baseAngle - oscillationRange;
const angleMax = baseAngle + oscillationRange;


const goingUp = resultat === "1";
const targetAngle = goingUp ? angleMax : angleMin;

// ============================================================
// 🧹 ARRÊTE LES ANIMATIONS EXISTANTES
// ============================================================
gsap.killTweensOf(pointer);

// ============================================================
// 🚀 ANIMATION DE L’AIGUILLE
// ============================================================
gsap.to(pointer, {
  rotation: targetAngle,
  duration: 1.2,
  ease: "power2.inOut",
  onComplete: () => {
    gsap.to(pointer, {
      rotation: goingUp ? angleMin : angleMax,
      duration: oscillationSpeed,
      ease: "sine.inOut",
      yoyo: true,
      repeat: -1
    });
  }
});

}

window.Script101 = function()
{
  // ============================================================
// 🔁 SCRIPT — ALLER AU PROCHAIN EXERCICE ÉCHOUÉ ("Réviser les erreurs")
// ============================================================

// -------- VARIABLES DE CONTEXTE --------
const seqPos = getVar("0_Position_Sequence"); // ex: "1", "2", "3", "4"
const seqKey = `S${seqPos}`;                  // ex: "S1"
const exCurrent = parseInt(getVar(`${seqKey}_Exo_Current`) || 0, 10); // ex: 3
const historique = getVar(`${seqKey}_Win_Lose`) || ""; // ex: "110010"

// -------- SÉCURITÉ --------
if (!seqPos || !historique) {
  console.warn("⚠️ Impossible d'exécuter le script — séquence ou historique manquant.");
  return;
}

// ============================================================
// 🔍 RECHERCHE DU PROCHAIN ÉCHEC ("0")
// ============================================================

// On cherche le prochain "0" APRÈS la position actuelle
const nextFailIndex = historique.indexOf("0", exCurrent);

// ============================================================
// 🎯 MISE À JOUR OU FIN DE LA RÉVISION
// ============================================================

if (nextFailIndex === -1) {
  // Aucun autre exercice échoué trouvé → fin du mode révision
  setVar("S0_Revision_Erreurs", 2);
  console.log("🎉 Tous les exercices échoués ont été revus — fin du mode révision (S0_Revision_Erreurs = 2).");
} else {
  // Prochain exercice échoué trouvé
  const nextExercise = nextFailIndex + 1; // index → position 1-based
  setVar("0_Position_Exercice", nextExercise);
  console.log(`🔁 Révision → Prochain exercice échoué : EX${nextExercise}`);
}

console.log(`(Séquence : ${seqKey}, Historique : "${historique}")`);

}

window.Script102 = function()
{
  // ============================================================
// 🎬 REMPLACEMENT DYNAMIQUE DE VIDÉO (version simplifiée)
// ============================================================
// Remplace directement la vidéo de l'objet Storyline (ID fixe)
// avec le chemin complet contenu dans la variable "Ex_Video".
// ============================================================

// -------- Lecture de la variable --------
const newVideoPath = getVar("Ex_Video"); // ex: "Ressources_Sequences/S1/Videos/S1_EX1.mp4"

// -------- Sécurité --------
if (!newVideoPath || newVideoPath.trim() === "") {
  console.warn("⚠️ Aucune vidéo spécifiée dans Ex_Video — remplacement annulé.");
  return;
}

// -------- Sélection directe de la vidéo --------
const videoElement = document.querySelector('[data-model-id="5pTX8N7gCDH"] video');
if (!videoElement) {
  console.error("❌ Impossible de trouver la vidéo avec data-model-id=5pTX8N7gCDH.");
  return;
}

// -------- Remplacement de la source --------
videoElement.setAttribute("xlink:href", newVideoPath);
videoElement.src = newVideoPath;
videoElement.load();

// -------- Suppression de la vignette (poster) --------
const container = videoElement.closest('[data-model-id="5pTX8N7gCDH"]');
if (container) {
  const poster = container.querySelector("img.video-player-poster");
  if (poster) {
    poster.remove();
    console.log("✅ Vignette (poster) supprimée — la 1ère image de la vidéo sera visible.");
  }
}
}

window.Script103 = function()
{
  // ============================================================
// 🖼️ REMPLACEMENT DYNAMIQUE D’IMAGE (version simplifiée)
// ============================================================
// Remplace directement l’image de l’objet Storyline (ID fixe)
// avec le chemin complet contenu dans la variable "Ex_Image".
// Aucun calcul de dossier ou de chemin n’est effectué.
// ============================================================

// -------- Lecture de la variable --------
const newImagePath = getVar("Ex_Image"); // ex: "Ressources_Sequences/S1/images/EX1.jpg"

// -------- Sécurité --------
if (!newImagePath || newImagePath.trim() === "") {
  console.warn("⚠️ Aucune image spécifiée dans Ex_Image — remplacement annulé.");
  return;
}

// -------- Sélection directe de l’image --------
const imageElement = document.querySelector('[data-model-id="6jUy2ox5l86"] image');
if (!imageElement) {
  console.error("❌ Impossible de trouver l’image avec data-model-id=6jUy2ox5l86.");
  return;
}

// -------- Remplacement du lien --------
imageElement.setAttributeNS("http://www.w3.org/1999/xlink", "xlink:href", newImagePath);

}

window.Script104 = function()
{
  // ============================================================
// 🖼️ REMPLACEMENT DYNAMIQUE D’IMAGE (version simplifiée)
// ============================================================
// Remplace directement l’image de l’objet Storyline (ID fixe)
// avec le chemin complet contenu dans la variable "Ex_Image".
// Aucun calcul de dossier ou de chemin n’est effectué.
// ============================================================

// -------- Lecture de la variable --------
const newImagePath = getVar("Ex_Image"); // ex: "Ressources_Sequences/S1/images/EX1.jpg"

// -------- Sécurité --------
if (!newImagePath || newImagePath.trim() === "") {
  console.warn("⚠️ Aucune image spécifiée dans Ex_Image — remplacement annulé.");
  return;
}

// -------- Sélection directe de l’image --------
const imageElement = document.querySelector('[data-model-id="6c22D92goAT"] image');
if (!imageElement) {
  console.error("❌ Impossible de trouver l’image avec data-model-id=6c22D92goAT.");
  return;
}

// -------- Remplacement du lien --------
imageElement.setAttributeNS("http://www.w3.org/1999/xlink", "xlink:href", newImagePath);

}

window.Script105 = function()
{
  // ============================================================
// ⚙️ BARRE DE PROGRESSION — SYNCHRONISATION AVEC LA SÉQUENCE EN COURS
// ============================================================

// --------- Lecture de la séquence courante ---------
const seqPos = getVar("0_Position_Sequence");   // ex. 1 → S1
const seqKey = `S${seqPos}`;

// --------- Lecture des variables de la séquence correspondante ---------
const Exo_Reached = getVar("S0_Exo_Reached") || 0;
const Exo_Total = getVar("S0_Exo_Total") || 1;

// --------- Calcul du pourcentage ---------
const progress = Math.min(Exo_Reached / Exo_Total, 1); // clamp entre 0 et 1

// --------- Sélectionne l'objet Storyline ---------
const ProgressBar = document.querySelector(`[data-model-id="6f561U28wA4"]`);

if (ProgressBar) {
  // --------- Sélectionne l'élément graphique principal ---------
  const shape = ProgressBar.querySelector("path");

  if (shape) {
    // Si ce n’est pas déjà fait, on garde la largeur d’origine
    if (!shape.dataset.fullWidth) {
      const bbox = shape.getBBox();
      shape.dataset.fullWidth = bbox.width;
    }

    // --------- Calcul de la largeur selon la progression ---------
    const fullWidth = parseFloat(shape.dataset.fullWidth);

    // --------- Application du remplissage via clip-path ---------
    shape.style.clipPath = `inset(0 ${100 - progress * 100}% 0 0 round 0px)`;
  }
}

}

window.Script106 = function()
{
  // ============================================================
// ⚙️ BARRE DE PROGRESSION ANIMÉE (AVEC INITIALISATION INTELLIGENTE)
// ============================================================

// Durée de l’animation en millisecondes (modifiable)
const animationDuration = 800; // 0.8s = fluide, 300 = rapide, 1500 = lente

function updateProgressBarAnimated() {
  // --------- Lecture de la séquence courante ---------
  const seqPos = getVar("0_Position_Sequence");
  const seqKey = `S${seqPos}`;

  // --------- Lecture des variables globales S0 ---------
  const Exo_Reached = getVar("S0_Exo_Reached") || 0;
  const Exo_Total = getVar("S0_Exo_Total") || 1;
  const progress = Math.min(Exo_Reached / Exo_Total, 1);

  // --------- Sélectionne l'objet Storyline ---------
  const ProgressBar = document.querySelector(`[data-model-id="6f561U28wA4"]`);
  if (!ProgressBar) return;

  const shape = ProgressBar.querySelector("path");
  if (!shape) return;

  // --------- Initialisation si nécessaire ---------
  if (!shape.dataset.fullWidth) {
    const bbox = shape.getBBox();
    shape.dataset.fullWidth = bbox.width;
  }

  // --------- Nouvelle logique : position initiale intelligente ---------
  let startProgress;

  if (shape.dataset.currentProgress !== undefined) {
    // On continue à partir de la progression actuelle
    startProgress = parseFloat(shape.dataset.currentProgress) || 0;
  } else if (Exo_Reached >= 1) {
    // Si aucune donnée mais au moins un exercice complété,
    // on démarre au niveau précédent
    startProgress = (Exo_Reached - 1) / Exo_Total;
  } else {
    // Sinon, tout au début
    startProgress = 0;
  }

  const startTime = performance.now();

  // --------- Fonction d'animation fluide ---------
  function animate(time) {
    const elapsed = time - startTime;
    const t = Math.min(elapsed / animationDuration, 1);
    const eased = t < 0.5 ? 2 * t * t : -1 + (4 - 2 * t) * t; // easeInOutQuad

    const currentProgress = startProgress + (progress - startProgress) * eased;
    shape.style.clipPath = `inset(0 ${100 - currentProgress * 100}% 0 0 round 0px)`;
    shape.dataset.currentProgress = currentProgress;

    if (t < 1) requestAnimationFrame(animate);
  }

  requestAnimationFrame(animate);
}

// ============================================================
// ▶️ APPEL DU SCRIPT (exécuté manuellement via trigger JS)
// ============================================================

updateProgressBarAnimated();

}

window.Script107 = function()
{
  // -------- Initialisation --------

// Récupère le numéro ou identifiant d'exercice (ex: "EX2")
const AudioPath = getVar("0_Audio_Lecteur");

// Si un audio était déjà en cours → on le stoppe et on remet au début
if (window.audioUnique) {
  window.audioUnique.pause();
  window.audioUnique.currentTime = 0;
}

// Crée un nouvel objet audio
window.audioUnique = new Audio(AudioPath);

// Lecture
window.audioUnique.play().catch(err => {
  console.log("Erreur lecture Back :", err);
});
}

window.Script108 = function()
{
  // ============================================================
// 🎯 MISE À JOUR DES VARIABLES Sx_Win_Lose SELON Ex_Success (texte)
// ============================================================

// -------- Lecture des variables Storyline --------
const seqPos  = getVar("0_Position_Sequence");
const exPos   = getVar("0_Position_Exercice");
const success = getVar("Ex_Success");

// -------- Construction du nom de la séquence --------
const seqKey     = `S${seqPos}`;
const winLoseVar = `${seqKey}_Win_Lose`;

// -------- Lecture actuelle de la variable Win_Lose --------
let winLose = getVar(winLoseVar) || "";

// -------- S’assure que la longueur correspond au nombre total d’exercices --------
const total = getVar(`0_Menu_${seqKey}_Exo_Total`);

// -------- Conversion en tableau pour modification --------
const chars = winLose.split("");

// -------- Mise à jour du caractère correspondant à l’exercice actuel --------
if (!(chars[exPos - 1] === "1" && success === "0")) {
    chars[exPos - 1] = success === "1" ? "1" : "0";
}
// Si l'exercice est déjà réussi, on garde la réussite.

// -------- Conversion inverse en chaîne --------
winLose = chars.join("");

// -------- Écriture dans Storyline --------
setVar(winLoseVar, winLose);

// ============================================================
// 🔁 SWITCH AUTOMATIQUE DE 0_Feedback_Switch
// ============================================================
let feedbackSwitch = getVar("0_Feedback_Switch");
feedbackSwitch = feedbackSwitch === true || feedbackSwitch === "true" ? false : true;
setVar("0_Feedback_Switch", feedbackSwitch);

}

window.Script109 = function()
{
  // ============================================================
// 🏁 SCRIPT DE FIN D’EXERCICE — MISE À JOUR PROGRESSION & TENTATIVES
// ============================================================

// -------- CONFIGURATION --------
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;

const exCurrent  = parseInt(getVar(`${seqKey}_Exo_Current`), 10);
const exReached  = parseInt(getVar(`${seqKey}_Exo_Reached`), 10);
const tentVar    = `${seqKey}_Exo_Current_Tentatives`;
// ============================================================
// 🧭 MISE À JOUR DE LA PROGRESSION
// ============================================================

// Si on avance (évite de revenir en arrière)
if (exCurrent > exReached) {
  setVar(`${seqKey}_Exo_Reached`, exCurrent);
  setVar("S0_Exo_Reached", exCurrent); 
}

// ============================================================
// 🧮 MARQUAGE DE L’EXERCICE TERMINÉ
// ============================================================

setVar(tentVar, -10);

}

window.Script110 = function()
{
  // ============================================================
// 🧠 SAUVEGARDE AUTOMATIQUE DES DONNÉES UTILISATEUR (GLOBAL)
// ============================================================
//
// 🔹 Ce script est appelé automatiquement après la validation d’un exercice.
// 🔹 Il détecte le type d’exercice et sauvegarde la réponse dans la variable JSON
//    correspondante (ex: S1_UserData)
//
// ============================================================

// ------------------------------------------------------------
// 🔧 Lecture des infos de contexte
// ------------------------------------------------------------
const seqPos = getVar("0_Position_Sequence");           // ex: "1"
const exPos = parseInt(getVar("0_Position_Exercice"), 10);
const seqKey = `S${seqPos}`;
const exType = getVar("Ex_Type");
const success = getVar("Ex_Success");
const tentativesRestantes = parseInt(getVar("Ex_Tentatives"), 10);

// Variable cible (ex: "S1_UserData")
const userDataVar = `${seqKey}_UserData`;

// ------------------------------------------------------------
// 🔧 Lecture du JSON existant
// ------------------------------------------------------------
let data = {};
try {
  const existing = getVar(userDataVar);
  data = existing ? JSON.parse(existing) : {};
} catch (err) {
  console.warn(`⚠️ JSON invalide dans ${userDataVar}, réinitialisation.`, err);
  data = {};
}

// ------------------------------------------------------------
// 🧮 Tentatives initiales (si dispo dans cache global)
// ------------------------------------------------------------
let tentativesInitiales = 0;
try {
  const exData = window.sequenceCache?.[seqKey]?.[`EX${exPos}`];
  tentativesInitiales = exData?.Tentatives || 1;
} catch {
  tentativesInitiales = 1;
}

const tentativesUtilisees = Math.max(0, tentativesInitiales - tentativesRestantes);

// ------------------------------------------------------------
// 🎯 Récupération de la réponse selon le type d’exercice
// ------------------------------------------------------------
let userResponseObj = {};

switch (exType) {
  // 🔹 QCU
  case "QCU": {
    const answerKey = getVar("0_Reponse");
    const answerText = getVar(`0_Choix_${answerKey}`) || "";
    userResponseObj = { [answerKey]: answerText };
    break;
  }

  // 🔹 QCM
  case "QCM": {
    const responseRaw = (getVar("0_Reponse") || "").split("|").filter(Boolean);
    responseRaw.forEach(k => {
      userResponseObj[k] = getVar(`0_Choix_${k}`) || "";
    });
    break;
  }

  // 🔹 True or false
  case "True or false": {
    const answer = (getVar("0_Reponse") || "").toLowerCase();
    userResponseObj = { unique: answer };
    break;
  }

  // 🔹 Complete
  case "Complete": {
    const answer = getVar("0_Ex_Enonce") || "";
    userResponseObj = { unique: answer };
    break;
  }

  // 🔹 Matching
  case "Matching": {
    const reponse = getVar("0_Reponse") || "";
    userResponseObj = { associations: reponse };
    break;
  }

  // 🔹 Flashcard
  case "Flashcard": {
    const answer = getVar("0_Reponse") || "";
    userResponseObj = { unique: answer };
    break;
  }

  // 🔹 Information
  case "Information": {
    userResponseObj = { info: "Aucune interaction" };
    break;
  }

  // 🔹 Production orale - dictée
  case "Production orale - dictée": {
    const raw = getVar("0_Reponse") || "{}";
    try {
      const parsed = JSON.parse(raw);
      userResponseObj = {
        score: parsed.score || 0,
        texte_brut: parsed.texte_brut || "",
        texte_color: parsed.texte_color || ""
      };
    } catch (err) {
      console.warn("⚠️ Erreur de parsing JSON pour Production orale :", err);
      userResponseObj = { erreur: "Format de réponse invalide", raw };
    }
    break;
  }

  // 🔹 Défaut
  default: {
    const raw = getVar("0_Reponse") || "";
    userResponseObj = { inconnu: raw };
    console.warn(`❓ Type d’exercice inconnu : ${exType}`);
    break;
  }
}

// ------------------------------------------------------------
// 💾 Enregistrement dans le JSON
// ------------------------------------------------------------
data[`EX${exPos}`] = {
  Type: exType,
  Reponses_Choisies: userResponseObj,
  Statut: success,
  Tentatives_Utilisees: tentativesUtilisees
};

setVar(userDataVar, JSON.stringify(data));

// ------------------------------------------------------------
// 🧾 Log de contrôle
// ------------------------------------------------------------
console.group(`💾 Données sauvegardées → ${userDataVar}`);
console.log("Exercice :", `EX${exPos}`);
console.log("Type :", exType);
console.log("Réponses :", userResponseObj);
console.log("Statut :", success);
console.log("Tentatives utilisées :", tentativesUtilisees);
console.log("JSON complet :", data);
console.groupEnd();

}

window.Script111 = function()
{
  // ============================================================
// 🎯 VÉRIFICATION DE LA RÉPONSE (VRAI/FAUX) + GESTION DES TENTATIVES
// ============================================================

// --------- Lecture des variables Storyline ---------
const userAnswer = (getVar("0_Reponse") || "").toLowerCase().trim();
const correction  = (getVar("0_Ex_Correction") || "").toLowerCase().trim();
let tentatives    = parseInt(getVar("Ex_Tentatives"), 10);
const seqPos      = getVar("0_Position_Sequence");
const seqKey      = `S${seqPos}`;
const tentVar     = `${seqKey}_Exo_Current_Tentatives`;

let CompteurTentatives    = parseInt(getVar("Ex_Compteur_Tentatives"), 10);
const CompteurTentativesVar = `${seqKey}_Exo_Current_Compteur_Tentatives`;


// --------- Lecture du succès actuel ---------
let success = getVar("Ex_Success") || "";

// --------- Vérification de la réponse ---------
if (userAnswer === correction) {
  success = "1";
} else {
  if (tentatives > 0) {
    tentatives -= 1;
  }
  if (tentatives <= 0) {
    success = "0";
  }
}

CompteurTentatives++;

// ============================================================
// 💾 MISE À JOUR DES VARIABLES PERSISTANTES
// ============================================================

// Met à jour les variables locales et persistantes
setVar("Ex_Tentatives", tentatives);
setVar(tentVar, tentatives);

setVar("Ex_Compteur_Tentatives", CompteurTentatives);
setVar(CompteurTentativesVar, CompteurTentatives);

setVar("Ex_Success", success);

// Si l’exercice est terminé (succès ou plus de tentatives), on le marque comme "fini"
if (success === "1" || tentatives <= 0) {
  setVar(tentVar, -10);
}

}

window.Script112 = function()
{
  // ============================================================
// 🎯 TRUE/FALSE — MISE À JOUR AUTOMATIQUE DES ÉTATS DE FEEDBACK + POSITION DU SELECTED
// ============================================================

// -------- OBJETS STORYLINE --------
const feedback_False = object('65PKYm4i7xs');
const feedback_True  = object('5xxFgGmougW');
const selected       = object('5viMzPklxBm'); // indicateur visuel de la réponse choisie


// -------- VARIABLES STORYLINE --------
const seqPos = getVar("0_Position_Sequence"); // ex: "1"
const exPos = parseInt(getVar("0_Position_Exercice") || 0, 10);
const seqKey = `S${seqPos}`;
const userDataVar = `${seqKey}_UserData`;

const correction = (getVar("0_Ex_Correction") || "").toLowerCase().trim(); // "true" ou "false"
let reponse = (getVar("0_Reponse") || "").toLowerCase().trim();            // "true" ou "false"

// -------- SI AUCUNE RÉPONSE LOCALE, ON VA CHERCHER DANS USERDATA --------
if (!reponse) {
  try {
    const raw = getVar(userDataVar);
    if (raw) {
      const data = JSON.parse(raw);
      const exData = data[`EX${exPos}`];

      if (exData && exData.Type === "True or false") {
        const value = exData.Reponses_Choisies?.unique || "";
        if (value) {
          reponse = value.toLowerCase();
          console.log(`💾 Réponse restaurée depuis UserData : ${reponse}`);
        }
      }
    }
  } catch (err) {
    console.warn(`⚠️ Lecture UserData échouée pour ${userDataVar}`, err);
  }
}


// -------- FONCTION UTILE --------
function setFeedbackState(obj, state) {
  if (!obj) return;
  if (obj.state !== state) {
    obj.state = state;
    console.log(`🎨 ${obj.name || "(objet)"} → état défini sur "${state}"`);
  }
}

// ============================================================
// 🧠 LOGIQUE D’ÉTAT DES FEEDBACKS
// ============================================================
if (correction === "true") {
  setFeedbackState(feedback_True, "Correct Answer");
  setFeedbackState(feedback_False, "Wrong Answer");
} 
else if (correction === "false") {
  setFeedbackState(feedback_True, "Wrong Answer");
  setFeedbackState(feedback_False, "Correct Answer");
} 
else {
  setFeedbackState(feedback_True, "Normal");
  setFeedbackState(feedback_False, "Normal");
  console.warn("⚠️ 0_Ex_Correction n’est pas encore défini (états réinitialisés).");
}

// ============================================================
// 🎯 POSITIONNEMENT DU SÉLECTEUR
// ============================================================
if (selected) {
  if (reponse === "true") {
    selected.x = feedback_True.x;
    selected.y = feedback_True.y;
    selected.state = "Visible";
    console.log("🟣 Sélecteur positionné sur la réponse TRUE.");
  } 
  else if (reponse === "false") {
    selected.x = feedback_False.x;
    selected.y = feedback_False.y;
    selected.state = "Visible";
    console.log("🟣 Sélecteur positionné sur la réponse FALSE.");
  } 
  else {
    selected.state = "Caché";
    console.log("⚪ Aucune réponse sélectionnée → sélecteur masqué.");
  }
}

}

window.Script113 = function()
{
  // ============================================================
// 🎯 TRUE/FALSE — MISE À JOUR AUTOMATIQUE DES ÉTATS DE FEEDBACK + POSITION DU SELECTED
// ============================================================

// -------- OBJETS STORYLINE --------
const feedback_False = object('6UwscF1oNq9');
const feedback_True  = object('6aUnrN7Uku4');
const selected       = object('6gtFwN1HiQ2'); // indicateur visuel de la réponse choisie


// -------- VARIABLES STORYLINE --------
const seqPos = getVar("0_Position_Sequence"); // ex: "1"
const exPos = parseInt(getVar("0_Position_Exercice") || 0, 10);
const seqKey = `S${seqPos}`;
const userDataVar = `${seqKey}_UserData`;

const correction = (getVar("0_Ex_Correction") || "").toLowerCase().trim(); // "true" ou "false"
let reponse = (getVar("0_Reponse") || "").toLowerCase().trim();            // "true" ou "false"

// -------- SI AUCUNE RÉPONSE LOCALE, ON VA CHERCHER DANS USERDATA --------
if (!reponse) {
  try {
    const raw = getVar(userDataVar);
    if (raw) {
      const data = JSON.parse(raw);
      const exData = data[`EX${exPos}`];

      if (exData && exData.Type === "True or false") {
        const value = exData.Reponses_Choisies?.unique || "";
        if (value) {
          reponse = value.toLowerCase();
          console.log(`💾 Réponse restaurée depuis UserData : ${reponse}`);
        }
      }
    }
  } catch (err) {
    console.warn(`⚠️ Lecture UserData échouée pour ${userDataVar}`, err);
  }
}


// -------- FONCTION UTILE --------
function setFeedbackState(obj, state) {
  if (!obj) return;
  if (obj.state !== state) {
    obj.state = state;
    console.log(`🎨 ${obj.name || "(objet)"} → état défini sur "${state}"`);
  }
}

// ============================================================
// 🧠 LOGIQUE D’ÉTAT DES FEEDBACKS
// ============================================================
if (correction === "true") {
  setFeedbackState(feedback_True, "Correct Answer");
  setFeedbackState(feedback_False, "Wrong Answer");
} 
else if (correction === "false") {
  setFeedbackState(feedback_True, "Wrong Answer");
  setFeedbackState(feedback_False, "Correct Answer");
} 
else {
  setFeedbackState(feedback_True, "Normal");
  setFeedbackState(feedback_False, "Normal");
  console.warn("⚠️ 0_Ex_Correction n’est pas encore défini (états réinitialisés).");
}

// ============================================================
// 🎯 POSITIONNEMENT DU SÉLECTEUR
// ============================================================
if (selected) {
  if (reponse === "true") {
    selected.x = feedback_True.x;
    selected.y = feedback_True.y;
    selected.state = "Visible";
    console.log("🟣 Sélecteur positionné sur la réponse TRUE.");
  } 
  else if (reponse === "false") {
    selected.x = feedback_False.x;
    selected.y = feedback_False.y;
    selected.state = "Visible";
    console.log("🟣 Sélecteur positionné sur la réponse FALSE.");
  } 
  else {
    selected.state = "Caché";
    console.log("⚪ Aucune réponse sélectionnée → sélecteur masqué.");
  }
}

}

window.Script114 = function()
{
  // Récupère les objets Storyline
const carte  = document.querySelector('[data-model-id="6WOyyFcuLyH"]');
const bouton = document.querySelector('[data-model-id="5rCsry3VrNh"]');

// Points d'ancrage
carte.style.transformOrigin = "top left";
bouton.style.transformOrigin = "center";

// Timeline pour synchroniser
const tl = gsap.timeline();

tl.to(carte, {
  scale: 0,
  opacity: 0,
  duration: 0.5,
  ease: "power1.inOut"
}, 0);

// Rotation 90° du bouton en même temps
tl.to(bouton, {
  rotate: 0,          // ou "+=90" si tu veux ajouter 90° à chaque fois
  duration: 0.5,
  ease: "power1.inOut"
}, 0);

}

window.Script115 = function()
{
  // Récupère les objets Storyline
const carte  = document.querySelector('[data-model-id="6WOyyFcuLyH"]');
const bouton = document.querySelector('[data-model-id="5rCsry3VrNh"]');

// Points d'ancrage
carte.style.transformOrigin = "top left";
bouton.style.transformOrigin = "center";

// États initiaux
gsap.set(carte,  { scale: 0, opacity: 0 });
gsap.set(bouton, { rotate: 0 }); // ou 90 si tu veux qu'il démarre déjà tourné

// Timeline pour synchroniser
const tl = gsap.timeline();

tl.to(carte, {
  scale: 1,
  opacity: 1,
  duration: 0.5,
  ease: "power1.inOut"
}, 0);

// Rotation 90° du bouton en même temps
tl.to(bouton, {
  rotate: 45,          // ou "+=90" si tu veux ajouter 90° à chaque fois
  duration: 0.5,
  ease: "power1.inOut"
}, 0);

}

window.Script116 = function()
{
  // ============================================================
// 💬 FEEDBACK MOTIVATIONNEL — AVEC SUPPORT DU FORMAT "1101nn"
// ============================================================

// -------- VARIABLES DE BASE --------
let resultat = getVar("Ex_Success");
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;
const exCurrent = parseInt(getVar(`${seqKey}_Exo_Current`), 10);

// ============================================================
// 🔍 SI RESULTAT VIDE → CHERCHE DANS S1_Win_Lose ("1101nn")
// ============================================================
if (!resultat || resultat === "") {
  const historique = getVar(`${seqKey}_Win_Lose`) || "";
  const charAtIndex = historique.charAt(exCurrent - 1);

  if (charAtIndex === "1" || charAtIndex === "0") {
    resultat = charAtIndex;
  } else {
    console.log(`ℹ️ Aucun résultat valide trouvé dans ${seqKey}_Win_Lose à l’index ${exCurrent - 1}`);
  }
}

// ============================================================
// 💬 LISTES DE FEEDBACKS
// ============================================================
const feedbackCorrect = [
  "Bravo !",
  "Super !",
  "Bien joué !",
  "Excellent !"
];

const feedbackIncorrect = [
  "Pas exactement.",
  "Oups !",
  "La prochaine fois !"
];

const feedbackNeutre = [
  "Continue !"
];

// ============================================================
// 🎯 CHOIX DU FEEDBACK
// ============================================================
let liste;
switch (resultat) {
  case "1":
    liste = feedbackCorrect;
    break;
  case "0":
    liste = feedbackIncorrect;
    break;
  default:
    liste = feedbackNeutre;
    break;
}

// Sélection aléatoire dans la liste
const feedback = liste[Math.floor(Math.random() * liste.length)];

// ============================================================
// 🧾 MISE À JOUR STORYLINE
// ============================================================
setVar("Ex_Feedback_Motivation", feedback);

}

window.Script117 = function()
{
  // ============================================================
// 🔁 SCRIPT — ALLER AU PROCHAIN EXERCICE ÉCHOUÉ ("Réviser les erreurs")
// ============================================================

// -------- VARIABLES DE CONTEXTE --------
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;
const exCurrent = parseInt(getVar(`${seqKey}_Exo_Current`), 10);
const historique = getVar(`${seqKey}_Win_Lose`) || "";

// -------- SÉCURITÉ --------
if (!seqPos || !historique) {
  console.warn("⚠️ Impossible d'exécuter le script — séquence ou historique manquant.");
  return;
}

// ============================================================
// 🔍 RECHERCHE DU PROCHAIN ÉCHEC ("0")
// ============================================================

// On cherche le prochain "0" APRÈS la position actuelle
const nextFailIndex = historique.indexOf("0", exCurrent);

// ============================================================
// 🎯 MISE À JOUR OU FIN DE LA RÉVISION
// ============================================================

if (nextFailIndex === -1) {
  // Aucun autre exercice échoué trouvé → fin du mode révision
  setVar("S0_Revision_Erreurs", 2);

} else {
  // Prochain exercice échoué trouvé
  const nextExercise = nextFailIndex + 1; // index → position 1-based
  setVar("0_Position_Exercice", nextExercise);
}
}

window.Script118 = function()
{
  // ============================================================
// 🎯 ANIMATION DE JAUGE — Rotation + Oscillation continue + Feedback motivationnel + Indicateur visuel
// ============================================================

// -------- OBJETS STORYLINE --------
const pointer = object('5fZOHpnMbya');
const gauge = object('6nKxLAItMtB');

// -------- PARAMÈTRES --------
const minAngle = 0;
const maxAngle = 180;
const oscillationRange = 10;
const oscillationSpeed = 1.5;

// ============================================================
// 🧮 DETECTION DU RESULTAT + RECUPERATION VARIABLES STORYLINE
// ============================================================
let resultat = getVar("Ex_Success");
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;
const exCurrent = getVar(`${seqKey}_Exo_Current`);

// Si il n'y a pas de résultat direct, on tente de le retrouver dans Sx_Win_Lose
if (resultat === "") {
  const historique = getVar(`${seqKey}_Win_Lose`);
  const charAtIndex = historique.charAt(exCurrent - 1);
  if (charAtIndex === "1" || charAtIndex === "0") {
    resultat = charAtIndex;
  } else {
    console.log(`ℹ️ Aucun résultat valide trouvé dans ${seqKey}_Win_Lose à l’index ${exCurrent - 1}`);
    resultat = "";
  }
}

// ============================================================
// ⚙️ Changement couleur jauge
// ============================================================
if (resultat === "1") {
  gauge.state = "Correct" ;
} else if (resultat === "0") {
  gauge.state = "Incorrect" ;
}

// ============================================================
// ⚙️ CALCULS D’ANGLES
// ============================================================
const baseAngle = resultat * (maxAngle - minAngle) + minAngle;
const angleMin = baseAngle - oscillationRange;
const angleMax = baseAngle + oscillationRange;


const goingUp = resultat === "1";
const targetAngle = goingUp ? angleMax : angleMin;

// ============================================================
// 🧹 ARRÊTE LES ANIMATIONS EXISTANTES
// ============================================================
gsap.killTweensOf(pointer);

// ============================================================
// 🚀 ANIMATION DE L’AIGUILLE
// ============================================================
gsap.to(pointer, {
  rotation: targetAngle,
  duration: 1.2,
  ease: "power2.inOut",
  onComplete: () => {
    gsap.to(pointer, {
      rotation: goingUp ? angleMin : angleMax,
      duration: oscillationSpeed,
      ease: "sine.inOut",
      yoyo: true,
      repeat: -1
    });
  }
});

}

window.Script119 = function()
{
  const Btn_Affichage  = document.querySelector('[data-model-id="6geks01QgvK"]');
const temoin = object('6XIh2Zufqbt');

// (Optionnel mais recommandé) point d’ancrage de la rotation
Btn_Affichage.style.transformOrigin = "50% 50%";

// On lit l’état actuel puis on bascule
const isAffiche = (temoin.state === "Feedback_Affiche");

temoin.state = isAffiche ? "Feedback_Cache" : "Feedback_Affiche";

// Rotation GSAP (durée + easing ajustables)
gsap.to(Btn_Affichage, {
  rotation: isAffiche ? 180 : 0,
  duration: 0.45,
  ease: "power2.inOut",
  overwrite: "auto"
});

}

window.Script120 = function()
{
  // ============================================================
// 💬 FEEDBACK MOTIVATIONNEL — AVEC SUPPORT DU FORMAT "1101nn"
// ============================================================

// -------- VARIABLES DE BASE --------
let resultat = getVar("Ex_Success");
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;
const exCurrent = parseInt(getVar(`${seqKey}_Exo_Current`), 10);

// ============================================================
// 🔍 SI RESULTAT VIDE → CHERCHE DANS S1_Win_Lose ("1101nn")
// ============================================================
if (!resultat || resultat === "") {
  const historique = getVar(`${seqKey}_Win_Lose`) || "";
  const charAtIndex = historique.charAt(exCurrent - 1);

  if (charAtIndex === "1" || charAtIndex === "0") {
    resultat = charAtIndex;
  } else {
    console.log(`ℹ️ Aucun résultat valide trouvé dans ${seqKey}_Win_Lose à l’index ${exCurrent - 1}`);
  }
}

// ============================================================
// 💬 LISTES DE FEEDBACKS
// ============================================================
//const feedbackCorrect = [
//  "Bravo !",
//  "Super !",
//  "Bien joué !",
//  "Excellent !"
//];

//const feedbackIncorrect = [
//  "Pas exactement.",
//  "Oups !",
//  "La prochaine fois !"
//];

const feedbackCorrect = [
  "Bravo, c'est une bonne réponse !",
  "Super, tu es sur la bonne voie !",
  "Bien joué, tu progresses !",
  "Excellent, continue comme ça !"
];

const feedbackIncorrect = [
  "Ce n'est pas tout à fait ça.",
  "Oups, ce n'est pas la bonne réponse.",
  "Tu y arriveras la prochaine fois !",
  "Pas exactement. Encore un effort !"
];


const feedbackNeutre = [
  "Continue !"
];

// ============================================================
// 🎯 CHOIX DU FEEDBACK
// ============================================================
let liste;
switch (resultat) {
  case "1":
    liste = feedbackCorrect;
    break;
  case "0":
    liste = feedbackIncorrect;
    break;
  default:
    liste = feedbackNeutre;
    break;
}

// Sélection aléatoire dans la liste
const feedback = liste[Math.floor(Math.random() * liste.length)];

// ============================================================
// 🧾 MISE À JOUR STORYLINE
// ============================================================
setVar("Ex_Feedback_Motivation", feedback);

}

window.Script121 = function()
{
  // ============================================================
// 🔁 SCRIPT — ALLER AU PROCHAIN EXERCICE ÉCHOUÉ ("Réviser les erreurs")
// ============================================================

// -------- VARIABLES DE CONTEXTE --------
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;
const exCurrent = parseInt(getVar(`${seqKey}_Exo_Current`), 10);
const historique = getVar(`${seqKey}_Win_Lose`) || "";

// -------- SÉCURITÉ --------
if (!seqPos || !historique) {
  console.warn("⚠️ Impossible d'exécuter le script — séquence ou historique manquant.");
  return;
}

// ============================================================
// 🔍 RECHERCHE DU PROCHAIN ÉCHEC ("0")
// ============================================================

// On cherche le prochain "0" APRÈS la position actuelle
const nextFailIndex = historique.indexOf("0", exCurrent);

// ============================================================
// 🎯 MISE À JOUR OU FIN DE LA RÉVISION
// ============================================================

if (nextFailIndex === -1) {
  // Aucun autre exercice échoué trouvé → fin du mode révision
  setVar("S0_Revision_Erreurs", 2);

} else {
  // Prochain exercice échoué trouvé
  const nextExercise = nextFailIndex + 1; // index → position 1-based
  setVar("0_Position_Exercice", nextExercise);
}
}

window.Script122 = function()
{
  // ============================================================
// 🎯 ANIMATION DE JAUGE — Rotation + Oscillation continue + Feedback motivationnel + Indicateur visuel
// ============================================================

// -------- OBJETS STORYLINE --------
const pointer = object('61WVHrM0EGs');
//const gauge = object('5lezhyLYUu5'); Cet objet n'existe pas ?
const gauge = object('6rIRKS6iuFv');


// -------- PARAMÈTRES --------
const minAngle = 0;
const maxAngle = 180;
const oscillationRange = 10;
const oscillationSpeed = 1.5;

// ============================================================
// 🧮 DETECTION DU RESULTAT + RECUPERATION VARIABLES STORYLINE
// ============================================================
let resultat = getVar("Ex_Success");
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;
const exCurrent = getVar(`${seqKey}_Exo_Current`);

// Si il n'y a pas de résultat direct, on tente de le retrouver dans Sx_Win_Lose
if (resultat === "") {
  const historique = getVar(`${seqKey}_Win_Lose`);
  const charAtIndex = historique.charAt(exCurrent - 1);
  if (charAtIndex === "1" || charAtIndex === "0") {
    resultat = charAtIndex;
  } else {
    console.log(`ℹ️ Aucun résultat valide trouvé dans ${seqKey}_Win_Lose à l’index ${exCurrent - 1}`);
    resultat = "";
  }
}

// ============================================================
// ⚙️ Changement couleur jauge
// ============================================================
if (resultat === "1") {
  gauge.state = "Correct" ;
} else if (resultat === "0") {
  gauge.state = "Incorrect" ;
}

// ============================================================
// ⚙️ CALCULS D’ANGLES
// ============================================================
const baseAngle = resultat * (maxAngle - minAngle) + minAngle;
const angleMin = baseAngle - oscillationRange;
const angleMax = baseAngle + oscillationRange;


const goingUp = resultat === "1";
const targetAngle = goingUp ? angleMax : angleMin;

// ============================================================
// 🧹 ARRÊTE LES ANIMATIONS EXISTANTES
// ============================================================
gsap.killTweensOf(pointer);

// ============================================================
// 🚀 ANIMATION DE L’AIGUILLE
// ============================================================
gsap.to(pointer, {
  rotation: targetAngle,
  duration: 1.2,
  ease: "power2.inOut",
  onComplete: () => {
    gsap.to(pointer, {
      rotation: goingUp ? angleMin : angleMax,
      duration: oscillationSpeed,
      ease: "sine.inOut",
      yoyo: true,
      repeat: -1
    });
  }
});

}

window.Script123 = function()
{
  const Btn_Affichage  = document.querySelector('[data-model-id="6RRLU9ixx38"]');
const temoin = object('68ikzB1cq1L');

// (Optionnel mais recommandé) point d’ancrage de la rotation
Btn_Affichage.style.transformOrigin = "50% 50%";

// On lit l’état actuel puis on bascule
const isAffiche = (temoin.state === "Feedback_Affiche");

temoin.state = isAffiche ? "Feedback_Cache" : "Feedback_Affiche";

// Rotation GSAP (durée + easing ajustables)
gsap.to(Btn_Affichage, {
  rotation: isAffiche ? 180 : 0,
  duration: 0.45,
  ease: "power2.inOut",
  overwrite: "auto"
});

}

window.Script124 = function()
{
  // Récupère le résultat
let resultat = getVar("Ex_Success");

// Définit les listes de feedback
const feedbackCorrect = [
  "Bravo !",
  "Super !",
  "Bien joué !",
  "Excellent !"
];

const feedbackIncorrect = [
  "Pas exactement",
  "Oups !",
  "La prochaine fois !"
];

// Choisit la liste en fonction du résultat
let liste = (resultat === "1") ? feedbackCorrect : feedbackIncorrect;

// Sélectionne un élément aléatoire dans la liste
let feedback = liste[Math.floor(Math.random() * liste.length)];

// Met à jour la variable Storyline
setVar("Ex_Feedback_Motivation", feedback);

}

window.Script125 = function()
{
  // ============================================================
// 🎯 ANIMATION DE JAUGE — Rotation + Oscillation continue + Feedback motivationnel + Indicateur visuel
// ============================================================

// -------- OBJETS STORYLINE --------
const pointer = object('5Ux37gXcJcw');
const gauge = object('5enGetq7POY');

// -------- PARAMÈTRES --------
const minAngle = 0;
const maxAngle = 180;
const oscillationRange = 10;
const oscillationSpeed = 1.5;

// ============================================================
// 🧮 DETECTION DU RESULTAT + RECUPERATION VARIABLES STORYLINE
// ============================================================
let resultat = getVar("Ex_Success");
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;
const exCurrent = getVar(`${seqKey}_Exo_Current`);

// Si il n'y a pas de résultat direct, on tente de le retrouver dans Sx_Win_Lose
if (resultat === "") {
  const historique = getVar(`${seqKey}_Win_Lose`);
  const charAtIndex = historique.charAt(exCurrent - 1);
  if (charAtIndex === "1" || charAtIndex === "0") {
    resultat = charAtIndex;
  } else {
    console.log(`ℹ️ Aucun résultat valide trouvé dans ${seqKey}_Win_Lose à l’index ${exCurrent - 1}`);
    resultat = "";
  }
}

// ============================================================
// ⚙️ Changement couleur jauge
// ============================================================
if (resultat === "1") {
  gauge.state = "Correct" ;
} else if (resultat === "0") {
  gauge.state = "Incorrect" ;
}

// ============================================================
// ⚙️ CALCULS D’ANGLES
// ============================================================
const baseAngle = resultat * (maxAngle - minAngle) + minAngle;
const angleMin = baseAngle - oscillationRange;
const angleMax = baseAngle + oscillationRange;


const goingUp = resultat === "1";
const targetAngle = goingUp ? angleMax : angleMin;

// ============================================================
// 🧹 ARRÊTE LES ANIMATIONS EXISTANTES
// ============================================================
gsap.killTweensOf(pointer);

// ============================================================
// 🚀 ANIMATION DE L’AIGUILLE
// ============================================================
gsap.to(pointer, {
  rotation: targetAngle,
  duration: 1.2,
  ease: "power2.inOut",
  onComplete: () => {
    gsap.to(pointer, {
      rotation: goingUp ? angleMin : angleMax,
      duration: oscillationSpeed,
      ease: "sine.inOut",
      yoyo: true,
      repeat: -1
    });
  }
});

}

window.Script126 = function()
{
  // ============================================================
// 🔁 SCRIPT — ALLER AU PROCHAIN EXERCICE ÉCHOUÉ ("Réviser les erreurs")
// ============================================================

// -------- VARIABLES DE CONTEXTE --------
const seqPos = getVar("0_Position_Sequence"); // ex: "1", "2", "3", "4"
const seqKey = `S${seqPos}`;                  // ex: "S1"
const exCurrent = parseInt(getVar(`${seqKey}_Exo_Current`) || 0, 10); // ex: 3
const historique = getVar(`${seqKey}_Win_Lose`) || ""; // ex: "110010"

// -------- SÉCURITÉ --------
if (!seqPos || !historique) {
  console.warn("⚠️ Impossible d'exécuter le script — séquence ou historique manquant.");
  return;
}

// ============================================================
// 🔍 RECHERCHE DU PROCHAIN ÉCHEC ("0")
// ============================================================

// On cherche le prochain "0" APRÈS la position actuelle
const nextFailIndex = historique.indexOf("0", exCurrent);

// ============================================================
// 🎯 MISE À JOUR OU FIN DE LA RÉVISION
// ============================================================

if (nextFailIndex === -1) {
  // Aucun autre exercice échoué trouvé → fin du mode révision
  setVar("S0_Revision_Erreurs", 2);
  console.log("🎉 Tous les exercices échoués ont été revus — fin du mode révision (S0_Revision_Erreurs = 2).");
} else {
  // Prochain exercice échoué trouvé
  const nextExercise = nextFailIndex + 1; // index → position 1-based
  setVar("0_Position_Exercice", nextExercise);
  console.log(`🔁 Révision → Prochain exercice échoué : EX${nextExercise}`);
}

console.log(`(Séquence : ${seqKey}, Historique : "${historique}")`);

}

window.Script127 = function()
{
  // ============================================================
// 🎬 REMPLACEMENT DYNAMIQUE DE VIDÉO (version simplifiée)
// ============================================================
// Remplace directement la vidéo de l'objet Storyline (ID fixe)
// avec le chemin complet contenu dans la variable "Ex_Video".
// ============================================================

// -------- Lecture de la variable --------
const newVideoPath = getVar("Ex_Video"); // ex: "Ressources_Sequences/S1/Videos/S1_EX1.mp4"

// -------- Sécurité --------
if (!newVideoPath || newVideoPath.trim() === "") {
  console.warn("⚠️ Aucune vidéo spécifiée dans Ex_Video — remplacement annulé.");
  return;
}

// -------- Sélection directe de la vidéo --------
const videoElement = document.querySelector('[data-model-id="5pTX8N7gCDH"] video');
if (!videoElement) {
  console.error("❌ Impossible de trouver la vidéo avec data-model-id=5pTX8N7gCDH.");
  return;
}

// -------- Remplacement de la source --------
videoElement.setAttribute("xlink:href", newVideoPath);
videoElement.src = newVideoPath;
videoElement.load();

// -------- Suppression de la vignette (poster) --------
const container = videoElement.closest('[data-model-id="5pTX8N7gCDH"]');
if (container) {
  const poster = container.querySelector("img.video-player-poster");
  if (poster) {
    poster.remove();
    console.log("✅ Vignette (poster) supprimée — la 1ère image de la vidéo sera visible.");
  }
}
}

window.Script128 = function()
{
  // ============================================================
// 🖼️ REMPLACEMENT DYNAMIQUE D’IMAGE (version simplifiée)
// ============================================================
// Remplace directement l’image de l’objet Storyline (ID fixe)
// avec le chemin complet contenu dans la variable "Ex_Image".
// Aucun calcul de dossier ou de chemin n’est effectué.
// ============================================================

// -------- Lecture de la variable --------
const newImagePath = getVar("Ex_Image"); // ex: "Ressources_Sequences/S1/images/EX1.jpg"

// -------- Sécurité --------
if (!newImagePath || newImagePath.trim() === "") {
  console.warn("⚠️ Aucune image spécifiée dans Ex_Image — remplacement annulé.");
  return;
}

// -------- Sélection directe de l’image --------
const imageElement = document.querySelector('[data-model-id="6jUy2ox5l86"] image');
if (!imageElement) {
  console.error("❌ Impossible de trouver l’image avec data-model-id=6jUy2ox5l86.");
  return;
}

// -------- Remplacement du lien --------
imageElement.setAttributeNS("http://www.w3.org/1999/xlink", "xlink:href", newImagePath);

}

window.Script129 = function()
{
  // ============================================================
// 🖼️ REMPLACEMENT DYNAMIQUE D’IMAGE (version simplifiée)
// ============================================================
// Remplace directement l’image de l’objet Storyline (ID fixe)
// avec le chemin complet contenu dans la variable "Ex_Image".
// Aucun calcul de dossier ou de chemin n’est effectué.
// ============================================================

// -------- Lecture de la variable --------
const newImagePath = getVar("Ex_Image"); // ex: "Ressources_Sequences/S1/images/EX1.jpg"

// -------- Sécurité --------
if (!newImagePath || newImagePath.trim() === "") {
  console.warn("⚠️ Aucune image spécifiée dans Ex_Image — remplacement annulé.");
  return;
}

// -------- Sélection directe de l’image --------
const imageElement = document.querySelector('[data-model-id="6c22D92goAT"] image');
if (!imageElement) {
  console.error("❌ Impossible de trouver l’image avec data-model-id=6c22D92goAT.");
  return;
}

// -------- Remplacement du lien --------
imageElement.setAttributeNS("http://www.w3.org/1999/xlink", "xlink:href", newImagePath);

}

window.Script130 = function()
{
  // ============================================================
// ⚙️ BARRE DE PROGRESSION — SYNCHRONISATION AVEC LA SÉQUENCE EN COURS
// ============================================================

// --------- Lecture de la séquence courante ---------
const seqPos = getVar("0_Position_Sequence");   // ex. 1 → S1
const seqKey = `S${seqPos}`;

// --------- Lecture des variables de la séquence correspondante ---------
const Exo_Reached = getVar("S0_Exo_Reached") || 0;
const Exo_Total = getVar("S0_Exo_Total") || 1;

// --------- Calcul du pourcentage ---------
const progress = Math.min(Exo_Reached / Exo_Total, 1); // clamp entre 0 et 1

// --------- Sélectionne l'objet Storyline ---------
const ProgressBar = document.querySelector(`[data-model-id="6f561U28wA4"]`);

if (ProgressBar) {
  // --------- Sélectionne l'élément graphique principal ---------
  const shape = ProgressBar.querySelector("path");

  if (shape) {
    // Si ce n’est pas déjà fait, on garde la largeur d’origine
    if (!shape.dataset.fullWidth) {
      const bbox = shape.getBBox();
      shape.dataset.fullWidth = bbox.width;
    }

    // --------- Calcul de la largeur selon la progression ---------
    const fullWidth = parseFloat(shape.dataset.fullWidth);

    // --------- Application du remplissage via clip-path ---------
    shape.style.clipPath = `inset(0 ${100 - progress * 100}% 0 0 round 0px)`;
  }
}

}

window.Script131 = function()
{
  // ============================================================
// ⚙️ BARRE DE PROGRESSION ANIMÉE (AVEC INITIALISATION INTELLIGENTE)
// ============================================================

// Durée de l’animation en millisecondes (modifiable)
const animationDuration = 800; // 0.8s = fluide, 300 = rapide, 1500 = lente

function updateProgressBarAnimated() {
  // --------- Lecture de la séquence courante ---------
  const seqPos = getVar("0_Position_Sequence");
  const seqKey = `S${seqPos}`;

  // --------- Lecture des variables globales S0 ---------
  const Exo_Reached = getVar("S0_Exo_Reached") || 0;
  const Exo_Total = getVar("S0_Exo_Total") || 1;
  const progress = Math.min(Exo_Reached / Exo_Total, 1);

  // --------- Sélectionne l'objet Storyline ---------
  const ProgressBar = document.querySelector(`[data-model-id="6f561U28wA4"]`);
  if (!ProgressBar) return;

  const shape = ProgressBar.querySelector("path");
  if (!shape) return;

  // --------- Initialisation si nécessaire ---------
  if (!shape.dataset.fullWidth) {
    const bbox = shape.getBBox();
    shape.dataset.fullWidth = bbox.width;
  }

  // --------- Nouvelle logique : position initiale intelligente ---------
  let startProgress;

  if (shape.dataset.currentProgress !== undefined) {
    // On continue à partir de la progression actuelle
    startProgress = parseFloat(shape.dataset.currentProgress) || 0;
  } else if (Exo_Reached >= 1) {
    // Si aucune donnée mais au moins un exercice complété,
    // on démarre au niveau précédent
    startProgress = (Exo_Reached - 1) / Exo_Total;
  } else {
    // Sinon, tout au début
    startProgress = 0;
  }

  const startTime = performance.now();

  // --------- Fonction d'animation fluide ---------
  function animate(time) {
    const elapsed = time - startTime;
    const t = Math.min(elapsed / animationDuration, 1);
    const eased = t < 0.5 ? 2 * t * t : -1 + (4 - 2 * t) * t; // easeInOutQuad

    const currentProgress = startProgress + (progress - startProgress) * eased;
    shape.style.clipPath = `inset(0 ${100 - currentProgress * 100}% 0 0 round 0px)`;
    shape.dataset.currentProgress = currentProgress;

    if (t < 1) requestAnimationFrame(animate);
  }

  requestAnimationFrame(animate);
}

// ============================================================
// ▶️ APPEL DU SCRIPT (exécuté manuellement via trigger JS)
// ============================================================

updateProgressBarAnimated();

}

window.Script132 = function()
{
  // -------- Initialisation --------

// Récupère le numéro ou identifiant d'exercice (ex: "EX2")
const AudioPath = getVar("0_Audio_Lecteur");

// Si un audio était déjà en cours → on le stoppe et on remet au début
if (window.audioUnique) {
  window.audioUnique.pause();
  window.audioUnique.currentTime = 0;
}

// Crée un nouvel objet audio
window.audioUnique = new Audio(AudioPath);

// Lecture
window.audioUnique.play().catch(err => {
  console.log("Erreur lecture Back :", err);
});
}

window.Script133 = function()
{
  // ============================================================
// 🎯 MISE À JOUR DES VARIABLES Sx_Win_Lose SELON Ex_Success (texte)
// ============================================================

// -------- Lecture des variables Storyline --------
const seqPos  = getVar("0_Position_Sequence");
const exPos   = getVar("0_Position_Exercice");
const success = getVar("Ex_Success");

// -------- Construction du nom de la séquence --------
const seqKey     = `S${seqPos}`;
const winLoseVar = `${seqKey}_Win_Lose`;

// -------- Lecture actuelle de la variable Win_Lose --------
let winLose = getVar(winLoseVar) || "";

// -------- S’assure que la longueur correspond au nombre total d’exercices --------
const total = getVar(`0_Menu_${seqKey}_Exo_Total`);

// -------- Conversion en tableau pour modification --------
const chars = winLose.split("");

// -------- Mise à jour du caractère correspondant à l’exercice actuel --------
if (!(chars[exPos - 1] === "1" && success === "0")) {
    chars[exPos - 1] = success === "1" ? "1" : "0";
}
// Si l'exercice est déjà réussi, on garde la réussite.

// -------- Conversion inverse en chaîne --------
winLose = chars.join("");

// -------- Écriture dans Storyline --------
setVar(winLoseVar, winLose);

// ============================================================
// 🔁 SWITCH AUTOMATIQUE DE 0_Feedback_Switch
// ============================================================
let feedbackSwitch = getVar("0_Feedback_Switch");
feedbackSwitch = feedbackSwitch === true || feedbackSwitch === "true" ? false : true;
setVar("0_Feedback_Switch", feedbackSwitch);

}

window.Script134 = function()
{
  // ============================================================
// 🏁 SCRIPT DE FIN D’EXERCICE — MISE À JOUR PROGRESSION & TENTATIVES
// ============================================================

// -------- CONFIGURATION --------
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;

const exCurrent  = parseInt(getVar(`${seqKey}_Exo_Current`), 10);
const exReached  = parseInt(getVar(`${seqKey}_Exo_Reached`), 10);
const tentVar    = `${seqKey}_Exo_Current_Tentatives`;
// ============================================================
// 🧭 MISE À JOUR DE LA PROGRESSION
// ============================================================

// Si on avance (évite de revenir en arrière)
if (exCurrent > exReached) {
  setVar(`${seqKey}_Exo_Reached`, exCurrent);
  setVar("S0_Exo_Reached", exCurrent); 
}

// ============================================================
// 🧮 MARQUAGE DE L’EXERCICE TERMINÉ
// ============================================================

setVar(tentVar, -10);

}

window.Script135 = function()
{
  // ============================================================
// 🧠 SAUVEGARDE AUTOMATIQUE DES DONNÉES UTILISATEUR (GLOBAL)
// ============================================================
//
// 🔹 Ce script est appelé automatiquement après la validation d’un exercice.
// 🔹 Il détecte le type d’exercice et sauvegarde la réponse dans la variable JSON
//    correspondante (ex: S1_UserData)
//
// ============================================================

// ------------------------------------------------------------
// 🔧 Lecture des infos de contexte
// ------------------------------------------------------------
const seqPos = getVar("0_Position_Sequence");           // ex: "1"
const exPos = parseInt(getVar("0_Position_Exercice"), 10);
const seqKey = `S${seqPos}`;
const exType = getVar("Ex_Type");
const success = getVar("Ex_Success");
const tentativesRestantes = parseInt(getVar("Ex_Tentatives"), 10);

// Variable cible (ex: "S1_UserData")
const userDataVar = `${seqKey}_UserData`;

// ------------------------------------------------------------
// 🔧 Lecture du JSON existant
// ------------------------------------------------------------
let data = {};
try {
  const existing = getVar(userDataVar);
  data = existing ? JSON.parse(existing) : {};
} catch (err) {
  console.warn(`⚠️ JSON invalide dans ${userDataVar}, réinitialisation.`, err);
  data = {};
}

// ------------------------------------------------------------
// 🧮 Tentatives initiales (si dispo dans cache global)
// ------------------------------------------------------------
let tentativesInitiales = 0;
try {
  const exData = window.sequenceCache?.[seqKey]?.[`EX${exPos}`];
  tentativesInitiales = exData?.Tentatives || 1;
} catch {
  tentativesInitiales = 1;
}

const tentativesUtilisees = Math.max(0, tentativesInitiales - tentativesRestantes);

// ------------------------------------------------------------
// 🎯 Récupération de la réponse selon le type d’exercice
// ------------------------------------------------------------
let userResponseObj = {};

switch (exType) {
  // 🔹 QCU
  case "QCU": {
    const answerKey = getVar("0_Reponse");
    const answerText = getVar(`0_Choix_${answerKey}`) || "";
    userResponseObj = { [answerKey]: answerText };
    break;
  }

  // 🔹 QCM
  case "QCM": {
    const responseRaw = (getVar("0_Reponse") || "").split("|").filter(Boolean);
    responseRaw.forEach(k => {
      userResponseObj[k] = getVar(`0_Choix_${k}`) || "";
    });
    break;
  }

  // 🔹 True or false
  case "True or false": {
    const answer = (getVar("0_Reponse") || "").toLowerCase();
    userResponseObj = { unique: answer };
    break;
  }

  // 🔹 Complete
  case "Complete": {
    const answer = getVar("0_Ex_Enonce") || "";
    userResponseObj = { unique: answer };
    break;
  }

  // 🔹 Matching
  case "Matching": {
    const reponse = getVar("0_Reponse") || "";
    userResponseObj = { associations: reponse };
    break;
  }

  // 🔹 Flashcard
  case "Flashcard": {
    const answer = getVar("0_Reponse") || "";
    userResponseObj = { unique: answer };
    break;
  }

  // 🔹 Information
  case "Information": {
    userResponseObj = { info: "Aucune interaction" };
    break;
  }

  // 🔹 Production orale - dictée
  case "Production orale - dictée": {
    const raw = getVar("0_Reponse") || "{}";
    try {
      const parsed = JSON.parse(raw);
      userResponseObj = {
        score: parsed.score || 0,
        texte_brut: parsed.texte_brut || "",
        texte_color: parsed.texte_color || ""
      };
    } catch (err) {
      console.warn("⚠️ Erreur de parsing JSON pour Production orale :", err);
      userResponseObj = { erreur: "Format de réponse invalide", raw };
    }
    break;
  }

  // 🔹 Défaut
  default: {
    const raw = getVar("0_Reponse") || "";
    userResponseObj = { inconnu: raw };
    console.warn(`❓ Type d’exercice inconnu : ${exType}`);
    break;
  }
}

// ------------------------------------------------------------
// 💾 Enregistrement dans le JSON
// ------------------------------------------------------------
data[`EX${exPos}`] = {
  Type: exType,
  Reponses_Choisies: userResponseObj,
  Statut: success,
  Tentatives_Utilisees: tentativesUtilisees
};

setVar(userDataVar, JSON.stringify(data));

// ------------------------------------------------------------
// 🧾 Log de contrôle
// ------------------------------------------------------------
console.group(`💾 Données sauvegardées → ${userDataVar}`);
console.log("Exercice :", `EX${exPos}`);
console.log("Type :", exType);
console.log("Réponses :", userResponseObj);
console.log("Statut :", success);
console.log("Tentatives utilisées :", tentativesUtilisees);
console.log("JSON complet :", data);
console.groupEnd();

}

window.Script136 = function()
{
  // ============================================================
// 🎯 COMPLETE — VÉRIFICATION DE LA RÉPONSE + COLORATION (si EasyMode)
// ============================================================

// 🎨 Couleurs
const colorCorrect = "#0EBE75";
const colorIncorrect = "#f19097";

// --------- Lecture des variables Storyline ---------
let userAnswerRaw   = getVar("0_Reponse") || "";
let correctionRaw   = getVar("0_Ex_Correction") || "";
let tentatives      = parseInt(getVar("Ex_Tentatives"), 10);
const seqPos        = getVar("0_Position_Sequence");
const seqKey        = `S${seqPos}`;
const tentVar       = `${seqKey}_Exo_Current_Tentatives`;

let CompteurTentatives    = parseInt(getVar("Ex_Compteur_Tentatives"), 10);
const CompteurTentativesVar = `${seqKey}_Exo_Current_Compteur_Tentatives`;
let success = getVar("Ex_Success") || "";

const easyMode = getVar("0_EasyMode") === true || getVar("0_EasyMode") === "true";

// ============================================================
// 🧼 FONCTIONS DE NETTOYAGE
// ============================================================

// 🔹 Supprime balises HTML et espaces multiples
function cleanText(txt) {
  return txt
    .replace(/<[^>]+>/g, "")
    .replace(/\s+/g, " ")
    .replace(/[’']/g, "'")
    .trim()
    .toLowerCase();
}

// 🔹 Transforme la correction "#mot#" → "mot"
function expandCorrection(txt) {
  return txt.replace(/#/g, "");
}

// ============================================================
// 🧩 TRAITEMENT DES CHAÎNES
// ============================================================
const userAnswerClean   = cleanText(userAnswerRaw);
const correctExpanded   = cleanText(expandCorrection(correctionRaw));

console.group("🧠 COMPLETE — Vérification");
console.log("🧽 Réponse utilisateur nettoyée :", userAnswerClean);
console.log("✅ Correction attendue :", correctExpanded);
console.groupEnd();

// ============================================================
// 🧮 VÉRIFICATION DE LA RÉPONSE
// ============================================================

// ✅ Réponse entièrement correcte
if (userAnswerClean === correctExpanded && userAnswerClean.length > 0) {
  success = "1";
  console.log("🎯 Réponse parfaitement correcte !");
} else {
  // ❌ Réponse incorrecte
  if (tentatives > 0) {
    tentatives -= 1;
    console.log(`⚠️ Réponse incorrecte — Tentatives restantes : ${tentatives}`);
  }
  if (tentatives <= 0) {
    success = "0";
    console.log("🚫 Aucune tentative restante — échec final.");
  }
}

CompteurTentatives++;

// ============================================================
// 💾 MISE À JOUR DES VARIABLES STORYLINE
// ============================================================
setVar("Ex_Tentatives", tentatives);
setVar(tentVar, tentatives);

setVar("Ex_Compteur_Tentatives", CompteurTentatives);
setVar(CompteurTentativesVar, CompteurTentatives);

setVar("Ex_Success", success);
setVar("0_Complete_Reponse_Temporaire", userAnswerRaw);

// 🚩 Si l’exercice est terminé (réussi ou épuisé)
if (success === "1" || tentatives <= 0) {
  setVar(tentVar, -10); // signal de fin pour la séquence
}

console.log("📊 Vérification terminée — Succès =", success);

// ============================================================
// 🌈 COLORATION SI EASYMODE ACTIVÉ
// ============================================================
if (easyMode) {
  console.log("🟢 EasyMode activé → Affichage coloré des réponses");

  // --- 1️⃣ Génération de la correction colorée ---
  let id = 1;
  const correctionHTML = correctionRaw.replace(/#(.*?)#/g, (_, mot) => {
    return `<font class="complete_answer" data-correction-id="${id++}" color="${colorCorrect}">${mot.trim()}</font>`;
  });

  // --- 2️⃣ Comparaison avec la réponse utilisateur ---
  const corrDiv = document.createElement("div");
  corrDiv.innerHTML = correctionHTML;

  const respDiv = document.createElement("div");
  respDiv.innerHTML = userAnswerRaw;

  const corrFonts = [...corrDiv.querySelectorAll("font.complete_answer")];
  const respFonts = [...respDiv.querySelectorAll("font.complete_blank")];

  for (let i = 0; i < respFonts.length; i++) {
    const userFont = respFonts[i];
    const correctFont = corrFonts[i];
    if (!userFont || !correctFont) continue;

    const userText = (userFont.textContent || "").trim().toLowerCase();
    const correctText = (correctFont.textContent || "").trim().toLowerCase();

    userFont.setAttribute("color", userText === correctText ? colorCorrect : colorIncorrect);
  }

  // --- 3️⃣ Injection du résultat dans Storyline ---
  const updatedResponseHTML = respDiv.innerHTML;
  setVar("0_Ex_Enonce", updatedResponseHTML);

  console.log("🎨 Réponse colorée affichée dans 0_Ex_Enonce :", updatedResponseHTML);
}

}

window.Script137 = function()
{
  // ============================================================
// 💬 COMPLETE — COLORATION DES RÉPONSES ET DE LA CORRECTION COMPLÈTE
// ============================================================

// 🎨 Couleurs
// Les 3èmes teintes sombre du vert/rouge de correction
// Pour des raisons de lisibilité sur le blanc #FFFFFF
const colorCorrect = "#064C2F";
const colorIncorrect = "#5D1F23";

// ============================================================
// 1️⃣ — GÉNÉRATION DE LA CORRECTION COLORÉE (à partir des #)
// ============================================================
let correctionRaw = getVar("0_Ex_Correction") || "";
let id = 1;

// On remplace les #mots# par des balises colorées tout en gardant le reste du texte
const correctionHTML = correctionRaw.replace(/#(.*?)#/g, (_, mot) => {
  return `<font class="complete_answer" data-correction-id="${id++}" color="${colorCorrect}">${mot.trim()}</font>`;
});

// Mise à jour dans Storyline
setVar("0_Ex_Correction", correctionHTML);

// ============================================================
// 2️⃣ — COMPARAISON AVEC LA RÉPONSE UTILISATEUR (si elle existe)
// ============================================================

const userResponseRaw = getVar("0_Reponse") || "";
const seqPos = getVar("0_Position_Sequence");
const exPos = parseInt(getVar("0_Position_Exercice") || 0, 10);
const seqKey = `S${seqPos}`;
const userDataVar = `${seqKey}_UserData`;

if (userResponseRaw.trim() !== "") {
  // --- Préparation DOMs virtuels ---
  const corrDiv = document.createElement("div");
  corrDiv.innerHTML = correctionHTML;

  const respDiv = document.createElement("div");
  respDiv.innerHTML = userResponseRaw;

  const corrFonts = [...corrDiv.querySelectorAll("font.complete_answer")];
  const respFonts = [...respDiv.querySelectorAll("font.complete_blank")];

  // --- Comparaison mot par mot ---
  for (let i = 0; i < respFonts.length; i++) {
    const userFont = respFonts[i];
    const correctFont = corrFonts[i];
    if (!userFont || !correctFont) continue;

    const userText = (userFont.textContent || "").trim().toLowerCase();
    const correctText = (correctFont.textContent || "").trim().toLowerCase();

    userFont.setAttribute("color", userText === correctText ? colorCorrect : colorIncorrect);
  }

  // --- Injection du résultat dans Storyline ---
  const updatedResponseHTML = respDiv.innerHTML;
  setVar("0_Ex_Enonce", updatedResponseHTML);

  // --- 🔁 Déclenchement du système d’enregistrement global ---
  // On inverse la valeur de 0_UserDataVar_Switch pour signaler un changement
  const currentSwitch = getVar("0_UserDataVar_Switch");
  const newSwitch = currentSwitch === true || currentSwitch === "true" ? false : true;
  setVar("0_UserDataVar_Switch", newSwitch);

  console.log("🎨 Réponse colorée complète :", updatedResponseHTML);
  console.log("💾 Signal d’enregistrement déclenché (0_UserDataVar_Switch).");
}
// ============================================================
// 3️⃣ — SINON : RESTAURATION D’UNE RÉPONSE EXISTANTE
// ============================================================
else {
  try {
    const existing = JSON.parse(getVar(userDataVar) || "{}");
    const savedHTML = existing[`EX${exPos}`]?.Reponses_Choisies?.unique || "";

    if (savedHTML) {
      setVar("0_Ex_Enonce", savedHTML);
      console.log("💾 Réponse restaurée depuis UserData :", savedHTML);
    } else {
      console.log(`ℹ️ Aucune réponse sauvegardée pour EX${exPos}.`);
    }
  } catch (err) {
    console.warn("⚠️ Impossible de lire les UserData :", err);
  }
}

}

window.Script138 = function()
{
  // ============================================================
// 🧩 COMPLETE — INITIALISATION DU TEXTE AVEC BALISES STRUCTURÉES
// ============================================================

// 💡 Couleur du trou actif
const colorTrouActif = "#3443f7";

// --------------- Variables Storyline ---------------
let texteIncomplet = getVar("0_Complete_IncompleteTexte") || "";

// --------------- Fonction principale ---------------
function initCompleteText(texte) {
  // Remplace chaque série de tirets par une balise <font>
  let id = 1;
  const processed = texte.replace(/(_{2,})/g, (match) => {
    const length = match.length;
    const color = id === 1 ? ` color="${colorTrouActif}"` : "";
    const state = id === 1 ? "Actif" : "Inactif";
    return `<font class="complete_blank"${color} data-id="${id++}" data-length="${length}" data-state="${state}">${match}</font>`;
  });

  return processed;
}

// --------------- Exécution ---------------
const initialized = initCompleteText(texteIncomplet);
setVar("0_Ex_Enonce", initialized);
console.log("✅ COMPLETE initialisé :", initialized);

}

window.Script139 = function()
{
  // ============================================================
// ✏️ COMPLETE — SAISIE DE RÉPONSE + PASSAGE AU TROU SUIVANT
// ============================================================

// 💡 Couleur du trou actif
const colorTrouActif = "#3443f7";

// --------------- Lecture des variables Storyline ---------------
let reponse = getVar("0_Complete_Choix_Reponse") || "";
let enonce = getVar("0_Ex_Enonce") || "";

// --------------- Préparation DOM caché ---------------
const parserDiv = document.createElement("div");
parserDiv.style.display = "none";
parserDiv.innerHTML = enonce;
document.body.appendChild(parserDiv);

const blanks = [...parserDiv.querySelectorAll("font.complete_blank")];
const activeBlank = parserDiv.querySelector('font.complete_blank[data-state="Actif"]');

if (activeBlank) {
  // 🟦 Remplace le texte du trou actif par la réponse
  activeBlank.textContent = reponse;
  activeBlank.dataset.state = "Inactif";
  // On garde la couleur bleue pour indiquer qu’il a été rempli
  activeBlank.setAttribute("color", colorTrouActif);

  // ➡️ Trouver le suivant et l’activer
  const index = blanks.indexOf(activeBlank);
  const nextBlank = blanks[index + 1];

  if (nextBlank) {
    const length = parseInt(nextBlank.dataset.length || 4, 10);
    nextBlank.textContent = "_".repeat(length);
    nextBlank.dataset.state = "Actif";
    nextBlank.setAttribute("color", colorTrouActif);
  } else {
    console.log("✅ Plus de trous à compléter, texte complet.");
    setVar("0_Complete_Reponse_Temporaire", parserDiv.innerHTML)
  }
} else {
  console.warn("⚠️ Aucun trou actif trouvé.");
}

// --------------- Mise à jour Storyline ---------------
setVar("0_Ex_Enonce", parserDiv.innerHTML);
setVar("0_Complete_Choix_Reponse", ""); // reset du champ de saisie

document.body.removeChild(parserDiv);

}

window.Script140 = function()
{
  // ============================================================
// 🎯 COMPLETE — POSITIONNEMENT DYNAMIQUE DES CHOIX (2, 4 ou 5 réponses)
// ============================================================

// --- RÉCUPÉRATION DES OBJETS (boutons de choix) ---
const choix_A = object("6en9HfNUun8");
const choix_B = object("68fNqb3QKNi");
const choix_C = object("6r1qjgjnWIK");
const choix_D = object("6BSov5t1NNu");
const choix_E = object("69Gle80Bf4m");
const choix_F = object("6aNQoebqW09"); // non utilisé ici mais gardé pour compatibilité

// --- POSITIONS DE RÉFÉRENCE ---
const positionA2ou4 = object("5lSbDm05duT");
const positionB2ou4 = object("64zOOmQDR5K");
const positionD5ouPositionC4 = object("5wJYIAYhPnJ");
const positionE5ouPositionD4 = object("5s4RiaqoKhB");

// ============================================================
// 🧮 DÉTECTION DU NOMBRE DE CHOIX DISPONIBLES
// ============================================================
const choixVars = [
  getVar("0_Complete_Choix_A"),
  getVar("0_Complete_Choix_B"),
  getVar("0_Complete_Choix_C"),
  getVar("0_Complete_Choix_D"),
  getVar("0_Complete_Choix_E"),
  getVar("0_Complete_Choix_F")
];
const choixValides = choixVars.filter(txt => txt && txt.trim() !== "");
const nbChoix = choixValides.length;

console.log(`🧩 Nombre de choix détectés : ${nbChoix}`);

// ============================================================
// ⚙️ POSITIONNEMENT EN FONCTION DU NOMBRE DE CHOIX
// ============================================================

// --- CAS : 2 OU 4 RÉPONSES ---
if (nbChoix === 2 || nbChoix === 4) {
  if (choix_A && positionA2ou4) choix_A.x = positionA2ou4.x;
  if (choix_B && positionB2ou4) choix_B.x = positionB2ou4.x;

  if (nbChoix === 4) {
    if (choix_C && positionD5ouPositionC4) choix_C.x = positionD5ouPositionC4.x;
    if (choix_C && positionD5ouPositionC4) choix_C.y = positionD5ouPositionC4.y;
    if (choix_D && positionE5ouPositionD4) choix_D.x = positionE5ouPositionD4.x;
  }
}

// --- CAS : 5 RÉPONSES ---
else if (nbChoix === 5) {
  if (choix_D && positionD5ouPositionC4) choix_D.x = positionD5ouPositionC4.x;
  if (choix_E && positionE5ouPositionD4) choix_E.x = positionE5ouPositionD4.x;
}

console.log("📍 Positionnement des choix mis à jour selon le nombre de réponses.");

}

window.Script141 = function()
{
  // ============================================================
// 🔙 COMPLETE — RETOUR AU TROU PRÉCÉDENT (VERSION STABLE DOM)
// ============================================================

// 💡 Couleur du trou actif
const colorTrouActif = "#3443f7";

// ------------------------------------------------------------
// 🧩 Lecture du texte actuel (avec balises <font>)
// ------------------------------------------------------------
let enonce = getVar("0_Ex_Enonce") || "";
if (!enonce.includes("complete_blank")) {
  console.warn("⚠️ Aucun trou détecté dans l’énoncé.");
  return;
}

// ------------------------------------------------------------
// 🧱 Création d’un DOM caché pour manipulation propre
// ------------------------------------------------------------
const parserDiv = document.createElement("div");
parserDiv.style.display = "none";
parserDiv.innerHTML = enonce;
document.body.appendChild(parserDiv);

const blanks = [...parserDiv.querySelectorAll("font.complete_blank")];
if (blanks.length === 0) {
  console.warn("⚠️ Aucun élément complete_blank trouvé.");
  document.body.removeChild(parserDiv);
  return;
}

// ------------------------------------------------------------
// 🎯 Étape 1 — Chercher l’actif
// ------------------------------------------------------------
const activeBlank = parserDiv.querySelector('font.complete_blank[data-state="Actif"]');

if (activeBlank) {
  // Trouver le précédent
  const index = blanks.indexOf(activeBlank);
  const prevBlank = blanks[index - 1];

  // Passer l’actif en inactif
  activeBlank.dataset.state = "Inactif";
  activeBlank.removeAttribute("color");

  // S’il y a un précédent
  if (prevBlank) {
    const nbTirets = parseInt(prevBlank.dataset.length || 4, 10);
    prevBlank.dataset.state = "Actif";
    prevBlank.setAttribute("color", colorTrouActif);
    prevBlank.textContent = "_".repeat(nbTirets);
    console.log(`🔙 Trou précédent activé (#${prevBlank.dataset.id})`);
  } else {
    console.log("🔝 Aucun précédent à activer (on est déjà au premier trou).");
  }
} 
else {
  // ------------------------------------------------------------
  // ✴️ Étape 2 — Aucun trou actif → réactivation du dernier
  // ------------------------------------------------------------
  const lastBlank = blanks.at(-1);
  const nbTirets = parseInt(lastBlank.dataset.length || 4, 10);
  lastBlank.dataset.state = "Actif";
  lastBlank.setAttribute("color", colorTrouActif);
  lastBlank.textContent = "_".repeat(nbTirets);

  console.log(`🔁 Aucun trou actif trouvé → réactivation du dernier (#${lastBlank.dataset.id})`);
}

// ------------------------------------------------------------
// 💾 Mise à jour Storyline
// ------------------------------------------------------------
setVar("0_Ex_Enonce", parserDiv.innerHTML);
setVar("0_Complete_Reponse_Temporaire", "");

document.body.removeChild(parserDiv);

console.log("✅ Retour effectué sur le trou précédent.");

}

window.Script142 = function()
{
  // ============================================================
// 🔙 COMPLETE — RETOUR AU TROU PRÉCÉDENT (VERSION STABLE DOM)
// ============================================================

// 💡 Couleur du trou actif
const colorTrouActif = "#3443f7";

// ------------------------------------------------------------
// 🧩 Lecture du texte actuel (avec balises <font>)
// ------------------------------------------------------------
let enonce = getVar("0_Ex_Enonce") || "";
if (!enonce.includes("complete_blank")) {
  console.warn("⚠️ Aucun trou détecté dans l’énoncé.");
  return;
}

// ------------------------------------------------------------
// 🧱 Création d’un DOM caché pour manipulation propre
// ------------------------------------------------------------
const parserDiv = document.createElement("div");
parserDiv.style.display = "none";
parserDiv.innerHTML = enonce;
document.body.appendChild(parserDiv);

const blanks = [...parserDiv.querySelectorAll("font.complete_blank")];
if (blanks.length === 0) {
  console.warn("⚠️ Aucun élément complete_blank trouvé.");
  document.body.removeChild(parserDiv);
  return;
}

// ------------------------------------------------------------
// 🎯 Étape 1 — Chercher l’actif
// ------------------------------------------------------------
const activeBlank = parserDiv.querySelector('font.complete_blank[data-state="Actif"]');

if (activeBlank) {
  // Trouver le précédent
  const index = blanks.indexOf(activeBlank);
  const prevBlank = blanks[index - 1];

  // Passer l’actif en inactif
  activeBlank.dataset.state = "Inactif";
  activeBlank.removeAttribute("color");

  // S’il y a un précédent
  if (prevBlank) {
    const nbTirets = parseInt(prevBlank.dataset.length || 4, 10);
    prevBlank.dataset.state = "Actif";
    prevBlank.setAttribute("color", colorTrouActif);
    prevBlank.textContent = "_".repeat(nbTirets);
    console.log(`🔙 Trou précédent activé (#${prevBlank.dataset.id})`);
  } else {
    console.log("🔝 Aucun précédent à activer (on est déjà au premier trou).");
  }
} 
else {
  // ------------------------------------------------------------
  // ✴️ Étape 2 — Aucun trou actif → réactivation du dernier
  // ------------------------------------------------------------
  const lastBlank = blanks.at(-1);
  const nbTirets = parseInt(lastBlank.dataset.length || 4, 10);
  lastBlank.dataset.state = "Actif";
  lastBlank.setAttribute("color", colorTrouActif);
  lastBlank.textContent = "_".repeat(nbTirets);

  console.log(`🔁 Aucun trou actif trouvé → réactivation du dernier (#${lastBlank.dataset.id})`);
}

// ------------------------------------------------------------
// 💾 Mise à jour Storyline
// ------------------------------------------------------------
setVar("0_Ex_Enonce", parserDiv.innerHTML);
setVar("0_Complete_Reponse_Temporaire", "");

document.body.removeChild(parserDiv);

console.log("✅ Retour effectué sur le trou précédent.");

}

window.Script143 = function()
{
  // Récupère les objets Storyline
const carte  = document.querySelector('[data-model-id="6WOyyFcuLyH"]');
const bouton = document.querySelector('[data-model-id="5rCsry3VrNh"]');

// Points d'ancrage
carte.style.transformOrigin = "top left";
bouton.style.transformOrigin = "center";

// Timeline pour synchroniser
const tl = gsap.timeline();

tl.to(carte, {
  scale: 0,
  opacity: 0,
  duration: 0.5,
  ease: "power1.inOut"
}, 0);

// Rotation 90° du bouton en même temps
tl.to(bouton, {
  rotate: 0,          // ou "+=90" si tu veux ajouter 90° à chaque fois
  duration: 0.5,
  ease: "power1.inOut"
}, 0);

}

window.Script144 = function()
{
  // Récupère les objets Storyline
const carte  = document.querySelector('[data-model-id="6WOyyFcuLyH"]');
const bouton = document.querySelector('[data-model-id="5rCsry3VrNh"]');

// Points d'ancrage
carte.style.transformOrigin = "top left";
bouton.style.transformOrigin = "center";

// États initiaux
gsap.set(carte,  { scale: 0, opacity: 0 });
gsap.set(bouton, { rotate: 0 }); // ou 90 si tu veux qu'il démarre déjà tourné

// Timeline pour synchroniser
const tl = gsap.timeline();

tl.to(carte, {
  scale: 1,
  opacity: 1,
  duration: 0.5,
  ease: "power1.inOut"
}, 0);

// Rotation 90° du bouton en même temps
tl.to(bouton, {
  rotate: 45,          // ou "+=90" si tu veux ajouter 90° à chaque fois
  duration: 0.5,
  ease: "power1.inOut"
}, 0);

}

window.Script145 = function()
{
  // ============================================================
// 💬 FEEDBACK MOTIVATIONNEL — AVEC SUPPORT DU FORMAT "1101nn"
// ============================================================

// -------- VARIABLES DE BASE --------
let resultat = getVar("Ex_Success");
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;
const exCurrent = parseInt(getVar(`${seqKey}_Exo_Current`), 10);

// ============================================================
// 🔍 SI RESULTAT VIDE → CHERCHE DANS S1_Win_Lose ("1101nn")
// ============================================================
if (!resultat || resultat === "") {
  const historique = getVar(`${seqKey}_Win_Lose`) || "";
  const charAtIndex = historique.charAt(exCurrent - 1);

  if (charAtIndex === "1" || charAtIndex === "0") {
    resultat = charAtIndex;
  } else {
    console.log(`ℹ️ Aucun résultat valide trouvé dans ${seqKey}_Win_Lose à l’index ${exCurrent - 1}`);
  }
}

// ============================================================
// 💬 LISTES DE FEEDBACKS
// ============================================================
const feedbackCorrect = [
  "Bravo !",
  "Super !",
  "Bien joué !",
  "Excellent !"
];

const feedbackIncorrect = [
  "Pas exactement.",
  "Oups !",
  "La prochaine fois !"
];

const feedbackNeutre = [
  "Continue !"
];

// ============================================================
// 🎯 CHOIX DU FEEDBACK
// ============================================================
let liste;
switch (resultat) {
  case "1":
    liste = feedbackCorrect;
    break;
  case "0":
    liste = feedbackIncorrect;
    break;
  default:
    liste = feedbackNeutre;
    break;
}

// Sélection aléatoire dans la liste
const feedback = liste[Math.floor(Math.random() * liste.length)];

// ============================================================
// 🧾 MISE À JOUR STORYLINE
// ============================================================
setVar("Ex_Feedback_Motivation", feedback);

}

window.Script146 = function()
{
  // ============================================================
// 🔁 SCRIPT — ALLER AU PROCHAIN EXERCICE ÉCHOUÉ ("Réviser les erreurs")
// ============================================================

// -------- VARIABLES DE CONTEXTE --------
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;
const exCurrent = parseInt(getVar(`${seqKey}_Exo_Current`), 10);
const historique = getVar(`${seqKey}_Win_Lose`) || "";

// -------- SÉCURITÉ --------
if (!seqPos || !historique) {
  console.warn("⚠️ Impossible d'exécuter le script — séquence ou historique manquant.");
  return;
}

// ============================================================
// 🔍 RECHERCHE DU PROCHAIN ÉCHEC ("0")
// ============================================================

// On cherche le prochain "0" APRÈS la position actuelle
const nextFailIndex = historique.indexOf("0", exCurrent);

// ============================================================
// 🎯 MISE À JOUR OU FIN DE LA RÉVISION
// ============================================================

if (nextFailIndex === -1) {
  // Aucun autre exercice échoué trouvé → fin du mode révision
  setVar("S0_Revision_Erreurs", 2);

} else {
  // Prochain exercice échoué trouvé
  const nextExercise = nextFailIndex + 1; // index → position 1-based
  setVar("0_Position_Exercice", nextExercise);
}
}

window.Script147 = function()
{
  // ============================================================
// 🎯 ANIMATION DE JAUGE — Rotation + Oscillation continue + Feedback motivationnel + Indicateur visuel
// ============================================================

// -------- OBJETS STORYLINE --------
const pointer = object('5fZOHpnMbya');
const gauge = object('6nKxLAItMtB');

// -------- PARAMÈTRES --------
const minAngle = 0;
const maxAngle = 180;
const oscillationRange = 10;
const oscillationSpeed = 1.5;

// ============================================================
// 🧮 DETECTION DU RESULTAT + RECUPERATION VARIABLES STORYLINE
// ============================================================
let resultat = getVar("Ex_Success");
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;
const exCurrent = getVar(`${seqKey}_Exo_Current`);

// Si il n'y a pas de résultat direct, on tente de le retrouver dans Sx_Win_Lose
if (resultat === "") {
  const historique = getVar(`${seqKey}_Win_Lose`);
  const charAtIndex = historique.charAt(exCurrent - 1);
  if (charAtIndex === "1" || charAtIndex === "0") {
    resultat = charAtIndex;
  } else {
    console.log(`ℹ️ Aucun résultat valide trouvé dans ${seqKey}_Win_Lose à l’index ${exCurrent - 1}`);
    resultat = "";
  }
}

// ============================================================
// ⚙️ Changement couleur jauge
// ============================================================
if (resultat === "1") {
  gauge.state = "Correct" ;
} else if (resultat === "0") {
  gauge.state = "Incorrect" ;
}

// ============================================================
// ⚙️ CALCULS D’ANGLES
// ============================================================
const baseAngle = resultat * (maxAngle - minAngle) + minAngle;
const angleMin = baseAngle - oscillationRange;
const angleMax = baseAngle + oscillationRange;


const goingUp = resultat === "1";
const targetAngle = goingUp ? angleMax : angleMin;

// ============================================================
// 🧹 ARRÊTE LES ANIMATIONS EXISTANTES
// ============================================================
gsap.killTweensOf(pointer);

// ============================================================
// 🚀 ANIMATION DE L’AIGUILLE
// ============================================================
gsap.to(pointer, {
  rotation: targetAngle,
  duration: 1.2,
  ease: "power2.inOut",
  onComplete: () => {
    gsap.to(pointer, {
      rotation: goingUp ? angleMin : angleMax,
      duration: oscillationSpeed,
      ease: "sine.inOut",
      yoyo: true,
      repeat: -1
    });
  }
});

}

window.Script148 = function()
{
  const Btn_Affichage  = document.querySelector('[data-model-id="6geks01QgvK"]');
const temoin = object('6XIh2Zufqbt');

// (Optionnel mais recommandé) point d’ancrage de la rotation
Btn_Affichage.style.transformOrigin = "50% 50%";

// On lit l’état actuel puis on bascule
const isAffiche = (temoin.state === "Feedback_Affiche");

temoin.state = isAffiche ? "Feedback_Cache" : "Feedback_Affiche";

// Rotation GSAP (durée + easing ajustables)
gsap.to(Btn_Affichage, {
  rotation: isAffiche ? 180 : 0,
  duration: 0.45,
  ease: "power2.inOut",
  overwrite: "auto"
});

}

window.Script149 = function()
{
  // ============================================================
// 💬 FEEDBACK MOTIVATIONNEL — AVEC SUPPORT DU FORMAT "1101nn"
// ============================================================

// -------- VARIABLES DE BASE --------
let resultat = getVar("Ex_Success");
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;
const exCurrent = parseInt(getVar(`${seqKey}_Exo_Current`), 10);

// ============================================================
// 🔍 SI RESULTAT VIDE → CHERCHE DANS S1_Win_Lose ("1101nn")
// ============================================================
if (!resultat || resultat === "") {
  const historique = getVar(`${seqKey}_Win_Lose`) || "";
  const charAtIndex = historique.charAt(exCurrent - 1);

  if (charAtIndex === "1" || charAtIndex === "0") {
    resultat = charAtIndex;
  } else {
    console.log(`ℹ️ Aucun résultat valide trouvé dans ${seqKey}_Win_Lose à l’index ${exCurrent - 1}`);
  }
}

// ============================================================
// 💬 LISTES DE FEEDBACKS
// ============================================================
//const feedbackCorrect = [
//  "Bravo !",
//  "Super !",
//  "Bien joué !",
//  "Excellent !"
//];

//const feedbackIncorrect = [
//  "Pas exactement.",
//  "Oups !",
//  "La prochaine fois !"
//];

const feedbackCorrect = [
  "Bravo, c'est une bonne réponse !",
  "Super, tu es sur la bonne voie !",
  "Bien joué, tu progresses !",
  "Excellent, continue comme ça !"
];

const feedbackIncorrect = [
  "Ce n'est pas tout à fait ça.",
  "Oups, ce n'est pas la bonne réponse.",
  "Tu y arriveras la prochaine fois !",
  "Pas exactement. Encore un effort !"
];


const feedbackNeutre = [
  "Continue !"
];

// ============================================================
// 🎯 CHOIX DU FEEDBACK
// ============================================================
let liste;
switch (resultat) {
  case "1":
    liste = feedbackCorrect;
    break;
  case "0":
    liste = feedbackIncorrect;
    break;
  default:
    liste = feedbackNeutre;
    break;
}

// Sélection aléatoire dans la liste
const feedback = liste[Math.floor(Math.random() * liste.length)];

// ============================================================
// 🧾 MISE À JOUR STORYLINE
// ============================================================
setVar("Ex_Feedback_Motivation", feedback);

}

window.Script150 = function()
{
  // ============================================================
// 🔁 SCRIPT — ALLER AU PROCHAIN EXERCICE ÉCHOUÉ ("Réviser les erreurs")
// ============================================================

// -------- VARIABLES DE CONTEXTE --------
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;
const exCurrent = parseInt(getVar(`${seqKey}_Exo_Current`), 10);
const historique = getVar(`${seqKey}_Win_Lose`) || "";

// -------- SÉCURITÉ --------
if (!seqPos || !historique) {
  console.warn("⚠️ Impossible d'exécuter le script — séquence ou historique manquant.");
  return;
}

// ============================================================
// 🔍 RECHERCHE DU PROCHAIN ÉCHEC ("0")
// ============================================================

// On cherche le prochain "0" APRÈS la position actuelle
const nextFailIndex = historique.indexOf("0", exCurrent);

// ============================================================
// 🎯 MISE À JOUR OU FIN DE LA RÉVISION
// ============================================================

if (nextFailIndex === -1) {
  // Aucun autre exercice échoué trouvé → fin du mode révision
  setVar("S0_Revision_Erreurs", 2);

} else {
  // Prochain exercice échoué trouvé
  const nextExercise = nextFailIndex + 1; // index → position 1-based
  setVar("0_Position_Exercice", nextExercise);
}
}

window.Script151 = function()
{
  // ============================================================
// 🎯 ANIMATION DE JAUGE — Rotation + Oscillation continue + Feedback motivationnel + Indicateur visuel
// ============================================================

// -------- OBJETS STORYLINE --------
const pointer = object('61WVHrM0EGs');
//const gauge = object('5lezhyLYUu5'); Cet objet n'existe pas ?
const gauge = object('6rIRKS6iuFv');


// -------- PARAMÈTRES --------
const minAngle = 0;
const maxAngle = 180;
const oscillationRange = 10;
const oscillationSpeed = 1.5;

// ============================================================
// 🧮 DETECTION DU RESULTAT + RECUPERATION VARIABLES STORYLINE
// ============================================================
let resultat = getVar("Ex_Success");
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;
const exCurrent = getVar(`${seqKey}_Exo_Current`);

// Si il n'y a pas de résultat direct, on tente de le retrouver dans Sx_Win_Lose
if (resultat === "") {
  const historique = getVar(`${seqKey}_Win_Lose`);
  const charAtIndex = historique.charAt(exCurrent - 1);
  if (charAtIndex === "1" || charAtIndex === "0") {
    resultat = charAtIndex;
  } else {
    console.log(`ℹ️ Aucun résultat valide trouvé dans ${seqKey}_Win_Lose à l’index ${exCurrent - 1}`);
    resultat = "";
  }
}

// ============================================================
// ⚙️ Changement couleur jauge
// ============================================================
if (resultat === "1") {
  gauge.state = "Correct" ;
} else if (resultat === "0") {
  gauge.state = "Incorrect" ;
}

// ============================================================
// ⚙️ CALCULS D’ANGLES
// ============================================================
const baseAngle = resultat * (maxAngle - minAngle) + minAngle;
const angleMin = baseAngle - oscillationRange;
const angleMax = baseAngle + oscillationRange;


const goingUp = resultat === "1";
const targetAngle = goingUp ? angleMax : angleMin;

// ============================================================
// 🧹 ARRÊTE LES ANIMATIONS EXISTANTES
// ============================================================
gsap.killTweensOf(pointer);

// ============================================================
// 🚀 ANIMATION DE L’AIGUILLE
// ============================================================
gsap.to(pointer, {
  rotation: targetAngle,
  duration: 1.2,
  ease: "power2.inOut",
  onComplete: () => {
    gsap.to(pointer, {
      rotation: goingUp ? angleMin : angleMax,
      duration: oscillationSpeed,
      ease: "sine.inOut",
      yoyo: true,
      repeat: -1
    });
  }
});

}

window.Script152 = function()
{
  const Btn_Affichage  = document.querySelector('[data-model-id="6RRLU9ixx38"]');
const temoin = object('68ikzB1cq1L');

// (Optionnel mais recommandé) point d’ancrage de la rotation
Btn_Affichage.style.transformOrigin = "50% 50%";

// On lit l’état actuel puis on bascule
const isAffiche = (temoin.state === "Feedback_Affiche");

temoin.state = isAffiche ? "Feedback_Cache" : "Feedback_Affiche";

// Rotation GSAP (durée + easing ajustables)
gsap.to(Btn_Affichage, {
  rotation: isAffiche ? 180 : 0,
  duration: 0.45,
  ease: "power2.inOut",
  overwrite: "auto"
});

}

window.Script153 = function()
{
  // Récupère le résultat
let resultat = getVar("Ex_Success");

// Définit les listes de feedback
const feedbackCorrect = [
  "Bravo !",
  "Super !",
  "Bien joué !",
  "Excellent !"
];

const feedbackIncorrect = [
  "Pas exactement",
  "Oups !",
  "La prochaine fois !"
];

// Choisit la liste en fonction du résultat
let liste = (resultat === "1") ? feedbackCorrect : feedbackIncorrect;

// Sélectionne un élément aléatoire dans la liste
let feedback = liste[Math.floor(Math.random() * liste.length)];

// Met à jour la variable Storyline
setVar("Ex_Feedback_Motivation", feedback);

}

window.Script154 = function()
{
  // ============================================================
// 🎯 ANIMATION DE JAUGE — Rotation + Oscillation continue + Feedback motivationnel + Indicateur visuel
// ============================================================

// -------- OBJETS STORYLINE --------
const pointer = object('5Ux37gXcJcw');
const gauge = object('5enGetq7POY');

// -------- PARAMÈTRES --------
const minAngle = 0;
const maxAngle = 180;
const oscillationRange = 10;
const oscillationSpeed = 1.5;

// ============================================================
// 🧮 DETECTION DU RESULTAT + RECUPERATION VARIABLES STORYLINE
// ============================================================
let resultat = getVar("Ex_Success");
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;
const exCurrent = getVar(`${seqKey}_Exo_Current`);

// Si il n'y a pas de résultat direct, on tente de le retrouver dans Sx_Win_Lose
if (resultat === "") {
  const historique = getVar(`${seqKey}_Win_Lose`);
  const charAtIndex = historique.charAt(exCurrent - 1);
  if (charAtIndex === "1" || charAtIndex === "0") {
    resultat = charAtIndex;
  } else {
    console.log(`ℹ️ Aucun résultat valide trouvé dans ${seqKey}_Win_Lose à l’index ${exCurrent - 1}`);
    resultat = "";
  }
}

// ============================================================
// ⚙️ Changement couleur jauge
// ============================================================
if (resultat === "1") {
  gauge.state = "Correct" ;
} else if (resultat === "0") {
  gauge.state = "Incorrect" ;
}

// ============================================================
// ⚙️ CALCULS D’ANGLES
// ============================================================
const baseAngle = resultat * (maxAngle - minAngle) + minAngle;
const angleMin = baseAngle - oscillationRange;
const angleMax = baseAngle + oscillationRange;


const goingUp = resultat === "1";
const targetAngle = goingUp ? angleMax : angleMin;

// ============================================================
// 🧹 ARRÊTE LES ANIMATIONS EXISTANTES
// ============================================================
gsap.killTweensOf(pointer);

// ============================================================
// 🚀 ANIMATION DE L’AIGUILLE
// ============================================================
gsap.to(pointer, {
  rotation: targetAngle,
  duration: 1.2,
  ease: "power2.inOut",
  onComplete: () => {
    gsap.to(pointer, {
      rotation: goingUp ? angleMin : angleMax,
      duration: oscillationSpeed,
      ease: "sine.inOut",
      yoyo: true,
      repeat: -1
    });
  }
});

}

window.Script155 = function()
{
  // ============================================================
// 🔁 SCRIPT — ALLER AU PROCHAIN EXERCICE ÉCHOUÉ ("Réviser les erreurs")
// ============================================================

// -------- VARIABLES DE CONTEXTE --------
const seqPos = getVar("0_Position_Sequence"); // ex: "1", "2", "3", "4"
const seqKey = `S${seqPos}`;                  // ex: "S1"
const exCurrent = parseInt(getVar(`${seqKey}_Exo_Current`) || 0, 10); // ex: 3
const historique = getVar(`${seqKey}_Win_Lose`) || ""; // ex: "110010"

// -------- SÉCURITÉ --------
if (!seqPos || !historique) {
  console.warn("⚠️ Impossible d'exécuter le script — séquence ou historique manquant.");
  return;
}

// ============================================================
// 🔍 RECHERCHE DU PROCHAIN ÉCHEC ("0")
// ============================================================

// On cherche le prochain "0" APRÈS la position actuelle
const nextFailIndex = historique.indexOf("0", exCurrent);

// ============================================================
// 🎯 MISE À JOUR OU FIN DE LA RÉVISION
// ============================================================

if (nextFailIndex === -1) {
  // Aucun autre exercice échoué trouvé → fin du mode révision
  setVar("S0_Revision_Erreurs", 2);
  console.log("🎉 Tous les exercices échoués ont été revus — fin du mode révision (S0_Revision_Erreurs = 2).");
} else {
  // Prochain exercice échoué trouvé
  const nextExercise = nextFailIndex + 1; // index → position 1-based
  setVar("0_Position_Exercice", nextExercise);
  console.log(`🔁 Révision → Prochain exercice échoué : EX${nextExercise}`);
}

console.log(`(Séquence : ${seqKey}, Historique : "${historique}")`);

}

window.Script156 = function()
{
  // ============================================================
// 🎬 REMPLACEMENT DYNAMIQUE DE VIDÉO (version simplifiée)
// ============================================================
// Remplace directement la vidéo de l'objet Storyline (ID fixe)
// avec le chemin complet contenu dans la variable "Ex_Video".
// ============================================================

// -------- Lecture de la variable --------
const newVideoPath = getVar("Ex_Video"); // ex: "Ressources_Sequences/S1/Videos/S1_EX1.mp4"

// -------- Sécurité --------
if (!newVideoPath || newVideoPath.trim() === "") {
  console.warn("⚠️ Aucune vidéo spécifiée dans Ex_Video — remplacement annulé.");
  return;
}

// -------- Sélection directe de la vidéo --------
const videoElement = document.querySelector('[data-model-id="5pTX8N7gCDH"] video');
if (!videoElement) {
  console.error("❌ Impossible de trouver la vidéo avec data-model-id=5pTX8N7gCDH.");
  return;
}

// -------- Remplacement de la source --------
videoElement.setAttribute("xlink:href", newVideoPath);
videoElement.src = newVideoPath;
videoElement.load();

// -------- Suppression de la vignette (poster) --------
const container = videoElement.closest('[data-model-id="5pTX8N7gCDH"]');
if (container) {
  const poster = container.querySelector("img.video-player-poster");
  if (poster) {
    poster.remove();
    console.log("✅ Vignette (poster) supprimée — la 1ère image de la vidéo sera visible.");
  }
}
}

window.Script157 = function()
{
  // ============================================================
// 🖼️ REMPLACEMENT DYNAMIQUE D’IMAGE (version simplifiée)
// ============================================================
// Remplace directement l’image de l’objet Storyline (ID fixe)
// avec le chemin complet contenu dans la variable "Ex_Image".
// Aucun calcul de dossier ou de chemin n’est effectué.
// ============================================================

// -------- Lecture de la variable --------
const newImagePath = getVar("Ex_Image"); // ex: "Ressources_Sequences/S1/images/EX1.jpg"

// -------- Sécurité --------
if (!newImagePath || newImagePath.trim() === "") {
  console.warn("⚠️ Aucune image spécifiée dans Ex_Image — remplacement annulé.");
  return;
}

// -------- Sélection directe de l’image --------
const imageElement = document.querySelector('[data-model-id="6jUy2ox5l86"] image');
if (!imageElement) {
  console.error("❌ Impossible de trouver l’image avec data-model-id=6jUy2ox5l86.");
  return;
}

// -------- Remplacement du lien --------
imageElement.setAttributeNS("http://www.w3.org/1999/xlink", "xlink:href", newImagePath);

}

window.Script158 = function()
{
  // ============================================================
// 🖼️ REMPLACEMENT DYNAMIQUE D’IMAGE (version simplifiée)
// ============================================================
// Remplace directement l’image de l’objet Storyline (ID fixe)
// avec le chemin complet contenu dans la variable "Ex_Image".
// Aucun calcul de dossier ou de chemin n’est effectué.
// ============================================================

// -------- Lecture de la variable --------
const newImagePath = getVar("Ex_Image"); // ex: "Ressources_Sequences/S1/images/EX1.jpg"

// -------- Sécurité --------
if (!newImagePath || newImagePath.trim() === "") {
  console.warn("⚠️ Aucune image spécifiée dans Ex_Image — remplacement annulé.");
  return;
}

// -------- Sélection directe de l’image --------
const imageElement = document.querySelector('[data-model-id="6c22D92goAT"] image');
if (!imageElement) {
  console.error("❌ Impossible de trouver l’image avec data-model-id=6c22D92goAT.");
  return;
}

// -------- Remplacement du lien --------
imageElement.setAttributeNS("http://www.w3.org/1999/xlink", "xlink:href", newImagePath);

}

window.Script159 = function()
{
  // ============================================================
// ⚙️ BARRE DE PROGRESSION — SYNCHRONISATION AVEC LA SÉQUENCE EN COURS
// ============================================================

// --------- Lecture de la séquence courante ---------
const seqPos = getVar("0_Position_Sequence");   // ex. 1 → S1
const seqKey = `S${seqPos}`;

// --------- Lecture des variables de la séquence correspondante ---------
const Exo_Reached = getVar("S0_Exo_Reached") || 0;
const Exo_Total = getVar("S0_Exo_Total") || 1;

// --------- Calcul du pourcentage ---------
const progress = Math.min(Exo_Reached / Exo_Total, 1); // clamp entre 0 et 1

// --------- Sélectionne l'objet Storyline ---------
const ProgressBar = document.querySelector(`[data-model-id="6f561U28wA4"]`);

if (ProgressBar) {
  // --------- Sélectionne l'élément graphique principal ---------
  const shape = ProgressBar.querySelector("path");

  if (shape) {
    // Si ce n’est pas déjà fait, on garde la largeur d’origine
    if (!shape.dataset.fullWidth) {
      const bbox = shape.getBBox();
      shape.dataset.fullWidth = bbox.width;
    }

    // --------- Calcul de la largeur selon la progression ---------
    const fullWidth = parseFloat(shape.dataset.fullWidth);

    // --------- Application du remplissage via clip-path ---------
    shape.style.clipPath = `inset(0 ${100 - progress * 100}% 0 0 round 0px)`;
  }
}

}

window.Script160 = function()
{
  // ============================================================
// ⚙️ BARRE DE PROGRESSION ANIMÉE (AVEC INITIALISATION INTELLIGENTE)
// ============================================================

// Durée de l’animation en millisecondes (modifiable)
const animationDuration = 800; // 0.8s = fluide, 300 = rapide, 1500 = lente

function updateProgressBarAnimated() {
  // --------- Lecture de la séquence courante ---------
  const seqPos = getVar("0_Position_Sequence");
  const seqKey = `S${seqPos}`;

  // --------- Lecture des variables globales S0 ---------
  const Exo_Reached = getVar("S0_Exo_Reached") || 0;
  const Exo_Total = getVar("S0_Exo_Total") || 1;
  const progress = Math.min(Exo_Reached / Exo_Total, 1);

  // --------- Sélectionne l'objet Storyline ---------
  const ProgressBar = document.querySelector(`[data-model-id="6f561U28wA4"]`);
  if (!ProgressBar) return;

  const shape = ProgressBar.querySelector("path");
  if (!shape) return;

  // --------- Initialisation si nécessaire ---------
  if (!shape.dataset.fullWidth) {
    const bbox = shape.getBBox();
    shape.dataset.fullWidth = bbox.width;
  }

  // --------- Nouvelle logique : position initiale intelligente ---------
  let startProgress;

  if (shape.dataset.currentProgress !== undefined) {
    // On continue à partir de la progression actuelle
    startProgress = parseFloat(shape.dataset.currentProgress) || 0;
  } else if (Exo_Reached >= 1) {
    // Si aucune donnée mais au moins un exercice complété,
    // on démarre au niveau précédent
    startProgress = (Exo_Reached - 1) / Exo_Total;
  } else {
    // Sinon, tout au début
    startProgress = 0;
  }

  const startTime = performance.now();

  // --------- Fonction d'animation fluide ---------
  function animate(time) {
    const elapsed = time - startTime;
    const t = Math.min(elapsed / animationDuration, 1);
    const eased = t < 0.5 ? 2 * t * t : -1 + (4 - 2 * t) * t; // easeInOutQuad

    const currentProgress = startProgress + (progress - startProgress) * eased;
    shape.style.clipPath = `inset(0 ${100 - currentProgress * 100}% 0 0 round 0px)`;
    shape.dataset.currentProgress = currentProgress;

    if (t < 1) requestAnimationFrame(animate);
  }

  requestAnimationFrame(animate);
}

// ============================================================
// ▶️ APPEL DU SCRIPT (exécuté manuellement via trigger JS)
// ============================================================

updateProgressBarAnimated();

}

window.Script161 = function()
{
  // -------- Initialisation --------

// Récupère le numéro ou identifiant d'exercice (ex: "EX2")
const AudioPath = getVar("0_Audio_Lecteur");

// Si un audio était déjà en cours → on le stoppe et on remet au début
if (window.audioUnique) {
  window.audioUnique.pause();
  window.audioUnique.currentTime = 0;
}

// Crée un nouvel objet audio
window.audioUnique = new Audio(AudioPath);

// Lecture
window.audioUnique.play().catch(err => {
  console.log("Erreur lecture Back :", err);
});
}

window.Script162 = function()
{
  // ============================================================
// 🎯 MISE À JOUR DES VARIABLES Sx_Win_Lose SELON Ex_Success (texte)
// ============================================================

// -------- Lecture des variables Storyline --------
const seqPos  = getVar("0_Position_Sequence");
const exPos   = getVar("0_Position_Exercice");
const success = getVar("Ex_Success");

// -------- Construction du nom de la séquence --------
const seqKey     = `S${seqPos}`;
const winLoseVar = `${seqKey}_Win_Lose`;

// -------- Lecture actuelle de la variable Win_Lose --------
let winLose = getVar(winLoseVar) || "";

// -------- S’assure que la longueur correspond au nombre total d’exercices --------
const total = getVar(`0_Menu_${seqKey}_Exo_Total`);

// -------- Conversion en tableau pour modification --------
const chars = winLose.split("");

// -------- Mise à jour du caractère correspondant à l’exercice actuel --------
if (!(chars[exPos - 1] === "1" && success === "0")) {
    chars[exPos - 1] = success === "1" ? "1" : "0";
}
// Si l'exercice est déjà réussi, on garde la réussite.

// -------- Conversion inverse en chaîne --------
winLose = chars.join("");

// -------- Écriture dans Storyline --------
setVar(winLoseVar, winLose);

// ============================================================
// 🔁 SWITCH AUTOMATIQUE DE 0_Feedback_Switch
// ============================================================
let feedbackSwitch = getVar("0_Feedback_Switch");
feedbackSwitch = feedbackSwitch === true || feedbackSwitch === "true" ? false : true;
setVar("0_Feedback_Switch", feedbackSwitch);

}

window.Script163 = function()
{
  // ============================================================
// 🏁 SCRIPT DE FIN D’EXERCICE — MISE À JOUR PROGRESSION & TENTATIVES
// ============================================================

// -------- CONFIGURATION --------
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;

const exCurrent  = parseInt(getVar(`${seqKey}_Exo_Current`), 10);
const exReached  = parseInt(getVar(`${seqKey}_Exo_Reached`), 10);
const tentVar    = `${seqKey}_Exo_Current_Tentatives`;
// ============================================================
// 🧭 MISE À JOUR DE LA PROGRESSION
// ============================================================

// Si on avance (évite de revenir en arrière)
if (exCurrent > exReached) {
  setVar(`${seqKey}_Exo_Reached`, exCurrent);
  setVar("S0_Exo_Reached", exCurrent); 
}

// ============================================================
// 🧮 MARQUAGE DE L’EXERCICE TERMINÉ
// ============================================================

setVar(tentVar, -10);

}

window.Script164 = function()
{
  // ============================================================
// 🧠 SAUVEGARDE AUTOMATIQUE DES DONNÉES UTILISATEUR (GLOBAL)
// ============================================================
//
// 🔹 Ce script est appelé automatiquement après la validation d’un exercice.
// 🔹 Il détecte le type d’exercice et sauvegarde la réponse dans la variable JSON
//    correspondante (ex: S1_UserData)
//
// ============================================================

// ------------------------------------------------------------
// 🔧 Lecture des infos de contexte
// ------------------------------------------------------------
const seqPos = getVar("0_Position_Sequence");           // ex: "1"
const exPos = parseInt(getVar("0_Position_Exercice"), 10);
const seqKey = `S${seqPos}`;
const exType = getVar("Ex_Type");
const success = getVar("Ex_Success");
const tentativesRestantes = parseInt(getVar("Ex_Tentatives"), 10);

// Variable cible (ex: "S1_UserData")
const userDataVar = `${seqKey}_UserData`;

// ------------------------------------------------------------
// 🔧 Lecture du JSON existant
// ------------------------------------------------------------
let data = {};
try {
  const existing = getVar(userDataVar);
  data = existing ? JSON.parse(existing) : {};
} catch (err) {
  console.warn(`⚠️ JSON invalide dans ${userDataVar}, réinitialisation.`, err);
  data = {};
}

// ------------------------------------------------------------
// 🧮 Tentatives initiales (si dispo dans cache global)
// ------------------------------------------------------------
let tentativesInitiales = 0;
try {
  const exData = window.sequenceCache?.[seqKey]?.[`EX${exPos}`];
  tentativesInitiales = exData?.Tentatives || 1;
} catch {
  tentativesInitiales = 1;
}

const tentativesUtilisees = Math.max(0, tentativesInitiales - tentativesRestantes);

// ------------------------------------------------------------
// 🎯 Récupération de la réponse selon le type d’exercice
// ------------------------------------------------------------
let userResponseObj = {};

switch (exType) {
  // 🔹 QCU
  case "QCU": {
    const answerKey = getVar("0_Reponse");
    const answerText = getVar(`0_Choix_${answerKey}`) || "";
    userResponseObj = { [answerKey]: answerText };
    break;
  }

  // 🔹 QCM
  case "QCM": {
    const responseRaw = (getVar("0_Reponse") || "").split("|").filter(Boolean);
    responseRaw.forEach(k => {
      userResponseObj[k] = getVar(`0_Choix_${k}`) || "";
    });
    break;
  }

  // 🔹 True or false
  case "True or false": {
    const answer = (getVar("0_Reponse") || "").toLowerCase();
    userResponseObj = { unique: answer };
    break;
  }

  // 🔹 Complete
  case "Complete": {
    const answer = getVar("0_Ex_Enonce") || "";
    userResponseObj = { unique: answer };
    break;
  }

  // 🔹 Matching
  case "Matching": {
    const reponse = getVar("0_Reponse") || "";
    userResponseObj = { associations: reponse };
    break;
  }

  // 🔹 Flashcard
  case "Flashcard": {
    const answer = getVar("0_Reponse") || "";
    userResponseObj = { unique: answer };
    break;
  }

  // 🔹 Information
  case "Information": {
    userResponseObj = { info: "Aucune interaction" };
    break;
  }

  // 🔹 Production orale - dictée
  case "Production orale - dictée": {
    const raw = getVar("0_Reponse") || "{}";
    try {
      const parsed = JSON.parse(raw);
      userResponseObj = {
        score: parsed.score || 0,
        texte_brut: parsed.texte_brut || "",
        texte_color: parsed.texte_color || ""
      };
    } catch (err) {
      console.warn("⚠️ Erreur de parsing JSON pour Production orale :", err);
      userResponseObj = { erreur: "Format de réponse invalide", raw };
    }
    break;
  }

  // 🔹 Défaut
  default: {
    const raw = getVar("0_Reponse") || "";
    userResponseObj = { inconnu: raw };
    console.warn(`❓ Type d’exercice inconnu : ${exType}`);
    break;
  }
}

// ------------------------------------------------------------
// 💾 Enregistrement dans le JSON
// ------------------------------------------------------------
data[`EX${exPos}`] = {
  Type: exType,
  Reponses_Choisies: userResponseObj,
  Statut: success,
  Tentatives_Utilisees: tentativesUtilisees
};

setVar(userDataVar, JSON.stringify(data));

// ------------------------------------------------------------
// 🧾 Log de contrôle
// ------------------------------------------------------------
console.group(`💾 Données sauvegardées → ${userDataVar}`);
console.log("Exercice :", `EX${exPos}`);
console.log("Type :", exType);
console.log("Réponses :", userResponseObj);
console.log("Statut :", success);
console.log("Tentatives utilisées :", tentativesUtilisees);
console.log("JSON complet :", data);
console.groupEnd();

}

window.Script165 = function()
{
  // ============================================================
// 🎯 MATCHING — ALIGNEMENT + ÉCHANGE VISUEL DES ÉTIQUETTES
//    + VÉRIFICATION INDIVIDUELLE + GESTION DES TENTATIVES
// ============================================================

// --------- ÉTIQUETTES GAUCHE (groupes pour déplacement) ---------
const objetsGauche = {
  A: object("5iQigltUZuq"),
  B: object("6dqnNZXdA7Z"),
  C: object("5puSsmxEWCo"),
  D: object("5mrmg4WFsGx")
};

// --------- ÉTIQUETTES DROITE (groupes pour déplacement) ---------
const objetsDroite = {
  1: object("6ABkMU9AHKl"),
  2: object("6oPclunoyLm"),
  3: object("6nbvK3SCa1S"),
  4: object("5ntH1siHHyE")
};

// --------- OBJETS D'ÉTAT ---------
const objetsEtatGauche = {
  A: object("5Vx9OK6bhqJ"),
  B: object("5stJ8obBFuZ"),
  C: object("6hyfEcFwgV3"),
  D: object("6hNeAe7f6ex")
};
const objetsEtatDroite = {
  1: object("6mgI5bDjGMt"),
  2: object("6njbNlrA7cK"),
  3: object("6JWKQ62dycb"),
  4: object("6A9CfPugIpg")
};

// --------- FONCTION DE CHANGEMENT D’ÉTAT ---------
function setFeedbackState(obj, state) {
  if (!obj) return;
  if (obj.state !== state) obj.state = state;
}

// ============================================================
// 📋 VARIABLES STORYLINE
// ============================================================
const choixGauche = getVar("0_Matching_Choix_Gauche");
const choixDroit  = getVar("0_Matching_Choix_Droit");

if (!choixGauche || !choixDroit) {
  console.warn("⚠️ Variables de choix manquantes ou vides.");
  return;
}

const positions = {
  1: getVar("0_Matching_Pos_Choix_1"),
  2: getVar("0_Matching_Pos_Choix_2"),
  3: getVar("0_Matching_Pos_Choix_3"),
  4: getVar("0_Matching_Pos_Choix_4")
};

const objGroupeGauche = objetsGauche[choixGauche];
const objGroupeDroite = objetsDroite[choixDroit];
const objEtatGauche = objetsEtatGauche[choixGauche];
const objEtatDroite = objetsEtatDroite[choixDroit];

if (!objGroupeGauche || !objGroupeDroite) {
  console.warn("⚠️ Objet non trouvé pour", choixGauche, choixDroit);
  return;
}

// ============================================================
// 🧩 VÉRIFICATION DE LA PAIRE CHOISIE
// ============================================================
const pairesGauche = {
  A: getVar("0_Matching_Choix_A"),
  B: getVar("0_Matching_Choix_B"),
  C: getVar("0_Matching_Choix_C"),
  D: getVar("0_Matching_Choix_D")
};
const pairesDroite = {
  1: getVar("0_Matching_Choix_1"),
  2: getVar("0_Matching_Choix_2"),
  3: getVar("0_Matching_Choix_3"),
  4: getVar("0_Matching_Choix_4")
};

const gauchePair = pairesGauche[choixGauche];
const droitePair = pairesDroite[choixDroit];
const paireCorrecte = gauchePair && droitePair && gauchePair === droitePair;

// ============================================================
// ⚙️ CONFIG SÉQUENCE
// ============================================================
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;
const tentVar = `${seqKey}_Exo_Current_Tentatives`;
let tentatives = parseInt(getVar("Ex_Tentatives"), 10);
let CompteurTentatives = parseInt(getVar("Ex_Compteur_Tentatives"), 10);
const CompteurTentativesVar = `${seqKey}_Exo_Current_Compteur_Tentatives`;

// ============================================================
// 🧩 FONCTION D’ENREGISTREMENT FINALE
// ============================================================
function finalizeAfterAnimation() {
  if (paireCorrecte || tentatives <= 1) {
    const positionsFinales = {
      1: getVar("0_Matching_Pos_Choix_1"),
      2: getVar("0_Matching_Pos_Choix_2"),
      3: getVar("0_Matching_Pos_Choix_3"),
      4: getVar("0_Matching_Pos_Choix_4")
    };

    const associations = [];
    ["1", "2", "3", "4"].forEach(num => {
      const gauche = positionsFinales[num];
      if (["A", "B", "C", "D"].includes(gauche)) associations.push(`${gauche}-${num}`);
    });

    const reponseFinale = associations.join("|");
    setVar("0_Reponse", reponseFinale);
  }

  if (!paireCorrecte) {
    if (tentatives > 0) tentatives -= 1;
    setVar("Ex_Tentatives", tentatives);
    setVar(tentVar, tentatives);
    if (tentatives <= 0) setVar("Ex_Success", "0");
  }

  CompteurTentatives++;
  setVar("Ex_Compteur_Tentatives", CompteurTentatives);
  setVar(CompteurTentativesVar, CompteurTentatives);

  if (getVar("Ex_Success") === "1" || tentatives <= 0) setVar(tentVar, -10);

  resetMatchingVars();
}

// ============================================================
// 🔄 ANIMATION SELON LE RÉSULTAT
// ============================================================
if (paireCorrecte) {
  // ✅ Bonne correspondance → Déplacement + état désactivé
  setFeedbackState(objEtatDroite, "Disabled");
  setFeedbackState(objEtatGauche, "Disabled");

  // Recherche d’un autre élément à échanger
  let autreDroiteKey = null;
  for (let i = 1; i <= 4; i++) {
    if (positions[i] === choixGauche && i !== Number(choixDroit)) {
      autreDroiteKey = i;
      break;
    }
  }

  if (autreDroiteKey) {
    const autreDroite = objetsDroite[autreDroiteKey];
    const yDroiteActuel = objGroupeDroite.y;
    const yAutreDroite = autreDroite.y;

    const t1 = gsap.timeline();
    t1.to([objGroupeDroite, autreDroite], { scale: 105, duration: 0.2, ease: "power1.out" }, 0);
    t1.to(objGroupeDroite, { y: yAutreDroite, duration: 0.6, ease: "power2.inOut" }, 0);
    t1.to(autreDroite, { y: yDroiteActuel, duration: 0.6, ease: "power2.inOut" }, 0);
    t1.to([objGroupeDroite, autreDroite], { scale: 100, duration: 0.2, ease: "power1.in" }, "-=0.2");

    t1.eventCallback("onComplete", () => {
      const temp = positions[autreDroiteKey];
      setVar(`0_Matching_Pos_Choix_${autreDroiteKey}`, positions[choixDroit] || "");
      setVar(`0_Matching_Pos_Choix_${choixDroit}`, temp || "");
      finalizeAfterAnimation();
    });
  } else {
    // Pas d’échange — petite pulsation simple
    gsap.fromTo(
      objGroupeDroite,
      { scale: 100 },
      { scale: 110, duration: 0.2, yoyo: true, repeat: 1, ease: "power1.inOut", onComplete: finalizeAfterAnimation }
    );
  }

} else {
  // ❌ Mauvaise correspondance → pas de déplacement (Storyline gère l’effet visuel)
  setFeedbackState(objEtatDroite, "Incorrect");
  setFeedbackState(objEtatGauche, "Incorrect");
  finalizeAfterAnimation();
}

// ============================================================
// 🧹 RESET DES VARIABLES DE CHOIX
// ============================================================
function resetMatchingVars() {
  setVar("0_Matching_Check", false);
  setVar("0_Matching_Choix_Gauche", "");
  setVar("0_Matching_Choix_Droit", "");
}

}

window.Script166 = function()
{
  // ============================================================
// 🧠 MATCHING — AFFICHAGE FINAL DE LA CORRECTION (Ex_Success = 0)
// ============================================================

// --------- ÉTIQUETTES GAUCHE ---------
const objetsGauche = {
  A: object("5iQigltUZuq"),
  B: object("6dqnNZXdA7Z"),
  C: object("5puSsmxEWCo"),
  D: object("5mrmg4WFsGx")
};

// --------- ÉTIQUETTES DROITE ---------
const objetsDroite = {
  1: object("6ABkMU9AHKl"),
  2: object("6oPclunoyLm"),
  3: object("6nbvK3SCa1S"),
  4: object("5ntH1siHHyE")
};

// --------- OBJETS D'ÉTAT ---------
const objetsEtatGauche = {
  A: object("5Vx9OK6bhqJ"),
  B: object("5stJ8obBFuZ"),
  C: object("6hyfEcFwgV3"),
  D: object("6hNeAe7f6ex")
};
const objetsEtatDroite = {
  1: object("6mgI5bDjGMt"),
  2: object("6njbNlrA7cK"),
  3: object("6JWKQ62dycb"),
  4: object("6A9CfPugIpg")
};

// --------- FONCTION D'ÉTAT ---------
function setFeedbackState(obj, state) {
  if (!obj) return;
  if (obj.state !== state) obj.state = state;
}

// --------- RÉCUPÉRATION DES PAIRES ---------
const pairesGauche = {
  A: getVar("0_Matching_Choix_A"),
  B: getVar("0_Matching_Choix_B"),
  C: getVar("0_Matching_Choix_C"),
  D: getVar("0_Matching_Choix_D")
};
const pairesDroite = {
  1: getVar("0_Matching_Choix_1"),
  2: getVar("0_Matching_Choix_2"),
  3: getVar("0_Matching_Choix_3"),
  4: getVar("0_Matching_Choix_4")
};

// --------- DÉTERMINATION DES BONNES CORRESPONDANCES ---------
const corrections = {};
for (let droiteKey = 1; droiteKey <= 4; droiteKey++) {
  const droitePair = pairesDroite[droiteKey];
  const correctGauche = Object.keys(pairesGauche).find(
    k => pairesGauche[k] === droitePair
  );
  if (correctGauche) corrections[droiteKey] = correctGauche;
}

// --------- ANIMATION DE CORRECTION ---------
const tl = gsap.timeline();

for (let i = 1; i <= 4; i++) {
  const droite = objetsDroite[i];
  const bonneGaucheKey = corrections[i];
  const objGauche = objetsGauche[bonneGaucheKey];
  const etatGauche = objetsEtatGauche[bonneGaucheKey];
  const etatDroite = objetsEtatDroite[i];
  
  // 🟢 Mise en "Correct_Feedback"
  setFeedbackState(etatGauche, "Correct_Feedback");
  setFeedbackState(etatDroite, "Correct_Feedback");
  
  if (!droite || !objGauche) continue;

  // 🎬 Animation de repositionnement
  if (Math.abs(droite.y - objGauche.y) > 1) {
    tl.to(droite, { y: objGauche.y, scale: 105, duration: 0.6, ease: "power2.inOut" }, 0);
    tl.to(droite, { scale: 100, duration: 0.2, ease: "power1.in" }, "-=0.2");
  }

  setVar(`0_Matching_Pos_Choix_${i}`, bonneGaucheKey);
}

// --------- FIN ---------
tl.eventCallback("onComplete", () => {
  console.log("✅ Correction finale affichée + états Correct_Feedback.");
});

}

window.Script167 = function()
{
  // ============================================================
// 🎯 MATCHING — POSITIONNEMENT DYNAMIQUE DES ÉTIQUETTES
// ============================================================

// --------- POSITIONS DE RÉFÉRENCE ---------
const positionA1_2 = object('66P70wGnRcu');
const positionB2_2 = object('6P9M7FWradH');

const positionA1_3 = object('6h0k15NAhy2');
const positionB2_3 = object('6IUGr27kYKH');
const positionC3_3 = object('5YEgF8EFiSm');

const positionA1_4 = object('6fvcdP5bLVG');
const positionB2_4 = object('5fHFWIasbpR');
const positionC3_4 = object('6nx5T62sxUN');
const positionD4_4 = object('6djgch1fP4f');

// --------- ÉTIQUETTES (GROUPES GAUCHE / DROITE) ---------
const choix_1_Matching_GRP = object('6ABkMU9AHKl');
const choix_A_Matching_GRP = object('5iQigltUZuq');

const choix_2_Matching_GRP = object('6oPclunoyLm');
const choix_B_Matching_GRP = object('6dqnNZXdA7Z');

const choix_3_Matching_GRP = object('6nbvK3SCa1S');
const choix_C_Matching_GRP = object('5puSsmxEWCo');

const choix_4_Matching_GRP = object('5ntH1siHHyE');
const choix_D_Matching_GRP = object('5mrmg4WFsGx');

// ============================================================
// 🧮 DÉTERMINATION DU NOMBRE DE PAIRES
// ============================================================

const paires = [
  getVar("0_Matching_Choix_A"),
  getVar("0_Matching_Choix_B"),
  getVar("0_Matching_Choix_C"),
  getVar("0_Matching_Choix_D")
];
const nbPaires = paires.filter(p => p && p.trim() !== "").length;

console.log(`🔢 Nombre de paires détectées : ${nbPaires}`);

// ============================================================
// ⚙️ POSITIONNEMENT DES ÉTIQUETTES SELON LE NOMBRE DE PAIRES
// ============================================================

function positionnerPaire(lettre, numero, positionRef) {
  const objGauche = { A: choix_A_Matching_GRP, B: choix_B_Matching_GRP, C: choix_C_Matching_GRP, D: choix_D_Matching_GRP }[lettre];
  const objDroite = { 1: choix_1_Matching_GRP, 2: choix_2_Matching_GRP, 3: choix_3_Matching_GRP, 4: choix_4_Matching_GRP }[numero];
  if (!objGauche || !objDroite || !positionRef) return;

  objGauche.y = positionRef.y;
  objDroite.y = positionRef.y;
}

// --- CAS 2 PAIRES (A1 / B2) ---
if (nbPaires === 2) {
  positionnerPaire("A", "1", positionA1_2);
  positionnerPaire("B", "2", positionB2_2);
}

// --- CAS 3 PAIRES (A1 / B2 / C3) ---
else if (nbPaires === 3) {
  positionnerPaire("A", "1", positionA1_3);
  positionnerPaire("B", "2", positionB2_3);
  positionnerPaire("C", "3", positionC3_3);
}

// --- CAS 4 PAIRES (A1 / B2 / C3 / D4) ---
else {
  positionnerPaire("A", "1", positionA1_4);
  positionnerPaire("B", "2", positionB2_4);
  positionnerPaire("C", "3", positionC3_4);
  positionnerPaire("D", "4", positionD4_4);
}

console.log("📍 Positionnement des étiquettes Matching mis à jour.");

}

window.Script168 = function()
{
  // ============================
// 🎧 Injecteur Audio Universel (Plyr WebObject) — anti-reload + double injection + single-play
// ============================

// ✅ Table de suivi (remplace allInjectedAudios)
window.allInjectedAudios = []; // { index, modelId, iframe }

const audioBindings = {
  "6bJUNCeaDdA": "0_Matching_Audio_A",
  "6MT7kDpfYVE": "0_Matching_Audio_B",
  "5nZOXy41rLy": "0_Matching_Audio_C",
  "5fiMlo5Cvvk": "0_Matching_Audio_D",
  "5gIqIxAeVcV": "0_Matching_Audio_1",
  "6ACY4Sk2XKV": "0_Matching_Audio_2",
  "5uMOH8YI9rA": "0_Matching_Audio_3",
  "61akCgEPnE5": "0_Matching_Audio_4",
};

// =====================================================
// 🚀 Lancement principal (avec double injection retardée)
// =====================================================
setTimeout(() => {
  if (shouldRunAudioInjector()) {
    injectAllAudios();
    setTimeout(() => injectAllAudios(), 1200);
  }
}, 700);

// -----------------------------------------------------
// 🔍 Vérifie si au moins une variable audio est définie (non vide)
// -----------------------------------------------------
function shouldRunAudioInjector() {
  try {
    const allVars = Object.values(audioBindings).map((v) => getVar(v));
    const filled = allVars.filter((v) => v && v.trim() !== "");
    return filled.length > 0;
  } catch (e) {
    return true; // sécurité
  }
}

// =====================================================
// ⚙️ Injection principale (envoi postMessage au WebObject)
// =====================================================
function injectAllAudios() {
  cleanupOldAudios();

  const iframes = Array.from(document.querySelectorAll("iframe"));
  if (!iframes.length) {
    setTimeout(injectAllAudios, 300);
    return;
  }

  iframes.forEach((iframe, index) => {
    const parentGroup = iframe.closest(".slide-object-stategroup,[data-model-id]");
    const modelId = parentGroup?.dataset?.modelId;
    const varName = audioBindings[modelId];
    if (!modelId || !varName) return;

    let audioSrc = getVar(varName);
    if (!audioSrc || audioSrc.trim() === "") return;

    // 🔧 Correction automatique du chemin relatif (même logique que ton original)
    if (
      !audioSrc.startsWith("http") &&
      !audioSrc.startsWith("../") &&
      !audioSrc.startsWith("./")
    ) {
      audioSrc = "../../../" + audioSrc;
    }

    observeIframeLifecycle(iframe, audioSrc, index, modelId);
  });
}

// =====================================================
// 🧹 Nettoyage (on ne supprime plus de DOM dans les iframes)
// =====================================================
function cleanupOldAudios() {
  // Ici on ne peut plus pause/vider des <audio> natifs injectés (puisqu’on n’injecte plus)
  // → on réinitialise juste notre registre
  window.allInjectedAudios = [];
}

// =====================================================
// 🔁 Observation du rechargement/remplacement de l’iframe
// =====================================================
function observeIframeLifecycle(iframe, audioSrc, index, modelId) {
  let currentIframe = iframe;

  const parent = iframe.parentNode;
  if (!parent) return;

  const observer = new MutationObserver((mutations) => {
    mutations.forEach((m) => {
      m.addedNodes.forEach((n) => {
        if (n && n.tagName === "IFRAME") {
          currentIframe = n;
          waitAndSend(n, audioSrc, index, modelId);
        }
      });
    });
  });

  observer.observe(parent, { childList: true });

  // 1ère injection
  waitAndSend(currentIframe, audioSrc, index, modelId);
}

// =====================================================
// 📩 Attente + envoi SET_AUDIO (sans toucher au DOM de l’iframe)
// + anti double-envoi si déjà la bonne source
// =====================================================
function waitAndSend(iframe, audioSrc, index, modelId, essais = 0) {
  try {
    const visible =
      iframe.offsetParent !== null &&
      iframe.offsetWidth > 0 &&
      iframe.offsetHeight > 0;

    if (!iframe.contentWindow || !visible) {
      if (essais < 40) {
        setTimeout(() => waitAndSend(iframe, audioSrc, index, modelId, essais + 1), 200);
      }
      return;
    }

    // Anti spam : si on a déjà envoyé cette src à CETTE iframe, on ne renvoie pas
    const wanted = String(audioSrc).trim();
    const lastSent = iframe.dataset.lastAudioSent || "";
    if (lastSent === wanted) {
      // on s’assure juste que l’iframe est dans le registre
      registerIframe(index, modelId, iframe);
      return;
    }
    iframe.dataset.lastAudioSent = wanted;

    // Envoi au WebObject Plyr
    iframe.contentWindow.postMessage(
      { type: "SET_AUDIO", src: wanted, modelId, index },
      "*"
    );

    registerIframe(index, modelId, iframe);
  } catch (e) {
    // silencieux
  }
}

function registerIframe(index, modelId, iframe) {
  // remplace/ajoute une entrée
  const existing = window.allInjectedAudios.find((x) => x.modelId === modelId);
  if (existing) {
    existing.iframe = iframe;
    existing.index = index;
    return;
  }
  window.allInjectedAudios.push({ index, modelId, iframe });
}

// =====================================================
// 🔇 Single-play : quand un WebObject joue, on stop les autres
// (nécessite que le WebObject envoie AUDIO_PLAYING)
// =====================================================
if (!window.__singlePlayListenerAdded) {
  window.__singlePlayListenerAdded = true;

  window.addEventListener("message", (event) => {
    const data = event.data;
    if (!data || data.type !== "AUDIO_PLAYING") return;

    const playingModelId = data.modelId;

    window.allInjectedAudios.forEach((entry) => {
      if (entry.modelId === playingModelId) return;
      try {
        entry.iframe?.contentWindow?.postMessage({ type: "STOP_AUDIO" }, "*");
      } catch {}
    });
  });
}

}

window.Script169 = function()
{
  // ============================================================
// 🔁 RESTAURATION DU MATCHING D’APRÈS LES DONNÉES UTILISATEUR
// ============================================================

// --------- CONTEXTE GLOBAL ---------
const seqPos = getVar("0_Position_Sequence");
const exPos = parseInt(getVar("0_Position_Exercice") || 0, 10);
const seqKey = `S${seqPos}`;
const userDataVar = `${seqKey}_UserData`;

// --------- LECTURE USERDATA ---------
let data = {};
try {
  const raw = getVar(userDataVar);
  data = raw ? JSON.parse(raw) : {};
} catch (err) {
  console.warn(`⚠️ JSON invalide dans ${userDataVar}`, err);
}
const exData = data[`EX${exPos}`];
if (!exData || exData.Type !== "Matching") {
  console.log("ℹ️ Aucun matching sauvegardé pour cet exercice.");
  return;
}

const associations = exData.Reponses_Choisies?.associations || "";
if (!associations) {
  console.log("ℹ️ Aucune association enregistrée.");
  return;
}

// --------- OBJETS ---------
const objetsGauche = {
  A: object("5iQigltUZuq"),
  B: object("6dqnNZXdA7Z"),
  C: object("5puSsmxEWCo"),
  D: object("5mrmg4WFsGx")
};
const objetsDroite = {
  1: object("6ABkMU9AHKl"),
  2: object("6oPclunoyLm"),
  3: object("6nbvK3SCa1S"),
  4: object("5ntH1siHHyE")
};
const objetsEtatGauche = {
  A: object("5Vx9OK6bhqJ"),
  B: object("5stJ8obBFuZ"),
  C: object("6hyfEcFwgV3"),
  D: object("6hNeAe7f6ex")
};
const objetsEtatDroite = {
  1: object("6mgI5bDjGMt"),
  2: object("6njbNlrA7cK"),
  3: object("6JWKQ62dycb"),
  4: object("6A9CfPugIpg")
};

function setFeedbackState(obj, state) {
  if (!obj) return;
  if (obj.state !== state) obj.state = state;
}

// --------- RÉCUP DES BONNES PAIRES (pour comparaison) ---------
const pairesGauche = {
  A: getVar("0_Matching_Choix_A"),
  B: getVar("0_Matching_Choix_B"),
  C: getVar("0_Matching_Choix_C"),
  D: getVar("0_Matching_Choix_D")
};
const pairesDroite = {
  1: getVar("0_Matching_Choix_1"),
  2: getVar("0_Matching_Choix_2"),
  3: getVar("0_Matching_Choix_3"),
  4: getVar("0_Matching_Choix_4")
};

// --------- POSITIONS ---------
const positionsYGauche = {
  A: objetsGauche.A?.y || 0,
  B: objetsGauche.B?.y || 0,
  C: objetsGauche.C?.y || 0,
  D: objetsGauche.D?.y || 0
};

// --------- RESTAURATION VISUELLE ---------
associations.split("|").forEach(p => {
  const [gauche, droite] = p.split("-");
  const objGauche = objetsGauche[gauche];
  const objDroite = objetsDroite[droite];
  const etatGauche = objetsEtatGauche[gauche];
  const etatDroite = objetsEtatDroite[droite];

  if (!objGauche || !objDroite) return;

  // 🧩 Déplacement
  gsap.to(objDroite, {
    duration: 0.6,
    y: positionsYGauche[gauche],
    ease: "power2.inOut"
  });

  // 🧠 Vérifie si la paire est correcte
  const gauchePair = pairesGauche[gauche];
  const droitePair = pairesDroite[droite];
  const estCorrecte = gauchePair && droitePair && gauchePair === droitePair;

  // 🟩 ou 🟥 selon le cas
  setFeedbackState(etatGauche, estCorrecte ? "Correct_Feedback" : "Incorrect_Feedback");
  setFeedbackState(etatDroite, estCorrecte ? "Correct_Feedback" : "Incorrect_Feedback");

  // 🔄 Mise à jour logique
  setVar(`0_Matching_Pos_Choix_${droite}`, gauche);
});

console.log(`🎯 Matching restauré (${associations}) avec états correct/incorrect.`);

}

window.Script170 = function()
{
  // ============================================================
// 🧠 MATCHING — AFFICHAGE FINAL DE LA CORRECTION (Ex_Success = 0)
// ============================================================

// --------- ÉTIQUETTES GAUCHE ---------
const objetsGauche = {
  A: object("5iQigltUZuq"),
  B: object("6dqnNZXdA7Z"),
  C: object("5puSsmxEWCo"),
  D: object("5mrmg4WFsGx")
};

// --------- ÉTIQUETTES DROITE ---------
const objetsDroite = {
  1: object("6ABkMU9AHKl"),
  2: object("6oPclunoyLm"),
  3: object("6nbvK3SCa1S"),
  4: object("5ntH1siHHyE")
};

// --------- OBJETS D'ÉTAT ---------
const objetsEtatGauche = {
  A: object("5Vx9OK6bhqJ"),
  B: object("5stJ8obBFuZ"),
  C: object("6hyfEcFwgV3"),
  D: object("6hNeAe7f6ex")
};
const objetsEtatDroite = {
  1: object("6mgI5bDjGMt"),
  2: object("6njbNlrA7cK"),
  3: object("6JWKQ62dycb"),
  4: object("6A9CfPugIpg")
};

// --------- FONCTION D'ÉTAT ---------
function setFeedbackState(obj, state) {
  if (!obj) return;
  if (obj.state !== state) obj.state = state;
}

// --------- RÉCUPÉRATION DES PAIRES ---------
const pairesGauche = {
  A: getVar("0_Matching_Choix_A"),
  B: getVar("0_Matching_Choix_B"),
  C: getVar("0_Matching_Choix_C"),
  D: getVar("0_Matching_Choix_D")
};
const pairesDroite = {
  1: getVar("0_Matching_Choix_1"),
  2: getVar("0_Matching_Choix_2"),
  3: getVar("0_Matching_Choix_3"),
  4: getVar("0_Matching_Choix_4")
};

// --------- DÉTERMINATION DES BONNES CORRESPONDANCES ---------
const corrections = {};
for (let droiteKey = 1; droiteKey <= 4; droiteKey++) {
  const droitePair = pairesDroite[droiteKey];
  const correctGauche = Object.keys(pairesGauche).find(
    k => pairesGauche[k] === droitePair
  );
  if (correctGauche) corrections[droiteKey] = correctGauche;
}

// --------- ANIMATION DE CORRECTION ---------
const tl = gsap.timeline();

for (let i = 1; i <= 4; i++) {
  const droite = objetsDroite[i];
  const bonneGaucheKey = corrections[i];
  const objGauche = objetsGauche[bonneGaucheKey];
  const etatGauche = objetsEtatGauche[bonneGaucheKey];
  const etatDroite = objetsEtatDroite[i];

  if (!droite || !objGauche) continue;

  // 🟢 Mise en "Correct_Feedback"
  setFeedbackState(etatGauche, "Correct_Feedback");
  setFeedbackState(etatDroite, "Correct_Feedback");

  // 🎬 Animation de repositionnement
  if (Math.abs(droite.y - objGauche.y) > 1) {
    tl.to(droite, { y: objGauche.y, scale: 105, duration: 0.6, ease: "power2.inOut" }, 0);
    tl.to(droite, { scale: 100, duration: 0.2, ease: "power1.in" }, "-=0.2");
  }

  setVar(`0_Matching_Pos_Choix_${i}`, bonneGaucheKey);
}

// --------- FIN ---------
tl.eventCallback("onComplete", () => {
  console.log("✅ Correction finale affichée + états Correct_Feedback.");
});

}

window.Script171 = function()
{
  // Récupère les objets Storyline
const carte  = document.querySelector('[data-model-id="6WOyyFcuLyH"]');
const bouton = document.querySelector('[data-model-id="5rCsry3VrNh"]');

// Points d'ancrage
carte.style.transformOrigin = "top left";
bouton.style.transformOrigin = "center";

// Timeline pour synchroniser
const tl = gsap.timeline();

tl.to(carte, {
  scale: 0,
  opacity: 0,
  duration: 0.5,
  ease: "power1.inOut"
}, 0);

// Rotation 90° du bouton en même temps
tl.to(bouton, {
  rotate: 0,          // ou "+=90" si tu veux ajouter 90° à chaque fois
  duration: 0.5,
  ease: "power1.inOut"
}, 0);

}

window.Script172 = function()
{
  // Récupère les objets Storyline
const carte  = document.querySelector('[data-model-id="6WOyyFcuLyH"]');
const bouton = document.querySelector('[data-model-id="5rCsry3VrNh"]');

// Points d'ancrage
carte.style.transformOrigin = "top left";
bouton.style.transformOrigin = "center";

// États initiaux
gsap.set(carte,  { scale: 0, opacity: 0 });
gsap.set(bouton, { rotate: 0 }); // ou 90 si tu veux qu'il démarre déjà tourné

// Timeline pour synchroniser
const tl = gsap.timeline();

tl.to(carte, {
  scale: 1,
  opacity: 1,
  duration: 0.5,
  ease: "power1.inOut"
}, 0);

// Rotation 90° du bouton en même temps
tl.to(bouton, {
  rotate: 45,          // ou "+=90" si tu veux ajouter 90° à chaque fois
  duration: 0.5,
  ease: "power1.inOut"
}, 0);

}

window.Script173 = function()
{
  // ============================================================
// 💬 FEEDBACK MOTIVATIONNEL — AVEC SUPPORT DU FORMAT "1101nn"
// ============================================================

// -------- VARIABLES DE BASE --------
let resultat = getVar("Ex_Success");
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;
const exCurrent = parseInt(getVar(`${seqKey}_Exo_Current`), 10);

// ============================================================
// 🔍 SI RESULTAT VIDE → CHERCHE DANS S1_Win_Lose ("1101nn")
// ============================================================
if (!resultat || resultat === "") {
  const historique = getVar(`${seqKey}_Win_Lose`) || "";
  const charAtIndex = historique.charAt(exCurrent - 1);

  if (charAtIndex === "1" || charAtIndex === "0") {
    resultat = charAtIndex;
  } else {
    console.log(`ℹ️ Aucun résultat valide trouvé dans ${seqKey}_Win_Lose à l’index ${exCurrent - 1}`);
  }
}

// ============================================================
// 💬 LISTES DE FEEDBACKS
// ============================================================
const feedbackCorrect = [
  "Bravo !",
  "Super !",
  "Bien joué !",
  "Excellent !"
];

const feedbackIncorrect = [
  "Pas exactement.",
  "Oups !",
  "La prochaine fois !"
];

const feedbackNeutre = [
  "Continue !"
];

// ============================================================
// 🎯 CHOIX DU FEEDBACK
// ============================================================
let liste;
switch (resultat) {
  case "1":
    liste = feedbackCorrect;
    break;
  case "0":
    liste = feedbackIncorrect;
    break;
  default:
    liste = feedbackNeutre;
    break;
}

// Sélection aléatoire dans la liste
const feedback = liste[Math.floor(Math.random() * liste.length)];

// ============================================================
// 🧾 MISE À JOUR STORYLINE
// ============================================================
setVar("Ex_Feedback_Motivation", feedback);

}

window.Script174 = function()
{
  // ============================================================
// 🔁 SCRIPT — ALLER AU PROCHAIN EXERCICE ÉCHOUÉ ("Réviser les erreurs")
// ============================================================

// -------- VARIABLES DE CONTEXTE --------
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;
const exCurrent = parseInt(getVar(`${seqKey}_Exo_Current`), 10);
const historique = getVar(`${seqKey}_Win_Lose`) || "";

// -------- SÉCURITÉ --------
if (!seqPos || !historique) {
  console.warn("⚠️ Impossible d'exécuter le script — séquence ou historique manquant.");
  return;
}

// ============================================================
// 🔍 RECHERCHE DU PROCHAIN ÉCHEC ("0")
// ============================================================

// On cherche le prochain "0" APRÈS la position actuelle
const nextFailIndex = historique.indexOf("0", exCurrent);

// ============================================================
// 🎯 MISE À JOUR OU FIN DE LA RÉVISION
// ============================================================

if (nextFailIndex === -1) {
  // Aucun autre exercice échoué trouvé → fin du mode révision
  setVar("S0_Revision_Erreurs", 2);

} else {
  // Prochain exercice échoué trouvé
  const nextExercise = nextFailIndex + 1; // index → position 1-based
  setVar("0_Position_Exercice", nextExercise);
}
}

window.Script175 = function()
{
  // ============================================================
// 🎯 ANIMATION DE JAUGE — Rotation + Oscillation continue + Feedback motivationnel + Indicateur visuel
// ============================================================

// -------- OBJETS STORYLINE --------
const pointer = object('5fZOHpnMbya');
const gauge = object('6nKxLAItMtB');

// -------- PARAMÈTRES --------
const minAngle = 0;
const maxAngle = 180;
const oscillationRange = 10;
const oscillationSpeed = 1.5;

// ============================================================
// 🧮 DETECTION DU RESULTAT + RECUPERATION VARIABLES STORYLINE
// ============================================================
let resultat = getVar("Ex_Success");
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;
const exCurrent = getVar(`${seqKey}_Exo_Current`);

// Si il n'y a pas de résultat direct, on tente de le retrouver dans Sx_Win_Lose
if (resultat === "") {
  const historique = getVar(`${seqKey}_Win_Lose`);
  const charAtIndex = historique.charAt(exCurrent - 1);
  if (charAtIndex === "1" || charAtIndex === "0") {
    resultat = charAtIndex;
  } else {
    console.log(`ℹ️ Aucun résultat valide trouvé dans ${seqKey}_Win_Lose à l’index ${exCurrent - 1}`);
    resultat = "";
  }
}

// ============================================================
// ⚙️ Changement couleur jauge
// ============================================================
if (resultat === "1") {
  gauge.state = "Correct" ;
} else if (resultat === "0") {
  gauge.state = "Incorrect" ;
}

// ============================================================
// ⚙️ CALCULS D’ANGLES
// ============================================================
const baseAngle = resultat * (maxAngle - minAngle) + minAngle;
const angleMin = baseAngle - oscillationRange;
const angleMax = baseAngle + oscillationRange;


const goingUp = resultat === "1";
const targetAngle = goingUp ? angleMax : angleMin;

// ============================================================
// 🧹 ARRÊTE LES ANIMATIONS EXISTANTES
// ============================================================
gsap.killTweensOf(pointer);

// ============================================================
// 🚀 ANIMATION DE L’AIGUILLE
// ============================================================
gsap.to(pointer, {
  rotation: targetAngle,
  duration: 1.2,
  ease: "power2.inOut",
  onComplete: () => {
    gsap.to(pointer, {
      rotation: goingUp ? angleMin : angleMax,
      duration: oscillationSpeed,
      ease: "sine.inOut",
      yoyo: true,
      repeat: -1
    });
  }
});

}

window.Script176 = function()
{
  const Btn_Affichage  = document.querySelector('[data-model-id="6geks01QgvK"]');
const temoin = object('6XIh2Zufqbt');

// (Optionnel mais recommandé) point d’ancrage de la rotation
Btn_Affichage.style.transformOrigin = "50% 50%";

// On lit l’état actuel puis on bascule
const isAffiche = (temoin.state === "Feedback_Affiche");

temoin.state = isAffiche ? "Feedback_Cache" : "Feedback_Affiche";

// Rotation GSAP (durée + easing ajustables)
gsap.to(Btn_Affichage, {
  rotation: isAffiche ? 180 : 0,
  duration: 0.45,
  ease: "power2.inOut",
  overwrite: "auto"
});

}

window.Script177 = function()
{
  // ============================================================
// 💬 FEEDBACK MOTIVATIONNEL — AVEC SUPPORT DU FORMAT "1101nn"
// ============================================================

// -------- VARIABLES DE BASE --------
let resultat = getVar("Ex_Success");
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;
const exCurrent = parseInt(getVar(`${seqKey}_Exo_Current`), 10);

// ============================================================
// 🔍 SI RESULTAT VIDE → CHERCHE DANS S1_Win_Lose ("1101nn")
// ============================================================
if (!resultat || resultat === "") {
  const historique = getVar(`${seqKey}_Win_Lose`) || "";
  const charAtIndex = historique.charAt(exCurrent - 1);

  if (charAtIndex === "1" || charAtIndex === "0") {
    resultat = charAtIndex;
  } else {
    console.log(`ℹ️ Aucun résultat valide trouvé dans ${seqKey}_Win_Lose à l’index ${exCurrent - 1}`);
  }
}

// ============================================================
// 💬 LISTES DE FEEDBACKS
// ============================================================
//const feedbackCorrect = [
//  "Bravo !",
//  "Super !",
//  "Bien joué !",
//  "Excellent !"
//];

//const feedbackIncorrect = [
//  "Pas exactement.",
//  "Oups !",
//  "La prochaine fois !"
//];

const feedbackCorrect = [
  "Bravo, c'est une bonne réponse !",
  "Super, tu es sur la bonne voie !",
  "Bien joué, tu progresses !",
  "Excellent, continue comme ça !"
];

const feedbackIncorrect = [
  "Ce n'est pas tout à fait ça.",
  "Oups, ce n'est pas la bonne réponse.",
  "Tu y arriveras la prochaine fois !",
  "Pas exactement. Encore un effort !"
];


const feedbackNeutre = [
  "Continue !"
];

// ============================================================
// 🎯 CHOIX DU FEEDBACK
// ============================================================
let liste;
switch (resultat) {
  case "1":
    liste = feedbackCorrect;
    break;
  case "0":
    liste = feedbackIncorrect;
    break;
  default:
    liste = feedbackNeutre;
    break;
}

// Sélection aléatoire dans la liste
const feedback = liste[Math.floor(Math.random() * liste.length)];

// ============================================================
// 🧾 MISE À JOUR STORYLINE
// ============================================================
setVar("Ex_Feedback_Motivation", feedback);

}

window.Script178 = function()
{
  // ============================================================
// 🔁 SCRIPT — ALLER AU PROCHAIN EXERCICE ÉCHOUÉ ("Réviser les erreurs")
// ============================================================

// -------- VARIABLES DE CONTEXTE --------
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;
const exCurrent = parseInt(getVar(`${seqKey}_Exo_Current`), 10);
const historique = getVar(`${seqKey}_Win_Lose`) || "";

// -------- SÉCURITÉ --------
if (!seqPos || !historique) {
  console.warn("⚠️ Impossible d'exécuter le script — séquence ou historique manquant.");
  return;
}

// ============================================================
// 🔍 RECHERCHE DU PROCHAIN ÉCHEC ("0")
// ============================================================

// On cherche le prochain "0" APRÈS la position actuelle
const nextFailIndex = historique.indexOf("0", exCurrent);

// ============================================================
// 🎯 MISE À JOUR OU FIN DE LA RÉVISION
// ============================================================

if (nextFailIndex === -1) {
  // Aucun autre exercice échoué trouvé → fin du mode révision
  setVar("S0_Revision_Erreurs", 2);

} else {
  // Prochain exercice échoué trouvé
  const nextExercise = nextFailIndex + 1; // index → position 1-based
  setVar("0_Position_Exercice", nextExercise);
}
}

window.Script179 = function()
{
  // ============================================================
// 🎯 ANIMATION DE JAUGE — Rotation + Oscillation continue + Feedback motivationnel + Indicateur visuel
// ============================================================

// -------- OBJETS STORYLINE --------
const pointer = object('61WVHrM0EGs');
//const gauge = object('5lezhyLYUu5'); Cet objet n'existe pas ?
const gauge = object('6rIRKS6iuFv');


// -------- PARAMÈTRES --------
const minAngle = 0;
const maxAngle = 180;
const oscillationRange = 10;
const oscillationSpeed = 1.5;

// ============================================================
// 🧮 DETECTION DU RESULTAT + RECUPERATION VARIABLES STORYLINE
// ============================================================
let resultat = getVar("Ex_Success");
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;
const exCurrent = getVar(`${seqKey}_Exo_Current`);

// Si il n'y a pas de résultat direct, on tente de le retrouver dans Sx_Win_Lose
if (resultat === "") {
  const historique = getVar(`${seqKey}_Win_Lose`);
  const charAtIndex = historique.charAt(exCurrent - 1);
  if (charAtIndex === "1" || charAtIndex === "0") {
    resultat = charAtIndex;
  } else {
    console.log(`ℹ️ Aucun résultat valide trouvé dans ${seqKey}_Win_Lose à l’index ${exCurrent - 1}`);
    resultat = "";
  }
}

// ============================================================
// ⚙️ Changement couleur jauge
// ============================================================
if (resultat === "1") {
  gauge.state = "Correct" ;
} else if (resultat === "0") {
  gauge.state = "Incorrect" ;
}

// ============================================================
// ⚙️ CALCULS D’ANGLES
// ============================================================
const baseAngle = resultat * (maxAngle - minAngle) + minAngle;
const angleMin = baseAngle - oscillationRange;
const angleMax = baseAngle + oscillationRange;


const goingUp = resultat === "1";
const targetAngle = goingUp ? angleMax : angleMin;

// ============================================================
// 🧹 ARRÊTE LES ANIMATIONS EXISTANTES
// ============================================================
gsap.killTweensOf(pointer);

// ============================================================
// 🚀 ANIMATION DE L’AIGUILLE
// ============================================================
gsap.to(pointer, {
  rotation: targetAngle,
  duration: 1.2,
  ease: "power2.inOut",
  onComplete: () => {
    gsap.to(pointer, {
      rotation: goingUp ? angleMin : angleMax,
      duration: oscillationSpeed,
      ease: "sine.inOut",
      yoyo: true,
      repeat: -1
    });
  }
});

}

window.Script180 = function()
{
  const Btn_Affichage  = document.querySelector('[data-model-id="6RRLU9ixx38"]');
const temoin = object('68ikzB1cq1L');

// (Optionnel mais recommandé) point d’ancrage de la rotation
Btn_Affichage.style.transformOrigin = "50% 50%";

// On lit l’état actuel puis on bascule
const isAffiche = (temoin.state === "Feedback_Affiche");

temoin.state = isAffiche ? "Feedback_Cache" : "Feedback_Affiche";

// Rotation GSAP (durée + easing ajustables)
gsap.to(Btn_Affichage, {
  rotation: isAffiche ? 180 : 0,
  duration: 0.45,
  ease: "power2.inOut",
  overwrite: "auto"
});

}

window.Script181 = function()
{
  // Récupère le résultat
let resultat = getVar("Ex_Success");

// Définit les listes de feedback
const feedbackCorrect = [
  "Bravo !",
  "Super !",
  "Bien joué !",
  "Excellent !"
];

const feedbackIncorrect = [
  "Pas exactement",
  "Oups !",
  "La prochaine fois !"
];

// Choisit la liste en fonction du résultat
let liste = (resultat === "1") ? feedbackCorrect : feedbackIncorrect;

// Sélectionne un élément aléatoire dans la liste
let feedback = liste[Math.floor(Math.random() * liste.length)];

// Met à jour la variable Storyline
setVar("Ex_Feedback_Motivation", feedback);

}

window.Script182 = function()
{
  // ============================================================
// 🎯 ANIMATION DE JAUGE — Rotation + Oscillation continue + Feedback motivationnel + Indicateur visuel
// ============================================================

// -------- OBJETS STORYLINE --------
const pointer = object('5Ux37gXcJcw');
const gauge = object('5enGetq7POY');

// -------- PARAMÈTRES --------
const minAngle = 0;
const maxAngle = 180;
const oscillationRange = 10;
const oscillationSpeed = 1.5;

// ============================================================
// 🧮 DETECTION DU RESULTAT + RECUPERATION VARIABLES STORYLINE
// ============================================================
let resultat = getVar("Ex_Success");
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;
const exCurrent = getVar(`${seqKey}_Exo_Current`);

// Si il n'y a pas de résultat direct, on tente de le retrouver dans Sx_Win_Lose
if (resultat === "") {
  const historique = getVar(`${seqKey}_Win_Lose`);
  const charAtIndex = historique.charAt(exCurrent - 1);
  if (charAtIndex === "1" || charAtIndex === "0") {
    resultat = charAtIndex;
  } else {
    console.log(`ℹ️ Aucun résultat valide trouvé dans ${seqKey}_Win_Lose à l’index ${exCurrent - 1}`);
    resultat = "";
  }
}

// ============================================================
// ⚙️ Changement couleur jauge
// ============================================================
if (resultat === "1") {
  gauge.state = "Correct" ;
} else if (resultat === "0") {
  gauge.state = "Incorrect" ;
}

// ============================================================
// ⚙️ CALCULS D’ANGLES
// ============================================================
const baseAngle = resultat * (maxAngle - minAngle) + minAngle;
const angleMin = baseAngle - oscillationRange;
const angleMax = baseAngle + oscillationRange;


const goingUp = resultat === "1";
const targetAngle = goingUp ? angleMax : angleMin;

// ============================================================
// 🧹 ARRÊTE LES ANIMATIONS EXISTANTES
// ============================================================
gsap.killTweensOf(pointer);

// ============================================================
// 🚀 ANIMATION DE L’AIGUILLE
// ============================================================
gsap.to(pointer, {
  rotation: targetAngle,
  duration: 1.2,
  ease: "power2.inOut",
  onComplete: () => {
    gsap.to(pointer, {
      rotation: goingUp ? angleMin : angleMax,
      duration: oscillationSpeed,
      ease: "sine.inOut",
      yoyo: true,
      repeat: -1
    });
  }
});

}

window.Script183 = function()
{
  // ============================================================
// 🔁 SCRIPT — ALLER AU PROCHAIN EXERCICE ÉCHOUÉ ("Réviser les erreurs")
// ============================================================

// -------- VARIABLES DE CONTEXTE --------
const seqPos = getVar("0_Position_Sequence"); // ex: "1", "2", "3", "4"
const seqKey = `S${seqPos}`;                  // ex: "S1"
const exCurrent = parseInt(getVar(`${seqKey}_Exo_Current`) || 0, 10); // ex: 3
const historique = getVar(`${seqKey}_Win_Lose`) || ""; // ex: "110010"

// -------- SÉCURITÉ --------
if (!seqPos || !historique) {
  console.warn("⚠️ Impossible d'exécuter le script — séquence ou historique manquant.");
  return;
}

// ============================================================
// 🔍 RECHERCHE DU PROCHAIN ÉCHEC ("0")
// ============================================================

// On cherche le prochain "0" APRÈS la position actuelle
const nextFailIndex = historique.indexOf("0", exCurrent);

// ============================================================
// 🎯 MISE À JOUR OU FIN DE LA RÉVISION
// ============================================================

if (nextFailIndex === -1) {
  // Aucun autre exercice échoué trouvé → fin du mode révision
  setVar("S0_Revision_Erreurs", 2);
  console.log("🎉 Tous les exercices échoués ont été revus — fin du mode révision (S0_Revision_Erreurs = 2).");
} else {
  // Prochain exercice échoué trouvé
  const nextExercise = nextFailIndex + 1; // index → position 1-based
  setVar("0_Position_Exercice", nextExercise);
  console.log(`🔁 Révision → Prochain exercice échoué : EX${nextExercise}`);
}

console.log(`(Séquence : ${seqKey}, Historique : "${historique}")`);

}

window.Script184 = function()
{
  // ============================================================
// 🎬 REMPLACEMENT DYNAMIQUE DE VIDÉO (version simplifiée)
// ============================================================
// Remplace directement la vidéo de l'objet Storyline (ID fixe)
// avec le chemin complet contenu dans la variable "Ex_Video".
// ============================================================

// -------- Lecture de la variable --------
const newVideoPath = getVar("Ex_Video"); // ex: "Ressources_Sequences/S1/Videos/S1_EX1.mp4"

// -------- Sécurité --------
if (!newVideoPath || newVideoPath.trim() === "") {
  console.warn("⚠️ Aucune vidéo spécifiée dans Ex_Video — remplacement annulé.");
  return;
}

// -------- Sélection directe de la vidéo --------
const videoElement = document.querySelector('[data-model-id="5pTX8N7gCDH"] video');
if (!videoElement) {
  console.error("❌ Impossible de trouver la vidéo avec data-model-id=5pTX8N7gCDH.");
  return;
}

// -------- Remplacement de la source --------
videoElement.setAttribute("xlink:href", newVideoPath);
videoElement.src = newVideoPath;
videoElement.load();

// -------- Suppression de la vignette (poster) --------
const container = videoElement.closest('[data-model-id="5pTX8N7gCDH"]');
if (container) {
  const poster = container.querySelector("img.video-player-poster");
  if (poster) {
    poster.remove();
    console.log("✅ Vignette (poster) supprimée — la 1ère image de la vidéo sera visible.");
  }
}
}

window.Script185 = function()
{
  // ============================================================
// 🖼️ REMPLACEMENT DYNAMIQUE D’IMAGE (version simplifiée)
// ============================================================
// Remplace directement l’image de l’objet Storyline (ID fixe)
// avec le chemin complet contenu dans la variable "Ex_Image".
// Aucun calcul de dossier ou de chemin n’est effectué.
// ============================================================

// -------- Lecture de la variable --------
const newImagePath = getVar("Ex_Image"); // ex: "Ressources_Sequences/S1/images/EX1.jpg"

// -------- Sécurité --------
if (!newImagePath || newImagePath.trim() === "") {
  console.warn("⚠️ Aucune image spécifiée dans Ex_Image — remplacement annulé.");
  return;
}

// -------- Sélection directe de l’image --------
const imageElement = document.querySelector('[data-model-id="6jUy2ox5l86"] image');
if (!imageElement) {
  console.error("❌ Impossible de trouver l’image avec data-model-id=6jUy2ox5l86.");
  return;
}

// -------- Remplacement du lien --------
imageElement.setAttributeNS("http://www.w3.org/1999/xlink", "xlink:href", newImagePath);

}

window.Script186 = function()
{
  // ============================================================
// 🖼️ REMPLACEMENT DYNAMIQUE D’IMAGE (version simplifiée)
// ============================================================
// Remplace directement l’image de l’objet Storyline (ID fixe)
// avec le chemin complet contenu dans la variable "Ex_Image".
// Aucun calcul de dossier ou de chemin n’est effectué.
// ============================================================

// -------- Lecture de la variable --------
const newImagePath = getVar("Ex_Image"); // ex: "Ressources_Sequences/S1/images/EX1.jpg"

// -------- Sécurité --------
if (!newImagePath || newImagePath.trim() === "") {
  console.warn("⚠️ Aucune image spécifiée dans Ex_Image — remplacement annulé.");
  return;
}

// -------- Sélection directe de l’image --------
const imageElement = document.querySelector('[data-model-id="6c22D92goAT"] image');
if (!imageElement) {
  console.error("❌ Impossible de trouver l’image avec data-model-id=6c22D92goAT.");
  return;
}

// -------- Remplacement du lien --------
imageElement.setAttributeNS("http://www.w3.org/1999/xlink", "xlink:href", newImagePath);

}

window.Script187 = function()
{
  // ============================================================
// ⚙️ BARRE DE PROGRESSION — SYNCHRONISATION AVEC LA SÉQUENCE EN COURS
// ============================================================

// --------- Lecture de la séquence courante ---------
const seqPos = getVar("0_Position_Sequence");   // ex. 1 → S1
const seqKey = `S${seqPos}`;

// --------- Lecture des variables de la séquence correspondante ---------
const Exo_Reached = getVar("S0_Exo_Reached") || 0;
const Exo_Total = getVar("S0_Exo_Total") || 1;

// --------- Calcul du pourcentage ---------
const progress = Math.min(Exo_Reached / Exo_Total, 1); // clamp entre 0 et 1

// --------- Sélectionne l'objet Storyline ---------
const ProgressBar = document.querySelector(`[data-model-id="6f561U28wA4"]`);

if (ProgressBar) {
  // --------- Sélectionne l'élément graphique principal ---------
  const shape = ProgressBar.querySelector("path");

  if (shape) {
    // Si ce n’est pas déjà fait, on garde la largeur d’origine
    if (!shape.dataset.fullWidth) {
      const bbox = shape.getBBox();
      shape.dataset.fullWidth = bbox.width;
    }

    // --------- Calcul de la largeur selon la progression ---------
    const fullWidth = parseFloat(shape.dataset.fullWidth);

    // --------- Application du remplissage via clip-path ---------
    shape.style.clipPath = `inset(0 ${100 - progress * 100}% 0 0 round 0px)`;
  }
}

}

window.Script188 = function()
{
  // ============================================================
// ⚙️ BARRE DE PROGRESSION ANIMÉE (AVEC INITIALISATION INTELLIGENTE)
// ============================================================

// Durée de l’animation en millisecondes (modifiable)
const animationDuration = 800; // 0.8s = fluide, 300 = rapide, 1500 = lente

function updateProgressBarAnimated() {
  // --------- Lecture de la séquence courante ---------
  const seqPos = getVar("0_Position_Sequence");
  const seqKey = `S${seqPos}`;

  // --------- Lecture des variables globales S0 ---------
  const Exo_Reached = getVar("S0_Exo_Reached") || 0;
  const Exo_Total = getVar("S0_Exo_Total") || 1;
  const progress = Math.min(Exo_Reached / Exo_Total, 1);

  // --------- Sélectionne l'objet Storyline ---------
  const ProgressBar = document.querySelector(`[data-model-id="6f561U28wA4"]`);
  if (!ProgressBar) return;

  const shape = ProgressBar.querySelector("path");
  if (!shape) return;

  // --------- Initialisation si nécessaire ---------
  if (!shape.dataset.fullWidth) {
    const bbox = shape.getBBox();
    shape.dataset.fullWidth = bbox.width;
  }

  // --------- Nouvelle logique : position initiale intelligente ---------
  let startProgress;

  if (shape.dataset.currentProgress !== undefined) {
    // On continue à partir de la progression actuelle
    startProgress = parseFloat(shape.dataset.currentProgress) || 0;
  } else if (Exo_Reached >= 1) {
    // Si aucune donnée mais au moins un exercice complété,
    // on démarre au niveau précédent
    startProgress = (Exo_Reached - 1) / Exo_Total;
  } else {
    // Sinon, tout au début
    startProgress = 0;
  }

  const startTime = performance.now();

  // --------- Fonction d'animation fluide ---------
  function animate(time) {
    const elapsed = time - startTime;
    const t = Math.min(elapsed / animationDuration, 1);
    const eased = t < 0.5 ? 2 * t * t : -1 + (4 - 2 * t) * t; // easeInOutQuad

    const currentProgress = startProgress + (progress - startProgress) * eased;
    shape.style.clipPath = `inset(0 ${100 - currentProgress * 100}% 0 0 round 0px)`;
    shape.dataset.currentProgress = currentProgress;

    if (t < 1) requestAnimationFrame(animate);
  }

  requestAnimationFrame(animate);
}

// ============================================================
// ▶️ APPEL DU SCRIPT (exécuté manuellement via trigger JS)
// ============================================================

updateProgressBarAnimated();

}

window.Script189 = function()
{
  // -------- Initialisation --------

// Récupère le numéro ou identifiant d'exercice (ex: "EX2")
const AudioPath = getVar("0_Audio_Lecteur");

// Si un audio était déjà en cours → on le stoppe et on remet au début
if (window.audioUnique) {
  window.audioUnique.pause();
  window.audioUnique.currentTime = 0;
}

// Crée un nouvel objet audio
window.audioUnique = new Audio(AudioPath);

// Lecture
window.audioUnique.play().catch(err => {
  console.log("Erreur lecture Back :", err);
});
}

window.Script190 = function()
{
  // ============================================================
// 🎯 MISE À JOUR DES VARIABLES Sx_Win_Lose SELON Ex_Success (texte)
// ============================================================

// -------- Lecture des variables Storyline --------
const seqPos  = getVar("0_Position_Sequence");
const exPos   = getVar("0_Position_Exercice");
const success = getVar("Ex_Success");

// -------- Construction du nom de la séquence --------
const seqKey     = `S${seqPos}`;
const winLoseVar = `${seqKey}_Win_Lose`;

// -------- Lecture actuelle de la variable Win_Lose --------
let winLose = getVar(winLoseVar) || "";

// -------- S’assure que la longueur correspond au nombre total d’exercices --------
const total = getVar(`0_Menu_${seqKey}_Exo_Total`);

// -------- Conversion en tableau pour modification --------
const chars = winLose.split("");

// -------- Mise à jour du caractère correspondant à l’exercice actuel --------
if (!(chars[exPos - 1] === "1" && success === "0")) {
    chars[exPos - 1] = success === "1" ? "1" : "0";
}
// Si l'exercice est déjà réussi, on garde la réussite.

// -------- Conversion inverse en chaîne --------
winLose = chars.join("");

// -------- Écriture dans Storyline --------
setVar(winLoseVar, winLose);

// ============================================================
// 🔁 SWITCH AUTOMATIQUE DE 0_Feedback_Switch
// ============================================================
let feedbackSwitch = getVar("0_Feedback_Switch");
feedbackSwitch = feedbackSwitch === true || feedbackSwitch === "true" ? false : true;
setVar("0_Feedback_Switch", feedbackSwitch);

}

window.Script191 = function()
{
  // ============================================================
// 🏁 SCRIPT DE FIN D’EXERCICE — MISE À JOUR PROGRESSION & TENTATIVES
// ============================================================

// -------- CONFIGURATION --------
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;

const exCurrent  = parseInt(getVar(`${seqKey}_Exo_Current`), 10);
const exReached  = parseInt(getVar(`${seqKey}_Exo_Reached`), 10);
const tentVar    = `${seqKey}_Exo_Current_Tentatives`;
// ============================================================
// 🧭 MISE À JOUR DE LA PROGRESSION
// ============================================================

// Si on avance (évite de revenir en arrière)
if (exCurrent > exReached) {
  setVar(`${seqKey}_Exo_Reached`, exCurrent);
  setVar("S0_Exo_Reached", exCurrent); 
}

// ============================================================
// 🧮 MARQUAGE DE L’EXERCICE TERMINÉ
// ============================================================

setVar(tentVar, -10);

}

window.Script192 = function()
{
  // ============================================================
// 🧠 SAUVEGARDE AUTOMATIQUE DES DONNÉES UTILISATEUR (GLOBAL)
// ============================================================
//
// 🔹 Ce script est appelé automatiquement après la validation d’un exercice.
// 🔹 Il détecte le type d’exercice et sauvegarde la réponse dans la variable JSON
//    correspondante (ex: S1_UserData)
//
// ============================================================

// ------------------------------------------------------------
// 🔧 Lecture des infos de contexte
// ------------------------------------------------------------
const seqPos = getVar("0_Position_Sequence");           // ex: "1"
const exPos = parseInt(getVar("0_Position_Exercice"), 10);
const seqKey = `S${seqPos}`;
const exType = getVar("Ex_Type");
const success = getVar("Ex_Success");
const tentativesRestantes = parseInt(getVar("Ex_Tentatives"), 10);

// Variable cible (ex: "S1_UserData")
const userDataVar = `${seqKey}_UserData`;

// ------------------------------------------------------------
// 🔧 Lecture du JSON existant
// ------------------------------------------------------------
let data = {};
try {
  const existing = getVar(userDataVar);
  data = existing ? JSON.parse(existing) : {};
} catch (err) {
  console.warn(`⚠️ JSON invalide dans ${userDataVar}, réinitialisation.`, err);
  data = {};
}

// ------------------------------------------------------------
// 🧮 Tentatives initiales (si dispo dans cache global)
// ------------------------------------------------------------
let tentativesInitiales = 0;
try {
  const exData = window.sequenceCache?.[seqKey]?.[`EX${exPos}`];
  tentativesInitiales = exData?.Tentatives || 1;
} catch {
  tentativesInitiales = 1;
}

const tentativesUtilisees = Math.max(0, tentativesInitiales - tentativesRestantes);

// ------------------------------------------------------------
// 🎯 Récupération de la réponse selon le type d’exercice
// ------------------------------------------------------------
let userResponseObj = {};

switch (exType) {
  // 🔹 QCU
  case "QCU": {
    const answerKey = getVar("0_Reponse");
    const answerText = getVar(`0_Choix_${answerKey}`) || "";
    userResponseObj = { [answerKey]: answerText };
    break;
  }

  // 🔹 QCM
  case "QCM": {
    const responseRaw = (getVar("0_Reponse") || "").split("|").filter(Boolean);
    responseRaw.forEach(k => {
      userResponseObj[k] = getVar(`0_Choix_${k}`) || "";
    });
    break;
  }

  // 🔹 True or false
  case "True or false": {
    const answer = (getVar("0_Reponse") || "").toLowerCase();
    userResponseObj = { unique: answer };
    break;
  }

  // 🔹 Complete
  case "Complete": {
    const answer = getVar("0_Ex_Enonce") || "";
    userResponseObj = { unique: answer };
    break;
  }

  // 🔹 Matching
  case "Matching": {
    const reponse = getVar("0_Reponse") || "";
    userResponseObj = { associations: reponse };
    break;
  }

  // 🔹 Flashcard
  case "Flashcard": {
    const answer = getVar("0_Reponse") || "";
    userResponseObj = { unique: answer };
    break;
  }

  // 🔹 Information
  case "Information": {
    userResponseObj = { info: "Aucune interaction" };
    break;
  }

  // 🔹 Production orale - dictée
  case "Production orale - dictée": {
    const raw = getVar("0_Reponse") || "{}";
    try {
      const parsed = JSON.parse(raw);
      userResponseObj = {
        score: parsed.score || 0,
        texte_brut: parsed.texte_brut || "",
        texte_color: parsed.texte_color || ""
      };
    } catch (err) {
      console.warn("⚠️ Erreur de parsing JSON pour Production orale :", err);
      userResponseObj = { erreur: "Format de réponse invalide", raw };
    }
    break;
  }

  // 🔹 Défaut
  default: {
    const raw = getVar("0_Reponse") || "";
    userResponseObj = { inconnu: raw };
    console.warn(`❓ Type d’exercice inconnu : ${exType}`);
    break;
  }
}

// ------------------------------------------------------------
// 💾 Enregistrement dans le JSON
// ------------------------------------------------------------
data[`EX${exPos}`] = {
  Type: exType,
  Reponses_Choisies: userResponseObj,
  Statut: success,
  Tentatives_Utilisees: tentativesUtilisees
};

setVar(userDataVar, JSON.stringify(data));

// ------------------------------------------------------------
// 🧾 Log de contrôle
// ------------------------------------------------------------
console.group(`💾 Données sauvegardées → ${userDataVar}`);
console.log("Exercice :", `EX${exPos}`);
console.log("Type :", exType);
console.log("Réponses :", userResponseObj);
console.log("Statut :", success);
console.log("Tentatives utilisées :", tentativesUtilisees);
console.log("JSON complet :", data);
console.groupEnd();

}

window.Script193 = function()
{
  // ============================================================
// 🔁 SCRIPT — ALLER AU PROCHAIN EXERCICE ÉCHOUÉ ("Réviser les erreurs")
// ============================================================

// -------- VARIABLES DE CONTEXTE --------
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;
const exCurrent = parseInt(getVar(`${seqKey}_Exo_Current`), 10);
const historique = getVar(`${seqKey}_Win_Lose`) || "";

// -------- SÉCURITÉ --------
if (!seqPos || !historique) {
  console.warn("⚠️ Impossible d'exécuter le script — séquence ou historique manquant.");
  return;
}

// ============================================================
// 🔍 RECHERCHE DU PROCHAIN ÉCHEC ("0")
// ============================================================

// On cherche le prochain "0" APRÈS la position actuelle
const nextFailIndex = historique.indexOf("0", exCurrent);

// ============================================================
// 🎯 MISE À JOUR OU FIN DE LA RÉVISION
// ============================================================

if (nextFailIndex === -1) {
  // Aucun autre exercice échoué trouvé → fin du mode révision
  setVar("S0_Revision_Erreurs", 2);

} else {
  // Prochain exercice échoué trouvé
  const nextExercise = nextFailIndex + 1; // index → position 1-based
  setVar("0_Position_Exercice", nextExercise);
}
}

window.Script194 = function()
{
  // ============================================================
// 🖼️ REMPLACEMENT DYNAMIQUE D’IMAGE (version simplifiée)
// ============================================================
// Remplace directement l’image de l’objet Storyline (ID fixe)
// avec le chemin complet contenu dans la variable "Ex_Image".
// Aucun calcul de dossier ou de chemin n’est effectué.
// ============================================================

// -------- Lecture de la variable --------
const newImagePath = getVar("Ex_Image"); // ex: "Ressources_Sequences/S1/images/EX1.jpg"

// -------- Sécurité --------
if (!newImagePath || newImagePath.trim() === "") {
  console.warn("⚠️ Aucune image spécifiée dans Ex_Image — remplacement annulé.");
  return;
}

// -------- Sélection directe de l’image --------
const imageElement = document.querySelector('[data-model-id="6Ow7lZTxwcC"] image');
if (!imageElement) {
  console.error("❌ Impossible de trouver l’image avec data-model-id=6Ow7lZTxwcC.");
  return;
}

// -------- Remplacement du lien --------
imageElement.setAttributeNS("http://www.w3.org/1999/xlink", "xlink:href", newImagePath);

}

window.Script195 = function()
{
  // ============================================================
// 🖼️ REMPLACEMENT DYNAMIQUE D’IMAGE (version simplifiée)
// ============================================================
// Remplace directement l’image de l’objet Storyline (ID fixe)
// avec le chemin complet contenu dans la variable "Ex_Image".
// Aucun calcul de dossier ou de chemin n’est effectué.
// ============================================================

// -------- Lecture de la variable --------
const newImagePath = getVar("Ex_Image"); // ex: "Ressources_Sequences/S1/images/EX1.jpg"

// -------- Sécurité --------
if (!newImagePath || newImagePath.trim() === "") {
  console.warn("⚠️ Aucune image spécifiée dans Ex_Image — remplacement annulé.");
  return;
}

// -------- Sélection directe de l’image --------
const imageElement = document.querySelector('[data-model-id="6XW2DT3l0TI"] image');
if (!imageElement) {
  console.error("❌ Impossible de trouver l’image avec data-model-id=6jUy2ox5l86.");
  return;
}

// -------- Remplacement du lien --------
imageElement.setAttributeNS("http://www.w3.org/1999/xlink", "xlink:href", newImagePath);

}

window.Script196 = function()
{
  // Récupère les objets Storyline
const carte  = document.querySelector('[data-model-id="6WOyyFcuLyH"]');
const bouton = document.querySelector('[data-model-id="5rCsry3VrNh"]');

// Points d'ancrage
carte.style.transformOrigin = "top left";
bouton.style.transformOrigin = "center";

// Timeline pour synchroniser
const tl = gsap.timeline();

tl.to(carte, {
  scale: 0,
  opacity: 0,
  duration: 0.5,
  ease: "power1.inOut"
}, 0);

// Rotation 90° du bouton en même temps
tl.to(bouton, {
  rotate: 0,          // ou "+=90" si tu veux ajouter 90° à chaque fois
  duration: 0.5,
  ease: "power1.inOut"
}, 0);

}

window.Script197 = function()
{
  // Récupère les objets Storyline
const carte  = document.querySelector('[data-model-id="6WOyyFcuLyH"]');
const bouton = document.querySelector('[data-model-id="5rCsry3VrNh"]');

// Points d'ancrage
carte.style.transformOrigin = "top left";
bouton.style.transformOrigin = "center";

// États initiaux
gsap.set(carte,  { scale: 0, opacity: 0 });
gsap.set(bouton, { rotate: 0 }); // ou 90 si tu veux qu'il démarre déjà tourné

// Timeline pour synchroniser
const tl = gsap.timeline();

tl.to(carte, {
  scale: 1,
  opacity: 1,
  duration: 0.5,
  ease: "power1.inOut"
}, 0);

// Rotation 90° du bouton en même temps
tl.to(bouton, {
  rotate: 45,          // ou "+=90" si tu veux ajouter 90° à chaque fois
  duration: 0.5,
  ease: "power1.inOut"
}, 0);

}

window.Script198 = function()
{
  // ============================================================
// 💬 FEEDBACK MOTIVATIONNEL — AVEC SUPPORT DU FORMAT "1101nn"
// ============================================================

// -------- VARIABLES DE BASE --------
let resultat = getVar("Ex_Success");
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;
const exCurrent = parseInt(getVar(`${seqKey}_Exo_Current`), 10);

// ============================================================
// 🔍 SI RESULTAT VIDE → CHERCHE DANS S1_Win_Lose ("1101nn")
// ============================================================
if (!resultat || resultat === "") {
  const historique = getVar(`${seqKey}_Win_Lose`) || "";
  const charAtIndex = historique.charAt(exCurrent - 1);

  if (charAtIndex === "1" || charAtIndex === "0") {
    resultat = charAtIndex;
  } else {
    console.log(`ℹ️ Aucun résultat valide trouvé dans ${seqKey}_Win_Lose à l’index ${exCurrent - 1}`);
  }
}

// ============================================================
// 💬 LISTES DE FEEDBACKS
// ============================================================
const feedbackCorrect = [
  "Bravo !",
  "Super !",
  "Bien joué !",
  "Excellent !"
];

const feedbackIncorrect = [
  "Pas exactement.",
  "Oups !",
  "La prochaine fois !"
];

const feedbackNeutre = [
  "Continue !"
];

// ============================================================
// 🎯 CHOIX DU FEEDBACK
// ============================================================
let liste;
switch (resultat) {
  case "1":
    liste = feedbackCorrect;
    break;
  case "0":
    liste = feedbackIncorrect;
    break;
  default:
    liste = feedbackNeutre;
    break;
}

// Sélection aléatoire dans la liste
const feedback = liste[Math.floor(Math.random() * liste.length)];

// ============================================================
// 🧾 MISE À JOUR STORYLINE
// ============================================================
setVar("Ex_Feedback_Motivation", feedback);

}

window.Script199 = function()
{
  // ============================================================
// 🔁 SCRIPT — ALLER AU PROCHAIN EXERCICE ÉCHOUÉ ("Réviser les erreurs")
// ============================================================

// -------- VARIABLES DE CONTEXTE --------
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;
const exCurrent = parseInt(getVar(`${seqKey}_Exo_Current`), 10);
const historique = getVar(`${seqKey}_Win_Lose`) || "";

// -------- SÉCURITÉ --------
if (!seqPos || !historique) {
  console.warn("⚠️ Impossible d'exécuter le script — séquence ou historique manquant.");
  return;
}

// ============================================================
// 🔍 RECHERCHE DU PROCHAIN ÉCHEC ("0")
// ============================================================

// On cherche le prochain "0" APRÈS la position actuelle
const nextFailIndex = historique.indexOf("0", exCurrent);

// ============================================================
// 🎯 MISE À JOUR OU FIN DE LA RÉVISION
// ============================================================

if (nextFailIndex === -1) {
  // Aucun autre exercice échoué trouvé → fin du mode révision
  setVar("S0_Revision_Erreurs", 2);

} else {
  // Prochain exercice échoué trouvé
  const nextExercise = nextFailIndex + 1; // index → position 1-based
  setVar("0_Position_Exercice", nextExercise);
}
}

window.Script200 = function()
{
  // ============================================================
// 🎯 ANIMATION DE JAUGE — Rotation + Oscillation continue + Feedback motivationnel + Indicateur visuel
// ============================================================

// -------- OBJETS STORYLINE --------
const pointer = object('5fZOHpnMbya');
const gauge = object('6nKxLAItMtB');

// -------- PARAMÈTRES --------
const minAngle = 0;
const maxAngle = 180;
const oscillationRange = 10;
const oscillationSpeed = 1.5;

// ============================================================
// 🧮 DETECTION DU RESULTAT + RECUPERATION VARIABLES STORYLINE
// ============================================================
let resultat = getVar("Ex_Success");
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;
const exCurrent = getVar(`${seqKey}_Exo_Current`);

// Si il n'y a pas de résultat direct, on tente de le retrouver dans Sx_Win_Lose
if (resultat === "") {
  const historique = getVar(`${seqKey}_Win_Lose`);
  const charAtIndex = historique.charAt(exCurrent - 1);
  if (charAtIndex === "1" || charAtIndex === "0") {
    resultat = charAtIndex;
  } else {
    console.log(`ℹ️ Aucun résultat valide trouvé dans ${seqKey}_Win_Lose à l’index ${exCurrent - 1}`);
    resultat = "";
  }
}

// ============================================================
// ⚙️ Changement couleur jauge
// ============================================================
if (resultat === "1") {
  gauge.state = "Correct" ;
} else if (resultat === "0") {
  gauge.state = "Incorrect" ;
}

// ============================================================
// ⚙️ CALCULS D’ANGLES
// ============================================================
const baseAngle = resultat * (maxAngle - minAngle) + minAngle;
const angleMin = baseAngle - oscillationRange;
const angleMax = baseAngle + oscillationRange;


const goingUp = resultat === "1";
const targetAngle = goingUp ? angleMax : angleMin;

// ============================================================
// 🧹 ARRÊTE LES ANIMATIONS EXISTANTES
// ============================================================
gsap.killTweensOf(pointer);

// ============================================================
// 🚀 ANIMATION DE L’AIGUILLE
// ============================================================
gsap.to(pointer, {
  rotation: targetAngle,
  duration: 1.2,
  ease: "power2.inOut",
  onComplete: () => {
    gsap.to(pointer, {
      rotation: goingUp ? angleMin : angleMax,
      duration: oscillationSpeed,
      ease: "sine.inOut",
      yoyo: true,
      repeat: -1
    });
  }
});

}

window.Script201 = function()
{
  const Btn_Affichage  = document.querySelector('[data-model-id="6geks01QgvK"]');
const temoin = object('6XIh2Zufqbt');

// (Optionnel mais recommandé) point d’ancrage de la rotation
Btn_Affichage.style.transformOrigin = "50% 50%";

// On lit l’état actuel puis on bascule
const isAffiche = (temoin.state === "Feedback_Affiche");

temoin.state = isAffiche ? "Feedback_Cache" : "Feedback_Affiche";

// Rotation GSAP (durée + easing ajustables)
gsap.to(Btn_Affichage, {
  rotation: isAffiche ? 180 : 0,
  duration: 0.45,
  ease: "power2.inOut",
  overwrite: "auto"
});

}

window.Script202 = function()
{
  // ============================================================
// 💬 FEEDBACK MOTIVATIONNEL — AVEC SUPPORT DU FORMAT "1101nn"
// ============================================================

// -------- VARIABLES DE BASE --------
let resultat = getVar("Ex_Success");
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;
const exCurrent = parseInt(getVar(`${seqKey}_Exo_Current`), 10);

// ============================================================
// 🔍 SI RESULTAT VIDE → CHERCHE DANS S1_Win_Lose ("1101nn")
// ============================================================
if (!resultat || resultat === "") {
  const historique = getVar(`${seqKey}_Win_Lose`) || "";
  const charAtIndex = historique.charAt(exCurrent - 1);

  if (charAtIndex === "1" || charAtIndex === "0") {
    resultat = charAtIndex;
  } else {
    console.log(`ℹ️ Aucun résultat valide trouvé dans ${seqKey}_Win_Lose à l’index ${exCurrent - 1}`);
  }
}

// ============================================================
// 💬 LISTES DE FEEDBACKS
// ============================================================
//const feedbackCorrect = [
//  "Bravo !",
//  "Super !",
//  "Bien joué !",
//  "Excellent !"
//];

//const feedbackIncorrect = [
//  "Pas exactement.",
//  "Oups !",
//  "La prochaine fois !"
//];

const feedbackCorrect = [
  "Bravo, c'est une bonne réponse !",
  "Super, tu es sur la bonne voie !",
  "Bien joué, tu progresses !",
  "Excellent, continue comme ça !"
];

const feedbackIncorrect = [
  "Ce n'est pas tout à fait ça.",
  "Oups, ce n'est pas la bonne réponse.",
  "Tu y arriveras la prochaine fois !",
  "Pas exactement. Encore un effort !"
];


const feedbackNeutre = [
  "Continue !"
];

// ============================================================
// 🎯 CHOIX DU FEEDBACK
// ============================================================
let liste;
switch (resultat) {
  case "1":
    liste = feedbackCorrect;
    break;
  case "0":
    liste = feedbackIncorrect;
    break;
  default:
    liste = feedbackNeutre;
    break;
}

// Sélection aléatoire dans la liste
const feedback = liste[Math.floor(Math.random() * liste.length)];

// ============================================================
// 🧾 MISE À JOUR STORYLINE
// ============================================================
setVar("Ex_Feedback_Motivation", feedback);

}

window.Script203 = function()
{
  // ============================================================
// 🔁 SCRIPT — ALLER AU PROCHAIN EXERCICE ÉCHOUÉ ("Réviser les erreurs")
// ============================================================

// -------- VARIABLES DE CONTEXTE --------
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;
const exCurrent = parseInt(getVar(`${seqKey}_Exo_Current`), 10);
const historique = getVar(`${seqKey}_Win_Lose`) || "";

// -------- SÉCURITÉ --------
if (!seqPos || !historique) {
  console.warn("⚠️ Impossible d'exécuter le script — séquence ou historique manquant.");
  return;
}

// ============================================================
// 🔍 RECHERCHE DU PROCHAIN ÉCHEC ("0")
// ============================================================

// On cherche le prochain "0" APRÈS la position actuelle
const nextFailIndex = historique.indexOf("0", exCurrent);

// ============================================================
// 🎯 MISE À JOUR OU FIN DE LA RÉVISION
// ============================================================

if (nextFailIndex === -1) {
  // Aucun autre exercice échoué trouvé → fin du mode révision
  setVar("S0_Revision_Erreurs", 2);

} else {
  // Prochain exercice échoué trouvé
  const nextExercise = nextFailIndex + 1; // index → position 1-based
  setVar("0_Position_Exercice", nextExercise);
}
}

window.Script204 = function()
{
  // ============================================================
// 🎯 ANIMATION DE JAUGE — Rotation + Oscillation continue + Feedback motivationnel + Indicateur visuel
// ============================================================

// -------- OBJETS STORYLINE --------
const pointer = object('61WVHrM0EGs');
//const gauge = object('5lezhyLYUu5'); Cet objet n'existe pas ?
const gauge = object('6rIRKS6iuFv');


// -------- PARAMÈTRES --------
const minAngle = 0;
const maxAngle = 180;
const oscillationRange = 10;
const oscillationSpeed = 1.5;

// ============================================================
// 🧮 DETECTION DU RESULTAT + RECUPERATION VARIABLES STORYLINE
// ============================================================
let resultat = getVar("Ex_Success");
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;
const exCurrent = getVar(`${seqKey}_Exo_Current`);

// Si il n'y a pas de résultat direct, on tente de le retrouver dans Sx_Win_Lose
if (resultat === "") {
  const historique = getVar(`${seqKey}_Win_Lose`);
  const charAtIndex = historique.charAt(exCurrent - 1);
  if (charAtIndex === "1" || charAtIndex === "0") {
    resultat = charAtIndex;
  } else {
    console.log(`ℹ️ Aucun résultat valide trouvé dans ${seqKey}_Win_Lose à l’index ${exCurrent - 1}`);
    resultat = "";
  }
}

// ============================================================
// ⚙️ Changement couleur jauge
// ============================================================
if (resultat === "1") {
  gauge.state = "Correct" ;
} else if (resultat === "0") {
  gauge.state = "Incorrect" ;
}

// ============================================================
// ⚙️ CALCULS D’ANGLES
// ============================================================
const baseAngle = resultat * (maxAngle - minAngle) + minAngle;
const angleMin = baseAngle - oscillationRange;
const angleMax = baseAngle + oscillationRange;


const goingUp = resultat === "1";
const targetAngle = goingUp ? angleMax : angleMin;

// ============================================================
// 🧹 ARRÊTE LES ANIMATIONS EXISTANTES
// ============================================================
gsap.killTweensOf(pointer);

// ============================================================
// 🚀 ANIMATION DE L’AIGUILLE
// ============================================================
gsap.to(pointer, {
  rotation: targetAngle,
  duration: 1.2,
  ease: "power2.inOut",
  onComplete: () => {
    gsap.to(pointer, {
      rotation: goingUp ? angleMin : angleMax,
      duration: oscillationSpeed,
      ease: "sine.inOut",
      yoyo: true,
      repeat: -1
    });
  }
});

}

window.Script205 = function()
{
  const Btn_Affichage  = document.querySelector('[data-model-id="6RRLU9ixx38"]');
const temoin = object('68ikzB1cq1L');

// (Optionnel mais recommandé) point d’ancrage de la rotation
Btn_Affichage.style.transformOrigin = "50% 50%";

// On lit l’état actuel puis on bascule
const isAffiche = (temoin.state === "Feedback_Affiche");

temoin.state = isAffiche ? "Feedback_Cache" : "Feedback_Affiche";

// Rotation GSAP (durée + easing ajustables)
gsap.to(Btn_Affichage, {
  rotation: isAffiche ? 180 : 0,
  duration: 0.45,
  ease: "power2.inOut",
  overwrite: "auto"
});

}

window.Script206 = function()
{
  // Récupère le résultat
let resultat = getVar("Ex_Success");

// Définit les listes de feedback
const feedbackCorrect = [
  "Bravo !",
  "Super !",
  "Bien joué !",
  "Excellent !"
];

const feedbackIncorrect = [
  "Pas exactement",
  "Oups !",
  "La prochaine fois !"
];

// Choisit la liste en fonction du résultat
let liste = (resultat === "1") ? feedbackCorrect : feedbackIncorrect;

// Sélectionne un élément aléatoire dans la liste
let feedback = liste[Math.floor(Math.random() * liste.length)];

// Met à jour la variable Storyline
setVar("Ex_Feedback_Motivation", feedback);

}

window.Script207 = function()
{
  // ============================================================
// 🎯 ANIMATION DE JAUGE — Rotation + Oscillation continue + Feedback motivationnel + Indicateur visuel
// ============================================================

// -------- OBJETS STORYLINE --------
const pointer = object('5Ux37gXcJcw');
const gauge = object('5enGetq7POY');

// -------- PARAMÈTRES --------
const minAngle = 0;
const maxAngle = 180;
const oscillationRange = 10;
const oscillationSpeed = 1.5;

// ============================================================
// 🧮 DETECTION DU RESULTAT + RECUPERATION VARIABLES STORYLINE
// ============================================================
let resultat = getVar("Ex_Success");
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;
const exCurrent = getVar(`${seqKey}_Exo_Current`);

// Si il n'y a pas de résultat direct, on tente de le retrouver dans Sx_Win_Lose
if (resultat === "") {
  const historique = getVar(`${seqKey}_Win_Lose`);
  const charAtIndex = historique.charAt(exCurrent - 1);
  if (charAtIndex === "1" || charAtIndex === "0") {
    resultat = charAtIndex;
  } else {
    console.log(`ℹ️ Aucun résultat valide trouvé dans ${seqKey}_Win_Lose à l’index ${exCurrent - 1}`);
    resultat = "";
  }
}

// ============================================================
// ⚙️ Changement couleur jauge
// ============================================================
if (resultat === "1") {
  gauge.state = "Correct" ;
} else if (resultat === "0") {
  gauge.state = "Incorrect" ;
}

// ============================================================
// ⚙️ CALCULS D’ANGLES
// ============================================================
const baseAngle = resultat * (maxAngle - minAngle) + minAngle;
const angleMin = baseAngle - oscillationRange;
const angleMax = baseAngle + oscillationRange;


const goingUp = resultat === "1";
const targetAngle = goingUp ? angleMax : angleMin;

// ============================================================
// 🧹 ARRÊTE LES ANIMATIONS EXISTANTES
// ============================================================
gsap.killTweensOf(pointer);

// ============================================================
// 🚀 ANIMATION DE L’AIGUILLE
// ============================================================
gsap.to(pointer, {
  rotation: targetAngle,
  duration: 1.2,
  ease: "power2.inOut",
  onComplete: () => {
    gsap.to(pointer, {
      rotation: goingUp ? angleMin : angleMax,
      duration: oscillationSpeed,
      ease: "sine.inOut",
      yoyo: true,
      repeat: -1
    });
  }
});

}

window.Script208 = function()
{
  // ============================================================
// 🔁 SCRIPT — ALLER AU PROCHAIN EXERCICE ÉCHOUÉ ("Réviser les erreurs")
// ============================================================

// -------- VARIABLES DE CONTEXTE --------
const seqPos = getVar("0_Position_Sequence"); // ex: "1", "2", "3", "4"
const seqKey = `S${seqPos}`;                  // ex: "S1"
const exCurrent = parseInt(getVar(`${seqKey}_Exo_Current`) || 0, 10); // ex: 3
const historique = getVar(`${seqKey}_Win_Lose`) || ""; // ex: "110010"

// -------- SÉCURITÉ --------
if (!seqPos || !historique) {
  console.warn("⚠️ Impossible d'exécuter le script — séquence ou historique manquant.");
  return;
}

// ============================================================
// 🔍 RECHERCHE DU PROCHAIN ÉCHEC ("0")
// ============================================================

// On cherche le prochain "0" APRÈS la position actuelle
const nextFailIndex = historique.indexOf("0", exCurrent);

// ============================================================
// 🎯 MISE À JOUR OU FIN DE LA RÉVISION
// ============================================================

if (nextFailIndex === -1) {
  // Aucun autre exercice échoué trouvé → fin du mode révision
  setVar("S0_Revision_Erreurs", 2);
  console.log("🎉 Tous les exercices échoués ont été revus — fin du mode révision (S0_Revision_Erreurs = 2).");
} else {
  // Prochain exercice échoué trouvé
  const nextExercise = nextFailIndex + 1; // index → position 1-based
  setVar("0_Position_Exercice", nextExercise);
  console.log(`🔁 Révision → Prochain exercice échoué : EX${nextExercise}`);
}

console.log(`(Séquence : ${seqKey}, Historique : "${historique}")`);

}

window.Script209 = function()
{
  // ============================================================
// 🎬 REMPLACEMENT DYNAMIQUE DE VIDÉO (version simplifiée)
// ============================================================
// Remplace directement la vidéo de l'objet Storyline (ID fixe)
// avec le chemin complet contenu dans la variable "Ex_Video".
// ============================================================

// -------- Lecture de la variable --------
const newVideoPath = getVar("Ex_Video"); // ex: "Ressources_Sequences/S1/Videos/S1_EX1.mp4"

// -------- Sécurité --------
if (!newVideoPath || newVideoPath.trim() === "") {
  console.warn("⚠️ Aucune vidéo spécifiée dans Ex_Video — remplacement annulé.");
  return;
}

// -------- Sélection directe de la vidéo --------
const videoElement = document.querySelector('[data-model-id="5pTX8N7gCDH"] video');
if (!videoElement) {
  console.error("❌ Impossible de trouver la vidéo avec data-model-id=5pTX8N7gCDH.");
  return;
}

// -------- Remplacement de la source --------
videoElement.setAttribute("xlink:href", newVideoPath);
videoElement.src = newVideoPath;
videoElement.load();

// -------- Suppression de la vignette (poster) --------
const container = videoElement.closest('[data-model-id="5pTX8N7gCDH"]');
if (container) {
  const poster = container.querySelector("img.video-player-poster");
  if (poster) {
    poster.remove();
    console.log("✅ Vignette (poster) supprimée — la 1ère image de la vidéo sera visible.");
  }
}
}

window.Script210 = function()
{
  // ============================================================
// 🖼️ REMPLACEMENT DYNAMIQUE D’IMAGE (version simplifiée)
// ============================================================
// Remplace directement l’image de l’objet Storyline (ID fixe)
// avec le chemin complet contenu dans la variable "Ex_Image".
// Aucun calcul de dossier ou de chemin n’est effectué.
// ============================================================

// -------- Lecture de la variable --------
const newImagePath = getVar("Ex_Image"); // ex: "Ressources_Sequences/S1/images/EX1.jpg"

// -------- Sécurité --------
if (!newImagePath || newImagePath.trim() === "") {
  console.warn("⚠️ Aucune image spécifiée dans Ex_Image — remplacement annulé.");
  return;
}

// -------- Sélection directe de l’image --------
const imageElement = document.querySelector('[data-model-id="6jUy2ox5l86"] image');
if (!imageElement) {
  console.error("❌ Impossible de trouver l’image avec data-model-id=6jUy2ox5l86.");
  return;
}

// -------- Remplacement du lien --------
imageElement.setAttributeNS("http://www.w3.org/1999/xlink", "xlink:href", newImagePath);

}

window.Script211 = function()
{
  // ============================================================
// 🖼️ REMPLACEMENT DYNAMIQUE D’IMAGE (version simplifiée)
// ============================================================
// Remplace directement l’image de l’objet Storyline (ID fixe)
// avec le chemin complet contenu dans la variable "Ex_Image".
// Aucun calcul de dossier ou de chemin n’est effectué.
// ============================================================

// -------- Lecture de la variable --------
const newImagePath = getVar("Ex_Image"); // ex: "Ressources_Sequences/S1/images/EX1.jpg"

// -------- Sécurité --------
if (!newImagePath || newImagePath.trim() === "") {
  console.warn("⚠️ Aucune image spécifiée dans Ex_Image — remplacement annulé.");
  return;
}

// -------- Sélection directe de l’image --------
const imageElement = document.querySelector('[data-model-id="6c22D92goAT"] image');
if (!imageElement) {
  console.error("❌ Impossible de trouver l’image avec data-model-id=6c22D92goAT.");
  return;
}

// -------- Remplacement du lien --------
imageElement.setAttributeNS("http://www.w3.org/1999/xlink", "xlink:href", newImagePath);

}

window.Script212 = function()
{
  // ============================================================
// ⚙️ BARRE DE PROGRESSION — SYNCHRONISATION AVEC LA SÉQUENCE EN COURS
// ============================================================

// --------- Lecture de la séquence courante ---------
const seqPos = getVar("0_Position_Sequence");   // ex. 1 → S1
const seqKey = `S${seqPos}`;

// --------- Lecture des variables de la séquence correspondante ---------
const Exo_Reached = getVar("S0_Exo_Reached") || 0;
const Exo_Total = getVar("S0_Exo_Total") || 1;

// --------- Calcul du pourcentage ---------
const progress = Math.min(Exo_Reached / Exo_Total, 1); // clamp entre 0 et 1

// --------- Sélectionne l'objet Storyline ---------
const ProgressBar = document.querySelector(`[data-model-id="6f561U28wA4"]`);

if (ProgressBar) {
  // --------- Sélectionne l'élément graphique principal ---------
  const shape = ProgressBar.querySelector("path");

  if (shape) {
    // Si ce n’est pas déjà fait, on garde la largeur d’origine
    if (!shape.dataset.fullWidth) {
      const bbox = shape.getBBox();
      shape.dataset.fullWidth = bbox.width;
    }

    // --------- Calcul de la largeur selon la progression ---------
    const fullWidth = parseFloat(shape.dataset.fullWidth);

    // --------- Application du remplissage via clip-path ---------
    shape.style.clipPath = `inset(0 ${100 - progress * 100}% 0 0 round 0px)`;
  }
}

}

window.Script213 = function()
{
  // ============================================================
// ⚙️ BARRE DE PROGRESSION ANIMÉE (AVEC INITIALISATION INTELLIGENTE)
// ============================================================

// Durée de l’animation en millisecondes (modifiable)
const animationDuration = 800; // 0.8s = fluide, 300 = rapide, 1500 = lente

function updateProgressBarAnimated() {
  // --------- Lecture de la séquence courante ---------
  const seqPos = getVar("0_Position_Sequence");
  const seqKey = `S${seqPos}`;

  // --------- Lecture des variables globales S0 ---------
  const Exo_Reached = getVar("S0_Exo_Reached") || 0;
  const Exo_Total = getVar("S0_Exo_Total") || 1;
  const progress = Math.min(Exo_Reached / Exo_Total, 1);

  // --------- Sélectionne l'objet Storyline ---------
  const ProgressBar = document.querySelector(`[data-model-id="6f561U28wA4"]`);
  if (!ProgressBar) return;

  const shape = ProgressBar.querySelector("path");
  if (!shape) return;

  // --------- Initialisation si nécessaire ---------
  if (!shape.dataset.fullWidth) {
    const bbox = shape.getBBox();
    shape.dataset.fullWidth = bbox.width;
  }

  // --------- Nouvelle logique : position initiale intelligente ---------
  let startProgress;

  if (shape.dataset.currentProgress !== undefined) {
    // On continue à partir de la progression actuelle
    startProgress = parseFloat(shape.dataset.currentProgress) || 0;
  } else if (Exo_Reached >= 1) {
    // Si aucune donnée mais au moins un exercice complété,
    // on démarre au niveau précédent
    startProgress = (Exo_Reached - 1) / Exo_Total;
  } else {
    // Sinon, tout au début
    startProgress = 0;
  }

  const startTime = performance.now();

  // --------- Fonction d'animation fluide ---------
  function animate(time) {
    const elapsed = time - startTime;
    const t = Math.min(elapsed / animationDuration, 1);
    const eased = t < 0.5 ? 2 * t * t : -1 + (4 - 2 * t) * t; // easeInOutQuad

    const currentProgress = startProgress + (progress - startProgress) * eased;
    shape.style.clipPath = `inset(0 ${100 - currentProgress * 100}% 0 0 round 0px)`;
    shape.dataset.currentProgress = currentProgress;

    if (t < 1) requestAnimationFrame(animate);
  }

  requestAnimationFrame(animate);
}

// ============================================================
// ▶️ APPEL DU SCRIPT (exécuté manuellement via trigger JS)
// ============================================================

updateProgressBarAnimated();

}

window.Script214 = function()
{
  // -------- Initialisation --------

// Récupère le numéro ou identifiant d'exercice (ex: "EX2")
const AudioPath = getVar("0_Audio_Lecteur");

// Si un audio était déjà en cours → on le stoppe et on remet au début
if (window.audioUnique) {
  window.audioUnique.pause();
  window.audioUnique.currentTime = 0;
}

// Crée un nouvel objet audio
window.audioUnique = new Audio(AudioPath);

// Lecture
window.audioUnique.play().catch(err => {
  console.log("Erreur lecture Back :", err);
});
}

window.Script215 = function()
{
  // ============================================================
// 🎯 MISE À JOUR DES VARIABLES Sx_Win_Lose SELON Ex_Success (texte)
// ============================================================

// -------- Lecture des variables Storyline --------
const seqPos  = getVar("0_Position_Sequence");
const exPos   = getVar("0_Position_Exercice");
const success = getVar("Ex_Success");

// -------- Construction du nom de la séquence --------
const seqKey     = `S${seqPos}`;
const winLoseVar = `${seqKey}_Win_Lose`;

// -------- Lecture actuelle de la variable Win_Lose --------
let winLose = getVar(winLoseVar) || "";

// -------- S’assure que la longueur correspond au nombre total d’exercices --------
const total = getVar(`0_Menu_${seqKey}_Exo_Total`);

// -------- Conversion en tableau pour modification --------
const chars = winLose.split("");

// -------- Mise à jour du caractère correspondant à l’exercice actuel --------
if (!(chars[exPos - 1] === "1" && success === "0")) {
    chars[exPos - 1] = success === "1" ? "1" : "0";
}
// Si l'exercice est déjà réussi, on garde la réussite.

// -------- Conversion inverse en chaîne --------
winLose = chars.join("");

// -------- Écriture dans Storyline --------
setVar(winLoseVar, winLose);

// ============================================================
// 🔁 SWITCH AUTOMATIQUE DE 0_Feedback_Switch
// ============================================================
let feedbackSwitch = getVar("0_Feedback_Switch");
feedbackSwitch = feedbackSwitch === true || feedbackSwitch === "true" ? false : true;
setVar("0_Feedback_Switch", feedbackSwitch);

}

window.Script216 = function()
{
  // ============================================================
// 🏁 SCRIPT DE FIN D’EXERCICE — MISE À JOUR PROGRESSION & TENTATIVES
// ============================================================

// -------- CONFIGURATION --------
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;

const exCurrent  = parseInt(getVar(`${seqKey}_Exo_Current`), 10);
const exReached  = parseInt(getVar(`${seqKey}_Exo_Reached`), 10);
const tentVar    = `${seqKey}_Exo_Current_Tentatives`;
// ============================================================
// 🧭 MISE À JOUR DE LA PROGRESSION
// ============================================================

// Si on avance (évite de revenir en arrière)
if (exCurrent > exReached) {
  setVar(`${seqKey}_Exo_Reached`, exCurrent);
  setVar("S0_Exo_Reached", exCurrent); 
}

// ============================================================
// 🧮 MARQUAGE DE L’EXERCICE TERMINÉ
// ============================================================

setVar(tentVar, -10);

}

window.Script217 = function()
{
  // ============================================================
// 🧠 SAUVEGARDE AUTOMATIQUE DES DONNÉES UTILISATEUR (GLOBAL)
// ============================================================
//
// 🔹 Ce script est appelé automatiquement après la validation d’un exercice.
// 🔹 Il détecte le type d’exercice et sauvegarde la réponse dans la variable JSON
//    correspondante (ex: S1_UserData)
//
// ============================================================

// ------------------------------------------------------------
// 🔧 Lecture des infos de contexte
// ------------------------------------------------------------
const seqPos = getVar("0_Position_Sequence");           // ex: "1"
const exPos = parseInt(getVar("0_Position_Exercice"), 10);
const seqKey = `S${seqPos}`;
const exType = getVar("Ex_Type");
const success = getVar("Ex_Success");
const tentativesRestantes = parseInt(getVar("Ex_Tentatives"), 10);

// Variable cible (ex: "S1_UserData")
const userDataVar = `${seqKey}_UserData`;

// ------------------------------------------------------------
// 🔧 Lecture du JSON existant
// ------------------------------------------------------------
let data = {};
try {
  const existing = getVar(userDataVar);
  data = existing ? JSON.parse(existing) : {};
} catch (err) {
  console.warn(`⚠️ JSON invalide dans ${userDataVar}, réinitialisation.`, err);
  data = {};
}

// ------------------------------------------------------------
// 🧮 Tentatives initiales (si dispo dans cache global)
// ------------------------------------------------------------
let tentativesInitiales = 0;
try {
  const exData = window.sequenceCache?.[seqKey]?.[`EX${exPos}`];
  tentativesInitiales = exData?.Tentatives || 1;
} catch {
  tentativesInitiales = 1;
}

const tentativesUtilisees = Math.max(0, tentativesInitiales - tentativesRestantes);

// ------------------------------------------------------------
// 🎯 Récupération de la réponse selon le type d’exercice
// ------------------------------------------------------------
let userResponseObj = {};

switch (exType) {
  // 🔹 QCU
  case "QCU": {
    const answerKey = getVar("0_Reponse");
    const answerText = getVar(`0_Choix_${answerKey}`) || "";
    userResponseObj = { [answerKey]: answerText };
    break;
  }

  // 🔹 QCM
  case "QCM": {
    const responseRaw = (getVar("0_Reponse") || "").split("|").filter(Boolean);
    responseRaw.forEach(k => {
      userResponseObj[k] = getVar(`0_Choix_${k}`) || "";
    });
    break;
  }

  // 🔹 True or false
  case "True or false": {
    const answer = (getVar("0_Reponse") || "").toLowerCase();
    userResponseObj = { unique: answer };
    break;
  }

  // 🔹 Complete
  case "Complete": {
    const answer = getVar("0_Ex_Enonce") || "";
    userResponseObj = { unique: answer };
    break;
  }

  // 🔹 Matching
  case "Matching": {
    const reponse = getVar("0_Reponse") || "";
    userResponseObj = { associations: reponse };
    break;
  }

  // 🔹 Flashcard
  case "Flashcard": {
    const answer = getVar("0_Reponse") || "";
    userResponseObj = { unique: answer };
    break;
  }

  // 🔹 Information
  case "Information": {
    userResponseObj = { info: "Aucune interaction" };
    break;
  }

  // 🔹 Production orale - dictée
  case "Production orale - dictée": {
    const raw = getVar("0_Reponse") || "{}";
    try {
      const parsed = JSON.parse(raw);
      userResponseObj = {
        score: parsed.score || 0,
        texte_brut: parsed.texte_brut || "",
        texte_color: parsed.texte_color || ""
      };
    } catch (err) {
      console.warn("⚠️ Erreur de parsing JSON pour Production orale :", err);
      userResponseObj = { erreur: "Format de réponse invalide", raw };
    }
    break;
  }

  // 🔹 Défaut
  default: {
    const raw = getVar("0_Reponse") || "";
    userResponseObj = { inconnu: raw };
    console.warn(`❓ Type d’exercice inconnu : ${exType}`);
    break;
  }
}

// ------------------------------------------------------------
// 💾 Enregistrement dans le JSON
// ------------------------------------------------------------
data[`EX${exPos}`] = {
  Type: exType,
  Reponses_Choisies: userResponseObj,
  Statut: success,
  Tentatives_Utilisees: tentativesUtilisees
};

setVar(userDataVar, JSON.stringify(data));

// ------------------------------------------------------------
// 🧾 Log de contrôle
// ------------------------------------------------------------
console.group(`💾 Données sauvegardées → ${userDataVar}`);
console.log("Exercice :", `EX${exPos}`);
console.log("Type :", exType);
console.log("Réponses :", userResponseObj);
console.log("Statut :", success);
console.log("Tentatives utilisées :", tentativesUtilisees);
console.log("JSON complet :", data);
console.groupEnd();

}

window.Script218 = function()
{
  // ============================================================
// 🔁 SCRIPT — ALLER AU PROCHAIN EXERCICE ÉCHOUÉ ("Réviser les erreurs")
// ============================================================

// -------- VARIABLES DE CONTEXTE --------
const seqPos = getVar("0_Position_Sequence"); // ex: "1", "2", "3", "4"
const seqKey = `S${seqPos}`;                  // ex: "S1"
const exCurrent = parseInt(getVar(`${seqKey}_Exo_Current`) || 0, 10); // ex: 3
const historique = getVar(`${seqKey}_Win_Lose`) || ""; // ex: "110010"

// -------- SÉCURITÉ --------
if (!seqPos || !historique) {
  console.warn("⚠️ Impossible d'exécuter le script — séquence ou historique manquant.");
  return;
}

// ============================================================
// 🔍 RECHERCHE DU PROCHAIN ÉCHEC ("0")
// ============================================================

// On cherche le prochain "0" APRÈS la position actuelle
const nextFailIndex = historique.indexOf("0", exCurrent);

// ============================================================
// 🎯 MISE À JOUR OU FIN DE LA RÉVISION
// ============================================================

if (nextFailIndex === -1) {
  // Aucun autre exercice échoué trouvé → fin du mode révision
  setVar("S0_Revision_Erreurs", 2);
  console.log("🎉 Tous les exercices échoués ont été revus — fin du mode révision (S0_Revision_Erreurs = 2).");
} else {
  // Prochain exercice échoué trouvé
  const nextExercise = nextFailIndex + 1; // index → position 1-based
  setVar("0_Position_Exercice", nextExercise);
  console.log(`🔁 Révision → Prochain exercice échoué : EX${nextExercise}`);
}

console.log(`(Séquence : ${seqKey}, Historique : "${historique}")`);

}

window.Script219 = function()
{
  // ============================================================
// 🖼️ REMPLACEMENT DYNAMIQUE D’IMAGE (version simplifiée)
// ============================================================
// Remplace directement l’image de l’objet Storyline (ID fixe)
// avec le chemin complet contenu dans la variable "Ex_Image".
// Aucun calcul de dossier ou de chemin n’est effectué.
// ============================================================

// -------- Lecture de la variable --------
const newImagePath = getVar("Ex_Image"); // ex: "Ressources_Sequences/S1/images/EX1.jpg"

// -------- Sécurité --------
if (!newImagePath || newImagePath.trim() === "") {
  console.warn("⚠️ Aucune image spécifiée dans Ex_Image — remplacement annulé.");
  return;
}

// -------- Sélection directe de l’image --------
const imageElement = document.querySelector('[data-model-id="6R3LkxIWiTk"] image');
if (!imageElement) {
  console.error("❌ Impossible de trouver l’image avec data-model-id=6jUy2ox5l86.");
  return;
}

// -------- Remplacement du lien --------
imageElement.setAttributeNS("http://www.w3.org/1999/xlink", "xlink:href", newImagePath);

}

window.Script220 = function()
{
  // ============================================================
// 🔁 SCRIPT — ALLER AU PROCHAIN EXERCICE ÉCHOUÉ ("Réviser les erreurs")
// ============================================================

// -------- VARIABLES DE CONTEXTE --------
const seqPos = getVar("0_Position_Sequence"); // ex: "1", "2", "3", "4"
const seqKey = `S${seqPos}`;                  // ex: "S1"
const exCurrent = parseInt(getVar(`${seqKey}_Exo_Current`) || 0, 10); // ex: 3
const historique = getVar(`${seqKey}_Win_Lose`) || ""; // ex: "110010"

// -------- SÉCURITÉ --------
if (!seqPos || !historique) {
  console.warn("⚠️ Impossible d'exécuter le script — séquence ou historique manquant.");
  return;
}

// ============================================================
// 🔍 RECHERCHE DU PROCHAIN ÉCHEC ("0")
// ============================================================

// On cherche le prochain "0" APRÈS la position actuelle
const nextFailIndex = historique.indexOf("0", exCurrent);

// ============================================================
// 🎯 MISE À JOUR OU FIN DE LA RÉVISION
// ============================================================

if (nextFailIndex === -1) {
  // Aucun autre exercice échoué trouvé → fin du mode révision
  setVar("S0_Revision_Erreurs", 2);
  console.log("🎉 Tous les exercices échoués ont été revus — fin du mode révision (S0_Revision_Erreurs = 2).");
} else {
  // Prochain exercice échoué trouvé
  const nextExercise = nextFailIndex + 1; // index → position 1-based
  setVar("0_Position_Exercice", nextExercise);
  console.log(`🔁 Révision → Prochain exercice échoué : EX${nextExercise}`);
}

console.log(`(Séquence : ${seqKey}, Historique : "${historique}")`);

}

window.Script221 = function()
{
  // Récupère les objets Storyline
const carte  = document.querySelector('[data-model-id="6WOyyFcuLyH"]');
const bouton = document.querySelector('[data-model-id="5rCsry3VrNh"]');

// Points d'ancrage
carte.style.transformOrigin = "top left";
bouton.style.transformOrigin = "center";

// Timeline pour synchroniser
const tl = gsap.timeline();

tl.to(carte, {
  scale: 0,
  opacity: 0,
  duration: 0.5,
  ease: "power1.inOut"
}, 0);

// Rotation 90° du bouton en même temps
tl.to(bouton, {
  rotate: 0,          // ou "+=90" si tu veux ajouter 90° à chaque fois
  duration: 0.5,
  ease: "power1.inOut"
}, 0);

}

window.Script222 = function()
{
  // Récupère les objets Storyline
const carte  = document.querySelector('[data-model-id="6WOyyFcuLyH"]');
const bouton = document.querySelector('[data-model-id="5rCsry3VrNh"]');

// Points d'ancrage
carte.style.transformOrigin = "top left";
bouton.style.transformOrigin = "center";

// États initiaux
gsap.set(carte,  { scale: 0, opacity: 0 });
gsap.set(bouton, { rotate: 0 }); // ou 90 si tu veux qu'il démarre déjà tourné

// Timeline pour synchroniser
const tl = gsap.timeline();

tl.to(carte, {
  scale: 1,
  opacity: 1,
  duration: 0.5,
  ease: "power1.inOut"
}, 0);

// Rotation 90° du bouton en même temps
tl.to(bouton, {
  rotate: 45,          // ou "+=90" si tu veux ajouter 90° à chaque fois
  duration: 0.5,
  ease: "power1.inOut"
}, 0);

}

window.Script223 = function()
{
  // ============================================================
// 💬 FEEDBACK MOTIVATIONNEL — AVEC SUPPORT DU FORMAT "1101nn"
// ============================================================

// -------- VARIABLES DE BASE --------
let resultat = getVar("Ex_Success");
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;
const exCurrent = parseInt(getVar(`${seqKey}_Exo_Current`), 10);

// ============================================================
// 🔍 SI RESULTAT VIDE → CHERCHE DANS S1_Win_Lose ("1101nn")
// ============================================================
if (!resultat || resultat === "") {
  const historique = getVar(`${seqKey}_Win_Lose`) || "";
  const charAtIndex = historique.charAt(exCurrent - 1);

  if (charAtIndex === "1" || charAtIndex === "0") {
    resultat = charAtIndex;
  } else {
    console.log(`ℹ️ Aucun résultat valide trouvé dans ${seqKey}_Win_Lose à l’index ${exCurrent - 1}`);
  }
}

// ============================================================
// 💬 LISTES DE FEEDBACKS
// ============================================================
const feedbackCorrect = [
  "Bravo !",
  "Super !",
  "Bien joué !",
  "Excellent !"
];

const feedbackIncorrect = [
  "Pas exactement.",
  "Oups !",
  "La prochaine fois !"
];

const feedbackNeutre = [
  "Continue !"
];

// ============================================================
// 🎯 CHOIX DU FEEDBACK
// ============================================================
let liste;
switch (resultat) {
  case "1":
    liste = feedbackCorrect;
    break;
  case "0":
    liste = feedbackIncorrect;
    break;
  default:
    liste = feedbackNeutre;
    break;
}

// Sélection aléatoire dans la liste
const feedback = liste[Math.floor(Math.random() * liste.length)];

// ============================================================
// 🧾 MISE À JOUR STORYLINE
// ============================================================
setVar("Ex_Feedback_Motivation", feedback);

}

window.Script224 = function()
{
  // ============================================================
// 🔁 SCRIPT — ALLER AU PROCHAIN EXERCICE ÉCHOUÉ ("Réviser les erreurs")
// ============================================================

// -------- VARIABLES DE CONTEXTE --------
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;
const exCurrent = parseInt(getVar(`${seqKey}_Exo_Current`), 10);
const historique = getVar(`${seqKey}_Win_Lose`) || "";

// -------- SÉCURITÉ --------
if (!seqPos || !historique) {
  console.warn("⚠️ Impossible d'exécuter le script — séquence ou historique manquant.");
  return;
}

// ============================================================
// 🔍 RECHERCHE DU PROCHAIN ÉCHEC ("0")
// ============================================================

// On cherche le prochain "0" APRÈS la position actuelle
const nextFailIndex = historique.indexOf("0", exCurrent);

// ============================================================
// 🎯 MISE À JOUR OU FIN DE LA RÉVISION
// ============================================================

if (nextFailIndex === -1) {
  // Aucun autre exercice échoué trouvé → fin du mode révision
  setVar("S0_Revision_Erreurs", 2);

} else {
  // Prochain exercice échoué trouvé
  const nextExercise = nextFailIndex + 1; // index → position 1-based
  setVar("0_Position_Exercice", nextExercise);
}
}

window.Script225 = function()
{
  // ============================================================
// 🎯 ANIMATION DE JAUGE — Rotation + Oscillation continue + Feedback motivationnel + Indicateur visuel
// ============================================================

// -------- OBJETS STORYLINE --------
const pointer = object('5fZOHpnMbya');
const gauge = object('6nKxLAItMtB');

// -------- PARAMÈTRES --------
const minAngle = 0;
const maxAngle = 180;
const oscillationRange = 10;
const oscillationSpeed = 1.5;

// ============================================================
// 🧮 DETECTION DU RESULTAT + RECUPERATION VARIABLES STORYLINE
// ============================================================
let resultat = getVar("Ex_Success");
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;
const exCurrent = getVar(`${seqKey}_Exo_Current`);

// Si il n'y a pas de résultat direct, on tente de le retrouver dans Sx_Win_Lose
if (resultat === "") {
  const historique = getVar(`${seqKey}_Win_Lose`);
  const charAtIndex = historique.charAt(exCurrent - 1);
  if (charAtIndex === "1" || charAtIndex === "0") {
    resultat = charAtIndex;
  } else {
    console.log(`ℹ️ Aucun résultat valide trouvé dans ${seqKey}_Win_Lose à l’index ${exCurrent - 1}`);
    resultat = "";
  }
}

// ============================================================
// ⚙️ Changement couleur jauge
// ============================================================
if (resultat === "1") {
  gauge.state = "Correct" ;
} else if (resultat === "0") {
  gauge.state = "Incorrect" ;
}

// ============================================================
// ⚙️ CALCULS D’ANGLES
// ============================================================
const baseAngle = resultat * (maxAngle - minAngle) + minAngle;
const angleMin = baseAngle - oscillationRange;
const angleMax = baseAngle + oscillationRange;


const goingUp = resultat === "1";
const targetAngle = goingUp ? angleMax : angleMin;

// ============================================================
// 🧹 ARRÊTE LES ANIMATIONS EXISTANTES
// ============================================================
gsap.killTweensOf(pointer);

// ============================================================
// 🚀 ANIMATION DE L’AIGUILLE
// ============================================================
gsap.to(pointer, {
  rotation: targetAngle,
  duration: 1.2,
  ease: "power2.inOut",
  onComplete: () => {
    gsap.to(pointer, {
      rotation: goingUp ? angleMin : angleMax,
      duration: oscillationSpeed,
      ease: "sine.inOut",
      yoyo: true,
      repeat: -1
    });
  }
});

}

window.Script226 = function()
{
  const Btn_Affichage  = document.querySelector('[data-model-id="6geks01QgvK"]');
const temoin = object('6XIh2Zufqbt');

// (Optionnel mais recommandé) point d’ancrage de la rotation
Btn_Affichage.style.transformOrigin = "50% 50%";

// On lit l’état actuel puis on bascule
const isAffiche = (temoin.state === "Feedback_Affiche");

temoin.state = isAffiche ? "Feedback_Cache" : "Feedback_Affiche";

// Rotation GSAP (durée + easing ajustables)
gsap.to(Btn_Affichage, {
  rotation: isAffiche ? 180 : 0,
  duration: 0.45,
  ease: "power2.inOut",
  overwrite: "auto"
});

}

window.Script227 = function()
{
  // ============================================================
// 💬 FEEDBACK MOTIVATIONNEL — AVEC SUPPORT DU FORMAT "1101nn"
// ============================================================

// -------- VARIABLES DE BASE --------
let resultat = getVar("Ex_Success");
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;
const exCurrent = parseInt(getVar(`${seqKey}_Exo_Current`), 10);

// ============================================================
// 🔍 SI RESULTAT VIDE → CHERCHE DANS S1_Win_Lose ("1101nn")
// ============================================================
if (!resultat || resultat === "") {
  const historique = getVar(`${seqKey}_Win_Lose`) || "";
  const charAtIndex = historique.charAt(exCurrent - 1);

  if (charAtIndex === "1" || charAtIndex === "0") {
    resultat = charAtIndex;
  } else {
    console.log(`ℹ️ Aucun résultat valide trouvé dans ${seqKey}_Win_Lose à l’index ${exCurrent - 1}`);
  }
}

// ============================================================
// 💬 LISTES DE FEEDBACKS
// ============================================================
//const feedbackCorrect = [
//  "Bravo !",
//  "Super !",
//  "Bien joué !",
//  "Excellent !"
//];

//const feedbackIncorrect = [
//  "Pas exactement.",
//  "Oups !",
//  "La prochaine fois !"
//];

const feedbackCorrect = [
  "Bravo, c'est une bonne réponse !",
  "Super, tu es sur la bonne voie !",
  "Bien joué, tu progresses !",
  "Excellent, continue comme ça !"
];

const feedbackIncorrect = [
  "Ce n'est pas tout à fait ça.",
  "Oups, ce n'est pas la bonne réponse.",
  "Tu y arriveras la prochaine fois !",
  "Pas exactement. Encore un effort !"
];


const feedbackNeutre = [
  "Continue !"
];

// ============================================================
// 🎯 CHOIX DU FEEDBACK
// ============================================================
let liste;
switch (resultat) {
  case "1":
    liste = feedbackCorrect;
    break;
  case "0":
    liste = feedbackIncorrect;
    break;
  default:
    liste = feedbackNeutre;
    break;
}

// Sélection aléatoire dans la liste
const feedback = liste[Math.floor(Math.random() * liste.length)];

// ============================================================
// 🧾 MISE À JOUR STORYLINE
// ============================================================
setVar("Ex_Feedback_Motivation", feedback);

}

window.Script228 = function()
{
  // ============================================================
// 🔁 SCRIPT — ALLER AU PROCHAIN EXERCICE ÉCHOUÉ ("Réviser les erreurs")
// ============================================================

// -------- VARIABLES DE CONTEXTE --------
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;
const exCurrent = parseInt(getVar(`${seqKey}_Exo_Current`), 10);
const historique = getVar(`${seqKey}_Win_Lose`) || "";

// -------- SÉCURITÉ --------
if (!seqPos || !historique) {
  console.warn("⚠️ Impossible d'exécuter le script — séquence ou historique manquant.");
  return;
}

// ============================================================
// 🔍 RECHERCHE DU PROCHAIN ÉCHEC ("0")
// ============================================================

// On cherche le prochain "0" APRÈS la position actuelle
const nextFailIndex = historique.indexOf("0", exCurrent);

// ============================================================
// 🎯 MISE À JOUR OU FIN DE LA RÉVISION
// ============================================================

if (nextFailIndex === -1) {
  // Aucun autre exercice échoué trouvé → fin du mode révision
  setVar("S0_Revision_Erreurs", 2);

} else {
  // Prochain exercice échoué trouvé
  const nextExercise = nextFailIndex + 1; // index → position 1-based
  setVar("0_Position_Exercice", nextExercise);
}
}

window.Script229 = function()
{
  // ============================================================
// 🎯 ANIMATION DE JAUGE — Rotation + Oscillation continue + Feedback motivationnel + Indicateur visuel
// ============================================================

// -------- OBJETS STORYLINE --------
const pointer = object('61WVHrM0EGs');
//const gauge = object('5lezhyLYUu5'); Cet objet n'existe pas ?
const gauge = object('6rIRKS6iuFv');


// -------- PARAMÈTRES --------
const minAngle = 0;
const maxAngle = 180;
const oscillationRange = 10;
const oscillationSpeed = 1.5;

// ============================================================
// 🧮 DETECTION DU RESULTAT + RECUPERATION VARIABLES STORYLINE
// ============================================================
let resultat = getVar("Ex_Success");
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;
const exCurrent = getVar(`${seqKey}_Exo_Current`);

// Si il n'y a pas de résultat direct, on tente de le retrouver dans Sx_Win_Lose
if (resultat === "") {
  const historique = getVar(`${seqKey}_Win_Lose`);
  const charAtIndex = historique.charAt(exCurrent - 1);
  if (charAtIndex === "1" || charAtIndex === "0") {
    resultat = charAtIndex;
  } else {
    console.log(`ℹ️ Aucun résultat valide trouvé dans ${seqKey}_Win_Lose à l’index ${exCurrent - 1}`);
    resultat = "";
  }
}

// ============================================================
// ⚙️ Changement couleur jauge
// ============================================================
if (resultat === "1") {
  gauge.state = "Correct" ;
} else if (resultat === "0") {
  gauge.state = "Incorrect" ;
}

// ============================================================
// ⚙️ CALCULS D’ANGLES
// ============================================================
const baseAngle = resultat * (maxAngle - minAngle) + minAngle;
const angleMin = baseAngle - oscillationRange;
const angleMax = baseAngle + oscillationRange;


const goingUp = resultat === "1";
const targetAngle = goingUp ? angleMax : angleMin;

// ============================================================
// 🧹 ARRÊTE LES ANIMATIONS EXISTANTES
// ============================================================
gsap.killTweensOf(pointer);

// ============================================================
// 🚀 ANIMATION DE L’AIGUILLE
// ============================================================
gsap.to(pointer, {
  rotation: targetAngle,
  duration: 1.2,
  ease: "power2.inOut",
  onComplete: () => {
    gsap.to(pointer, {
      rotation: goingUp ? angleMin : angleMax,
      duration: oscillationSpeed,
      ease: "sine.inOut",
      yoyo: true,
      repeat: -1
    });
  }
});

}

window.Script230 = function()
{
  const Btn_Affichage  = document.querySelector('[data-model-id="6RRLU9ixx38"]');
const temoin = object('68ikzB1cq1L');

// (Optionnel mais recommandé) point d’ancrage de la rotation
Btn_Affichage.style.transformOrigin = "50% 50%";

// On lit l’état actuel puis on bascule
const isAffiche = (temoin.state === "Feedback_Affiche");

temoin.state = isAffiche ? "Feedback_Cache" : "Feedback_Affiche";

// Rotation GSAP (durée + easing ajustables)
gsap.to(Btn_Affichage, {
  rotation: isAffiche ? 180 : 0,
  duration: 0.45,
  ease: "power2.inOut",
  overwrite: "auto"
});

}

window.Script231 = function()
{
  // Récupère le résultat
let resultat = getVar("Ex_Success");

// Définit les listes de feedback
const feedbackCorrect = [
  "Bravo !",
  "Super !",
  "Bien joué !",
  "Excellent !"
];

const feedbackIncorrect = [
  "Pas exactement",
  "Oups !",
  "La prochaine fois !"
];

// Choisit la liste en fonction du résultat
let liste = (resultat === "1") ? feedbackCorrect : feedbackIncorrect;

// Sélectionne un élément aléatoire dans la liste
let feedback = liste[Math.floor(Math.random() * liste.length)];

// Met à jour la variable Storyline
setVar("Ex_Feedback_Motivation", feedback);

}

window.Script232 = function()
{
  // ============================================================
// 🎯 ANIMATION DE JAUGE — Rotation + Oscillation continue + Feedback motivationnel + Indicateur visuel
// ============================================================

// -------- OBJETS STORYLINE --------
const pointer = object('5Ux37gXcJcw');
const gauge = object('5enGetq7POY');

// -------- PARAMÈTRES --------
const minAngle = 0;
const maxAngle = 180;
const oscillationRange = 10;
const oscillationSpeed = 1.5;

// ============================================================
// 🧮 DETECTION DU RESULTAT + RECUPERATION VARIABLES STORYLINE
// ============================================================
let resultat = getVar("Ex_Success");
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;
const exCurrent = getVar(`${seqKey}_Exo_Current`);

// Si il n'y a pas de résultat direct, on tente de le retrouver dans Sx_Win_Lose
if (resultat === "") {
  const historique = getVar(`${seqKey}_Win_Lose`);
  const charAtIndex = historique.charAt(exCurrent - 1);
  if (charAtIndex === "1" || charAtIndex === "0") {
    resultat = charAtIndex;
  } else {
    console.log(`ℹ️ Aucun résultat valide trouvé dans ${seqKey}_Win_Lose à l’index ${exCurrent - 1}`);
    resultat = "";
  }
}

// ============================================================
// ⚙️ Changement couleur jauge
// ============================================================
if (resultat === "1") {
  gauge.state = "Correct" ;
} else if (resultat === "0") {
  gauge.state = "Incorrect" ;
}

// ============================================================
// ⚙️ CALCULS D’ANGLES
// ============================================================
const baseAngle = resultat * (maxAngle - minAngle) + minAngle;
const angleMin = baseAngle - oscillationRange;
const angleMax = baseAngle + oscillationRange;


const goingUp = resultat === "1";
const targetAngle = goingUp ? angleMax : angleMin;

// ============================================================
// 🧹 ARRÊTE LES ANIMATIONS EXISTANTES
// ============================================================
gsap.killTweensOf(pointer);

// ============================================================
// 🚀 ANIMATION DE L’AIGUILLE
// ============================================================
gsap.to(pointer, {
  rotation: targetAngle,
  duration: 1.2,
  ease: "power2.inOut",
  onComplete: () => {
    gsap.to(pointer, {
      rotation: goingUp ? angleMin : angleMax,
      duration: oscillationSpeed,
      ease: "sine.inOut",
      yoyo: true,
      repeat: -1
    });
  }
});

}

window.Script233 = function()
{
  // ============================================================
// 🔁 SCRIPT — ALLER AU PROCHAIN EXERCICE ÉCHOUÉ ("Réviser les erreurs")
// ============================================================

// -------- VARIABLES DE CONTEXTE --------
const seqPos = getVar("0_Position_Sequence"); // ex: "1", "2", "3", "4"
const seqKey = `S${seqPos}`;                  // ex: "S1"
const exCurrent = parseInt(getVar(`${seqKey}_Exo_Current`) || 0, 10); // ex: 3
const historique = getVar(`${seqKey}_Win_Lose`) || ""; // ex: "110010"

// -------- SÉCURITÉ --------
if (!seqPos || !historique) {
  console.warn("⚠️ Impossible d'exécuter le script — séquence ou historique manquant.");
  return;
}

// ============================================================
// 🔍 RECHERCHE DU PROCHAIN ÉCHEC ("0")
// ============================================================

// On cherche le prochain "0" APRÈS la position actuelle
const nextFailIndex = historique.indexOf("0", exCurrent);

// ============================================================
// 🎯 MISE À JOUR OU FIN DE LA RÉVISION
// ============================================================

if (nextFailIndex === -1) {
  // Aucun autre exercice échoué trouvé → fin du mode révision
  setVar("S0_Revision_Erreurs", 2);
  console.log("🎉 Tous les exercices échoués ont été revus — fin du mode révision (S0_Revision_Erreurs = 2).");
} else {
  // Prochain exercice échoué trouvé
  const nextExercise = nextFailIndex + 1; // index → position 1-based
  setVar("0_Position_Exercice", nextExercise);
  console.log(`🔁 Révision → Prochain exercice échoué : EX${nextExercise}`);
}

console.log(`(Séquence : ${seqKey}, Historique : "${historique}")`);

}

window.Script234 = function()
{
  // ============================================================
// 🎬 REMPLACEMENT DYNAMIQUE DE VIDÉO (version simplifiée)
// ============================================================
// Remplace directement la vidéo de l'objet Storyline (ID fixe)
// avec le chemin complet contenu dans la variable "Ex_Video".
// ============================================================

// -------- Lecture de la variable --------
const newVideoPath = getVar("Ex_Video"); // ex: "Ressources_Sequences/S1/Videos/S1_EX1.mp4"

// -------- Sécurité --------
if (!newVideoPath || newVideoPath.trim() === "") {
  console.warn("⚠️ Aucune vidéo spécifiée dans Ex_Video — remplacement annulé.");
  return;
}

// -------- Sélection directe de la vidéo --------
const videoElement = document.querySelector('[data-model-id="5pTX8N7gCDH"] video');
if (!videoElement) {
  console.error("❌ Impossible de trouver la vidéo avec data-model-id=5pTX8N7gCDH.");
  return;
}

// -------- Remplacement de la source --------
videoElement.setAttribute("xlink:href", newVideoPath);
videoElement.src = newVideoPath;
videoElement.load();

// -------- Suppression de la vignette (poster) --------
const container = videoElement.closest('[data-model-id="5pTX8N7gCDH"]');
if (container) {
  const poster = container.querySelector("img.video-player-poster");
  if (poster) {
    poster.remove();
    console.log("✅ Vignette (poster) supprimée — la 1ère image de la vidéo sera visible.");
  }
}
}

window.Script235 = function()
{
  // ============================================================
// 🖼️ REMPLACEMENT DYNAMIQUE D’IMAGE (version simplifiée)
// ============================================================
// Remplace directement l’image de l’objet Storyline (ID fixe)
// avec le chemin complet contenu dans la variable "Ex_Image".
// Aucun calcul de dossier ou de chemin n’est effectué.
// ============================================================

// -------- Lecture de la variable --------
const newImagePath = getVar("Ex_Image"); // ex: "Ressources_Sequences/S1/images/EX1.jpg"

// -------- Sécurité --------
if (!newImagePath || newImagePath.trim() === "") {
  console.warn("⚠️ Aucune image spécifiée dans Ex_Image — remplacement annulé.");
  return;
}

// -------- Sélection directe de l’image --------
const imageElement = document.querySelector('[data-model-id="6jUy2ox5l86"] image');
if (!imageElement) {
  console.error("❌ Impossible de trouver l’image avec data-model-id=6jUy2ox5l86.");
  return;
}

// -------- Remplacement du lien --------
imageElement.setAttributeNS("http://www.w3.org/1999/xlink", "xlink:href", newImagePath);

}

window.Script236 = function()
{
  // ============================================================
// 🖼️ REMPLACEMENT DYNAMIQUE D’IMAGE (version simplifiée)
// ============================================================
// Remplace directement l’image de l’objet Storyline (ID fixe)
// avec le chemin complet contenu dans la variable "Ex_Image".
// Aucun calcul de dossier ou de chemin n’est effectué.
// ============================================================

// -------- Lecture de la variable --------
const newImagePath = getVar("Ex_Image"); // ex: "Ressources_Sequences/S1/images/EX1.jpg"

// -------- Sécurité --------
if (!newImagePath || newImagePath.trim() === "") {
  console.warn("⚠️ Aucune image spécifiée dans Ex_Image — remplacement annulé.");
  return;
}

// -------- Sélection directe de l’image --------
const imageElement = document.querySelector('[data-model-id="6c22D92goAT"] image');
if (!imageElement) {
  console.error("❌ Impossible de trouver l’image avec data-model-id=6c22D92goAT.");
  return;
}

// -------- Remplacement du lien --------
imageElement.setAttributeNS("http://www.w3.org/1999/xlink", "xlink:href", newImagePath);

}

window.Script237 = function()
{
  // ============================================================
// ⚙️ BARRE DE PROGRESSION — SYNCHRONISATION AVEC LA SÉQUENCE EN COURS
// ============================================================

// --------- Lecture de la séquence courante ---------
const seqPos = getVar("0_Position_Sequence");   // ex. 1 → S1
const seqKey = `S${seqPos}`;

// --------- Lecture des variables de la séquence correspondante ---------
const Exo_Reached = getVar("S0_Exo_Reached") || 0;
const Exo_Total = getVar("S0_Exo_Total") || 1;

// --------- Calcul du pourcentage ---------
const progress = Math.min(Exo_Reached / Exo_Total, 1); // clamp entre 0 et 1

// --------- Sélectionne l'objet Storyline ---------
const ProgressBar = document.querySelector(`[data-model-id="6f561U28wA4"]`);

if (ProgressBar) {
  // --------- Sélectionne l'élément graphique principal ---------
  const shape = ProgressBar.querySelector("path");

  if (shape) {
    // Si ce n’est pas déjà fait, on garde la largeur d’origine
    if (!shape.dataset.fullWidth) {
      const bbox = shape.getBBox();
      shape.dataset.fullWidth = bbox.width;
    }

    // --------- Calcul de la largeur selon la progression ---------
    const fullWidth = parseFloat(shape.dataset.fullWidth);

    // --------- Application du remplissage via clip-path ---------
    shape.style.clipPath = `inset(0 ${100 - progress * 100}% 0 0 round 0px)`;
  }
}

}

window.Script238 = function()
{
  // ============================================================
// ⚙️ BARRE DE PROGRESSION ANIMÉE (AVEC INITIALISATION INTELLIGENTE)
// ============================================================

// Durée de l’animation en millisecondes (modifiable)
const animationDuration = 800; // 0.8s = fluide, 300 = rapide, 1500 = lente

function updateProgressBarAnimated() {
  // --------- Lecture de la séquence courante ---------
  const seqPos = getVar("0_Position_Sequence");
  const seqKey = `S${seqPos}`;

  // --------- Lecture des variables globales S0 ---------
  const Exo_Reached = getVar("S0_Exo_Reached") || 0;
  const Exo_Total = getVar("S0_Exo_Total") || 1;
  const progress = Math.min(Exo_Reached / Exo_Total, 1);

  // --------- Sélectionne l'objet Storyline ---------
  const ProgressBar = document.querySelector(`[data-model-id="6f561U28wA4"]`);
  if (!ProgressBar) return;

  const shape = ProgressBar.querySelector("path");
  if (!shape) return;

  // --------- Initialisation si nécessaire ---------
  if (!shape.dataset.fullWidth) {
    const bbox = shape.getBBox();
    shape.dataset.fullWidth = bbox.width;
  }

  // --------- Nouvelle logique : position initiale intelligente ---------
  let startProgress;

  if (shape.dataset.currentProgress !== undefined) {
    // On continue à partir de la progression actuelle
    startProgress = parseFloat(shape.dataset.currentProgress) || 0;
  } else if (Exo_Reached >= 1) {
    // Si aucune donnée mais au moins un exercice complété,
    // on démarre au niveau précédent
    startProgress = (Exo_Reached - 1) / Exo_Total;
  } else {
    // Sinon, tout au début
    startProgress = 0;
  }

  const startTime = performance.now();

  // --------- Fonction d'animation fluide ---------
  function animate(time) {
    const elapsed = time - startTime;
    const t = Math.min(elapsed / animationDuration, 1);
    const eased = t < 0.5 ? 2 * t * t : -1 + (4 - 2 * t) * t; // easeInOutQuad

    const currentProgress = startProgress + (progress - startProgress) * eased;
    shape.style.clipPath = `inset(0 ${100 - currentProgress * 100}% 0 0 round 0px)`;
    shape.dataset.currentProgress = currentProgress;

    if (t < 1) requestAnimationFrame(animate);
  }

  requestAnimationFrame(animate);
}

// ============================================================
// ▶️ APPEL DU SCRIPT (exécuté manuellement via trigger JS)
// ============================================================

updateProgressBarAnimated();

}

window.Script239 = function()
{
  // -------- Initialisation --------

// Récupère le numéro ou identifiant d'exercice (ex: "EX2")
const AudioPath = getVar("0_Audio_Lecteur");

// Si un audio était déjà en cours → on le stoppe et on remet au début
if (window.audioUnique) {
  window.audioUnique.pause();
  window.audioUnique.currentTime = 0;
}

// Crée un nouvel objet audio
window.audioUnique = new Audio(AudioPath);

// Lecture
window.audioUnique.play().catch(err => {
  console.log("Erreur lecture Back :", err);
});
}

window.Script240 = function()
{
  // ============================================================
// 🎯 MISE À JOUR DES VARIABLES Sx_Win_Lose SELON Ex_Success (texte)
// ============================================================

// -------- Lecture des variables Storyline --------
const seqPos  = getVar("0_Position_Sequence");
const exPos   = getVar("0_Position_Exercice");
const success = getVar("Ex_Success");

// -------- Construction du nom de la séquence --------
const seqKey     = `S${seqPos}`;
const winLoseVar = `${seqKey}_Win_Lose`;

// -------- Lecture actuelle de la variable Win_Lose --------
let winLose = getVar(winLoseVar) || "";

// -------- S’assure que la longueur correspond au nombre total d’exercices --------
const total = getVar(`0_Menu_${seqKey}_Exo_Total`);

// -------- Conversion en tableau pour modification --------
const chars = winLose.split("");

// -------- Mise à jour du caractère correspondant à l’exercice actuel --------
if (!(chars[exPos - 1] === "1" && success === "0")) {
    chars[exPos - 1] = success === "1" ? "1" : "0";
}
// Si l'exercice est déjà réussi, on garde la réussite.

// -------- Conversion inverse en chaîne --------
winLose = chars.join("");

// -------- Écriture dans Storyline --------
setVar(winLoseVar, winLose);

// ============================================================
// 🔁 SWITCH AUTOMATIQUE DE 0_Feedback_Switch
// ============================================================
let feedbackSwitch = getVar("0_Feedback_Switch");
feedbackSwitch = feedbackSwitch === true || feedbackSwitch === "true" ? false : true;
setVar("0_Feedback_Switch", feedbackSwitch);

}

window.Script241 = function()
{
  // ============================================================
// 🏁 SCRIPT DE FIN D’EXERCICE — MISE À JOUR PROGRESSION & TENTATIVES
// ============================================================

// -------- CONFIGURATION --------
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;

const exCurrent  = parseInt(getVar(`${seqKey}_Exo_Current`), 10);
const exReached  = parseInt(getVar(`${seqKey}_Exo_Reached`), 10);
const tentVar    = `${seqKey}_Exo_Current_Tentatives`;
// ============================================================
// 🧭 MISE À JOUR DE LA PROGRESSION
// ============================================================

// Si on avance (évite de revenir en arrière)
if (exCurrent > exReached) {
  setVar(`${seqKey}_Exo_Reached`, exCurrent);
  setVar("S0_Exo_Reached", exCurrent); 
}

// ============================================================
// 🧮 MARQUAGE DE L’EXERCICE TERMINÉ
// ============================================================

setVar(tentVar, -10);

}

window.Script242 = function()
{
  // ============================================================
// 🧠 SAUVEGARDE AUTOMATIQUE DES DONNÉES UTILISATEUR (GLOBAL)
// ============================================================
//
// 🔹 Ce script est appelé automatiquement après la validation d’un exercice.
// 🔹 Il détecte le type d’exercice et sauvegarde la réponse dans la variable JSON
//    correspondante (ex: S1_UserData)
//
// ============================================================

// ------------------------------------------------------------
// 🔧 Lecture des infos de contexte
// ------------------------------------------------------------
const seqPos = getVar("0_Position_Sequence");           // ex: "1"
const exPos = parseInt(getVar("0_Position_Exercice"), 10);
const seqKey = `S${seqPos}`;
const exType = getVar("Ex_Type");
const success = getVar("Ex_Success");
const tentativesRestantes = parseInt(getVar("Ex_Tentatives"), 10);

// Variable cible (ex: "S1_UserData")
const userDataVar = `${seqKey}_UserData`;

// ------------------------------------------------------------
// 🔧 Lecture du JSON existant
// ------------------------------------------------------------
let data = {};
try {
  const existing = getVar(userDataVar);
  data = existing ? JSON.parse(existing) : {};
} catch (err) {
  console.warn(`⚠️ JSON invalide dans ${userDataVar}, réinitialisation.`, err);
  data = {};
}

// ------------------------------------------------------------
// 🧮 Tentatives initiales (si dispo dans cache global)
// ------------------------------------------------------------
let tentativesInitiales = 0;
try {
  const exData = window.sequenceCache?.[seqKey]?.[`EX${exPos}`];
  tentativesInitiales = exData?.Tentatives || 1;
} catch {
  tentativesInitiales = 1;
}

const tentativesUtilisees = Math.max(0, tentativesInitiales - tentativesRestantes);

// ------------------------------------------------------------
// 🎯 Récupération de la réponse selon le type d’exercice
// ------------------------------------------------------------
let userResponseObj = {};

switch (exType) {
  // 🔹 QCU
  case "QCU": {
    const answerKey = getVar("0_Reponse");
    const answerText = getVar(`0_Choix_${answerKey}`) || "";
    userResponseObj = { [answerKey]: answerText };
    break;
  }

  // 🔹 QCM
  case "QCM": {
    const responseRaw = (getVar("0_Reponse") || "").split("|").filter(Boolean);
    responseRaw.forEach(k => {
      userResponseObj[k] = getVar(`0_Choix_${k}`) || "";
    });
    break;
  }

  // 🔹 True or false
  case "True or false": {
    const answer = (getVar("0_Reponse") || "").toLowerCase();
    userResponseObj = { unique: answer };
    break;
  }

  // 🔹 Complete
  case "Complete": {
    const answer = getVar("0_Ex_Enonce") || "";
    userResponseObj = { unique: answer };
    break;
  }

  // 🔹 Matching
  case "Matching": {
    const reponse = getVar("0_Reponse") || "";
    userResponseObj = { associations: reponse };
    break;
  }

  // 🔹 Flashcard
  case "Flashcard": {
    const answer = getVar("0_Reponse") || "";
    userResponseObj = { unique: answer };
    break;
  }

  // 🔹 Information
  case "Information": {
    userResponseObj = { info: "Aucune interaction" };
    break;
  }

  // 🔹 Production orale - dictée
  case "Production orale - dictée": {
    const raw = getVar("0_Reponse") || "{}";
    try {
      const parsed = JSON.parse(raw);
      userResponseObj = {
        score: parsed.score || 0,
        texte_brut: parsed.texte_brut || "",
        texte_color: parsed.texte_color || ""
      };
    } catch (err) {
      console.warn("⚠️ Erreur de parsing JSON pour Production orale :", err);
      userResponseObj = { erreur: "Format de réponse invalide", raw };
    }
    break;
  }

  // 🔹 Défaut
  default: {
    const raw = getVar("0_Reponse") || "";
    userResponseObj = { inconnu: raw };
    console.warn(`❓ Type d’exercice inconnu : ${exType}`);
    break;
  }
}

// ------------------------------------------------------------
// 💾 Enregistrement dans le JSON
// ------------------------------------------------------------
data[`EX${exPos}`] = {
  Type: exType,
  Reponses_Choisies: userResponseObj,
  Statut: success,
  Tentatives_Utilisees: tentativesUtilisees
};

setVar(userDataVar, JSON.stringify(data));

// ------------------------------------------------------------
// 🧾 Log de contrôle
// ------------------------------------------------------------
console.group(`💾 Données sauvegardées → ${userDataVar}`);
console.log("Exercice :", `EX${exPos}`);
console.log("Type :", exType);
console.log("Réponses :", userResponseObj);
console.log("Statut :", success);
console.log("Tentatives utilisées :", tentativesUtilisees);
console.log("JSON complet :", data);
console.groupEnd();

}

window.Script243 = function()
{
  // ============================================================
// 🎤 VÉRIFICATION DE LA PRODUCTION ORALE + GESTION DES TENTATIVES
// ============================================================

// --------- Lecture des variables Storyline ---------
const reponseRaw = (getVar("0_Reponse") || "").trim();
const correctionRaw = (getVar("0_Ex_Enonce") || "").trim(); // Phrase attendue
let tentatives = parseInt(getVar("Ex_Tentatives"), 10);
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;
const tentVar = `${seqKey}_Exo_Current_Tentatives`;

let CompteurTentatives = parseInt(getVar("Ex_Compteur_Tentatives"), 10);
const CompteurTentativesVar = `${seqKey}_Exo_Current_Compteur_Tentatives`;

let success = getVar("Ex_Success") || "";

// ============================================================
// 🧩 EXTRACTION DES DONNÉES UTILISATEUR
// ============================================================
let userScore = 0;
let userText = "";

try {
  const data = JSON.parse(reponseRaw);
  userScore = data.score || 0;
  userText = data.texte_brut || "";
} catch (e) {
  console.warn("⚠️ 0_Reponse n’est pas un JSON valide :", reponseRaw);
  userText = reponseRaw;
}

// ============================================================
// 🧹 NORMALISATION DU TEXTE
// ============================================================
// Fonction utilitaire pour retirer ponctuation, accents, majuscules
function normalizeText(str) {
  return str
    .toLowerCase()
    .normalize("NFD") // retire accents
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[.,!?;:"'’«»]/g, "")
    .replace(/\s+/g, " ")
    .trim();
}

const correction = normalizeText(correctionRaw);
const userAnswer = normalizeText(userText);

console.log("🎯 Texte attendu :", correction);
console.log("🗣️ Texte prononcé :", userAnswer);
console.log("📈 Score :", userScore);

// ============================================================
// 🧮 COMPARAISON DES MOTS
// ============================================================
const expectedWords = correction.split(" ");
const userWords = userAnswer.split(" ");

const missingWords = expectedWords.filter(w => !userWords.includes(w));
const extraWords = userWords.filter(w => !expectedWords.includes(w));

console.log("🔎 Mots manquants :", missingWords);
console.log("➕ Mots en trop :", extraWords);

// ============================================================
// ✅ CONDITIONS DE RÉUSSITE
// ============================================================
// → Tous les mots attendus doivent être présents
// → Le score doit être ≥ 60 %
const allWordsRecognized = missingWords.length === 0;
const scoreSuffisant = userScore >= 60;

if (allWordsRecognized && scoreSuffisant) {
  success = "1"; // Succès
  console.log("🎉 Réussite : tous les mots reconnus et score suffisant.");
} else {
  console.log("❌ Échec : soit score trop bas, soit mots manquants.");
  if (tentatives > 0) tentatives -= 1;
  if (tentatives <= 0) success = "0";
}

CompteurTentatives++;

// ============================================================
// 💾 MISE À JOUR DES VARIABLES PERSISTANTES
// ============================================================
setVar("Ex_Tentatives", tentatives);
setVar(tentVar, tentatives);
setVar("Ex_Compteur_Tentatives", CompteurTentatives);
setVar(CompteurTentativesVar, CompteurTentatives);
setVar("Ex_Success", success);

// Si terminé (réussi ou épuisé)
if (success === "1" || tentatives <= 0) {
  setVar(tentVar, -10);
}

// ============================================================
// 🧾 LOG FINAL
// ============================================================
console.group(`🧠 Production Orale — Vérification`);
console.log("Réponse normalisée :", userAnswer);
console.log("Correction normalisée :", correction);
console.log("Score :", userScore);
console.log("Success :", success);
console.log("Tentatives restantes :", tentatives);
console.groupEnd();

}

window.Script244 = function()
{
  (async function () {

  // ===============================
  // 🌍 VARIABLES GLOBALES
  // ===============================
  window.mediaRecorder = null;
  window.audioChunks = [];
  window.audioBlob = null;

  // ===============================
  // 📦 CHARGEMENT SDK AZURE
  // ===============================
  if (!window.SpeechSDK) {
    console.log("⏳ Chargement SDK Speech...");

    await new Promise((resolve, reject) => {
      const script = document.createElement("script");
      script.src = "story_content/external_files/microsoft.cognitiveservices.speech.sdk.bundle-min.js";
      script.onload = resolve;
      script.onerror = reject;
      document.head.appendChild(script);
    });

    console.log("✅ SDK Speech chargé");
  }

  // ===============================
  // 🎙️ ENREGISTREMENT LOCAL
  // ===============================
  window.startRecording = async function () {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });

    window.mediaRecorder = new MediaRecorder(stream);
    window.audioChunks = [];

    window.mediaRecorder.ondataavailable = e => {
      if (e.data.size > 0) window.audioChunks.push(e.data);
    };

    window.mediaRecorder.start();
    console.log("🎙️ Enregistrement démarré");
  };

  // ===============================
  // ⏹️ STOP ENREGISTREMENT
  // ===============================
  window.stopRecording = async function () {
    return new Promise(resolve => {
      window.mediaRecorder.onstop = () => {
        window.mediaRecorder.stream.getTracks().forEach(t => t.stop());

        window.audioBlob = new Blob(
          window.audioChunks,
          { type: "audio/webm" }
        );

        console.log("🛑 Enregistrement arrêté");
        resolve(window.audioBlob);
      };

      window.mediaRecorder.stop();
    });
  };

  // ===============================
  // 🔄 CONVERSION WAV 16 kHz PCM
  // ===============================
  window.convertToWav = async function (blob) {
    const audioContext = new AudioContext({ sampleRate: 16000 });
    const arrayBuffer = await blob.arrayBuffer();
    const audioBuffer = await audioContext.decodeAudioData(arrayBuffer);

    const channelData = audioBuffer.getChannelData(0);
    return window.encodeWAV(channelData, 16000);
  };

  window.encodeWAV = function (samples, sampleRate) {
    const buffer = new ArrayBuffer(44 + samples.length * 2);
    const view = new DataView(buffer);

    function writeString(view, offset, string) {
      for (let i = 0; i < string.length; i++) {
        view.setUint8(offset + i, string.charCodeAt(i));
      }
    }

    writeString(view, 0, "RIFF");
    view.setUint32(4, 36 + samples.length * 2, true);
    writeString(view, 8, "WAVE");
    writeString(view, 12, "fmt ");
    view.setUint32(16, 16, true);
    view.setUint16(20, 1, true);
    view.setUint16(22, 1, true);
    view.setUint32(24, sampleRate, true);
    view.setUint32(28, sampleRate * 2, true);
    view.setUint16(32, 2, true);
    view.setUint16(34, 16, true);
    writeString(view, 36, "data");
    view.setUint32(40, samples.length * 2, true);

    let offset = 44;
    for (let i = 0; i < samples.length; i++, offset += 2) {
      const s = Math.max(-1, Math.min(1, samples[i]));
      view.setInt16(offset, s < 0 ? s * 0x8000 : s * 0x7fff, true);
    }

    return buffer;
  };

  console.log("🚀 Initialisation audio + SDK terminée");

})();

}

window.Script245 = function()
{
  // =======================
// LOADER CUSTOMIZATION
// =======================
const LOADER_CONFIG = {
  spinnerSize: 32,                 // px
  spinnerThickness: 4,             // px
  spinnerColor: '#3443f7',         // spinning arc color
  spinnerTrackColor: '#b9c1c7', // background ring
  overlayColor: '#FFFFFF)', // overlay over the object
  rotationSpeed: 1,                // seconds per rotation
  zIndex: 9999
};
// =======================


(function () {
  const obj = document.querySelector('[data-model-id="67w4lf90PQe"]');
  if (!obj) return;

  obj.style.position = 'relative';

  if (obj.querySelector('.custom-loader')) return;

  const loader = document.createElement('div');
  loader.className = 'custom-loader';
  loader.innerHTML = `<div class="spinner"></div>`;
  obj.appendChild(loader);

  if (!document.getElementById('custom-loader-style')) {
    const style = document.createElement('style');
    style.id = 'custom-loader-style';
    style.innerHTML = `
      .custom-loader {
        position: absolute;
        inset: 0;
        background: ${LOADER_CONFIG.overlayColor};
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: ${LOADER_CONFIG.zIndex};
        pointer-events: none;
      }

      .custom-loader .spinner {
        width: ${LOADER_CONFIG.spinnerSize}px;
        height: ${LOADER_CONFIG.spinnerSize}px;
        border: ${LOADER_CONFIG.spinnerThickness}px solid ${LOADER_CONFIG.spinnerTrackColor};
        border-top: ${LOADER_CONFIG.spinnerThickness}px solid ${LOADER_CONFIG.spinnerColor};
        border-radius: 50%;
        animation: spin ${LOADER_CONFIG.rotationSpeed}s linear infinite;
      }

      @keyframes spin {
        from { transform: rotate(0deg); }
        to { transform: rotate(360deg); }
      }
    `;
    document.head.appendChild(style);
  }
})();

}

window.Script246 = function()
{
  (function () {
  const obj = document.querySelector('[data-model-id="67w4lf90PQe"]');
  if (!obj) return;

  const loader = obj.querySelector('.custom-loader');
  if (loader) {
    loader.remove();
  }
})();

}

window.Script247 = function()
{
  stopRecording();

}

window.Script248 = function()
{
  startRecording();

}

window.Script249 = function()
{
  (function () {

  if (!window.audioBlob) {
    alert("Aucun enregistrement à lire");
    return;
  }

  // Création d'une URL temporaire pour le blob audio
  const audioUrl = URL.createObjectURL(window.audioBlob);

  // Création de l'objet audio
  const audio = new Audio(audioUrl);

  audio.onended = () => {
    // Libération de la mémoire
    URL.revokeObjectURL(audioUrl);
    console.log("🔊 Lecture terminée");
  };

  audio.play().then(() => {
    console.log("▶️ Lecture de l'enregistrement");
  }).catch(err => {
    console.error("Erreur lecture audio :", err);
  });

})();

}

window.Script250 = function()
{
  (async function () {

  // ============================================================
  // 🎬 INITIALISATION DU LOADER
  // ============================================================
  const loading_Container = object('67w4lf90PQe');
  if (loading_Container) {
    loading_Container.state = "_default"; // Affiche le loader
    console.log("⏳ Loader affiché (_default)");
  }

  try {

    // ============================================================
    // 🔐 VÉRIFICATIONS
    // ============================================================
    if (typeof SpeechSDK === "undefined") {
      alert("SDK Speech non chargé");
      throw new Error("SDK Speech non chargé");
    }

    if (!window.audioBlob) {
      alert("Aucun enregistrement disponible");
      throw new Error("Aucun enregistrement disponible");
    }

    // ============================================================
    // 🔄 CONVERSION AUDIO → WAV 16kHz
    // ============================================================
    const wavBuffer = await window.convertToWav(window.audioBlob);

    // ============================================================
    // 🌍 CHOIX DE LA RÉGION
    // ============================================================
    const assessmentRegion = getVar("0_Production_Orale_Region_Choice"); // "FR" ou "CA"

    let SPEECH_KEY = "";
    let SPEECH_REGION = "";
    let SPEECH_LANGUAGE = "";

    if (assessmentRegion === "CA") {
      SPEECH_KEY = getVar("KEY_MA_CA");
      SPEECH_REGION = "canadacentral";
      SPEECH_LANGUAGE = "fr-CA";
    } else {
      SPEECH_KEY = getVar("KEY_MA_FR");
      SPEECH_REGION = "francecentral";
      SPEECH_LANGUAGE = "fr-FR";
    }

    // ============================================================
    // 🧠 OUTIL NORMALISATION MOTS
    // ============================================================
    function normalizeWord(word) {
      return word
        .toLowerCase()
        .normalize("NFD")
        .replace(/[\u0300-\u036f]/g, "")
        .replace(/[^\w']/g, "");
    }

    // ============================================================
    // 1️⃣ RECONNAISSANCE LIBRE (PHRASE RÉELLE)
    // ============================================================
    const freeSpeechConfig = SpeechSDK.SpeechConfig.fromSubscription(
      SPEECH_KEY,
      SPEECH_REGION
    );
    freeSpeechConfig.speechRecognitionLanguage = SPEECH_LANGUAGE;

    const freeAudioConfig = SpeechSDK.AudioConfig.fromWavFileInput(
      new Uint8Array(wavBuffer)
    );

    const freeRecognizer = new SpeechSDK.SpeechRecognizer(
      freeSpeechConfig,
      freeAudioConfig
    );

    const realSpokenText = await new Promise(resolve => {
      freeRecognizer.recognizeOnceAsync(result => {
        if (result.reason === SpeechSDK.ResultReason.RecognizedSpeech) {
          resolve(result.text);
        } else {
          resolve("");
        }
        freeRecognizer.close();
      });
    });

    setVar("0_Production_Orale_Texte", realSpokenText);
    console.log("🗣️ Phrase réellement prononcée :", realSpokenText);

    // ============================================================
    // 2️⃣ PRONUNCIATION ASSESSMENT (PHRASE ATTENDUE)
    // ============================================================
    const paSpeechConfig = SpeechSDK.SpeechConfig.fromSubscription(
      SPEECH_KEY,
      SPEECH_REGION
    );
    paSpeechConfig.speechRecognitionLanguage = SPEECH_LANGUAGE;

    const paAudioConfig = SpeechSDK.AudioConfig.fromWavFileInput(
      new Uint8Array(wavBuffer)
    );

    const recognizer = new SpeechSDK.SpeechRecognizer(
      paSpeechConfig,
      paAudioConfig
    );

    const phraseAttendue = getVar("0_Ex_Enonce");

    const pronunciationConfig = new SpeechSDK.PronunciationAssessmentConfig(
      phraseAttendue,
      SpeechSDK.PronunciationAssessmentGradingSystem.HundredMark,
      SpeechSDK.PronunciationAssessmentGranularity.Phoneme,
      true
    );

    pronunciationConfig.enableProsodyAssessment = true;
    pronunciationConfig.applyTo(recognizer);

    recognizer.recognizeOnceAsync(result => {

      if (result.reason !== SpeechSDK.ResultReason.RecognizedSpeech) {
        alert("❌ Échec de reconnaissance");
        recognizer.close();
        if (loading_Container) loading_Container.state = "Invisible";
        return;
      }

      const pa = SpeechSDK.PronunciationAssessmentResult.fromResult(result);

      // ============================================================
      // 📦 ANALYSE MOT PAR MOT (PHRASE ATTENDUE)
      // ============================================================
      const jsonStr = result.properties.getProperty(
        SpeechSDK.PropertyId.SpeechServiceResponse_JsonResult
      );
      const json = JSON.parse(jsonStr);

      const analysis = json.NBest[0].Words.map(w => ({
        word: w.Word,
        score: w.PronunciationAssessment?.AccuracyScore ?? null
      }));

      // ============================================================
      // 🎯 DICTIONNAIRE DES MOTS ATTENDUS
      // ============================================================
      const expectedWordScores = {};
      analysis.forEach(item => {
        expectedWordScores[normalizeWord(item.word)] = item.score;
      });

      // ============================================================
      // 🎨 FEEDBACK CROISÉ (PHRASE DITE + SCORES)
      // ============================================================
      const spokenTokens = realSpokenText.split(/\s+/);

      const crossedFeedback = spokenTokens
        .map(token => {
          const clean = normalizeWord(token);
          if (!expectedWordScores.hasOwnProperty(clean)) {
            return token; // mot non attendu → noir
          }
          const score = expectedWordScores[clean];
          let color;
          if (score < 40) color = "#e53935";
          else if (score <= 60) color = "#fb8c00";
          else color = "#43a047";
          return `<font color="${color}">${token}</font>`;
        })
        .join(" ");

      // ============================================================
      // 💾 ENVOI STORYLINE
      // ============================================================
      setVar("0_Production_Orale_Score", pa.pronunciationScore);
      setVar("0_Production_Orale_Feedback", crossedFeedback);

      // ============================================================
      // 🧾 CONSTRUCTION DE LA VARIABLE 0_Reponse (FORMAT JSON)
      // ============================================================
      const responseData = {
        score: parseFloat(pa.pronunciationScore.toFixed(1)),
        texte_brut: realSpokenText.trim(),
        texte_color: crossedFeedback
      };

      const responseJSON = JSON.stringify(responseData);
      setVar("0_Reponse", responseJSON);

      console.log("💾 0_Reponse JSON :", responseJSON);

      // ============================================================
      // ✅ FIN DU PROCESSUS → Masquer le loader
      // ============================================================
      if (loading_Container) {
        loading_Container.state = "Invisible";
        console.log("✅ Loader masqué (Invisible)");
      }

      recognizer.close();
    });

  } catch (error) {
    console.error("❌ Erreur dans le script :", error);
    if (loading_Container) loading_Container.state = "Invisible";
  }

})();

}

window.Script251 = function()
{
  // Récupère les objets Storyline
const carte  = document.querySelector('[data-model-id="6WOyyFcuLyH"]');
const bouton = document.querySelector('[data-model-id="5rCsry3VrNh"]');

// Points d'ancrage
carte.style.transformOrigin = "top left";
bouton.style.transformOrigin = "center";

// Timeline pour synchroniser
const tl = gsap.timeline();

tl.to(carte, {
  scale: 0,
  opacity: 0,
  duration: 0.5,
  ease: "power1.inOut"
}, 0);

// Rotation 90° du bouton en même temps
tl.to(bouton, {
  rotate: 0,          // ou "+=90" si tu veux ajouter 90° à chaque fois
  duration: 0.5,
  ease: "power1.inOut"
}, 0);

}

window.Script252 = function()
{
  // Récupère les objets Storyline
const carte  = document.querySelector('[data-model-id="6WOyyFcuLyH"]');
const bouton = document.querySelector('[data-model-id="5rCsry3VrNh"]');

// Points d'ancrage
carte.style.transformOrigin = "top left";
bouton.style.transformOrigin = "center";

// États initiaux
gsap.set(carte,  { scale: 0, opacity: 0 });
gsap.set(bouton, { rotate: 0 }); // ou 90 si tu veux qu'il démarre déjà tourné

// Timeline pour synchroniser
const tl = gsap.timeline();

tl.to(carte, {
  scale: 1,
  opacity: 1,
  duration: 0.5,
  ease: "power1.inOut"
}, 0);

// Rotation 90° du bouton en même temps
tl.to(bouton, {
  rotate: 45,          // ou "+=90" si tu veux ajouter 90° à chaque fois
  duration: 0.5,
  ease: "power1.inOut"
}, 0);

}

window.Script253 = function()
{
  // ============================================================
// 💬 FEEDBACK MOTIVATIONNEL — AVEC SUPPORT DU FORMAT "1101nn"
// ============================================================

// -------- VARIABLES DE BASE --------
let resultat = getVar("Ex_Success");
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;
const exCurrent = parseInt(getVar(`${seqKey}_Exo_Current`), 10);

// ============================================================
// 🔍 SI RESULTAT VIDE → CHERCHE DANS S1_Win_Lose ("1101nn")
// ============================================================
if (!resultat || resultat === "") {
  const historique = getVar(`${seqKey}_Win_Lose`) || "";
  const charAtIndex = historique.charAt(exCurrent - 1);

  if (charAtIndex === "1" || charAtIndex === "0") {
    resultat = charAtIndex;
  } else {
    console.log(`ℹ️ Aucun résultat valide trouvé dans ${seqKey}_Win_Lose à l’index ${exCurrent - 1}`);
  }
}

// ============================================================
// 💬 LISTES DE FEEDBACKS
// ============================================================
const feedbackCorrect = [
  "Bravo !",
  "Super !",
  "Bien joué !",
  "Excellent !"
];

const feedbackIncorrect = [
  "Pas exactement.",
  "Oups !",
  "La prochaine fois !"
];

const feedbackNeutre = [
  "Continue !"
];

// ============================================================
// 🎯 CHOIX DU FEEDBACK
// ============================================================
let liste;
switch (resultat) {
  case "1":
    liste = feedbackCorrect;
    break;
  case "0":
    liste = feedbackIncorrect;
    break;
  default:
    liste = feedbackNeutre;
    break;
}

// Sélection aléatoire dans la liste
const feedback = liste[Math.floor(Math.random() * liste.length)];

// ============================================================
// 🧾 MISE À JOUR STORYLINE
// ============================================================
setVar("Ex_Feedback_Motivation", feedback);

}

window.Script254 = function()
{
  // ============================================================
// 🔁 SCRIPT — ALLER AU PROCHAIN EXERCICE ÉCHOUÉ ("Réviser les erreurs")
// ============================================================

// -------- VARIABLES DE CONTEXTE --------
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;
const exCurrent = parseInt(getVar(`${seqKey}_Exo_Current`), 10);
const historique = getVar(`${seqKey}_Win_Lose`) || "";

// -------- SÉCURITÉ --------
if (!seqPos || !historique) {
  console.warn("⚠️ Impossible d'exécuter le script — séquence ou historique manquant.");
  return;
}

// ============================================================
// 🔍 RECHERCHE DU PROCHAIN ÉCHEC ("0")
// ============================================================

// On cherche le prochain "0" APRÈS la position actuelle
const nextFailIndex = historique.indexOf("0", exCurrent);

// ============================================================
// 🎯 MISE À JOUR OU FIN DE LA RÉVISION
// ============================================================

if (nextFailIndex === -1) {
  // Aucun autre exercice échoué trouvé → fin du mode révision
  setVar("S0_Revision_Erreurs", 2);

} else {
  // Prochain exercice échoué trouvé
  const nextExercise = nextFailIndex + 1; // index → position 1-based
  setVar("0_Position_Exercice", nextExercise);
}
}

window.Script255 = function()
{
  // ============================================================
// 🎯 ANIMATION DE JAUGE — Rotation + Oscillation continue + Feedback motivationnel + Indicateur visuel
// ============================================================

// -------- OBJETS STORYLINE --------
const pointer = object('5fZOHpnMbya');
const gauge = object('6nKxLAItMtB');

// -------- PARAMÈTRES --------
const minAngle = 0;
const maxAngle = 180;
const oscillationRange = 10;
const oscillationSpeed = 1.5;

// ============================================================
// 🧮 DETECTION DU RESULTAT + RECUPERATION VARIABLES STORYLINE
// ============================================================
let resultat = getVar("Ex_Success");
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;
const exCurrent = getVar(`${seqKey}_Exo_Current`);

// Si il n'y a pas de résultat direct, on tente de le retrouver dans Sx_Win_Lose
if (resultat === "") {
  const historique = getVar(`${seqKey}_Win_Lose`);
  const charAtIndex = historique.charAt(exCurrent - 1);
  if (charAtIndex === "1" || charAtIndex === "0") {
    resultat = charAtIndex;
  } else {
    console.log(`ℹ️ Aucun résultat valide trouvé dans ${seqKey}_Win_Lose à l’index ${exCurrent - 1}`);
    resultat = "";
  }
}

// ============================================================
// ⚙️ Changement couleur jauge
// ============================================================
if (resultat === "1") {
  gauge.state = "Correct" ;
} else if (resultat === "0") {
  gauge.state = "Incorrect" ;
}

// ============================================================
// ⚙️ CALCULS D’ANGLES
// ============================================================
const baseAngle = resultat * (maxAngle - minAngle) + minAngle;
const angleMin = baseAngle - oscillationRange;
const angleMax = baseAngle + oscillationRange;


const goingUp = resultat === "1";
const targetAngle = goingUp ? angleMax : angleMin;

// ============================================================
// 🧹 ARRÊTE LES ANIMATIONS EXISTANTES
// ============================================================
gsap.killTweensOf(pointer);

// ============================================================
// 🚀 ANIMATION DE L’AIGUILLE
// ============================================================
gsap.to(pointer, {
  rotation: targetAngle,
  duration: 1.2,
  ease: "power2.inOut",
  onComplete: () => {
    gsap.to(pointer, {
      rotation: goingUp ? angleMin : angleMax,
      duration: oscillationSpeed,
      ease: "sine.inOut",
      yoyo: true,
      repeat: -1
    });
  }
});

}

window.Script256 = function()
{
  const Btn_Affichage  = document.querySelector('[data-model-id="6geks01QgvK"]');
const temoin = object('6XIh2Zufqbt');

// (Optionnel mais recommandé) point d’ancrage de la rotation
Btn_Affichage.style.transformOrigin = "50% 50%";

// On lit l’état actuel puis on bascule
const isAffiche = (temoin.state === "Feedback_Affiche");

temoin.state = isAffiche ? "Feedback_Cache" : "Feedback_Affiche";

// Rotation GSAP (durée + easing ajustables)
gsap.to(Btn_Affichage, {
  rotation: isAffiche ? 180 : 0,
  duration: 0.45,
  ease: "power2.inOut",
  overwrite: "auto"
});

}

window.Script257 = function()
{
  // ============================================================
// 💬 FEEDBACK MOTIVATIONNEL — AVEC SUPPORT DU FORMAT "1101nn"
// ============================================================

// -------- VARIABLES DE BASE --------
let resultat = getVar("Ex_Success");
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;
const exCurrent = parseInt(getVar(`${seqKey}_Exo_Current`), 10);

// ============================================================
// 🔍 SI RESULTAT VIDE → CHERCHE DANS S1_Win_Lose ("1101nn")
// ============================================================
if (!resultat || resultat === "") {
  const historique = getVar(`${seqKey}_Win_Lose`) || "";
  const charAtIndex = historique.charAt(exCurrent - 1);

  if (charAtIndex === "1" || charAtIndex === "0") {
    resultat = charAtIndex;
  } else {
    console.log(`ℹ️ Aucun résultat valide trouvé dans ${seqKey}_Win_Lose à l’index ${exCurrent - 1}`);
  }
}

// ============================================================
// 💬 LISTES DE FEEDBACKS
// ============================================================
//const feedbackCorrect = [
//  "Bravo !",
//  "Super !",
//  "Bien joué !",
//  "Excellent !"
//];

//const feedbackIncorrect = [
//  "Pas exactement.",
//  "Oups !",
//  "La prochaine fois !"
//];

const feedbackCorrect = [
  "Bravo, c'est une bonne réponse !",
  "Super, tu es sur la bonne voie !",
  "Bien joué, tu progresses !",
  "Excellent, continue comme ça !"
];

const feedbackIncorrect = [
  "Ce n'est pas tout à fait ça.",
  "Oups, ce n'est pas la bonne réponse.",
  "Tu y arriveras la prochaine fois !",
  "Pas exactement. Encore un effort !"
];


const feedbackNeutre = [
  "Continue !"
];

// ============================================================
// 🎯 CHOIX DU FEEDBACK
// ============================================================
let liste;
switch (resultat) {
  case "1":
    liste = feedbackCorrect;
    break;
  case "0":
    liste = feedbackIncorrect;
    break;
  default:
    liste = feedbackNeutre;
    break;
}

// Sélection aléatoire dans la liste
const feedback = liste[Math.floor(Math.random() * liste.length)];

// ============================================================
// 🧾 MISE À JOUR STORYLINE
// ============================================================
setVar("Ex_Feedback_Motivation", feedback);

}

window.Script258 = function()
{
  // ============================================================
// 🔁 SCRIPT — ALLER AU PROCHAIN EXERCICE ÉCHOUÉ ("Réviser les erreurs")
// ============================================================

// -------- VARIABLES DE CONTEXTE --------
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;
const exCurrent = parseInt(getVar(`${seqKey}_Exo_Current`), 10);
const historique = getVar(`${seqKey}_Win_Lose`) || "";

// -------- SÉCURITÉ --------
if (!seqPos || !historique) {
  console.warn("⚠️ Impossible d'exécuter le script — séquence ou historique manquant.");
  return;
}

// ============================================================
// 🔍 RECHERCHE DU PROCHAIN ÉCHEC ("0")
// ============================================================

// On cherche le prochain "0" APRÈS la position actuelle
const nextFailIndex = historique.indexOf("0", exCurrent);

// ============================================================
// 🎯 MISE À JOUR OU FIN DE LA RÉVISION
// ============================================================

if (nextFailIndex === -1) {
  // Aucun autre exercice échoué trouvé → fin du mode révision
  setVar("S0_Revision_Erreurs", 2);

} else {
  // Prochain exercice échoué trouvé
  const nextExercise = nextFailIndex + 1; // index → position 1-based
  setVar("0_Position_Exercice", nextExercise);
}
}

window.Script259 = function()
{
  // ============================================================
// 🎯 ANIMATION DE JAUGE — Rotation + Oscillation continue + Feedback motivationnel + Indicateur visuel
// ============================================================

// -------- OBJETS STORYLINE --------
const pointer = object('61WVHrM0EGs');
//const gauge = object('5lezhyLYUu5'); Cet objet n'existe pas ?
const gauge = object('6rIRKS6iuFv');


// -------- PARAMÈTRES --------
const minAngle = 0;
const maxAngle = 180;
const oscillationRange = 10;
const oscillationSpeed = 1.5;

// ============================================================
// 🧮 DETECTION DU RESULTAT + RECUPERATION VARIABLES STORYLINE
// ============================================================
let resultat = getVar("Ex_Success");
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;
const exCurrent = getVar(`${seqKey}_Exo_Current`);

// Si il n'y a pas de résultat direct, on tente de le retrouver dans Sx_Win_Lose
if (resultat === "") {
  const historique = getVar(`${seqKey}_Win_Lose`);
  const charAtIndex = historique.charAt(exCurrent - 1);
  if (charAtIndex === "1" || charAtIndex === "0") {
    resultat = charAtIndex;
  } else {
    console.log(`ℹ️ Aucun résultat valide trouvé dans ${seqKey}_Win_Lose à l’index ${exCurrent - 1}`);
    resultat = "";
  }
}

// ============================================================
// ⚙️ Changement couleur jauge
// ============================================================
if (resultat === "1") {
  gauge.state = "Correct" ;
} else if (resultat === "0") {
  gauge.state = "Incorrect" ;
}

// ============================================================
// ⚙️ CALCULS D’ANGLES
// ============================================================
const baseAngle = resultat * (maxAngle - minAngle) + minAngle;
const angleMin = baseAngle - oscillationRange;
const angleMax = baseAngle + oscillationRange;


const goingUp = resultat === "1";
const targetAngle = goingUp ? angleMax : angleMin;

// ============================================================
// 🧹 ARRÊTE LES ANIMATIONS EXISTANTES
// ============================================================
gsap.killTweensOf(pointer);

// ============================================================
// 🚀 ANIMATION DE L’AIGUILLE
// ============================================================
gsap.to(pointer, {
  rotation: targetAngle,
  duration: 1.2,
  ease: "power2.inOut",
  onComplete: () => {
    gsap.to(pointer, {
      rotation: goingUp ? angleMin : angleMax,
      duration: oscillationSpeed,
      ease: "sine.inOut",
      yoyo: true,
      repeat: -1
    });
  }
});

}

window.Script260 = function()
{
  const Btn_Affichage  = document.querySelector('[data-model-id="6RRLU9ixx38"]');
const temoin = object('68ikzB1cq1L');

// (Optionnel mais recommandé) point d’ancrage de la rotation
Btn_Affichage.style.transformOrigin = "50% 50%";

// On lit l’état actuel puis on bascule
const isAffiche = (temoin.state === "Feedback_Affiche");

temoin.state = isAffiche ? "Feedback_Cache" : "Feedback_Affiche";

// Rotation GSAP (durée + easing ajustables)
gsap.to(Btn_Affichage, {
  rotation: isAffiche ? 180 : 0,
  duration: 0.45,
  ease: "power2.inOut",
  overwrite: "auto"
});

}

window.Script261 = function()
{
  // Récupère le résultat
let resultat = getVar("Ex_Success");

// Définit les listes de feedback
const feedbackCorrect = [
  "Bravo !",
  "Super !",
  "Bien joué !",
  "Excellent !"
];

const feedbackIncorrect = [
  "Pas exactement",
  "Oups !",
  "La prochaine fois !"
];

// Choisit la liste en fonction du résultat
let liste = (resultat === "1") ? feedbackCorrect : feedbackIncorrect;

// Sélectionne un élément aléatoire dans la liste
let feedback = liste[Math.floor(Math.random() * liste.length)];

// Met à jour la variable Storyline
setVar("Ex_Feedback_Motivation", feedback);

}

window.Script262 = function()
{
  // ============================================================
// 🎯 ANIMATION DE JAUGE — Rotation + Oscillation continue + Feedback motivationnel + Indicateur visuel
// ============================================================

// -------- OBJETS STORYLINE --------
const pointer = object('5Ux37gXcJcw');
const gauge = object('5enGetq7POY');

// -------- PARAMÈTRES --------
const minAngle = 0;
const maxAngle = 180;
const oscillationRange = 10;
const oscillationSpeed = 1.5;

// ============================================================
// 🧮 DETECTION DU RESULTAT + RECUPERATION VARIABLES STORYLINE
// ============================================================
let resultat = getVar("Ex_Success");
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;
const exCurrent = getVar(`${seqKey}_Exo_Current`);

// Si il n'y a pas de résultat direct, on tente de le retrouver dans Sx_Win_Lose
if (resultat === "") {
  const historique = getVar(`${seqKey}_Win_Lose`);
  const charAtIndex = historique.charAt(exCurrent - 1);
  if (charAtIndex === "1" || charAtIndex === "0") {
    resultat = charAtIndex;
  } else {
    console.log(`ℹ️ Aucun résultat valide trouvé dans ${seqKey}_Win_Lose à l’index ${exCurrent - 1}`);
    resultat = "";
  }
}

// ============================================================
// ⚙️ Changement couleur jauge
// ============================================================
if (resultat === "1") {
  gauge.state = "Correct" ;
} else if (resultat === "0") {
  gauge.state = "Incorrect" ;
}

// ============================================================
// ⚙️ CALCULS D’ANGLES
// ============================================================
const baseAngle = resultat * (maxAngle - minAngle) + minAngle;
const angleMin = baseAngle - oscillationRange;
const angleMax = baseAngle + oscillationRange;


const goingUp = resultat === "1";
const targetAngle = goingUp ? angleMax : angleMin;

// ============================================================
// 🧹 ARRÊTE LES ANIMATIONS EXISTANTES
// ============================================================
gsap.killTweensOf(pointer);

// ============================================================
// 🚀 ANIMATION DE L’AIGUILLE
// ============================================================
gsap.to(pointer, {
  rotation: targetAngle,
  duration: 1.2,
  ease: "power2.inOut",
  onComplete: () => {
    gsap.to(pointer, {
      rotation: goingUp ? angleMin : angleMax,
      duration: oscillationSpeed,
      ease: "sine.inOut",
      yoyo: true,
      repeat: -1
    });
  }
});

}

window.Script263 = function()
{
  // ============================================================
// 🔁 SCRIPT — ALLER AU PROCHAIN EXERCICE ÉCHOUÉ ("Réviser les erreurs")
// ============================================================

// -------- VARIABLES DE CONTEXTE --------
const seqPos = getVar("0_Position_Sequence"); // ex: "1", "2", "3", "4"
const seqKey = `S${seqPos}`;                  // ex: "S1"
const exCurrent = parseInt(getVar(`${seqKey}_Exo_Current`) || 0, 10); // ex: 3
const historique = getVar(`${seqKey}_Win_Lose`) || ""; // ex: "110010"

// -------- SÉCURITÉ --------
if (!seqPos || !historique) {
  console.warn("⚠️ Impossible d'exécuter le script — séquence ou historique manquant.");
  return;
}

// ============================================================
// 🔍 RECHERCHE DU PROCHAIN ÉCHEC ("0")
// ============================================================

// On cherche le prochain "0" APRÈS la position actuelle
const nextFailIndex = historique.indexOf("0", exCurrent);

// ============================================================
// 🎯 MISE À JOUR OU FIN DE LA RÉVISION
// ============================================================

if (nextFailIndex === -1) {
  // Aucun autre exercice échoué trouvé → fin du mode révision
  setVar("S0_Revision_Erreurs", 2);
  console.log("🎉 Tous les exercices échoués ont été revus — fin du mode révision (S0_Revision_Erreurs = 2).");
} else {
  // Prochain exercice échoué trouvé
  const nextExercise = nextFailIndex + 1; // index → position 1-based
  setVar("0_Position_Exercice", nextExercise);
  console.log(`🔁 Révision → Prochain exercice échoué : EX${nextExercise}`);
}

console.log(`(Séquence : ${seqKey}, Historique : "${historique}")`);

}

window.Script264 = function()
{
  // ============================================================
// 🎬 REMPLACEMENT DYNAMIQUE DE VIDÉO (version simplifiée)
// ============================================================
// Remplace directement la vidéo de l'objet Storyline (ID fixe)
// avec le chemin complet contenu dans la variable "Ex_Video".
// ============================================================

// -------- Lecture de la variable --------
const newVideoPath = getVar("Ex_Video"); // ex: "Ressources_Sequences/S1/Videos/S1_EX1.mp4"

// -------- Sécurité --------
if (!newVideoPath || newVideoPath.trim() === "") {
  console.warn("⚠️ Aucune vidéo spécifiée dans Ex_Video — remplacement annulé.");
  return;
}

// -------- Sélection directe de la vidéo --------
const videoElement = document.querySelector('[data-model-id="5pTX8N7gCDH"] video');
if (!videoElement) {
  console.error("❌ Impossible de trouver la vidéo avec data-model-id=5pTX8N7gCDH.");
  return;
}

// -------- Remplacement de la source --------
videoElement.setAttribute("xlink:href", newVideoPath);
videoElement.src = newVideoPath;
videoElement.load();

// -------- Suppression de la vignette (poster) --------
const container = videoElement.closest('[data-model-id="5pTX8N7gCDH"]');
if (container) {
  const poster = container.querySelector("img.video-player-poster");
  if (poster) {
    poster.remove();
    console.log("✅ Vignette (poster) supprimée — la 1ère image de la vidéo sera visible.");
  }
}
}

window.Script265 = function()
{
  // ============================================================
// 🖼️ REMPLACEMENT DYNAMIQUE D’IMAGE (version simplifiée)
// ============================================================
// Remplace directement l’image de l’objet Storyline (ID fixe)
// avec le chemin complet contenu dans la variable "Ex_Image".
// Aucun calcul de dossier ou de chemin n’est effectué.
// ============================================================

// -------- Lecture de la variable --------
const newImagePath = getVar("Ex_Image"); // ex: "Ressources_Sequences/S1/images/EX1.jpg"

// -------- Sécurité --------
if (!newImagePath || newImagePath.trim() === "") {
  console.warn("⚠️ Aucune image spécifiée dans Ex_Image — remplacement annulé.");
  return;
}

// -------- Sélection directe de l’image --------
const imageElement = document.querySelector('[data-model-id="6jUy2ox5l86"] image');
if (!imageElement) {
  console.error("❌ Impossible de trouver l’image avec data-model-id=6jUy2ox5l86.");
  return;
}

// -------- Remplacement du lien --------
imageElement.setAttributeNS("http://www.w3.org/1999/xlink", "xlink:href", newImagePath);

}

window.Script266 = function()
{
  // ============================================================
// 🖼️ REMPLACEMENT DYNAMIQUE D’IMAGE (version simplifiée)
// ============================================================
// Remplace directement l’image de l’objet Storyline (ID fixe)
// avec le chemin complet contenu dans la variable "Ex_Image".
// Aucun calcul de dossier ou de chemin n’est effectué.
// ============================================================

// -------- Lecture de la variable --------
const newImagePath = getVar("Ex_Image"); // ex: "Ressources_Sequences/S1/images/EX1.jpg"

// -------- Sécurité --------
if (!newImagePath || newImagePath.trim() === "") {
  console.warn("⚠️ Aucune image spécifiée dans Ex_Image — remplacement annulé.");
  return;
}

// -------- Sélection directe de l’image --------
const imageElement = document.querySelector('[data-model-id="6c22D92goAT"] image');
if (!imageElement) {
  console.error("❌ Impossible de trouver l’image avec data-model-id=6c22D92goAT.");
  return;
}

// -------- Remplacement du lien --------
imageElement.setAttributeNS("http://www.w3.org/1999/xlink", "xlink:href", newImagePath);

}

window.Script267 = function()
{
  // ============================================================
// ⚙️ BARRE DE PROGRESSION — SYNCHRONISATION AVEC LA SÉQUENCE EN COURS
// ============================================================

// --------- Lecture de la séquence courante ---------
const seqPos = getVar("0_Position_Sequence");   // ex. 1 → S1
const seqKey = `S${seqPos}`;

// --------- Lecture des variables de la séquence correspondante ---------
const Exo_Reached = getVar("S0_Exo_Reached") || 0;
const Exo_Total = getVar("S0_Exo_Total") || 1;

// --------- Calcul du pourcentage ---------
const progress = Math.min(Exo_Reached / Exo_Total, 1); // clamp entre 0 et 1

// --------- Sélectionne l'objet Storyline ---------
const ProgressBar = document.querySelector(`[data-model-id="6f561U28wA4"]`);

if (ProgressBar) {
  // --------- Sélectionne l'élément graphique principal ---------
  const shape = ProgressBar.querySelector("path");

  if (shape) {
    // Si ce n’est pas déjà fait, on garde la largeur d’origine
    if (!shape.dataset.fullWidth) {
      const bbox = shape.getBBox();
      shape.dataset.fullWidth = bbox.width;
    }

    // --------- Calcul de la largeur selon la progression ---------
    const fullWidth = parseFloat(shape.dataset.fullWidth);

    // --------- Application du remplissage via clip-path ---------
    shape.style.clipPath = `inset(0 ${100 - progress * 100}% 0 0 round 0px)`;
  }
}

}

window.Script268 = function()
{
  // ============================================================
// ⚙️ BARRE DE PROGRESSION ANIMÉE (AVEC INITIALISATION INTELLIGENTE)
// ============================================================

// Durée de l’animation en millisecondes (modifiable)
const animationDuration = 800; // 0.8s = fluide, 300 = rapide, 1500 = lente

function updateProgressBarAnimated() {
  // --------- Lecture de la séquence courante ---------
  const seqPos = getVar("0_Position_Sequence");
  const seqKey = `S${seqPos}`;

  // --------- Lecture des variables globales S0 ---------
  const Exo_Reached = getVar("S0_Exo_Reached") || 0;
  const Exo_Total = getVar("S0_Exo_Total") || 1;
  const progress = Math.min(Exo_Reached / Exo_Total, 1);

  // --------- Sélectionne l'objet Storyline ---------
  const ProgressBar = document.querySelector(`[data-model-id="6f561U28wA4"]`);
  if (!ProgressBar) return;

  const shape = ProgressBar.querySelector("path");
  if (!shape) return;

  // --------- Initialisation si nécessaire ---------
  if (!shape.dataset.fullWidth) {
    const bbox = shape.getBBox();
    shape.dataset.fullWidth = bbox.width;
  }

  // --------- Nouvelle logique : position initiale intelligente ---------
  let startProgress;

  if (shape.dataset.currentProgress !== undefined) {
    // On continue à partir de la progression actuelle
    startProgress = parseFloat(shape.dataset.currentProgress) || 0;
  } else if (Exo_Reached >= 1) {
    // Si aucune donnée mais au moins un exercice complété,
    // on démarre au niveau précédent
    startProgress = (Exo_Reached - 1) / Exo_Total;
  } else {
    // Sinon, tout au début
    startProgress = 0;
  }

  const startTime = performance.now();

  // --------- Fonction d'animation fluide ---------
  function animate(time) {
    const elapsed = time - startTime;
    const t = Math.min(elapsed / animationDuration, 1);
    const eased = t < 0.5 ? 2 * t * t : -1 + (4 - 2 * t) * t; // easeInOutQuad

    const currentProgress = startProgress + (progress - startProgress) * eased;
    shape.style.clipPath = `inset(0 ${100 - currentProgress * 100}% 0 0 round 0px)`;
    shape.dataset.currentProgress = currentProgress;

    if (t < 1) requestAnimationFrame(animate);
  }

  requestAnimationFrame(animate);
}

// ============================================================
// ▶️ APPEL DU SCRIPT (exécuté manuellement via trigger JS)
// ============================================================

updateProgressBarAnimated();

}

window.Script269 = function()
{
  // -------- Initialisation --------

// Récupère le numéro ou identifiant d'exercice (ex: "EX2")
const AudioPath = getVar("0_Audio_Lecteur");

// Si un audio était déjà en cours → on le stoppe et on remet au début
if (window.audioUnique) {
  window.audioUnique.pause();
  window.audioUnique.currentTime = 0;
}

// Crée un nouvel objet audio
window.audioUnique = new Audio(AudioPath);

// Lecture
window.audioUnique.play().catch(err => {
  console.log("Erreur lecture Back :", err);
});
}

window.Script270 = function()
{
  // ============================================================
// 🎯 MISE À JOUR DES VARIABLES Sx_Win_Lose SELON Ex_Success (texte)
// ============================================================

// -------- Lecture des variables Storyline --------
const seqPos  = getVar("0_Position_Sequence");
const exPos   = getVar("0_Position_Exercice");
const success = getVar("Ex_Success");

// -------- Construction du nom de la séquence --------
const seqKey     = `S${seqPos}`;
const winLoseVar = `${seqKey}_Win_Lose`;

// -------- Lecture actuelle de la variable Win_Lose --------
let winLose = getVar(winLoseVar) || "";

// -------- S’assure que la longueur correspond au nombre total d’exercices --------
const total = getVar(`0_Menu_${seqKey}_Exo_Total`);

// -------- Conversion en tableau pour modification --------
const chars = winLose.split("");

// -------- Mise à jour du caractère correspondant à l’exercice actuel --------
if (!(chars[exPos - 1] === "1" && success === "0")) {
    chars[exPos - 1] = success === "1" ? "1" : "0";
}
// Si l'exercice est déjà réussi, on garde la réussite.

// -------- Conversion inverse en chaîne --------
winLose = chars.join("");

// -------- Écriture dans Storyline --------
setVar(winLoseVar, winLose);

// ============================================================
// 🔁 SWITCH AUTOMATIQUE DE 0_Feedback_Switch
// ============================================================
let feedbackSwitch = getVar("0_Feedback_Switch");
feedbackSwitch = feedbackSwitch === true || feedbackSwitch === "true" ? false : true;
setVar("0_Feedback_Switch", feedbackSwitch);

}

window.Script271 = function()
{
  // ============================================================
// 🏁 SCRIPT DE FIN D’EXERCICE — MISE À JOUR PROGRESSION & TENTATIVES
// ============================================================

// -------- CONFIGURATION --------
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;

const exCurrent  = parseInt(getVar(`${seqKey}_Exo_Current`), 10);
const exReached  = parseInt(getVar(`${seqKey}_Exo_Reached`), 10);
const tentVar    = `${seqKey}_Exo_Current_Tentatives`;
// ============================================================
// 🧭 MISE À JOUR DE LA PROGRESSION
// ============================================================

// Si on avance (évite de revenir en arrière)
if (exCurrent > exReached) {
  setVar(`${seqKey}_Exo_Reached`, exCurrent);
  setVar("S0_Exo_Reached", exCurrent); 
}

// ============================================================
// 🧮 MARQUAGE DE L’EXERCICE TERMINÉ
// ============================================================

setVar(tentVar, -10);

}

window.Script272 = function()
{
  // ============================================================
// 🧠 SAUVEGARDE AUTOMATIQUE DES DONNÉES UTILISATEUR (GLOBAL)
// ============================================================
//
// 🔹 Ce script est appelé automatiquement après la validation d’un exercice.
// 🔹 Il détecte le type d’exercice et sauvegarde la réponse dans la variable JSON
//    correspondante (ex: S1_UserData)
//
// ============================================================

// ------------------------------------------------------------
// 🔧 Lecture des infos de contexte
// ------------------------------------------------------------
const seqPos = getVar("0_Position_Sequence");           // ex: "1"
const exPos = parseInt(getVar("0_Position_Exercice"), 10);
const seqKey = `S${seqPos}`;
const exType = getVar("Ex_Type");
const success = getVar("Ex_Success");
const tentativesRestantes = parseInt(getVar("Ex_Tentatives"), 10);

// Variable cible (ex: "S1_UserData")
const userDataVar = `${seqKey}_UserData`;

// ------------------------------------------------------------
// 🔧 Lecture du JSON existant
// ------------------------------------------------------------
let data = {};
try {
  const existing = getVar(userDataVar);
  data = existing ? JSON.parse(existing) : {};
} catch (err) {
  console.warn(`⚠️ JSON invalide dans ${userDataVar}, réinitialisation.`, err);
  data = {};
}

// ------------------------------------------------------------
// 🧮 Tentatives initiales (si dispo dans cache global)
// ------------------------------------------------------------
let tentativesInitiales = 0;
try {
  const exData = window.sequenceCache?.[seqKey]?.[`EX${exPos}`];
  tentativesInitiales = exData?.Tentatives || 1;
} catch {
  tentativesInitiales = 1;
}

const tentativesUtilisees = Math.max(0, tentativesInitiales - tentativesRestantes);

// ------------------------------------------------------------
// 🎯 Récupération de la réponse selon le type d’exercice
// ------------------------------------------------------------
let userResponseObj = {};

switch (exType) {
  // 🔹 QCU
  case "QCU": {
    const answerKey = getVar("0_Reponse");
    const answerText = getVar(`0_Choix_${answerKey}`) || "";
    userResponseObj = { [answerKey]: answerText };
    break;
  }

  // 🔹 QCM
  case "QCM": {
    const responseRaw = (getVar("0_Reponse") || "").split("|").filter(Boolean);
    responseRaw.forEach(k => {
      userResponseObj[k] = getVar(`0_Choix_${k}`) || "";
    });
    break;
  }

  // 🔹 True or false
  case "True or false": {
    const answer = (getVar("0_Reponse") || "").toLowerCase();
    userResponseObj = { unique: answer };
    break;
  }

  // 🔹 Complete
  case "Complete": {
    const answer = getVar("0_Ex_Enonce") || "";
    userResponseObj = { unique: answer };
    break;
  }

  // 🔹 Matching
  case "Matching": {
    const reponse = getVar("0_Reponse") || "";
    userResponseObj = { associations: reponse };
    break;
  }

  // 🔹 Flashcard
  case "Flashcard": {
    const answer = getVar("0_Reponse") || "";
    userResponseObj = { unique: answer };
    break;
  }

  // 🔹 Information
  case "Information": {
    userResponseObj = { info: "Aucune interaction" };
    break;
  }

  // 🔹 Production orale - dictée
  case "Production orale - dictée": {
    const raw = getVar("0_Reponse") || "{}";
    try {
      const parsed = JSON.parse(raw);
      userResponseObj = {
        score: parsed.score || 0,
        texte_brut: parsed.texte_brut || "",
        texte_color: parsed.texte_color || ""
      };
    } catch (err) {
      console.warn("⚠️ Erreur de parsing JSON pour Production orale :", err);
      userResponseObj = { erreur: "Format de réponse invalide", raw };
    }
    break;
  }

  // 🔹 Défaut
  default: {
    const raw = getVar("0_Reponse") || "";
    userResponseObj = { inconnu: raw };
    console.warn(`❓ Type d’exercice inconnu : ${exType}`);
    break;
  }
}

// ------------------------------------------------------------
// 💾 Enregistrement dans le JSON
// ------------------------------------------------------------
data[`EX${exPos}`] = {
  Type: exType,
  Reponses_Choisies: userResponseObj,
  Statut: success,
  Tentatives_Utilisees: tentativesUtilisees
};

setVar(userDataVar, JSON.stringify(data));

// ------------------------------------------------------------
// 🧾 Log de contrôle
// ------------------------------------------------------------
console.group(`💾 Données sauvegardées → ${userDataVar}`);
console.log("Exercice :", `EX${exPos}`);
console.log("Type :", exType);
console.log("Réponses :", userResponseObj);
console.log("Statut :", success);
console.log("Tentatives utilisées :", tentativesUtilisees);
console.log("JSON complet :", data);
console.groupEnd();

}

window.Script273 = function()
{
  // ============================================================
// 🎯 VÉRIFICATION DE LA RÉPONSE (Flashcard)
// ============================================================

// --------- Lecture des variables Storyline ---------
const userAnswer = (getVar("0_Reponse") || "");

// --------- Comparaison logique ---------
let success = "0"; // Par défaut = échec

if (userAnswer === "OK") {
  success = "1";
}

// --------- Écriture dans Storyline ---------
setVar("Ex_Success", success);
}

window.Script274 = function()
{
  // -------- 5. Initialisation des cartes --------
var FrontCard = document.querySelector('[data-model-id="623BcObu0ym"]');
var BackCard  = document.querySelector('[data-model-id="6DIWbGqWkGP"]');

// Réinitialise l’état
setVar("0_Flashcard_FlipState", "");

// Positionne directement les cartes (sans animation)
gsap.set(FrontCard, { rotateY: 0 });
gsap.set(BackCard, { rotateY: -90 });

// Mets à jour la variable Storyline
setVar("0_Flashcard_FlipState", "FrontVisible");
}

window.Script275 = function()
{
  // ============================================================
// 🎯 FLASHCARDS — ROTATION CENTRÉE SUR UN OBJET DE RÉFÉRENCE
// ============================================================

// -------- Sélection des objets Storyline --------
var FrontCard  = document.querySelector('[data-model-id="623BcObu0ym"]');
var BackCard   = document.querySelector('[data-model-id="6DIWbGqWkGP"]');
var Container  = document.querySelector('[data-model-id="6C4lRLl70Ql"]'); // repère central

if (!FrontCard || !BackCard || !Container) {
  console.warn("⚠️ Impossible de trouver un des éléments Flashcard.");
} else {

  // ============================================================
  // 🧭 Fonction : Recentrer les cartes sur le conteneur
  // ============================================================
  function recenterFlashcards() {
    const containerRect = Container.getBoundingClientRect();
    const centerX = containerRect.left + containerRect.width / 2;
    const centerY = containerRect.top + containerRect.height / 2;

    [FrontCard, BackCard].forEach(card => {
      const cardRect = card.getBoundingClientRect();
      const offsetX = centerX - (cardRect.left + cardRect.width / 2);
      const offsetY = centerY - (cardRect.top + cardRect.height / 2);

      // Ajuste la position et définit le pivot au centre
      gsap.set(card, {
        x: "+=" + offsetX,
        y: "+=" + offsetY,
        transformOrigin: "center center",
        transformStyle: "preserve-3d"
      });
    });
  }

  // ============================================================
  // 📏 Recentrage initial et sur redimensionnement
  // ============================================================
  recenterFlashcards();
  window.addEventListener("resize", recenterFlashcards);

  // ============================================================
  // 🔄 Gestion du flip (Front ↔ Back)
  // ============================================================
  var rotation = getVar("0_Flashcard_Rotation");

  if (rotation === "FrontToBack") {
    setVar("0_Flashcard_FlipState", "");
    let tl = gsap.timeline();

    // Position de départ
    tl.set(BackCard, { rotateY: -90 });
    recenterFlashcards(); // 🔹 recentrage avant rotation

    // Animation du flip
    tl.to(FrontCard, { rotateY: -90, duration: 0.5 });
    tl.to(BackCard, { rotateY: 0, duration: 0.5, onComplete: () => {
      setVar("0_Flashcard_FlipState", "BackVisible");
    }});

  } else if (rotation === "BackToFront") {
    setVar("0_Flashcard_FlipState", "");
    let tl = gsap.timeline();

    // Position de départ
    tl.set(FrontCard, { rotateY: -90 });
    recenterFlashcards(); // 🔹 recentrage avant rotation

    // Animation du flip
    tl.to(BackCard, { rotateY: -90, duration: 0.5 });
    tl.to(FrontCard, { rotateY: 0, duration: 0.5, onComplete: () => {
      setVar("0_Flashcard_FlipState", "FrontVisible");
    }});
  }
}

}

window.Script276 = function()
{
  // ============================================================
// 🔁 SCRIPT — ALLER AU PROCHAIN EXERCICE ÉCHOUÉ ("Réviser les erreurs")
// ============================================================

// -------- VARIABLES DE CONTEXTE --------
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;
const exCurrent = parseInt(getVar(`${seqKey}_Exo_Current`), 10);
const historique = getVar(`${seqKey}_Win_Lose`) || "";

// -------- SÉCURITÉ --------
if (!seqPos || !historique) {
  console.warn("⚠️ Impossible d'exécuter le script — séquence ou historique manquant.");
  return;
}

// ============================================================
// 🔍 RECHERCHE DU PROCHAIN ÉCHEC ("0")
// ============================================================

// On cherche le prochain "0" APRÈS la position actuelle
const nextFailIndex = historique.indexOf("0", exCurrent);

// ============================================================
// 🎯 MISE À JOUR OU FIN DE LA RÉVISION
// ============================================================

if (nextFailIndex === -1) {
  // Aucun autre exercice échoué trouvé → fin du mode révision
  setVar("S0_Revision_Erreurs", 2);

} else {
  // Prochain exercice échoué trouvé
  const nextExercise = nextFailIndex + 1; // index → position 1-based
  setVar("0_Position_Exercice", nextExercise);
}
}

window.Script277 = function()
{
  //DESCRIPTION : 
//	Si Ex_Flashcard_Extra_Type est null alors on positionne 
//		le bouton "je révise" sur POS_ReviseNoExtra (à gauche)
//		le bouton "je maitrise" sur POS_MaitriseNoExtra (à droite)

const BTN_Maitrise = object('5gux1NZ9zv0');
const BTN_Revise = object('6BmjErDC6Y8');
const POS_Maitrise_NoExtra = object('5dJoE6z4Zzk');
const POS_Revise_NoExtra = object('6rCUE8FqkmX');

BTN_Maitrise.x = POS_Maitrise_NoExtra.x ;
BTN_Revise.x = POS_Revise_NoExtra.x ;
}

window.Script278 = function()
{
  //DESCRIPTION : 
//	Si on revient en arrière, les boutons de réponse sont absents donc
//	on centre le bouton des extras


const BTN_Complementaire = object('6ahmaEP7NLF');
const POS_Extra = object('5lWQU2aDKKi');

BTN_Complementaire.x = POS_Extra.x
}

window.Script279 = function()
{
  // Récupère les objets Storyline
const carte  = document.querySelector('[data-model-id="6WOyyFcuLyH"]');
const bouton = document.querySelector('[data-model-id="5rCsry3VrNh"]');

// Points d'ancrage
carte.style.transformOrigin = "top left";
bouton.style.transformOrigin = "center";

// Timeline pour synchroniser
const tl = gsap.timeline();

tl.to(carte, {
  scale: 0,
  opacity: 0,
  duration: 0.5,
  ease: "power1.inOut"
}, 0);

// Rotation 90° du bouton en même temps
tl.to(bouton, {
  rotate: 0,          // ou "+=90" si tu veux ajouter 90° à chaque fois
  duration: 0.5,
  ease: "power1.inOut"
}, 0);

}

window.Script280 = function()
{
  // Récupère les objets Storyline
const carte  = document.querySelector('[data-model-id="6WOyyFcuLyH"]');
const bouton = document.querySelector('[data-model-id="5rCsry3VrNh"]');

// Points d'ancrage
carte.style.transformOrigin = "top left";
bouton.style.transformOrigin = "center";

// États initiaux
gsap.set(carte,  { scale: 0, opacity: 0 });
gsap.set(bouton, { rotate: 0 }); // ou 90 si tu veux qu'il démarre déjà tourné

// Timeline pour synchroniser
const tl = gsap.timeline();

tl.to(carte, {
  scale: 1,
  opacity: 1,
  duration: 0.5,
  ease: "power1.inOut"
}, 0);

// Rotation 90° du bouton en même temps
tl.to(bouton, {
  rotate: 45,          // ou "+=90" si tu veux ajouter 90° à chaque fois
  duration: 0.5,
  ease: "power1.inOut"
}, 0);

}

window.Script281 = function()
{
  // ============================================================
// 💬 FEEDBACK MOTIVATIONNEL — AVEC SUPPORT DU FORMAT "1101nn"
// ============================================================

// -------- VARIABLES DE BASE --------
let resultat = getVar("Ex_Success");
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;
const exCurrent = parseInt(getVar(`${seqKey}_Exo_Current`), 10);

// ============================================================
// 🔍 SI RESULTAT VIDE → CHERCHE DANS S1_Win_Lose ("1101nn")
// ============================================================
if (!resultat || resultat === "") {
  const historique = getVar(`${seqKey}_Win_Lose`) || "";
  const charAtIndex = historique.charAt(exCurrent - 1);

  if (charAtIndex === "1" || charAtIndex === "0") {
    resultat = charAtIndex;
  } else {
    console.log(`ℹ️ Aucun résultat valide trouvé dans ${seqKey}_Win_Lose à l’index ${exCurrent - 1}`);
  }
}

// ============================================================
// 💬 LISTES DE FEEDBACKS
// ============================================================
const feedbackCorrect = [
  "Bravo !",
  "Super !",
  "Bien joué !",
  "Excellent !"
];

const feedbackIncorrect = [
  "Pas exactement.",
  "Oups !",
  "La prochaine fois !"
];

const feedbackNeutre = [
  "Continue !"
];

// ============================================================
// 🎯 CHOIX DU FEEDBACK
// ============================================================
let liste;
switch (resultat) {
  case "1":
    liste = feedbackCorrect;
    break;
  case "0":
    liste = feedbackIncorrect;
    break;
  default:
    liste = feedbackNeutre;
    break;
}

// Sélection aléatoire dans la liste
const feedback = liste[Math.floor(Math.random() * liste.length)];

// ============================================================
// 🧾 MISE À JOUR STORYLINE
// ============================================================
setVar("Ex_Feedback_Motivation", feedback);

}

window.Script282 = function()
{
  // ============================================================
// 🔁 SCRIPT — ALLER AU PROCHAIN EXERCICE ÉCHOUÉ ("Réviser les erreurs")
// ============================================================

// -------- VARIABLES DE CONTEXTE --------
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;
const exCurrent = parseInt(getVar(`${seqKey}_Exo_Current`), 10);
const historique = getVar(`${seqKey}_Win_Lose`) || "";

// -------- SÉCURITÉ --------
if (!seqPos || !historique) {
  console.warn("⚠️ Impossible d'exécuter le script — séquence ou historique manquant.");
  return;
}

// ============================================================
// 🔍 RECHERCHE DU PROCHAIN ÉCHEC ("0")
// ============================================================

// On cherche le prochain "0" APRÈS la position actuelle
const nextFailIndex = historique.indexOf("0", exCurrent);

// ============================================================
// 🎯 MISE À JOUR OU FIN DE LA RÉVISION
// ============================================================

if (nextFailIndex === -1) {
  // Aucun autre exercice échoué trouvé → fin du mode révision
  setVar("S0_Revision_Erreurs", 2);

} else {
  // Prochain exercice échoué trouvé
  const nextExercise = nextFailIndex + 1; // index → position 1-based
  setVar("0_Position_Exercice", nextExercise);
}
}

window.Script283 = function()
{
  // ============================================================
// 🎯 ANIMATION DE JAUGE — Rotation + Oscillation continue + Feedback motivationnel + Indicateur visuel
// ============================================================

// -------- OBJETS STORYLINE --------
const pointer = object('5fZOHpnMbya');
const gauge = object('6nKxLAItMtB');

// -------- PARAMÈTRES --------
const minAngle = 0;
const maxAngle = 180;
const oscillationRange = 10;
const oscillationSpeed = 1.5;

// ============================================================
// 🧮 DETECTION DU RESULTAT + RECUPERATION VARIABLES STORYLINE
// ============================================================
let resultat = getVar("Ex_Success");
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;
const exCurrent = getVar(`${seqKey}_Exo_Current`);

// Si il n'y a pas de résultat direct, on tente de le retrouver dans Sx_Win_Lose
if (resultat === "") {
  const historique = getVar(`${seqKey}_Win_Lose`);
  const charAtIndex = historique.charAt(exCurrent - 1);
  if (charAtIndex === "1" || charAtIndex === "0") {
    resultat = charAtIndex;
  } else {
    console.log(`ℹ️ Aucun résultat valide trouvé dans ${seqKey}_Win_Lose à l’index ${exCurrent - 1}`);
    resultat = "";
  }
}

// ============================================================
// ⚙️ Changement couleur jauge
// ============================================================
if (resultat === "1") {
  gauge.state = "Correct" ;
} else if (resultat === "0") {
  gauge.state = "Incorrect" ;
}

// ============================================================
// ⚙️ CALCULS D’ANGLES
// ============================================================
const baseAngle = resultat * (maxAngle - minAngle) + minAngle;
const angleMin = baseAngle - oscillationRange;
const angleMax = baseAngle + oscillationRange;


const goingUp = resultat === "1";
const targetAngle = goingUp ? angleMax : angleMin;

// ============================================================
// 🧹 ARRÊTE LES ANIMATIONS EXISTANTES
// ============================================================
gsap.killTweensOf(pointer);

// ============================================================
// 🚀 ANIMATION DE L’AIGUILLE
// ============================================================
gsap.to(pointer, {
  rotation: targetAngle,
  duration: 1.2,
  ease: "power2.inOut",
  onComplete: () => {
    gsap.to(pointer, {
      rotation: goingUp ? angleMin : angleMax,
      duration: oscillationSpeed,
      ease: "sine.inOut",
      yoyo: true,
      repeat: -1
    });
  }
});

}

window.Script284 = function()
{
  const Btn_Affichage  = document.querySelector('[data-model-id="6geks01QgvK"]');
const temoin = object('6XIh2Zufqbt');

// (Optionnel mais recommandé) point d’ancrage de la rotation
Btn_Affichage.style.transformOrigin = "50% 50%";

// On lit l’état actuel puis on bascule
const isAffiche = (temoin.state === "Feedback_Affiche");

temoin.state = isAffiche ? "Feedback_Cache" : "Feedback_Affiche";

// Rotation GSAP (durée + easing ajustables)
gsap.to(Btn_Affichage, {
  rotation: isAffiche ? 180 : 0,
  duration: 0.45,
  ease: "power2.inOut",
  overwrite: "auto"
});

}

window.Script285 = function()
{
  // ============================================================
// 💬 FEEDBACK MOTIVATIONNEL — AVEC SUPPORT DU FORMAT "1101nn"
// ============================================================

// -------- VARIABLES DE BASE --------
let resultat = getVar("Ex_Success");
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;
const exCurrent = parseInt(getVar(`${seqKey}_Exo_Current`), 10);

// ============================================================
// 🔍 SI RESULTAT VIDE → CHERCHE DANS S1_Win_Lose ("1101nn")
// ============================================================
if (!resultat || resultat === "") {
  const historique = getVar(`${seqKey}_Win_Lose`) || "";
  const charAtIndex = historique.charAt(exCurrent - 1);

  if (charAtIndex === "1" || charAtIndex === "0") {
    resultat = charAtIndex;
  } else {
    console.log(`ℹ️ Aucun résultat valide trouvé dans ${seqKey}_Win_Lose à l’index ${exCurrent - 1}`);
  }
}

// ============================================================
// 💬 LISTES DE FEEDBACKS
// ============================================================
//const feedbackCorrect = [
//  "Bravo !",
//  "Super !",
//  "Bien joué !",
//  "Excellent !"
//];

//const feedbackIncorrect = [
//  "Pas exactement.",
//  "Oups !",
//  "La prochaine fois !"
//];

const feedbackCorrect = [
  "Bravo, c'est une bonne réponse !",
  "Super, tu es sur la bonne voie !",
  "Bien joué, tu progresses !",
  "Excellent, continue comme ça !"
];

const feedbackIncorrect = [
  "Ce n'est pas tout à fait ça.",
  "Oups, ce n'est pas la bonne réponse.",
  "Tu y arriveras la prochaine fois !",
  "Pas exactement. Encore un effort !"
];


const feedbackNeutre = [
  "Continue !"
];

// ============================================================
// 🎯 CHOIX DU FEEDBACK
// ============================================================
let liste;
switch (resultat) {
  case "1":
    liste = feedbackCorrect;
    break;
  case "0":
    liste = feedbackIncorrect;
    break;
  default:
    liste = feedbackNeutre;
    break;
}

// Sélection aléatoire dans la liste
const feedback = liste[Math.floor(Math.random() * liste.length)];

// ============================================================
// 🧾 MISE À JOUR STORYLINE
// ============================================================
setVar("Ex_Feedback_Motivation", feedback);

}

window.Script286 = function()
{
  // ============================================================
// 🔁 SCRIPT — ALLER AU PROCHAIN EXERCICE ÉCHOUÉ ("Réviser les erreurs")
// ============================================================

// -------- VARIABLES DE CONTEXTE --------
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;
const exCurrent = parseInt(getVar(`${seqKey}_Exo_Current`), 10);
const historique = getVar(`${seqKey}_Win_Lose`) || "";

// -------- SÉCURITÉ --------
if (!seqPos || !historique) {
  console.warn("⚠️ Impossible d'exécuter le script — séquence ou historique manquant.");
  return;
}

// ============================================================
// 🔍 RECHERCHE DU PROCHAIN ÉCHEC ("0")
// ============================================================

// On cherche le prochain "0" APRÈS la position actuelle
const nextFailIndex = historique.indexOf("0", exCurrent);

// ============================================================
// 🎯 MISE À JOUR OU FIN DE LA RÉVISION
// ============================================================

if (nextFailIndex === -1) {
  // Aucun autre exercice échoué trouvé → fin du mode révision
  setVar("S0_Revision_Erreurs", 2);

} else {
  // Prochain exercice échoué trouvé
  const nextExercise = nextFailIndex + 1; // index → position 1-based
  setVar("0_Position_Exercice", nextExercise);
}
}

window.Script287 = function()
{
  // ============================================================
// 🎯 ANIMATION DE JAUGE — Rotation + Oscillation continue + Feedback motivationnel + Indicateur visuel
// ============================================================

// -------- OBJETS STORYLINE --------
const pointer = object('61WVHrM0EGs');
//const gauge = object('5lezhyLYUu5'); Cet objet n'existe pas ?
const gauge = object('6rIRKS6iuFv');


// -------- PARAMÈTRES --------
const minAngle = 0;
const maxAngle = 180;
const oscillationRange = 10;
const oscillationSpeed = 1.5;

// ============================================================
// 🧮 DETECTION DU RESULTAT + RECUPERATION VARIABLES STORYLINE
// ============================================================
let resultat = getVar("Ex_Success");
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;
const exCurrent = getVar(`${seqKey}_Exo_Current`);

// Si il n'y a pas de résultat direct, on tente de le retrouver dans Sx_Win_Lose
if (resultat === "") {
  const historique = getVar(`${seqKey}_Win_Lose`);
  const charAtIndex = historique.charAt(exCurrent - 1);
  if (charAtIndex === "1" || charAtIndex === "0") {
    resultat = charAtIndex;
  } else {
    console.log(`ℹ️ Aucun résultat valide trouvé dans ${seqKey}_Win_Lose à l’index ${exCurrent - 1}`);
    resultat = "";
  }
}

// ============================================================
// ⚙️ Changement couleur jauge
// ============================================================
if (resultat === "1") {
  gauge.state = "Correct" ;
} else if (resultat === "0") {
  gauge.state = "Incorrect" ;
}

// ============================================================
// ⚙️ CALCULS D’ANGLES
// ============================================================
const baseAngle = resultat * (maxAngle - minAngle) + minAngle;
const angleMin = baseAngle - oscillationRange;
const angleMax = baseAngle + oscillationRange;


const goingUp = resultat === "1";
const targetAngle = goingUp ? angleMax : angleMin;

// ============================================================
// 🧹 ARRÊTE LES ANIMATIONS EXISTANTES
// ============================================================
gsap.killTweensOf(pointer);

// ============================================================
// 🚀 ANIMATION DE L’AIGUILLE
// ============================================================
gsap.to(pointer, {
  rotation: targetAngle,
  duration: 1.2,
  ease: "power2.inOut",
  onComplete: () => {
    gsap.to(pointer, {
      rotation: goingUp ? angleMin : angleMax,
      duration: oscillationSpeed,
      ease: "sine.inOut",
      yoyo: true,
      repeat: -1
    });
  }
});

}

window.Script288 = function()
{
  const Btn_Affichage  = document.querySelector('[data-model-id="6RRLU9ixx38"]');
const temoin = object('68ikzB1cq1L');

// (Optionnel mais recommandé) point d’ancrage de la rotation
Btn_Affichage.style.transformOrigin = "50% 50%";

// On lit l’état actuel puis on bascule
const isAffiche = (temoin.state === "Feedback_Affiche");

temoin.state = isAffiche ? "Feedback_Cache" : "Feedback_Affiche";

// Rotation GSAP (durée + easing ajustables)
gsap.to(Btn_Affichage, {
  rotation: isAffiche ? 180 : 0,
  duration: 0.45,
  ease: "power2.inOut",
  overwrite: "auto"
});

}

window.Script289 = function()
{
  // Récupère le résultat
let resultat = getVar("Ex_Success");

// Définit les listes de feedback
const feedbackCorrect = [
  "Bravo !",
  "Super !",
  "Bien joué !",
  "Excellent !"
];

const feedbackIncorrect = [
  "Pas exactement",
  "Oups !",
  "La prochaine fois !"
];

// Choisit la liste en fonction du résultat
let liste = (resultat === "1") ? feedbackCorrect : feedbackIncorrect;

// Sélectionne un élément aléatoire dans la liste
let feedback = liste[Math.floor(Math.random() * liste.length)];

// Met à jour la variable Storyline
setVar("Ex_Feedback_Motivation", feedback);

}

window.Script290 = function()
{
  // ============================================================
// 🎯 ANIMATION DE JAUGE — Rotation + Oscillation continue + Feedback motivationnel + Indicateur visuel
// ============================================================

// -------- OBJETS STORYLINE --------
const pointer = object('5Ux37gXcJcw');
const gauge = object('5enGetq7POY');

// -------- PARAMÈTRES --------
const minAngle = 0;
const maxAngle = 180;
const oscillationRange = 10;
const oscillationSpeed = 1.5;

// ============================================================
// 🧮 DETECTION DU RESULTAT + RECUPERATION VARIABLES STORYLINE
// ============================================================
let resultat = getVar("Ex_Success");
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;
const exCurrent = getVar(`${seqKey}_Exo_Current`);

// Si il n'y a pas de résultat direct, on tente de le retrouver dans Sx_Win_Lose
if (resultat === "") {
  const historique = getVar(`${seqKey}_Win_Lose`);
  const charAtIndex = historique.charAt(exCurrent - 1);
  if (charAtIndex === "1" || charAtIndex === "0") {
    resultat = charAtIndex;
  } else {
    console.log(`ℹ️ Aucun résultat valide trouvé dans ${seqKey}_Win_Lose à l’index ${exCurrent - 1}`);
    resultat = "";
  }
}

// ============================================================
// ⚙️ Changement couleur jauge
// ============================================================
if (resultat === "1") {
  gauge.state = "Correct" ;
} else if (resultat === "0") {
  gauge.state = "Incorrect" ;
}

// ============================================================
// ⚙️ CALCULS D’ANGLES
// ============================================================
const baseAngle = resultat * (maxAngle - minAngle) + minAngle;
const angleMin = baseAngle - oscillationRange;
const angleMax = baseAngle + oscillationRange;


const goingUp = resultat === "1";
const targetAngle = goingUp ? angleMax : angleMin;

// ============================================================
// 🧹 ARRÊTE LES ANIMATIONS EXISTANTES
// ============================================================
gsap.killTweensOf(pointer);

// ============================================================
// 🚀 ANIMATION DE L’AIGUILLE
// ============================================================
gsap.to(pointer, {
  rotation: targetAngle,
  duration: 1.2,
  ease: "power2.inOut",
  onComplete: () => {
    gsap.to(pointer, {
      rotation: goingUp ? angleMin : angleMax,
      duration: oscillationSpeed,
      ease: "sine.inOut",
      yoyo: true,
      repeat: -1
    });
  }
});

}

window.Script291 = function()
{
  // ============================================================
// 🔁 SCRIPT — ALLER AU PROCHAIN EXERCICE ÉCHOUÉ ("Réviser les erreurs")
// ============================================================

// -------- VARIABLES DE CONTEXTE --------
const seqPos = getVar("0_Position_Sequence"); // ex: "1", "2", "3", "4"
const seqKey = `S${seqPos}`;                  // ex: "S1"
const exCurrent = parseInt(getVar(`${seqKey}_Exo_Current`) || 0, 10); // ex: 3
const historique = getVar(`${seqKey}_Win_Lose`) || ""; // ex: "110010"

// -------- SÉCURITÉ --------
if (!seqPos || !historique) {
  console.warn("⚠️ Impossible d'exécuter le script — séquence ou historique manquant.");
  return;
}

// ============================================================
// 🔍 RECHERCHE DU PROCHAIN ÉCHEC ("0")
// ============================================================

// On cherche le prochain "0" APRÈS la position actuelle
const nextFailIndex = historique.indexOf("0", exCurrent);

// ============================================================
// 🎯 MISE À JOUR OU FIN DE LA RÉVISION
// ============================================================

if (nextFailIndex === -1) {
  // Aucun autre exercice échoué trouvé → fin du mode révision
  setVar("S0_Revision_Erreurs", 2);
  console.log("🎉 Tous les exercices échoués ont été revus — fin du mode révision (S0_Revision_Erreurs = 2).");
} else {
  // Prochain exercice échoué trouvé
  const nextExercise = nextFailIndex + 1; // index → position 1-based
  setVar("0_Position_Exercice", nextExercise);
  console.log(`🔁 Révision → Prochain exercice échoué : EX${nextExercise}`);
}

console.log(`(Séquence : ${seqKey}, Historique : "${historique}")`);

}

window.Script292 = function()
{
  // ============================================================
// 🎬 REMPLACEMENT DYNAMIQUE DE VIDÉO (version simplifiée)
// ============================================================
// Remplace directement la vidéo de l'objet Storyline (ID fixe)
// avec le chemin complet contenu dans la variable "Ex_Video".
// ============================================================

// -------- Lecture de la variable --------
const newVideoPath = getVar("Ex_Video"); // ex: "Ressources_Sequences/S1/Videos/S1_EX1.mp4"

// -------- Sécurité --------
if (!newVideoPath || newVideoPath.trim() === "") {
  console.warn("⚠️ Aucune vidéo spécifiée dans Ex_Video — remplacement annulé.");
  return;
}

// -------- Sélection directe de la vidéo --------
const videoElement = document.querySelector('[data-model-id="5pTX8N7gCDH"] video');
if (!videoElement) {
  console.error("❌ Impossible de trouver la vidéo avec data-model-id=5pTX8N7gCDH.");
  return;
}

// -------- Remplacement de la source --------
videoElement.setAttribute("xlink:href", newVideoPath);
videoElement.src = newVideoPath;
videoElement.load();

// -------- Suppression de la vignette (poster) --------
const container = videoElement.closest('[data-model-id="5pTX8N7gCDH"]');
if (container) {
  const poster = container.querySelector("img.video-player-poster");
  if (poster) {
    poster.remove();
    console.log("✅ Vignette (poster) supprimée — la 1ère image de la vidéo sera visible.");
  }
}
}

window.Script293 = function()
{
  // ============================================================
// 🖼️ REMPLACEMENT DYNAMIQUE D’IMAGE (version simplifiée)
// ============================================================
// Remplace directement l’image de l’objet Storyline (ID fixe)
// avec le chemin complet contenu dans la variable "Ex_Image".
// Aucun calcul de dossier ou de chemin n’est effectué.
// ============================================================

// -------- Lecture de la variable --------
const newImagePath = getVar("Ex_Image"); // ex: "Ressources_Sequences/S1/images/EX1.jpg"

// -------- Sécurité --------
if (!newImagePath || newImagePath.trim() === "") {
  console.warn("⚠️ Aucune image spécifiée dans Ex_Image — remplacement annulé.");
  return;
}

// -------- Sélection directe de l’image --------
const imageElement = document.querySelector('[data-model-id="6jUy2ox5l86"] image');
if (!imageElement) {
  console.error("❌ Impossible de trouver l’image avec data-model-id=6jUy2ox5l86.");
  return;
}

// -------- Remplacement du lien --------
imageElement.setAttributeNS("http://www.w3.org/1999/xlink", "xlink:href", newImagePath);

}

window.Script294 = function()
{
  // ============================================================
// 🖼️ REMPLACEMENT DYNAMIQUE D’IMAGE (version simplifiée)
// ============================================================
// Remplace directement l’image de l’objet Storyline (ID fixe)
// avec le chemin complet contenu dans la variable "Ex_Image".
// Aucun calcul de dossier ou de chemin n’est effectué.
// ============================================================

// -------- Lecture de la variable --------
const newImagePath = getVar("Ex_Image"); // ex: "Ressources_Sequences/S1/images/EX1.jpg"

// -------- Sécurité --------
if (!newImagePath || newImagePath.trim() === "") {
  console.warn("⚠️ Aucune image spécifiée dans Ex_Image — remplacement annulé.");
  return;
}

// -------- Sélection directe de l’image --------
const imageElement = document.querySelector('[data-model-id="6c22D92goAT"] image');
if (!imageElement) {
  console.error("❌ Impossible de trouver l’image avec data-model-id=6c22D92goAT.");
  return;
}

// -------- Remplacement du lien --------
imageElement.setAttributeNS("http://www.w3.org/1999/xlink", "xlink:href", newImagePath);

}

window.Script295 = function()
{
  // ============================================================
// ⚙️ BARRE DE PROGRESSION — SYNCHRONISATION AVEC LA SÉQUENCE EN COURS
// ============================================================

// --------- Lecture de la séquence courante ---------
const seqPos = getVar("0_Position_Sequence");   // ex. 1 → S1
const seqKey = `S${seqPos}`;

// --------- Lecture des variables de la séquence correspondante ---------
const Exo_Reached = getVar("S0_Exo_Reached") || 0;
const Exo_Total = getVar("S0_Exo_Total") || 1;

// --------- Calcul du pourcentage ---------
const progress = Math.min(Exo_Reached / Exo_Total, 1); // clamp entre 0 et 1

// --------- Sélectionne l'objet Storyline ---------
const ProgressBar = document.querySelector(`[data-model-id="6f561U28wA4"]`);

if (ProgressBar) {
  // --------- Sélectionne l'élément graphique principal ---------
  const shape = ProgressBar.querySelector("path");

  if (shape) {
    // Si ce n’est pas déjà fait, on garde la largeur d’origine
    if (!shape.dataset.fullWidth) {
      const bbox = shape.getBBox();
      shape.dataset.fullWidth = bbox.width;
    }

    // --------- Calcul de la largeur selon la progression ---------
    const fullWidth = parseFloat(shape.dataset.fullWidth);

    // --------- Application du remplissage via clip-path ---------
    shape.style.clipPath = `inset(0 ${100 - progress * 100}% 0 0 round 0px)`;
  }
}

}

window.Script296 = function()
{
  // ============================================================
// ⚙️ BARRE DE PROGRESSION ANIMÉE (AVEC INITIALISATION INTELLIGENTE)
// ============================================================

// Durée de l’animation en millisecondes (modifiable)
const animationDuration = 800; // 0.8s = fluide, 300 = rapide, 1500 = lente

function updateProgressBarAnimated() {
  // --------- Lecture de la séquence courante ---------
  const seqPos = getVar("0_Position_Sequence");
  const seqKey = `S${seqPos}`;

  // --------- Lecture des variables globales S0 ---------
  const Exo_Reached = getVar("S0_Exo_Reached") || 0;
  const Exo_Total = getVar("S0_Exo_Total") || 1;
  const progress = Math.min(Exo_Reached / Exo_Total, 1);

  // --------- Sélectionne l'objet Storyline ---------
  const ProgressBar = document.querySelector(`[data-model-id="6f561U28wA4"]`);
  if (!ProgressBar) return;

  const shape = ProgressBar.querySelector("path");
  if (!shape) return;

  // --------- Initialisation si nécessaire ---------
  if (!shape.dataset.fullWidth) {
    const bbox = shape.getBBox();
    shape.dataset.fullWidth = bbox.width;
  }

  // --------- Nouvelle logique : position initiale intelligente ---------
  let startProgress;

  if (shape.dataset.currentProgress !== undefined) {
    // On continue à partir de la progression actuelle
    startProgress = parseFloat(shape.dataset.currentProgress) || 0;
  } else if (Exo_Reached >= 1) {
    // Si aucune donnée mais au moins un exercice complété,
    // on démarre au niveau précédent
    startProgress = (Exo_Reached - 1) / Exo_Total;
  } else {
    // Sinon, tout au début
    startProgress = 0;
  }

  const startTime = performance.now();

  // --------- Fonction d'animation fluide ---------
  function animate(time) {
    const elapsed = time - startTime;
    const t = Math.min(elapsed / animationDuration, 1);
    const eased = t < 0.5 ? 2 * t * t : -1 + (4 - 2 * t) * t; // easeInOutQuad

    const currentProgress = startProgress + (progress - startProgress) * eased;
    shape.style.clipPath = `inset(0 ${100 - currentProgress * 100}% 0 0 round 0px)`;
    shape.dataset.currentProgress = currentProgress;

    if (t < 1) requestAnimationFrame(animate);
  }

  requestAnimationFrame(animate);
}

// ============================================================
// ▶️ APPEL DU SCRIPT (exécuté manuellement via trigger JS)
// ============================================================

updateProgressBarAnimated();

}

window.Script297 = function()
{
  // -------- Initialisation --------

// Récupère le numéro ou identifiant d'exercice (ex: "EX2")
const AudioPath = getVar("0_Audio_Lecteur");

// Si un audio était déjà en cours → on le stoppe et on remet au début
if (window.audioUnique) {
  window.audioUnique.pause();
  window.audioUnique.currentTime = 0;
}

// Crée un nouvel objet audio
window.audioUnique = new Audio(AudioPath);

// Lecture
window.audioUnique.play().catch(err => {
  console.log("Erreur lecture Back :", err);
});
}

window.Script298 = function()
{
  // ============================================================
// 🎯 MISE À JOUR DES VARIABLES Sx_Win_Lose SELON Ex_Success (texte)
// ============================================================

// -------- Lecture des variables Storyline --------
const seqPos  = getVar("0_Position_Sequence");
const exPos   = getVar("0_Position_Exercice");
const success = getVar("Ex_Success");

// -------- Construction du nom de la séquence --------
const seqKey     = `S${seqPos}`;
const winLoseVar = `${seqKey}_Win_Lose`;

// -------- Lecture actuelle de la variable Win_Lose --------
let winLose = getVar(winLoseVar) || "";

// -------- S’assure que la longueur correspond au nombre total d’exercices --------
const total = getVar(`0_Menu_${seqKey}_Exo_Total`);

// -------- Conversion en tableau pour modification --------
const chars = winLose.split("");

// -------- Mise à jour du caractère correspondant à l’exercice actuel --------
if (!(chars[exPos - 1] === "1" && success === "0")) {
    chars[exPos - 1] = success === "1" ? "1" : "0";
}
// Si l'exercice est déjà réussi, on garde la réussite.

// -------- Conversion inverse en chaîne --------
winLose = chars.join("");

// -------- Écriture dans Storyline --------
setVar(winLoseVar, winLose);

// ============================================================
// 🔁 SWITCH AUTOMATIQUE DE 0_Feedback_Switch
// ============================================================
let feedbackSwitch = getVar("0_Feedback_Switch");
feedbackSwitch = feedbackSwitch === true || feedbackSwitch === "true" ? false : true;
setVar("0_Feedback_Switch", feedbackSwitch);

}

window.Script299 = function()
{
  // ============================================================
// 🏁 SCRIPT DE FIN D’EXERCICE — MISE À JOUR PROGRESSION & TENTATIVES
// ============================================================

// -------- CONFIGURATION --------
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;

const exCurrent  = parseInt(getVar(`${seqKey}_Exo_Current`), 10);
const exReached  = parseInt(getVar(`${seqKey}_Exo_Reached`), 10);
const tentVar    = `${seqKey}_Exo_Current_Tentatives`;
// ============================================================
// 🧭 MISE À JOUR DE LA PROGRESSION
// ============================================================

// Si on avance (évite de revenir en arrière)
if (exCurrent > exReached) {
  setVar(`${seqKey}_Exo_Reached`, exCurrent);
  setVar("S0_Exo_Reached", exCurrent); 
}

// ============================================================
// 🧮 MARQUAGE DE L’EXERCICE TERMINÉ
// ============================================================

setVar(tentVar, -10);

}

window.Script300 = function()
{
  // ============================================================
// 🧠 SAUVEGARDE AUTOMATIQUE DES DONNÉES UTILISATEUR (GLOBAL)
// ============================================================
//
// 🔹 Ce script est appelé automatiquement après la validation d’un exercice.
// 🔹 Il détecte le type d’exercice et sauvegarde la réponse dans la variable JSON
//    correspondante (ex: S1_UserData)
//
// ============================================================

// ------------------------------------------------------------
// 🔧 Lecture des infos de contexte
// ------------------------------------------------------------
const seqPos = getVar("0_Position_Sequence");           // ex: "1"
const exPos = parseInt(getVar("0_Position_Exercice"), 10);
const seqKey = `S${seqPos}`;
const exType = getVar("Ex_Type");
const success = getVar("Ex_Success");
const tentativesRestantes = parseInt(getVar("Ex_Tentatives"), 10);

// Variable cible (ex: "S1_UserData")
const userDataVar = `${seqKey}_UserData`;

// ------------------------------------------------------------
// 🔧 Lecture du JSON existant
// ------------------------------------------------------------
let data = {};
try {
  const existing = getVar(userDataVar);
  data = existing ? JSON.parse(existing) : {};
} catch (err) {
  console.warn(`⚠️ JSON invalide dans ${userDataVar}, réinitialisation.`, err);
  data = {};
}

// ------------------------------------------------------------
// 🧮 Tentatives initiales (si dispo dans cache global)
// ------------------------------------------------------------
let tentativesInitiales = 0;
try {
  const exData = window.sequenceCache?.[seqKey]?.[`EX${exPos}`];
  tentativesInitiales = exData?.Tentatives || 1;
} catch {
  tentativesInitiales = 1;
}

const tentativesUtilisees = Math.max(0, tentativesInitiales - tentativesRestantes);

// ------------------------------------------------------------
// 🎯 Récupération de la réponse selon le type d’exercice
// ------------------------------------------------------------
let userResponseObj = {};

switch (exType) {
  // 🔹 QCU
  case "QCU": {
    const answerKey = getVar("0_Reponse");
    const answerText = getVar(`0_Choix_${answerKey}`) || "";
    userResponseObj = { [answerKey]: answerText };
    break;
  }

  // 🔹 QCM
  case "QCM": {
    const responseRaw = (getVar("0_Reponse") || "").split("|").filter(Boolean);
    responseRaw.forEach(k => {
      userResponseObj[k] = getVar(`0_Choix_${k}`) || "";
    });
    break;
  }

  // 🔹 True or false
  case "True or false": {
    const answer = (getVar("0_Reponse") || "").toLowerCase();
    userResponseObj = { unique: answer };
    break;
  }

  // 🔹 Complete
  case "Complete": {
    const answer = getVar("0_Ex_Enonce") || "";
    userResponseObj = { unique: answer };
    break;
  }

  // 🔹 Matching
  case "Matching": {
    const reponse = getVar("0_Reponse") || "";
    userResponseObj = { associations: reponse };
    break;
  }

  // 🔹 Flashcard
  case "Flashcard": {
    const answer = getVar("0_Reponse") || "";
    userResponseObj = { unique: answer };
    break;
  }

  // 🔹 Information
  case "Information": {
    userResponseObj = { info: "Aucune interaction" };
    break;
  }

  // 🔹 Production orale - dictée
  case "Production orale - dictée": {
    const raw = getVar("0_Reponse") || "{}";
    try {
      const parsed = JSON.parse(raw);
      userResponseObj = {
        score: parsed.score || 0,
        texte_brut: parsed.texte_brut || "",
        texte_color: parsed.texte_color || ""
      };
    } catch (err) {
      console.warn("⚠️ Erreur de parsing JSON pour Production orale :", err);
      userResponseObj = { erreur: "Format de réponse invalide", raw };
    }
    break;
  }

  // 🔹 Défaut
  default: {
    const raw = getVar("0_Reponse") || "";
    userResponseObj = { inconnu: raw };
    console.warn(`❓ Type d’exercice inconnu : ${exType}`);
    break;
  }
}

// ------------------------------------------------------------
// 💾 Enregistrement dans le JSON
// ------------------------------------------------------------
data[`EX${exPos}`] = {
  Type: exType,
  Reponses_Choisies: userResponseObj,
  Statut: success,
  Tentatives_Utilisees: tentativesUtilisees
};

setVar(userDataVar, JSON.stringify(data));

// ------------------------------------------------------------
// 🧾 Log de contrôle
// ------------------------------------------------------------
console.group(`💾 Données sauvegardées → ${userDataVar}`);
console.log("Exercice :", `EX${exPos}`);
console.log("Type :", exType);
console.log("Réponses :", userResponseObj);
console.log("Statut :", success);
console.log("Tentatives utilisées :", tentativesUtilisees);
console.log("JSON complet :", data);
console.groupEnd();

}

window.Script301 = function()
{
  // ============================================================
// 🎯 VÉRIFICATION DE LA RÉPONSE (Flashcard)
// ============================================================

// --------- Lecture des variables Storyline ---------
const userAnswer = (getVar("0_Reponse") || "");

// --------- Comparaison logique ---------
let success = "0"; // Par défaut = échec

if (userAnswer === "OK") {
  success = "1";
}

// --------- Écriture dans Storyline ---------
setVar("Ex_Success", success);
}

window.Script302 = function()
{
  // -------- 5. Initialisation des cartes --------
var FrontCard = document.querySelector('[data-model-id="6BkoMqUXE3M"]');
var BackCard  = document.querySelector('[data-model-id="5iv4QdEL0t7"]');

// Réinitialise l’état
setVar("0_Flashcard_FlipState", "");

// Positionne directement les cartes (sans animation)
gsap.set(FrontCard, { rotateY: 0 });
gsap.set(BackCard, { rotateY: -90 });

// Mets à jour la variable Storyline
setVar("0_Flashcard_FlipState", "FrontVisible");
}

window.Script303 = function()
{
  // ============================================================
// 🎯 FLASHCARDS — ROTATION CENTRÉE SUR UN OBJET DE RÉFÉRENCE
// ============================================================

// -------- Sélection des objets Storyline --------
var FrontCard  = document.querySelector('[data-model-id="6BkoMqUXE3M"]');
var BackCard   = document.querySelector('[data-model-id="5iv4QdEL0t7"]');
var Container  = document.querySelector('[data-model-id="6WLodmlDOa8"]'); // repère central

if (!FrontCard || !BackCard || !Container) {
  console.warn("⚠️ Impossible de trouver un des éléments Flashcard.");
} else {

  // ============================================================
  // 🧭 Fonction : Recentrer les cartes sur le conteneur
  // ============================================================
  function recenterFlashcards() {
    const containerRect = Container.getBoundingClientRect();
    const centerX = containerRect.left + containerRect.width / 2;
    const centerY = containerRect.top + containerRect.height / 2;

    [FrontCard, BackCard].forEach(card => {
      const cardRect = card.getBoundingClientRect();
      const offsetX = centerX - (cardRect.left + cardRect.width / 2);
      const offsetY = centerY - (cardRect.top + cardRect.height / 2);

      // Ajuste la position et définit le pivot au centre
      gsap.set(card, {
        x: "+=" + offsetX,
        y: "+=" + offsetY,
        transformOrigin: "center center",
        transformStyle: "preserve-3d"
      });
    });
  }

  // ============================================================
  // 📏 Recentrage initial et sur redimensionnement
  // ============================================================
  recenterFlashcards();
  window.addEventListener("resize", recenterFlashcards);

  // ============================================================
  // 🔄 Gestion du flip (Front ↔ Back)
  // ============================================================
  var rotation = getVar("0_Flashcard_Rotation");

  if (rotation === "FrontToBack") {
    setVar("0_Flashcard_FlipState", "");
    let tl = gsap.timeline();

    // Position de départ
    tl.set(BackCard, { rotateY: -90 });
    recenterFlashcards(); // 🔹 recentrage avant rotation

    // Animation du flip
    tl.to(FrontCard, { rotateY: -90, duration: 0.5 });
    tl.to(BackCard, { rotateY: 0, duration: 0.5, onComplete: () => {
      setVar("0_Flashcard_FlipState", "BackVisible");
    }});

  } else if (rotation === "BackToFront") {
    setVar("0_Flashcard_FlipState", "");
    let tl = gsap.timeline();

    // Position de départ
    tl.set(FrontCard, { rotateY: -90 });
    recenterFlashcards(); // 🔹 recentrage avant rotation

    // Animation du flip
    tl.to(BackCard, { rotateY: -90, duration: 0.5 });
    tl.to(FrontCard, { rotateY: 0, duration: 0.5, onComplete: () => {
      setVar("0_Flashcard_FlipState", "FrontVisible");
    }});
  }
}

}

window.Script304 = function()
{
  // ============================================================
// 🔁 SCRIPT — ALLER AU PROCHAIN EXERCICE ÉCHOUÉ ("Réviser les erreurs")
// ============================================================

// -------- VARIABLES DE CONTEXTE --------
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;
const exCurrent = parseInt(getVar(`${seqKey}_Exo_Current`), 10);
const historique = getVar(`${seqKey}_Win_Lose`) || "";

// -------- SÉCURITÉ --------
if (!seqPos || !historique) {
  console.warn("⚠️ Impossible d'exécuter le script — séquence ou historique manquant.");
  return;
}

// ============================================================
// 🔍 RECHERCHE DU PROCHAIN ÉCHEC ("0")
// ============================================================

// On cherche le prochain "0" APRÈS la position actuelle
const nextFailIndex = historique.indexOf("0", exCurrent);

// ============================================================
// 🎯 MISE À JOUR OU FIN DE LA RÉVISION
// ============================================================

if (nextFailIndex === -1) {
  // Aucun autre exercice échoué trouvé → fin du mode révision
  setVar("S0_Revision_Erreurs", 2);

} else {
  // Prochain exercice échoué trouvé
  const nextExercise = nextFailIndex + 1; // index → position 1-based
  setVar("0_Position_Exercice", nextExercise);
}
}

window.Script305 = function()
{
  //DESCRIPTION : 
//	Si Ex_Flashcard_Extra_Type est null alors on positionne 
//		le bouton "je révise" sur POS_ReviseNoExtra (à gauche)
//		le bouton "je maitrise" sur POS_MaitriseNoExtra (à droite)

const BTN_Maitrise = object('6AXfsgOJJsJ');
const BTN_Revise = object('61COMqOTCSy');
const POS_Maitrise_NoExtra = object('5WJYuuDNL84');
const POS_Revise_NoExtra = object('6dAeBysfNI7');

BTN_Maitrise.x = POS_Maitrise_NoExtra.x ;
BTN_Revise.x = POS_Revise_NoExtra.x ;
}

window.Script306 = function()
{
  //DESCRIPTION : 
//	Si on revient en arrière, les boutons de réponse sont absents donc
//	on centre le bouton des extras


const BTN_Complementaire = object('6S5JTly5yOa');
const POS_Extra = object('5mYDNrMV8c3');

BTN_Complementaire.x = POS_Extra.x
}

window.Script307 = function()
{
  // Récupère les objets Storyline
const carte  = document.querySelector('[data-model-id="6WOyyFcuLyH"]');
const bouton = document.querySelector('[data-model-id="5rCsry3VrNh"]');

// Points d'ancrage
carte.style.transformOrigin = "top left";
bouton.style.transformOrigin = "center";

// Timeline pour synchroniser
const tl = gsap.timeline();

tl.to(carte, {
  scale: 0,
  opacity: 0,
  duration: 0.5,
  ease: "power1.inOut"
}, 0);

// Rotation 90° du bouton en même temps
tl.to(bouton, {
  rotate: 0,          // ou "+=90" si tu veux ajouter 90° à chaque fois
  duration: 0.5,
  ease: "power1.inOut"
}, 0);

}

window.Script308 = function()
{
  // Récupère les objets Storyline
const carte  = document.querySelector('[data-model-id="6WOyyFcuLyH"]');
const bouton = document.querySelector('[data-model-id="5rCsry3VrNh"]');

// Points d'ancrage
carte.style.transformOrigin = "top left";
bouton.style.transformOrigin = "center";

// États initiaux
gsap.set(carte,  { scale: 0, opacity: 0 });
gsap.set(bouton, { rotate: 0 }); // ou 90 si tu veux qu'il démarre déjà tourné

// Timeline pour synchroniser
const tl = gsap.timeline();

tl.to(carte, {
  scale: 1,
  opacity: 1,
  duration: 0.5,
  ease: "power1.inOut"
}, 0);

// Rotation 90° du bouton en même temps
tl.to(bouton, {
  rotate: 45,          // ou "+=90" si tu veux ajouter 90° à chaque fois
  duration: 0.5,
  ease: "power1.inOut"
}, 0);

}

window.Script309 = function()
{
  // ============================================================
// 💬 FEEDBACK MOTIVATIONNEL — AVEC SUPPORT DU FORMAT "1101nn"
// ============================================================

// -------- VARIABLES DE BASE --------
let resultat = getVar("Ex_Success");
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;
const exCurrent = parseInt(getVar(`${seqKey}_Exo_Current`), 10);

// ============================================================
// 🔍 SI RESULTAT VIDE → CHERCHE DANS S1_Win_Lose ("1101nn")
// ============================================================
if (!resultat || resultat === "") {
  const historique = getVar(`${seqKey}_Win_Lose`) || "";
  const charAtIndex = historique.charAt(exCurrent - 1);

  if (charAtIndex === "1" || charAtIndex === "0") {
    resultat = charAtIndex;
  } else {
    console.log(`ℹ️ Aucun résultat valide trouvé dans ${seqKey}_Win_Lose à l’index ${exCurrent - 1}`);
  }
}

// ============================================================
// 💬 LISTES DE FEEDBACKS
// ============================================================
const feedbackCorrect = [
  "Bravo !",
  "Super !",
  "Bien joué !",
  "Excellent !"
];

const feedbackIncorrect = [
  "Pas exactement.",
  "Oups !",
  "La prochaine fois !"
];

const feedbackNeutre = [
  "Continue !"
];

// ============================================================
// 🎯 CHOIX DU FEEDBACK
// ============================================================
let liste;
switch (resultat) {
  case "1":
    liste = feedbackCorrect;
    break;
  case "0":
    liste = feedbackIncorrect;
    break;
  default:
    liste = feedbackNeutre;
    break;
}

// Sélection aléatoire dans la liste
const feedback = liste[Math.floor(Math.random() * liste.length)];

// ============================================================
// 🧾 MISE À JOUR STORYLINE
// ============================================================
setVar("Ex_Feedback_Motivation", feedback);

}

window.Script310 = function()
{
  // ============================================================
// 🔁 SCRIPT — ALLER AU PROCHAIN EXERCICE ÉCHOUÉ ("Réviser les erreurs")
// ============================================================

// -------- VARIABLES DE CONTEXTE --------
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;
const exCurrent = parseInt(getVar(`${seqKey}_Exo_Current`), 10);
const historique = getVar(`${seqKey}_Win_Lose`) || "";

// -------- SÉCURITÉ --------
if (!seqPos || !historique) {
  console.warn("⚠️ Impossible d'exécuter le script — séquence ou historique manquant.");
  return;
}

// ============================================================
// 🔍 RECHERCHE DU PROCHAIN ÉCHEC ("0")
// ============================================================

// On cherche le prochain "0" APRÈS la position actuelle
const nextFailIndex = historique.indexOf("0", exCurrent);

// ============================================================
// 🎯 MISE À JOUR OU FIN DE LA RÉVISION
// ============================================================

if (nextFailIndex === -1) {
  // Aucun autre exercice échoué trouvé → fin du mode révision
  setVar("S0_Revision_Erreurs", 2);

} else {
  // Prochain exercice échoué trouvé
  const nextExercise = nextFailIndex + 1; // index → position 1-based
  setVar("0_Position_Exercice", nextExercise);
}
}

window.Script311 = function()
{
  // ============================================================
// 🎯 ANIMATION DE JAUGE — Rotation + Oscillation continue + Feedback motivationnel + Indicateur visuel
// ============================================================

// -------- OBJETS STORYLINE --------
const pointer = object('5fZOHpnMbya');
const gauge = object('6nKxLAItMtB');

// -------- PARAMÈTRES --------
const minAngle = 0;
const maxAngle = 180;
const oscillationRange = 10;
const oscillationSpeed = 1.5;

// ============================================================
// 🧮 DETECTION DU RESULTAT + RECUPERATION VARIABLES STORYLINE
// ============================================================
let resultat = getVar("Ex_Success");
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;
const exCurrent = getVar(`${seqKey}_Exo_Current`);

// Si il n'y a pas de résultat direct, on tente de le retrouver dans Sx_Win_Lose
if (resultat === "") {
  const historique = getVar(`${seqKey}_Win_Lose`);
  const charAtIndex = historique.charAt(exCurrent - 1);
  if (charAtIndex === "1" || charAtIndex === "0") {
    resultat = charAtIndex;
  } else {
    console.log(`ℹ️ Aucun résultat valide trouvé dans ${seqKey}_Win_Lose à l’index ${exCurrent - 1}`);
    resultat = "";
  }
}

// ============================================================
// ⚙️ Changement couleur jauge
// ============================================================
if (resultat === "1") {
  gauge.state = "Correct" ;
} else if (resultat === "0") {
  gauge.state = "Incorrect" ;
}

// ============================================================
// ⚙️ CALCULS D’ANGLES
// ============================================================
const baseAngle = resultat * (maxAngle - minAngle) + minAngle;
const angleMin = baseAngle - oscillationRange;
const angleMax = baseAngle + oscillationRange;


const goingUp = resultat === "1";
const targetAngle = goingUp ? angleMax : angleMin;

// ============================================================
// 🧹 ARRÊTE LES ANIMATIONS EXISTANTES
// ============================================================
gsap.killTweensOf(pointer);

// ============================================================
// 🚀 ANIMATION DE L’AIGUILLE
// ============================================================
gsap.to(pointer, {
  rotation: targetAngle,
  duration: 1.2,
  ease: "power2.inOut",
  onComplete: () => {
    gsap.to(pointer, {
      rotation: goingUp ? angleMin : angleMax,
      duration: oscillationSpeed,
      ease: "sine.inOut",
      yoyo: true,
      repeat: -1
    });
  }
});

}

window.Script312 = function()
{
  const Btn_Affichage  = document.querySelector('[data-model-id="6geks01QgvK"]');
const temoin = object('6XIh2Zufqbt');

// (Optionnel mais recommandé) point d’ancrage de la rotation
Btn_Affichage.style.transformOrigin = "50% 50%";

// On lit l’état actuel puis on bascule
const isAffiche = (temoin.state === "Feedback_Affiche");

temoin.state = isAffiche ? "Feedback_Cache" : "Feedback_Affiche";

// Rotation GSAP (durée + easing ajustables)
gsap.to(Btn_Affichage, {
  rotation: isAffiche ? 180 : 0,
  duration: 0.45,
  ease: "power2.inOut",
  overwrite: "auto"
});

}

window.Script313 = function()
{
  // ============================================================
// 💬 FEEDBACK MOTIVATIONNEL — AVEC SUPPORT DU FORMAT "1101nn"
// ============================================================

// -------- VARIABLES DE BASE --------
let resultat = getVar("Ex_Success");
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;
const exCurrent = parseInt(getVar(`${seqKey}_Exo_Current`), 10);

// ============================================================
// 🔍 SI RESULTAT VIDE → CHERCHE DANS S1_Win_Lose ("1101nn")
// ============================================================
if (!resultat || resultat === "") {
  const historique = getVar(`${seqKey}_Win_Lose`) || "";
  const charAtIndex = historique.charAt(exCurrent - 1);

  if (charAtIndex === "1" || charAtIndex === "0") {
    resultat = charAtIndex;
  } else {
    console.log(`ℹ️ Aucun résultat valide trouvé dans ${seqKey}_Win_Lose à l’index ${exCurrent - 1}`);
  }
}

// ============================================================
// 💬 LISTES DE FEEDBACKS
// ============================================================
//const feedbackCorrect = [
//  "Bravo !",
//  "Super !",
//  "Bien joué !",
//  "Excellent !"
//];

//const feedbackIncorrect = [
//  "Pas exactement.",
//  "Oups !",
//  "La prochaine fois !"
//];

const feedbackCorrect = [
  "Bravo, c'est une bonne réponse !",
  "Super, tu es sur la bonne voie !",
  "Bien joué, tu progresses !",
  "Excellent, continue comme ça !"
];

const feedbackIncorrect = [
  "Ce n'est pas tout à fait ça.",
  "Oups, ce n'est pas la bonne réponse.",
  "Tu y arriveras la prochaine fois !",
  "Pas exactement. Encore un effort !"
];


const feedbackNeutre = [
  "Continue !"
];

// ============================================================
// 🎯 CHOIX DU FEEDBACK
// ============================================================
let liste;
switch (resultat) {
  case "1":
    liste = feedbackCorrect;
    break;
  case "0":
    liste = feedbackIncorrect;
    break;
  default:
    liste = feedbackNeutre;
    break;
}

// Sélection aléatoire dans la liste
const feedback = liste[Math.floor(Math.random() * liste.length)];

// ============================================================
// 🧾 MISE À JOUR STORYLINE
// ============================================================
setVar("Ex_Feedback_Motivation", feedback);

}

window.Script314 = function()
{
  // ============================================================
// 🔁 SCRIPT — ALLER AU PROCHAIN EXERCICE ÉCHOUÉ ("Réviser les erreurs")
// ============================================================

// -------- VARIABLES DE CONTEXTE --------
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;
const exCurrent = parseInt(getVar(`${seqKey}_Exo_Current`), 10);
const historique = getVar(`${seqKey}_Win_Lose`) || "";

// -------- SÉCURITÉ --------
if (!seqPos || !historique) {
  console.warn("⚠️ Impossible d'exécuter le script — séquence ou historique manquant.");
  return;
}

// ============================================================
// 🔍 RECHERCHE DU PROCHAIN ÉCHEC ("0")
// ============================================================

// On cherche le prochain "0" APRÈS la position actuelle
const nextFailIndex = historique.indexOf("0", exCurrent);

// ============================================================
// 🎯 MISE À JOUR OU FIN DE LA RÉVISION
// ============================================================

if (nextFailIndex === -1) {
  // Aucun autre exercice échoué trouvé → fin du mode révision
  setVar("S0_Revision_Erreurs", 2);

} else {
  // Prochain exercice échoué trouvé
  const nextExercise = nextFailIndex + 1; // index → position 1-based
  setVar("0_Position_Exercice", nextExercise);
}
}

window.Script315 = function()
{
  // ============================================================
// 🎯 ANIMATION DE JAUGE — Rotation + Oscillation continue + Feedback motivationnel + Indicateur visuel
// ============================================================

// -------- OBJETS STORYLINE --------
const pointer = object('61WVHrM0EGs');
//const gauge = object('5lezhyLYUu5'); Cet objet n'existe pas ?
const gauge = object('6rIRKS6iuFv');


// -------- PARAMÈTRES --------
const minAngle = 0;
const maxAngle = 180;
const oscillationRange = 10;
const oscillationSpeed = 1.5;

// ============================================================
// 🧮 DETECTION DU RESULTAT + RECUPERATION VARIABLES STORYLINE
// ============================================================
let resultat = getVar("Ex_Success");
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;
const exCurrent = getVar(`${seqKey}_Exo_Current`);

// Si il n'y a pas de résultat direct, on tente de le retrouver dans Sx_Win_Lose
if (resultat === "") {
  const historique = getVar(`${seqKey}_Win_Lose`);
  const charAtIndex = historique.charAt(exCurrent - 1);
  if (charAtIndex === "1" || charAtIndex === "0") {
    resultat = charAtIndex;
  } else {
    console.log(`ℹ️ Aucun résultat valide trouvé dans ${seqKey}_Win_Lose à l’index ${exCurrent - 1}`);
    resultat = "";
  }
}

// ============================================================
// ⚙️ Changement couleur jauge
// ============================================================
if (resultat === "1") {
  gauge.state = "Correct" ;
} else if (resultat === "0") {
  gauge.state = "Incorrect" ;
}

// ============================================================
// ⚙️ CALCULS D’ANGLES
// ============================================================
const baseAngle = resultat * (maxAngle - minAngle) + minAngle;
const angleMin = baseAngle - oscillationRange;
const angleMax = baseAngle + oscillationRange;


const goingUp = resultat === "1";
const targetAngle = goingUp ? angleMax : angleMin;

// ============================================================
// 🧹 ARRÊTE LES ANIMATIONS EXISTANTES
// ============================================================
gsap.killTweensOf(pointer);

// ============================================================
// 🚀 ANIMATION DE L’AIGUILLE
// ============================================================
gsap.to(pointer, {
  rotation: targetAngle,
  duration: 1.2,
  ease: "power2.inOut",
  onComplete: () => {
    gsap.to(pointer, {
      rotation: goingUp ? angleMin : angleMax,
      duration: oscillationSpeed,
      ease: "sine.inOut",
      yoyo: true,
      repeat: -1
    });
  }
});

}

window.Script316 = function()
{
  const Btn_Affichage  = document.querySelector('[data-model-id="6RRLU9ixx38"]');
const temoin = object('68ikzB1cq1L');

// (Optionnel mais recommandé) point d’ancrage de la rotation
Btn_Affichage.style.transformOrigin = "50% 50%";

// On lit l’état actuel puis on bascule
const isAffiche = (temoin.state === "Feedback_Affiche");

temoin.state = isAffiche ? "Feedback_Cache" : "Feedback_Affiche";

// Rotation GSAP (durée + easing ajustables)
gsap.to(Btn_Affichage, {
  rotation: isAffiche ? 180 : 0,
  duration: 0.45,
  ease: "power2.inOut",
  overwrite: "auto"
});

}

window.Script317 = function()
{
  // Récupère le résultat
let resultat = getVar("Ex_Success");

// Définit les listes de feedback
const feedbackCorrect = [
  "Bravo !",
  "Super !",
  "Bien joué !",
  "Excellent !"
];

const feedbackIncorrect = [
  "Pas exactement",
  "Oups !",
  "La prochaine fois !"
];

// Choisit la liste en fonction du résultat
let liste = (resultat === "1") ? feedbackCorrect : feedbackIncorrect;

// Sélectionne un élément aléatoire dans la liste
let feedback = liste[Math.floor(Math.random() * liste.length)];

// Met à jour la variable Storyline
setVar("Ex_Feedback_Motivation", feedback);

}

window.Script318 = function()
{
  // ============================================================
// 🎯 ANIMATION DE JAUGE — Rotation + Oscillation continue + Feedback motivationnel + Indicateur visuel
// ============================================================

// -------- OBJETS STORYLINE --------
const pointer = object('5Ux37gXcJcw');
const gauge = object('5enGetq7POY');

// -------- PARAMÈTRES --------
const minAngle = 0;
const maxAngle = 180;
const oscillationRange = 10;
const oscillationSpeed = 1.5;

// ============================================================
// 🧮 DETECTION DU RESULTAT + RECUPERATION VARIABLES STORYLINE
// ============================================================
let resultat = getVar("Ex_Success");
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;
const exCurrent = getVar(`${seqKey}_Exo_Current`);

// Si il n'y a pas de résultat direct, on tente de le retrouver dans Sx_Win_Lose
if (resultat === "") {
  const historique = getVar(`${seqKey}_Win_Lose`);
  const charAtIndex = historique.charAt(exCurrent - 1);
  if (charAtIndex === "1" || charAtIndex === "0") {
    resultat = charAtIndex;
  } else {
    console.log(`ℹ️ Aucun résultat valide trouvé dans ${seqKey}_Win_Lose à l’index ${exCurrent - 1}`);
    resultat = "";
  }
}

// ============================================================
// ⚙️ Changement couleur jauge
// ============================================================
if (resultat === "1") {
  gauge.state = "Correct" ;
} else if (resultat === "0") {
  gauge.state = "Incorrect" ;
}

// ============================================================
// ⚙️ CALCULS D’ANGLES
// ============================================================
const baseAngle = resultat * (maxAngle - minAngle) + minAngle;
const angleMin = baseAngle - oscillationRange;
const angleMax = baseAngle + oscillationRange;


const goingUp = resultat === "1";
const targetAngle = goingUp ? angleMax : angleMin;

// ============================================================
// 🧹 ARRÊTE LES ANIMATIONS EXISTANTES
// ============================================================
gsap.killTweensOf(pointer);

// ============================================================
// 🚀 ANIMATION DE L’AIGUILLE
// ============================================================
gsap.to(pointer, {
  rotation: targetAngle,
  duration: 1.2,
  ease: "power2.inOut",
  onComplete: () => {
    gsap.to(pointer, {
      rotation: goingUp ? angleMin : angleMax,
      duration: oscillationSpeed,
      ease: "sine.inOut",
      yoyo: true,
      repeat: -1
    });
  }
});

}

window.Script319 = function()
{
  // ============================================================
// 🔁 SCRIPT — ALLER AU PROCHAIN EXERCICE ÉCHOUÉ ("Réviser les erreurs")
// ============================================================

// -------- VARIABLES DE CONTEXTE --------
const seqPos = getVar("0_Position_Sequence"); // ex: "1", "2", "3", "4"
const seqKey = `S${seqPos}`;                  // ex: "S1"
const exCurrent = parseInt(getVar(`${seqKey}_Exo_Current`) || 0, 10); // ex: 3
const historique = getVar(`${seqKey}_Win_Lose`) || ""; // ex: "110010"

// -------- SÉCURITÉ --------
if (!seqPos || !historique) {
  console.warn("⚠️ Impossible d'exécuter le script — séquence ou historique manquant.");
  return;
}

// ============================================================
// 🔍 RECHERCHE DU PROCHAIN ÉCHEC ("0")
// ============================================================

// On cherche le prochain "0" APRÈS la position actuelle
const nextFailIndex = historique.indexOf("0", exCurrent);

// ============================================================
// 🎯 MISE À JOUR OU FIN DE LA RÉVISION
// ============================================================

if (nextFailIndex === -1) {
  // Aucun autre exercice échoué trouvé → fin du mode révision
  setVar("S0_Revision_Erreurs", 2);
  console.log("🎉 Tous les exercices échoués ont été revus — fin du mode révision (S0_Revision_Erreurs = 2).");
} else {
  // Prochain exercice échoué trouvé
  const nextExercise = nextFailIndex + 1; // index → position 1-based
  setVar("0_Position_Exercice", nextExercise);
  console.log(`🔁 Révision → Prochain exercice échoué : EX${nextExercise}`);
}

console.log(`(Séquence : ${seqKey}, Historique : "${historique}")`);

}

window.Script320 = function()
{
  // ============================================================
// 🎬 REMPLACEMENT DYNAMIQUE DE VIDÉO (version simplifiée)
// ============================================================
// Remplace directement la vidéo de l'objet Storyline (ID fixe)
// avec le chemin complet contenu dans la variable "Ex_Video".
// ============================================================

// -------- Lecture de la variable --------
const newVideoPath = getVar("Ex_Video"); // ex: "Ressources_Sequences/S1/Videos/S1_EX1.mp4"

// -------- Sécurité --------
if (!newVideoPath || newVideoPath.trim() === "") {
  console.warn("⚠️ Aucune vidéo spécifiée dans Ex_Video — remplacement annulé.");
  return;
}

// -------- Sélection directe de la vidéo --------
const videoElement = document.querySelector('[data-model-id="5pTX8N7gCDH"] video');
if (!videoElement) {
  console.error("❌ Impossible de trouver la vidéo avec data-model-id=5pTX8N7gCDH.");
  return;
}

// -------- Remplacement de la source --------
videoElement.setAttribute("xlink:href", newVideoPath);
videoElement.src = newVideoPath;
videoElement.load();

// -------- Suppression de la vignette (poster) --------
const container = videoElement.closest('[data-model-id="5pTX8N7gCDH"]');
if (container) {
  const poster = container.querySelector("img.video-player-poster");
  if (poster) {
    poster.remove();
    console.log("✅ Vignette (poster) supprimée — la 1ère image de la vidéo sera visible.");
  }
}
}

window.Script321 = function()
{
  // ============================================================
// 🖼️ REMPLACEMENT DYNAMIQUE D’IMAGE (version simplifiée)
// ============================================================
// Remplace directement l’image de l’objet Storyline (ID fixe)
// avec le chemin complet contenu dans la variable "Ex_Image".
// Aucun calcul de dossier ou de chemin n’est effectué.
// ============================================================

// -------- Lecture de la variable --------
const newImagePath = getVar("Ex_Image"); // ex: "Ressources_Sequences/S1/images/EX1.jpg"

// -------- Sécurité --------
if (!newImagePath || newImagePath.trim() === "") {
  console.warn("⚠️ Aucune image spécifiée dans Ex_Image — remplacement annulé.");
  return;
}

// -------- Sélection directe de l’image --------
const imageElement = document.querySelector('[data-model-id="6jUy2ox5l86"] image');
if (!imageElement) {
  console.error("❌ Impossible de trouver l’image avec data-model-id=6jUy2ox5l86.");
  return;
}

// -------- Remplacement du lien --------
imageElement.setAttributeNS("http://www.w3.org/1999/xlink", "xlink:href", newImagePath);

}

window.Script322 = function()
{
  // ============================================================
// 🖼️ REMPLACEMENT DYNAMIQUE D’IMAGE (version simplifiée)
// ============================================================
// Remplace directement l’image de l’objet Storyline (ID fixe)
// avec le chemin complet contenu dans la variable "Ex_Image".
// Aucun calcul de dossier ou de chemin n’est effectué.
// ============================================================

// -------- Lecture de la variable --------
const newImagePath = getVar("Ex_Image"); // ex: "Ressources_Sequences/S1/images/EX1.jpg"

// -------- Sécurité --------
if (!newImagePath || newImagePath.trim() === "") {
  console.warn("⚠️ Aucune image spécifiée dans Ex_Image — remplacement annulé.");
  return;
}

// -------- Sélection directe de l’image --------
const imageElement = document.querySelector('[data-model-id="6c22D92goAT"] image');
if (!imageElement) {
  console.error("❌ Impossible de trouver l’image avec data-model-id=6c22D92goAT.");
  return;
}

// -------- Remplacement du lien --------
imageElement.setAttributeNS("http://www.w3.org/1999/xlink", "xlink:href", newImagePath);

}

window.Script323 = function()
{
  // ============================================================
// ⚙️ BARRE DE PROGRESSION — SYNCHRONISATION AVEC LA SÉQUENCE EN COURS
// ============================================================

// --------- Lecture de la séquence courante ---------
const seqPos = getVar("0_Position_Sequence");   // ex. 1 → S1
const seqKey = `S${seqPos}`;

// --------- Lecture des variables de la séquence correspondante ---------
const Exo_Reached = getVar("S0_Exo_Reached") || 0;
const Exo_Total = getVar("S0_Exo_Total") || 1;

// --------- Calcul du pourcentage ---------
const progress = Math.min(Exo_Reached / Exo_Total, 1); // clamp entre 0 et 1

// --------- Sélectionne l'objet Storyline ---------
const ProgressBar = document.querySelector(`[data-model-id="6f561U28wA4"]`);

if (ProgressBar) {
  // --------- Sélectionne l'élément graphique principal ---------
  const shape = ProgressBar.querySelector("path");

  if (shape) {
    // Si ce n’est pas déjà fait, on garde la largeur d’origine
    if (!shape.dataset.fullWidth) {
      const bbox = shape.getBBox();
      shape.dataset.fullWidth = bbox.width;
    }

    // --------- Calcul de la largeur selon la progression ---------
    const fullWidth = parseFloat(shape.dataset.fullWidth);

    // --------- Application du remplissage via clip-path ---------
    shape.style.clipPath = `inset(0 ${100 - progress * 100}% 0 0 round 0px)`;
  }
}

}

window.Script324 = function()
{
  // ============================================================
// ⚙️ BARRE DE PROGRESSION ANIMÉE (AVEC INITIALISATION INTELLIGENTE)
// ============================================================

// Durée de l’animation en millisecondes (modifiable)
const animationDuration = 800; // 0.8s = fluide, 300 = rapide, 1500 = lente

function updateProgressBarAnimated() {
  // --------- Lecture de la séquence courante ---------
  const seqPos = getVar("0_Position_Sequence");
  const seqKey = `S${seqPos}`;

  // --------- Lecture des variables globales S0 ---------
  const Exo_Reached = getVar("S0_Exo_Reached") || 0;
  const Exo_Total = getVar("S0_Exo_Total") || 1;
  const progress = Math.min(Exo_Reached / Exo_Total, 1);

  // --------- Sélectionne l'objet Storyline ---------
  const ProgressBar = document.querySelector(`[data-model-id="6f561U28wA4"]`);
  if (!ProgressBar) return;

  const shape = ProgressBar.querySelector("path");
  if (!shape) return;

  // --------- Initialisation si nécessaire ---------
  if (!shape.dataset.fullWidth) {
    const bbox = shape.getBBox();
    shape.dataset.fullWidth = bbox.width;
  }

  // --------- Nouvelle logique : position initiale intelligente ---------
  let startProgress;

  if (shape.dataset.currentProgress !== undefined) {
    // On continue à partir de la progression actuelle
    startProgress = parseFloat(shape.dataset.currentProgress) || 0;
  } else if (Exo_Reached >= 1) {
    // Si aucune donnée mais au moins un exercice complété,
    // on démarre au niveau précédent
    startProgress = (Exo_Reached - 1) / Exo_Total;
  } else {
    // Sinon, tout au début
    startProgress = 0;
  }

  const startTime = performance.now();

  // --------- Fonction d'animation fluide ---------
  function animate(time) {
    const elapsed = time - startTime;
    const t = Math.min(elapsed / animationDuration, 1);
    const eased = t < 0.5 ? 2 * t * t : -1 + (4 - 2 * t) * t; // easeInOutQuad

    const currentProgress = startProgress + (progress - startProgress) * eased;
    shape.style.clipPath = `inset(0 ${100 - currentProgress * 100}% 0 0 round 0px)`;
    shape.dataset.currentProgress = currentProgress;

    if (t < 1) requestAnimationFrame(animate);
  }

  requestAnimationFrame(animate);
}

// ============================================================
// ▶️ APPEL DU SCRIPT (exécuté manuellement via trigger JS)
// ============================================================

updateProgressBarAnimated();

}

window.Script325 = function()
{
  // -------- Initialisation --------

// Récupère le numéro ou identifiant d'exercice (ex: "EX2")
const AudioPath = getVar("0_Audio_Lecteur");

// Si un audio était déjà en cours → on le stoppe et on remet au début
if (window.audioUnique) {
  window.audioUnique.pause();
  window.audioUnique.currentTime = 0;
}

// Crée un nouvel objet audio
window.audioUnique = new Audio(AudioPath);

// Lecture
window.audioUnique.play().catch(err => {
  console.log("Erreur lecture Back :", err);
});
}

window.Script326 = function()
{
  // ============================================================
// 🎯 MISE À JOUR DES VARIABLES Sx_Win_Lose SELON Ex_Success (texte)
// ============================================================

// -------- Lecture des variables Storyline --------
const seqPos  = getVar("0_Position_Sequence");
const exPos   = getVar("0_Position_Exercice");
const success = getVar("Ex_Success");

// -------- Construction du nom de la séquence --------
const seqKey     = `S${seqPos}`;
const winLoseVar = `${seqKey}_Win_Lose`;

// -------- Lecture actuelle de la variable Win_Lose --------
let winLose = getVar(winLoseVar) || "";

// -------- S’assure que la longueur correspond au nombre total d’exercices --------
const total = getVar(`0_Menu_${seqKey}_Exo_Total`);

// -------- Conversion en tableau pour modification --------
const chars = winLose.split("");

// -------- Mise à jour du caractère correspondant à l’exercice actuel --------
if (!(chars[exPos - 1] === "1" && success === "0")) {
    chars[exPos - 1] = success === "1" ? "1" : "0";
}
// Si l'exercice est déjà réussi, on garde la réussite.

// -------- Conversion inverse en chaîne --------
winLose = chars.join("");

// -------- Écriture dans Storyline --------
setVar(winLoseVar, winLose);

// ============================================================
// 🔁 SWITCH AUTOMATIQUE DE 0_Feedback_Switch
// ============================================================
let feedbackSwitch = getVar("0_Feedback_Switch");
feedbackSwitch = feedbackSwitch === true || feedbackSwitch === "true" ? false : true;
setVar("0_Feedback_Switch", feedbackSwitch);

}

window.Script327 = function()
{
  // ============================================================
// 🏁 SCRIPT DE FIN D’EXERCICE — MISE À JOUR PROGRESSION & TENTATIVES
// ============================================================

// -------- CONFIGURATION --------
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;

const exCurrent  = parseInt(getVar(`${seqKey}_Exo_Current`), 10);
const exReached  = parseInt(getVar(`${seqKey}_Exo_Reached`), 10);
const tentVar    = `${seqKey}_Exo_Current_Tentatives`;
// ============================================================
// 🧭 MISE À JOUR DE LA PROGRESSION
// ============================================================

// Si on avance (évite de revenir en arrière)
if (exCurrent > exReached) {
  setVar(`${seqKey}_Exo_Reached`, exCurrent);
  setVar("S0_Exo_Reached", exCurrent); 
}

// ============================================================
// 🧮 MARQUAGE DE L’EXERCICE TERMINÉ
// ============================================================

setVar(tentVar, -10);

}

window.Script328 = function()
{
  // ============================================================
// 🧠 SAUVEGARDE AUTOMATIQUE DES DONNÉES UTILISATEUR (GLOBAL)
// ============================================================
//
// 🔹 Ce script est appelé automatiquement après la validation d’un exercice.
// 🔹 Il détecte le type d’exercice et sauvegarde la réponse dans la variable JSON
//    correspondante (ex: S1_UserData)
//
// ============================================================

// ------------------------------------------------------------
// 🔧 Lecture des infos de contexte
// ------------------------------------------------------------
const seqPos = getVar("0_Position_Sequence");           // ex: "1"
const exPos = parseInt(getVar("0_Position_Exercice"), 10);
const seqKey = `S${seqPos}`;
const exType = getVar("Ex_Type");
const success = getVar("Ex_Success");
const tentativesRestantes = parseInt(getVar("Ex_Tentatives"), 10);

// Variable cible (ex: "S1_UserData")
const userDataVar = `${seqKey}_UserData`;

// ------------------------------------------------------------
// 🔧 Lecture du JSON existant
// ------------------------------------------------------------
let data = {};
try {
  const existing = getVar(userDataVar);
  data = existing ? JSON.parse(existing) : {};
} catch (err) {
  console.warn(`⚠️ JSON invalide dans ${userDataVar}, réinitialisation.`, err);
  data = {};
}

// ------------------------------------------------------------
// 🧮 Tentatives initiales (si dispo dans cache global)
// ------------------------------------------------------------
let tentativesInitiales = 0;
try {
  const exData = window.sequenceCache?.[seqKey]?.[`EX${exPos}`];
  tentativesInitiales = exData?.Tentatives || 1;
} catch {
  tentativesInitiales = 1;
}

const tentativesUtilisees = Math.max(0, tentativesInitiales - tentativesRestantes);

// ------------------------------------------------------------
// 🎯 Récupération de la réponse selon le type d’exercice
// ------------------------------------------------------------
let userResponseObj = {};

switch (exType) {
  // 🔹 QCU
  case "QCU": {
    const answerKey = getVar("0_Reponse");
    const answerText = getVar(`0_Choix_${answerKey}`) || "";
    userResponseObj = { [answerKey]: answerText };
    break;
  }

  // 🔹 QCM
  case "QCM": {
    const responseRaw = (getVar("0_Reponse") || "").split("|").filter(Boolean);
    responseRaw.forEach(k => {
      userResponseObj[k] = getVar(`0_Choix_${k}`) || "";
    });
    break;
  }

  // 🔹 True or false
  case "True or false": {
    const answer = (getVar("0_Reponse") || "").toLowerCase();
    userResponseObj = { unique: answer };
    break;
  }

  // 🔹 Complete
  case "Complete": {
    const answer = getVar("0_Ex_Enonce") || "";
    userResponseObj = { unique: answer };
    break;
  }

  // 🔹 Matching
  case "Matching": {
    const reponse = getVar("0_Reponse") || "";
    userResponseObj = { associations: reponse };
    break;
  }

  // 🔹 Flashcard
  case "Flashcard": {
    const answer = getVar("0_Reponse") || "";
    userResponseObj = { unique: answer };
    break;
  }

  // 🔹 Information
  case "Information": {
    userResponseObj = { info: "Aucune interaction" };
    break;
  }

  // 🔹 Production orale - dictée
  case "Production orale - dictée": {
    const raw = getVar("0_Reponse") || "{}";
    try {
      const parsed = JSON.parse(raw);
      userResponseObj = {
        score: parsed.score || 0,
        texte_brut: parsed.texte_brut || "",
        texte_color: parsed.texte_color || ""
      };
    } catch (err) {
      console.warn("⚠️ Erreur de parsing JSON pour Production orale :", err);
      userResponseObj = { erreur: "Format de réponse invalide", raw };
    }
    break;
  }

  // 🔹 Défaut
  default: {
    const raw = getVar("0_Reponse") || "";
    userResponseObj = { inconnu: raw };
    console.warn(`❓ Type d’exercice inconnu : ${exType}`);
    break;
  }
}

// ------------------------------------------------------------
// 💾 Enregistrement dans le JSON
// ------------------------------------------------------------
data[`EX${exPos}`] = {
  Type: exType,
  Reponses_Choisies: userResponseObj,
  Statut: success,
  Tentatives_Utilisees: tentativesUtilisees
};

setVar(userDataVar, JSON.stringify(data));

// ------------------------------------------------------------
// 🧾 Log de contrôle
// ------------------------------------------------------------
console.group(`💾 Données sauvegardées → ${userDataVar}`);
console.log("Exercice :", `EX${exPos}`);
console.log("Type :", exType);
console.log("Réponses :", userResponseObj);
console.log("Statut :", success);
console.log("Tentatives utilisées :", tentativesUtilisees);
console.log("JSON complet :", data);
console.groupEnd();

}

window.Script329 = function()
{
  // Récupère les objets Storyline
const carte  = document.querySelector('[data-model-id="6WOyyFcuLyH"]');
const bouton = document.querySelector('[data-model-id="5rCsry3VrNh"]');

// Points d'ancrage
carte.style.transformOrigin = "top left";
bouton.style.transformOrigin = "center";

// Timeline pour synchroniser
const tl = gsap.timeline();

tl.to(carte, {
  scale: 0,
  opacity: 0,
  duration: 0.5,
  ease: "power1.inOut"
}, 0);

// Rotation 90° du bouton en même temps
tl.to(bouton, {
  rotate: 0,          // ou "+=90" si tu veux ajouter 90° à chaque fois
  duration: 0.5,
  ease: "power1.inOut"
}, 0);

}

window.Script330 = function()
{
  // Récupère les objets Storyline
const carte  = document.querySelector('[data-model-id="6WOyyFcuLyH"]');
const bouton = document.querySelector('[data-model-id="5rCsry3VrNh"]');

// Points d'ancrage
carte.style.transformOrigin = "top left";
bouton.style.transformOrigin = "center";

// États initiaux
gsap.set(carte,  { scale: 0, opacity: 0 });
gsap.set(bouton, { rotate: 0 }); // ou 90 si tu veux qu'il démarre déjà tourné

// Timeline pour synchroniser
const tl = gsap.timeline();

tl.to(carte, {
  scale: 1,
  opacity: 1,
  duration: 0.5,
  ease: "power1.inOut"
}, 0);

// Rotation 90° du bouton en même temps
tl.to(bouton, {
  rotate: 45,          // ou "+=90" si tu veux ajouter 90° à chaque fois
  duration: 0.5,
  ease: "power1.inOut"
}, 0);

}

window.Script331 = function()
{
  // ============================================================
// 💬 FEEDBACK MOTIVATIONNEL — AVEC SUPPORT DU FORMAT "1101nn"
// ============================================================

// -------- VARIABLES DE BASE --------
let resultat = getVar("Ex_Success");
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;
const exCurrent = parseInt(getVar(`${seqKey}_Exo_Current`), 10);

// ============================================================
// 🔍 SI RESULTAT VIDE → CHERCHE DANS S1_Win_Lose ("1101nn")
// ============================================================
if (!resultat || resultat === "") {
  const historique = getVar(`${seqKey}_Win_Lose`) || "";
  const charAtIndex = historique.charAt(exCurrent - 1);

  if (charAtIndex === "1" || charAtIndex === "0") {
    resultat = charAtIndex;
  } else {
    console.log(`ℹ️ Aucun résultat valide trouvé dans ${seqKey}_Win_Lose à l’index ${exCurrent - 1}`);
  }
}

// ============================================================
// 💬 LISTES DE FEEDBACKS
// ============================================================
const feedbackCorrect = [
  "Bravo !",
  "Super !",
  "Bien joué !",
  "Excellent !"
];

const feedbackIncorrect = [
  "Pas exactement.",
  "Oups !",
  "La prochaine fois !"
];

const feedbackNeutre = [
  "Continue !"
];

// ============================================================
// 🎯 CHOIX DU FEEDBACK
// ============================================================
let liste;
switch (resultat) {
  case "1":
    liste = feedbackCorrect;
    break;
  case "0":
    liste = feedbackIncorrect;
    break;
  default:
    liste = feedbackNeutre;
    break;
}

// Sélection aléatoire dans la liste
const feedback = liste[Math.floor(Math.random() * liste.length)];

// ============================================================
// 🧾 MISE À JOUR STORYLINE
// ============================================================
setVar("Ex_Feedback_Motivation", feedback);

}

window.Script332 = function()
{
  // ============================================================
// 🔁 SCRIPT — ALLER AU PROCHAIN EXERCICE ÉCHOUÉ ("Réviser les erreurs")
// ============================================================

// -------- VARIABLES DE CONTEXTE --------
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;
const exCurrent = parseInt(getVar(`${seqKey}_Exo_Current`), 10);
const historique = getVar(`${seqKey}_Win_Lose`) || "";

// -------- SÉCURITÉ --------
if (!seqPos || !historique) {
  console.warn("⚠️ Impossible d'exécuter le script — séquence ou historique manquant.");
  return;
}

// ============================================================
// 🔍 RECHERCHE DU PROCHAIN ÉCHEC ("0")
// ============================================================

// On cherche le prochain "0" APRÈS la position actuelle
const nextFailIndex = historique.indexOf("0", exCurrent);

// ============================================================
// 🎯 MISE À JOUR OU FIN DE LA RÉVISION
// ============================================================

if (nextFailIndex === -1) {
  // Aucun autre exercice échoué trouvé → fin du mode révision
  setVar("S0_Revision_Erreurs", 2);

} else {
  // Prochain exercice échoué trouvé
  const nextExercise = nextFailIndex + 1; // index → position 1-based
  setVar("0_Position_Exercice", nextExercise);
}
}

window.Script333 = function()
{
  // ============================================================
// 🎯 ANIMATION DE JAUGE — Rotation + Oscillation continue + Feedback motivationnel + Indicateur visuel
// ============================================================

// -------- OBJETS STORYLINE --------
const pointer = object('5fZOHpnMbya');
const gauge = object('6nKxLAItMtB');

// -------- PARAMÈTRES --------
const minAngle = 0;
const maxAngle = 180;
const oscillationRange = 10;
const oscillationSpeed = 1.5;

// ============================================================
// 🧮 DETECTION DU RESULTAT + RECUPERATION VARIABLES STORYLINE
// ============================================================
let resultat = getVar("Ex_Success");
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;
const exCurrent = getVar(`${seqKey}_Exo_Current`);

// Si il n'y a pas de résultat direct, on tente de le retrouver dans Sx_Win_Lose
if (resultat === "") {
  const historique = getVar(`${seqKey}_Win_Lose`);
  const charAtIndex = historique.charAt(exCurrent - 1);
  if (charAtIndex === "1" || charAtIndex === "0") {
    resultat = charAtIndex;
  } else {
    console.log(`ℹ️ Aucun résultat valide trouvé dans ${seqKey}_Win_Lose à l’index ${exCurrent - 1}`);
    resultat = "";
  }
}

// ============================================================
// ⚙️ Changement couleur jauge
// ============================================================
if (resultat === "1") {
  gauge.state = "Correct" ;
} else if (resultat === "0") {
  gauge.state = "Incorrect" ;
}

// ============================================================
// ⚙️ CALCULS D’ANGLES
// ============================================================
const baseAngle = resultat * (maxAngle - minAngle) + minAngle;
const angleMin = baseAngle - oscillationRange;
const angleMax = baseAngle + oscillationRange;


const goingUp = resultat === "1";
const targetAngle = goingUp ? angleMax : angleMin;

// ============================================================
// 🧹 ARRÊTE LES ANIMATIONS EXISTANTES
// ============================================================
gsap.killTweensOf(pointer);

// ============================================================
// 🚀 ANIMATION DE L’AIGUILLE
// ============================================================
gsap.to(pointer, {
  rotation: targetAngle,
  duration: 1.2,
  ease: "power2.inOut",
  onComplete: () => {
    gsap.to(pointer, {
      rotation: goingUp ? angleMin : angleMax,
      duration: oscillationSpeed,
      ease: "sine.inOut",
      yoyo: true,
      repeat: -1
    });
  }
});

}

window.Script334 = function()
{
  const Btn_Affichage  = document.querySelector('[data-model-id="6geks01QgvK"]');
const temoin = object('6XIh2Zufqbt');

// (Optionnel mais recommandé) point d’ancrage de la rotation
Btn_Affichage.style.transformOrigin = "50% 50%";

// On lit l’état actuel puis on bascule
const isAffiche = (temoin.state === "Feedback_Affiche");

temoin.state = isAffiche ? "Feedback_Cache" : "Feedback_Affiche";

// Rotation GSAP (durée + easing ajustables)
gsap.to(Btn_Affichage, {
  rotation: isAffiche ? 180 : 0,
  duration: 0.45,
  ease: "power2.inOut",
  overwrite: "auto"
});

}

window.Script335 = function()
{
  // ============================================================
// 💬 FEEDBACK MOTIVATIONNEL — AVEC SUPPORT DU FORMAT "1101nn"
// ============================================================

// -------- VARIABLES DE BASE --------
let resultat = getVar("Ex_Success");
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;
const exCurrent = parseInt(getVar(`${seqKey}_Exo_Current`), 10);

// ============================================================
// 🔍 SI RESULTAT VIDE → CHERCHE DANS S1_Win_Lose ("1101nn")
// ============================================================
if (!resultat || resultat === "") {
  const historique = getVar(`${seqKey}_Win_Lose`) || "";
  const charAtIndex = historique.charAt(exCurrent - 1);

  if (charAtIndex === "1" || charAtIndex === "0") {
    resultat = charAtIndex;
  } else {
    console.log(`ℹ️ Aucun résultat valide trouvé dans ${seqKey}_Win_Lose à l’index ${exCurrent - 1}`);
  }
}

// ============================================================
// 💬 LISTES DE FEEDBACKS
// ============================================================
//const feedbackCorrect = [
//  "Bravo !",
//  "Super !",
//  "Bien joué !",
//  "Excellent !"
//];

//const feedbackIncorrect = [
//  "Pas exactement.",
//  "Oups !",
//  "La prochaine fois !"
//];

const feedbackCorrect = [
  "Bravo, c'est une bonne réponse !",
  "Super, tu es sur la bonne voie !",
  "Bien joué, tu progresses !",
  "Excellent, continue comme ça !"
];

const feedbackIncorrect = [
  "Ce n'est pas tout à fait ça.",
  "Oups, ce n'est pas la bonne réponse.",
  "Tu y arriveras la prochaine fois !",
  "Pas exactement. Encore un effort !"
];


const feedbackNeutre = [
  "Continue !"
];

// ============================================================
// 🎯 CHOIX DU FEEDBACK
// ============================================================
let liste;
switch (resultat) {
  case "1":
    liste = feedbackCorrect;
    break;
  case "0":
    liste = feedbackIncorrect;
    break;
  default:
    liste = feedbackNeutre;
    break;
}

// Sélection aléatoire dans la liste
const feedback = liste[Math.floor(Math.random() * liste.length)];

// ============================================================
// 🧾 MISE À JOUR STORYLINE
// ============================================================
setVar("Ex_Feedback_Motivation", feedback);

}

window.Script336 = function()
{
  // ============================================================
// 🔁 SCRIPT — ALLER AU PROCHAIN EXERCICE ÉCHOUÉ ("Réviser les erreurs")
// ============================================================

// -------- VARIABLES DE CONTEXTE --------
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;
const exCurrent = parseInt(getVar(`${seqKey}_Exo_Current`), 10);
const historique = getVar(`${seqKey}_Win_Lose`) || "";

// -------- SÉCURITÉ --------
if (!seqPos || !historique) {
  console.warn("⚠️ Impossible d'exécuter le script — séquence ou historique manquant.");
  return;
}

// ============================================================
// 🔍 RECHERCHE DU PROCHAIN ÉCHEC ("0")
// ============================================================

// On cherche le prochain "0" APRÈS la position actuelle
const nextFailIndex = historique.indexOf("0", exCurrent);

// ============================================================
// 🎯 MISE À JOUR OU FIN DE LA RÉVISION
// ============================================================

if (nextFailIndex === -1) {
  // Aucun autre exercice échoué trouvé → fin du mode révision
  setVar("S0_Revision_Erreurs", 2);

} else {
  // Prochain exercice échoué trouvé
  const nextExercise = nextFailIndex + 1; // index → position 1-based
  setVar("0_Position_Exercice", nextExercise);
}
}

window.Script337 = function()
{
  // ============================================================
// 🎯 ANIMATION DE JAUGE — Rotation + Oscillation continue + Feedback motivationnel + Indicateur visuel
// ============================================================

// -------- OBJETS STORYLINE --------
const pointer = object('61WVHrM0EGs');
//const gauge = object('5lezhyLYUu5'); Cet objet n'existe pas ?
const gauge = object('6rIRKS6iuFv');


// -------- PARAMÈTRES --------
const minAngle = 0;
const maxAngle = 180;
const oscillationRange = 10;
const oscillationSpeed = 1.5;

// ============================================================
// 🧮 DETECTION DU RESULTAT + RECUPERATION VARIABLES STORYLINE
// ============================================================
let resultat = getVar("Ex_Success");
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;
const exCurrent = getVar(`${seqKey}_Exo_Current`);

// Si il n'y a pas de résultat direct, on tente de le retrouver dans Sx_Win_Lose
if (resultat === "") {
  const historique = getVar(`${seqKey}_Win_Lose`);
  const charAtIndex = historique.charAt(exCurrent - 1);
  if (charAtIndex === "1" || charAtIndex === "0") {
    resultat = charAtIndex;
  } else {
    console.log(`ℹ️ Aucun résultat valide trouvé dans ${seqKey}_Win_Lose à l’index ${exCurrent - 1}`);
    resultat = "";
  }
}

// ============================================================
// ⚙️ Changement couleur jauge
// ============================================================
if (resultat === "1") {
  gauge.state = "Correct" ;
} else if (resultat === "0") {
  gauge.state = "Incorrect" ;
}

// ============================================================
// ⚙️ CALCULS D’ANGLES
// ============================================================
const baseAngle = resultat * (maxAngle - minAngle) + minAngle;
const angleMin = baseAngle - oscillationRange;
const angleMax = baseAngle + oscillationRange;


const goingUp = resultat === "1";
const targetAngle = goingUp ? angleMax : angleMin;

// ============================================================
// 🧹 ARRÊTE LES ANIMATIONS EXISTANTES
// ============================================================
gsap.killTweensOf(pointer);

// ============================================================
// 🚀 ANIMATION DE L’AIGUILLE
// ============================================================
gsap.to(pointer, {
  rotation: targetAngle,
  duration: 1.2,
  ease: "power2.inOut",
  onComplete: () => {
    gsap.to(pointer, {
      rotation: goingUp ? angleMin : angleMax,
      duration: oscillationSpeed,
      ease: "sine.inOut",
      yoyo: true,
      repeat: -1
    });
  }
});

}

window.Script338 = function()
{
  const Btn_Affichage  = document.querySelector('[data-model-id="6RRLU9ixx38"]');
const temoin = object('68ikzB1cq1L');

// (Optionnel mais recommandé) point d’ancrage de la rotation
Btn_Affichage.style.transformOrigin = "50% 50%";

// On lit l’état actuel puis on bascule
const isAffiche = (temoin.state === "Feedback_Affiche");

temoin.state = isAffiche ? "Feedback_Cache" : "Feedback_Affiche";

// Rotation GSAP (durée + easing ajustables)
gsap.to(Btn_Affichage, {
  rotation: isAffiche ? 180 : 0,
  duration: 0.45,
  ease: "power2.inOut",
  overwrite: "auto"
});

}

window.Script339 = function()
{
  // Récupère le résultat
let resultat = getVar("Ex_Success");

// Définit les listes de feedback
const feedbackCorrect = [
  "Bravo !",
  "Super !",
  "Bien joué !",
  "Excellent !"
];

const feedbackIncorrect = [
  "Pas exactement",
  "Oups !",
  "La prochaine fois !"
];

// Choisit la liste en fonction du résultat
let liste = (resultat === "1") ? feedbackCorrect : feedbackIncorrect;

// Sélectionne un élément aléatoire dans la liste
let feedback = liste[Math.floor(Math.random() * liste.length)];

// Met à jour la variable Storyline
setVar("Ex_Feedback_Motivation", feedback);

}

window.Script340 = function()
{
  // ============================================================
// 🎯 ANIMATION DE JAUGE — Rotation + Oscillation continue + Feedback motivationnel + Indicateur visuel
// ============================================================

// -------- OBJETS STORYLINE --------
const pointer = object('5Ux37gXcJcw');
const gauge = object('5enGetq7POY');

// -------- PARAMÈTRES --------
const minAngle = 0;
const maxAngle = 180;
const oscillationRange = 10;
const oscillationSpeed = 1.5;

// ============================================================
// 🧮 DETECTION DU RESULTAT + RECUPERATION VARIABLES STORYLINE
// ============================================================
let resultat = getVar("Ex_Success");
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;
const exCurrent = getVar(`${seqKey}_Exo_Current`);

// Si il n'y a pas de résultat direct, on tente de le retrouver dans Sx_Win_Lose
if (resultat === "") {
  const historique = getVar(`${seqKey}_Win_Lose`);
  const charAtIndex = historique.charAt(exCurrent - 1);
  if (charAtIndex === "1" || charAtIndex === "0") {
    resultat = charAtIndex;
  } else {
    console.log(`ℹ️ Aucun résultat valide trouvé dans ${seqKey}_Win_Lose à l’index ${exCurrent - 1}`);
    resultat = "";
  }
}

// ============================================================
// ⚙️ Changement couleur jauge
// ============================================================
if (resultat === "1") {
  gauge.state = "Correct" ;
} else if (resultat === "0") {
  gauge.state = "Incorrect" ;
}

// ============================================================
// ⚙️ CALCULS D’ANGLES
// ============================================================
const baseAngle = resultat * (maxAngle - minAngle) + minAngle;
const angleMin = baseAngle - oscillationRange;
const angleMax = baseAngle + oscillationRange;


const goingUp = resultat === "1";
const targetAngle = goingUp ? angleMax : angleMin;

// ============================================================
// 🧹 ARRÊTE LES ANIMATIONS EXISTANTES
// ============================================================
gsap.killTweensOf(pointer);

// ============================================================
// 🚀 ANIMATION DE L’AIGUILLE
// ============================================================
gsap.to(pointer, {
  rotation: targetAngle,
  duration: 1.2,
  ease: "power2.inOut",
  onComplete: () => {
    gsap.to(pointer, {
      rotation: goingUp ? angleMin : angleMax,
      duration: oscillationSpeed,
      ease: "sine.inOut",
      yoyo: true,
      repeat: -1
    });
  }
});

}

window.Script341 = function()
{
  // ============================================================
// 🔁 SCRIPT — ALLER AU PROCHAIN EXERCICE ÉCHOUÉ ("Réviser les erreurs")
// ============================================================

// -------- VARIABLES DE CONTEXTE --------
const seqPos = getVar("0_Position_Sequence"); // ex: "1", "2", "3", "4"
const seqKey = `S${seqPos}`;                  // ex: "S1"
const exCurrent = parseInt(getVar(`${seqKey}_Exo_Current`) || 0, 10); // ex: 3
const historique = getVar(`${seqKey}_Win_Lose`) || ""; // ex: "110010"

// -------- SÉCURITÉ --------
if (!seqPos || !historique) {
  console.warn("⚠️ Impossible d'exécuter le script — séquence ou historique manquant.");
  return;
}

// ============================================================
// 🔍 RECHERCHE DU PROCHAIN ÉCHEC ("0")
// ============================================================

// On cherche le prochain "0" APRÈS la position actuelle
const nextFailIndex = historique.indexOf("0", exCurrent);

// ============================================================
// 🎯 MISE À JOUR OU FIN DE LA RÉVISION
// ============================================================

if (nextFailIndex === -1) {
  // Aucun autre exercice échoué trouvé → fin du mode révision
  setVar("S0_Revision_Erreurs", 2);
  console.log("🎉 Tous les exercices échoués ont été revus — fin du mode révision (S0_Revision_Erreurs = 2).");
} else {
  // Prochain exercice échoué trouvé
  const nextExercise = nextFailIndex + 1; // index → position 1-based
  setVar("0_Position_Exercice", nextExercise);
  console.log(`🔁 Révision → Prochain exercice échoué : EX${nextExercise}`);
}

console.log(`(Séquence : ${seqKey}, Historique : "${historique}")`);

}

window.Script342 = function()
{
  // ============================================================
// 🎬 REMPLACEMENT DYNAMIQUE DE VIDÉO (version simplifiée)
// ============================================================
// Remplace directement la vidéo de l'objet Storyline (ID fixe)
// avec le chemin complet contenu dans la variable "Ex_Video".
// ============================================================

// -------- Lecture de la variable --------
const newVideoPath = getVar("Ex_Video"); // ex: "Ressources_Sequences/S1/Videos/S1_EX1.mp4"

// -------- Sécurité --------
if (!newVideoPath || newVideoPath.trim() === "") {
  console.warn("⚠️ Aucune vidéo spécifiée dans Ex_Video — remplacement annulé.");
  return;
}

// -------- Sélection directe de la vidéo --------
const videoElement = document.querySelector('[data-model-id="5pTX8N7gCDH"] video');
if (!videoElement) {
  console.error("❌ Impossible de trouver la vidéo avec data-model-id=5pTX8N7gCDH.");
  return;
}

// -------- Remplacement de la source --------
videoElement.setAttribute("xlink:href", newVideoPath);
videoElement.src = newVideoPath;
videoElement.load();

// -------- Suppression de la vignette (poster) --------
const container = videoElement.closest('[data-model-id="5pTX8N7gCDH"]');
if (container) {
  const poster = container.querySelector("img.video-player-poster");
  if (poster) {
    poster.remove();
    console.log("✅ Vignette (poster) supprimée — la 1ère image de la vidéo sera visible.");
  }
}
}

window.Script343 = function()
{
  // ============================================================
// 🖼️ REMPLACEMENT DYNAMIQUE D’IMAGE (version simplifiée)
// ============================================================
// Remplace directement l’image de l’objet Storyline (ID fixe)
// avec le chemin complet contenu dans la variable "Ex_Image".
// Aucun calcul de dossier ou de chemin n’est effectué.
// ============================================================

// -------- Lecture de la variable --------
const newImagePath = getVar("Ex_Image"); // ex: "Ressources_Sequences/S1/images/EX1.jpg"

// -------- Sécurité --------
if (!newImagePath || newImagePath.trim() === "") {
  console.warn("⚠️ Aucune image spécifiée dans Ex_Image — remplacement annulé.");
  return;
}

// -------- Sélection directe de l’image --------
const imageElement = document.querySelector('[data-model-id="6jUy2ox5l86"] image');
if (!imageElement) {
  console.error("❌ Impossible de trouver l’image avec data-model-id=6jUy2ox5l86.");
  return;
}

// -------- Remplacement du lien --------
imageElement.setAttributeNS("http://www.w3.org/1999/xlink", "xlink:href", newImagePath);

}

window.Script344 = function()
{
  // ============================================================
// 🖼️ REMPLACEMENT DYNAMIQUE D’IMAGE (version simplifiée)
// ============================================================
// Remplace directement l’image de l’objet Storyline (ID fixe)
// avec le chemin complet contenu dans la variable "Ex_Image".
// Aucun calcul de dossier ou de chemin n’est effectué.
// ============================================================

// -------- Lecture de la variable --------
const newImagePath = getVar("Ex_Image"); // ex: "Ressources_Sequences/S1/images/EX1.jpg"

// -------- Sécurité --------
if (!newImagePath || newImagePath.trim() === "") {
  console.warn("⚠️ Aucune image spécifiée dans Ex_Image — remplacement annulé.");
  return;
}

// -------- Sélection directe de l’image --------
const imageElement = document.querySelector('[data-model-id="6c22D92goAT"] image');
if (!imageElement) {
  console.error("❌ Impossible de trouver l’image avec data-model-id=6c22D92goAT.");
  return;
}

// -------- Remplacement du lien --------
imageElement.setAttributeNS("http://www.w3.org/1999/xlink", "xlink:href", newImagePath);

}

window.Script345 = function()
{
  // ============================================================
// ⚙️ BARRE DE PROGRESSION — SYNCHRONISATION AVEC LA SÉQUENCE EN COURS
// ============================================================

// --------- Lecture de la séquence courante ---------
const seqPos = getVar("0_Position_Sequence");   // ex. 1 → S1
const seqKey = `S${seqPos}`;

// --------- Lecture des variables de la séquence correspondante ---------
const Exo_Reached = getVar("S0_Exo_Reached") || 0;
const Exo_Total = getVar("S0_Exo_Total") || 1;

// --------- Calcul du pourcentage ---------
const progress = Math.min(Exo_Reached / Exo_Total, 1); // clamp entre 0 et 1

// --------- Sélectionne l'objet Storyline ---------
const ProgressBar = document.querySelector(`[data-model-id="6f561U28wA4"]`);

if (ProgressBar) {
  // --------- Sélectionne l'élément graphique principal ---------
  const shape = ProgressBar.querySelector("path");

  if (shape) {
    // Si ce n’est pas déjà fait, on garde la largeur d’origine
    if (!shape.dataset.fullWidth) {
      const bbox = shape.getBBox();
      shape.dataset.fullWidth = bbox.width;
    }

    // --------- Calcul de la largeur selon la progression ---------
    const fullWidth = parseFloat(shape.dataset.fullWidth);

    // --------- Application du remplissage via clip-path ---------
    shape.style.clipPath = `inset(0 ${100 - progress * 100}% 0 0 round 0px)`;
  }
}

}

window.Script346 = function()
{
  // ============================================================
// ⚙️ BARRE DE PROGRESSION ANIMÉE (AVEC INITIALISATION INTELLIGENTE)
// ============================================================

// Durée de l’animation en millisecondes (modifiable)
const animationDuration = 800; // 0.8s = fluide, 300 = rapide, 1500 = lente

function updateProgressBarAnimated() {
  // --------- Lecture de la séquence courante ---------
  const seqPos = getVar("0_Position_Sequence");
  const seqKey = `S${seqPos}`;

  // --------- Lecture des variables globales S0 ---------
  const Exo_Reached = getVar("S0_Exo_Reached") || 0;
  const Exo_Total = getVar("S0_Exo_Total") || 1;
  const progress = Math.min(Exo_Reached / Exo_Total, 1);

  // --------- Sélectionne l'objet Storyline ---------
  const ProgressBar = document.querySelector(`[data-model-id="6f561U28wA4"]`);
  if (!ProgressBar) return;

  const shape = ProgressBar.querySelector("path");
  if (!shape) return;

  // --------- Initialisation si nécessaire ---------
  if (!shape.dataset.fullWidth) {
    const bbox = shape.getBBox();
    shape.dataset.fullWidth = bbox.width;
  }

  // --------- Nouvelle logique : position initiale intelligente ---------
  let startProgress;

  if (shape.dataset.currentProgress !== undefined) {
    // On continue à partir de la progression actuelle
    startProgress = parseFloat(shape.dataset.currentProgress) || 0;
  } else if (Exo_Reached >= 1) {
    // Si aucune donnée mais au moins un exercice complété,
    // on démarre au niveau précédent
    startProgress = (Exo_Reached - 1) / Exo_Total;
  } else {
    // Sinon, tout au début
    startProgress = 0;
  }

  const startTime = performance.now();

  // --------- Fonction d'animation fluide ---------
  function animate(time) {
    const elapsed = time - startTime;
    const t = Math.min(elapsed / animationDuration, 1);
    const eased = t < 0.5 ? 2 * t * t : -1 + (4 - 2 * t) * t; // easeInOutQuad

    const currentProgress = startProgress + (progress - startProgress) * eased;
    shape.style.clipPath = `inset(0 ${100 - currentProgress * 100}% 0 0 round 0px)`;
    shape.dataset.currentProgress = currentProgress;

    if (t < 1) requestAnimationFrame(animate);
  }

  requestAnimationFrame(animate);
}

// ============================================================
// ▶️ APPEL DU SCRIPT (exécuté manuellement via trigger JS)
// ============================================================

updateProgressBarAnimated();

}

window.Script347 = function()
{
  // ============================================================
// 📘 GESTION DU RECAP — Lecture du JSON et injection dans Storyline
// ============================================================

// ============================================================
// 🧪 DONNÉES DE TEST (MODE DEBUG)
// ============================================================
const debugData = {
  S1: {
    EX1: {
      Type: "True or false",
      Consigne: "Écoute le dialogue puis choisis si l’affirmation est vraie ou fausse.",
      Affirmation: "Marc se sent stressé par la formation qu’ils doivent suivre.",
      BonneReponse: "True",
      Feedback: "L’affirmation est vraie ! Marc dit qu’il se sent dépassé car il a beaucoup de travail.",
      Tentatives: 1,
      Image: "Ressources_Sequences/S1/Images/S1_EX1.jpg",
      Audio_Enonce: "Ressources_Sequences/S1/Audios/S1_EX1_main.mp3"
    },
    Recap: {
      Type: "Liste",
      Expressions: [
        {
          Texte: "1",
          Audio: "Ressources_Sequences/S1/Audios/Recap_1.mp3"
        },
        {
          Texte: "2",
          Audio: "Ressources_Sequences/S1/Audios/Recap_2.mp3"
        },
        {
          Texte: "3",
          Audio: "Ressources_Sequences/S1/Audios/Recap_3.mp3"
        }
      ]
    }
  },
  S2: {
    EX1: {
      Type: "True or false",
      Consigne: "Juste du remplissage",
      Affirmation: "Juste du remplissage",
      BonneReponse: "True",
      Feedback: "Juste du remplissage",
      Tentatives: 1,
      Image: "Ressources_Sequences/S2/Images/S2_EX1.jpg",
      Audio_Enonce: "Ressources_Sequences/S2/Audios/S2_EX1_main.mp3"
    },
    Recap: {
      Type: "Texte",
      Texte: "Du texte"
    }
  },
  S3: {
    EX1: {
      Type: "True or false",
      Consigne: "Juste du remplissage",
      Affirmation: "Juste du remplissage",
      BonneReponse: "True",
      Feedback: "Juste du remplissage",
      Tentatives: 1,
      Image: "Ressources_Sequences/S3/Images/S3_EX1.jpg",
      Audio_Enonce: "Ressources_Sequences/S3/Audios/S3_EX1_main.mp3"
    },
    Recap: {
      Type: "Liste",
      Expressions: [
        {
          Texte: "111",
          Audio: "Ressources_Sequences/S3/Audios/Recap_1.mp3"
        },
        {
          Texte: "222",
          Audio: "Ressources_Sequences/S3/Audios/Recap_2.mp3"
        }
      ]
    }
  },
  S4: {
    EX1: {
      Type: "True or false",
      Consigne: "Juste du remplissage",
      Affirmation: "Juste du remplissage",
      BonneReponse: "True",
      Feedback: "Juste du remplissage",
      Tentatives: 1,
      Image: "Ressources_Sequences/S4/Images/S4_EX1.jpg",
      Audio_Enonce: "Ressources_Sequences/S4/Audios/S4_EX1_main.mp3"
    },
    Recap: {
      Type: "Minimaliste"
    }
  }
};

// ============================================================
// ⚙️ VARIABLES STORYLINE
// ============================================================
const seqPos = getVar("0_Position_Sequence"); // ex: "1"
const seqKey = `S${seqPos}`;                  // ex: "S1"
const debugMode = getVar("00_Debug");         // true / false

// -------- RESET DES VARIABLES DE RECAP --------
[
  "Recap_Type",
  "Recap_Texte",
  "Recap_Expression_1", "Recap_Expression_2", "Recap_Expression_3",
  "Recap_Expression_4", "Recap_Expression_5", "Recap_Expression_6",
  "Recap_Audio_1", "Recap_Audio_2", "Recap_Audio_3",
  "Recap_Audio_4", "Recap_Audio_5", "Recap_Audio_6"
].forEach(v => setVar(v, ""));

// ============================================================
// 🧩 FONCTION : applique les données du recap à Storyline
// ============================================================
function applyRecapData(seqData) {
  const recapData = seqData.Recap;

  if (!recapData) {
    console.warn(`⚠️ Aucun récap trouvé dans ${seqKey}`);
    return;
  }

  console.log(`📘 Chargement du récap pour ${seqKey} → Type : ${recapData.Type}`);
  setVar("Recap_Type", recapData.Type || "");

  switch (recapData.Type) {
    // ------------------------------------------------------------
    // 🔹 CAS 1 : RECAP MINIMALISTE
    // ------------------------------------------------------------
    case "Minimaliste":
      console.log("🟢 Récap minimaliste — aucun contenu spécifique à charger.");
      break;

    // ------------------------------------------------------------
    // 🔹 CAS 2 : RECAP TEXTE
    // ------------------------------------------------------------
    case "Texte":
      setVar("Recap_Texte", recapData.Texte || "");
      console.log("📄 Récap texte chargé :", recapData.Texte);
      break;

    // ------------------------------------------------------------
    // 🔹 CAS 3 : RECAP LISTE (expressions avec audio)
    // ------------------------------------------------------------
    case "Liste":
      const expressions = recapData.Expressions || [];
      for (let i = 0; i < 6; i++) {
        const item = expressions[i];
        if (!item) continue;
        setVar(`Recap_Expression_${i + 1}`, item.Texte || "");
        setVar(`Recap_Audio_${i + 1}`, item.Audio || null);
      }
      console.log("📋 Récap liste chargé :", expressions);
      break;

    // ------------------------------------------------------------
    // 🔹 CAS INCONNU
    // ------------------------------------------------------------
    default:
      console.warn(`❔ Type de récap inconnu : ${recapData.Type}`);
      break;
  }

  console.log("✅ Données de récap injectées dans Storyline.");
}

// ============================================================
// 🚀 CHARGEMENT PRINCIPAL
// ============================================================
if (debugMode) {
  console.log(`🧪 MODE DEBUG ACTIVÉ — Lecture des données locales pour ${seqKey}`);
  if (debugData[seqKey]) {
    applyRecapData(debugData[seqKey]);
  } else {
    console.warn(`❌ Données debug manquantes pour ${seqKey}`);
  }
} else {
  console.log(`🌐 MODE NORMAL — Chargement du JSON : ${seqKey}`);
  if (window.sequenceCache?.[seqKey]) {
    applyRecapData(window.sequenceCache[seqKey]);
  } else {
    fetch(`Ressources_Sequences/${seqKey}/variables.json`)
      .then(r => r.json())
      .then(json => {
        window.sequenceCache = window.sequenceCache || {};
        window.sequenceCache[seqKey] = json;
        applyRecapData(json);
      })
      .catch(e => console.error("Erreur de chargement du JSON :", e));
  }
}

}

window.Script348 = function()
{
  // ============================================================
// ♻️ RÉINITIALISATION — Remplace tous les 0 et 1 par "n" dans Sx_Win_Lose
// ============================================================

// -------- VARIABLES STORYLINE --------
const seqPos = getVar("0_Position_Sequence"); // ex: "1", "2", "3", "4"
const seqKey = `S${seqPos}`;                  // ex: "S1"
const varName = `${seqKey}_Win_Lose`;         // ex: "S1_Win_Lose"

// -------- RÉCUPÉRATION --------
const historique = getVar(varName) || "";     // ex: "110010"

// -------- SÉCURITÉ --------
if (!historique) {
  console.warn(`⚠️ Impossible de réinitialiser — ${varName} est vide ou non défini.`);
  return;
}

// ============================================================
// 🧮 RÉINITIALISATION DE LA CHAÎNE
// ============================================================

// Remplace tous les caractères 1 ou 0 par "n"
const resetHistorique = historique.replace(/[10]/g, "n");

// ============================================================
// 💾 MISE À JOUR STORYLINE
// ============================================================
setVar(varName, resetHistorique);

// ============================================================
// 🧾 LOGS DE CONTRÔLE
// ============================================================
console.log(`♻️ ${varName} réinitialisé :`);
console.log(`Avant : "${historique}"`);
console.log(`Après  : "${resetHistorique}"`);

}

window.Script349 = function()
{
  // ============================================================
// ♻️ RÉINITIALISATION — Remplace tous les 0 et 1 par "n" dans Sx_Win_Lose
// ============================================================

// -------- VARIABLES STORYLINE --------
const seqPos = getVar("0_Position_Sequence"); // ex: "1", "2", "3", "4"
const seqKey = `S${seqPos}`;                  // ex: "S1"
const varName = `${seqKey}_Win_Lose`;         // ex: "S1_Win_Lose"

// -------- RÉCUPÉRATION --------
const historique = getVar(varName) || "";     // ex: "110010"

// -------- SÉCURITÉ --------
if (!historique) {
  console.warn(`⚠️ Impossible de réinitialiser — ${varName} est vide ou non défini.`);
  return;
}

// ============================================================
// 🧮 RÉINITIALISATION DE LA CHAÎNE
// ============================================================

// Remplace tous les caractères 1 ou 0 par "n"
const resetHistorique = historique.replace(/[10]/g, "n");

// ============================================================
// 💾 MISE À JOUR STORYLINE
// ============================================================
setVar(varName, resetHistorique);

// ============================================================
// 🧾 LOGS DE CONTRÔLE
// ============================================================
console.log(`♻️ ${varName} réinitialisé :`);
console.log(`Avant : "${historique}"`);
console.log(`Après  : "${resetHistorique}"`);

}

window.Script350 = function()
{
  // ============================================================
// 🎯 RÉVISER — ALLER AU PREMIER EXERCICE ÉCHOUÉ ("0")
// ============================================================

// -------- VARIABLES STORYLINE --------
const seqPos = getVar("0_Position_Sequence"); // ex: "1", "2", "3", "4"
const seqKey = `S${seqPos}`;                  // ex: "S1"
const historique = getVar(`${seqKey}_Win_Lose`) || ""; // ex: "110010"

// -------- SÉCURITÉ --------
if (!seqPos || !historique) {
  console.warn("⚠️ Impossible de lancer la révision : séquence ou historique manquant.");
  return;
}

// ============================================================
// 🔍 RECHERCHE DU PREMIER ÉCHEC ("0")
// ============================================================
const firstFailIndex = historique.indexOf("0");

if (firstFailIndex === -1) {
  console.log("🎉 Aucun exercice échoué à réviser — tout est réussi !");
  return;
}

// ============================================================
// 🎯 MISE À JOUR DE LA POSITION
// ============================================================
// Les exercices sont 1-based → on ajoute +1 à l’index trouvé
const firstExercise = firstFailIndex + 1;
setVar("0_Position_Exercice", firstExercise);

// ============================================================
// 🧾 LOG DE CONTRÔLE
// ============================================================
console.log(`🔁 Révision lancée → Premier exercice échoué : EX${firstExercise}`);
console.log(`(Séquence : ${seqKey}, Historique : "${historique}")`);

}

window.Script351 = function()
{
  // --------- Lecture de la séquence courante ---------
const seqPos = getVar("0_Position_Sequence");   // ex. 1 → S1
setVar(`S${seqPos}_Exo_Current`, 0);
setVar(`0_Menu_S${seqPos}_Completed`, true);
}

window.Script352 = function()
{
  // -------- Initialisation --------

// Récupère le numéro ou identifiant d'exercice (ex: "EX2")
const AudioPath = getVar("0_Audio_Lecteur");
console.log(AudioPath);

// Si un audio était déjà en cours → on le stoppe et on remet au début
if (window.audioUnique) {
  window.audioUnique.pause();
  window.audioUnique.currentTime = 0;
}

// Crée un nouvel objet audio
window.audioUnique = new Audio(AudioPath);

// Lecture
window.audioUnique.play().catch(err => {
  console.log("Erreur lecture Back :", err);
});
}

window.Script353 = function()
{
  // ============================================================
// 🎯 ANIMATION DE JAUGE — Rotation + Oscillation continue + Feedback motivationnel + Indicateur visuel
// ============================================================

// -------- OBJETS STORYLINE --------
const pointer = object('6XXFijQSVU6');    // Aiguille
const success_Bars = object('64dfQZKwEzX'); // Indicateur visuel (barres de succès)

// -------- PARAMÈTRES --------
const minAngle = 0;
const maxAngle = 180;
const oscillationRange = 10;
const oscillationSpeed = 1.5;

// -------- VARIABLES STORYLINE --------
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;
const historique = getVar(`${seqKey}_Win_Lose`) || "";

// ============================================================
// 🧮 CALCUL DU POURCENTAGE DE RÉUSSITE
// ============================================================
let successRate = 0;

if (historique.length > 0) {
  const total = historique.length;
  const wins = (historique.match(/1/g) || []).length;
  successRate = Math.round((wins / total) * 100);
  setVar("S0_Success_Rate", successRate);
} else {
  console.warn("⚠️ Aucune donnée trouvée dans", `${seqKey}_Win_Lose`);
}

// Clamp entre 0 et 100
successRate = Math.max(0, Math.min(100, successRate));

// ============================================================
// ⚙️ CALCULS D’ANGLES
// ============================================================
const baseAngle = (successRate / 100) * (maxAngle - minAngle) + minAngle;
const angleMin = baseAngle - oscillationRange;
const angleMax = baseAngle + oscillationRange;

const previousRate = window.lastSuccessRate ?? successRate;
window.lastSuccessRate = successRate;
const goingUp = successRate >= previousRate;
const targetAngle = goingUp ? angleMax : angleMin;

// ============================================================
// 🧹 ARRÊTE LES ANIMATIONS EXISTANTES
// ============================================================
gsap.killTweensOf(pointer);

// ============================================================
// 🚀 ANIMATION DE L’AIGUILLE
// ============================================================
gsap.to(pointer, {
  rotation: targetAngle,
  duration: 1.2,
  ease: "power2.inOut",
  onComplete: () => {
    gsap.to(pointer, {
      rotation: goingUp ? angleMin : angleMax,
      duration: oscillationSpeed,
      ease: "sine.inOut",
      yoyo: true,
      repeat: -1
    });
  }
});

// ============================================================
// 💬 FEEDBACK MOTIVATIONNEL — TON PROFESSIONNEL
// ============================================================
const feedbacks = {
  low: [
    "Poursuivez vos efforts !"
  ],
  mediumLow: [
    "C'est un début !"
  ],
  medium: [
    "Vous êtes sur la bonne voie !",
    "Continuez comme ça !"
  ],
  mediumHigh: [
    "Très bon travail !",
    "C'est super !"
  ],
  perfect: [
    "Excellent !",
    "C'est parfait !",
    "Félicitations !"
  ]
};

// -------- Sélection du bon groupe --------
let chosenList;

if (successRate < 25) {
  chosenList = feedbacks.low;
} else if (successRate < 50) {
  chosenList = feedbacks.mediumLow;
} else if (successRate < 75) {
  chosenList = feedbacks.medium;
} else if (successRate < 100) {
  chosenList = feedbacks.mediumHigh;
} else {
  chosenList = feedbacks.perfect;
}

// -------- Sélection aléatoire d’un message --------
const feedback = chosenList[Math.floor(Math.random() * chosenList.length)];

// -------- Envoi vers Storyline --------
setVar("Ex_Feedback_Motivation", feedback);

// ============================================================
// 💡 CHANGEMENT D’ÉTAT DE L’INDICATEUR VISUEL (success_Bars)
// ============================================================
if (success_Bars) {
  let state = "Failure";

  if (successRate >= 70) {
    state = "Success";
  } else if (successRate >= 40) {
    state = "Medium";
  }

  if (success_Bars.state !== state) {
    success_Bars.state = state;
    console.log(`🎨 success_Bars → état défini sur "${state}"`);
  }
}

// ============================================================
// 🧾 LOGS DE CONTRÔLE
// ============================================================
console.log(`📊 Séquence : ${seqKey}`);
console.log(`📈 Historique : "${historique}"`);
console.log(`✅ Taux de réussite : ${successRate}%`);
console.log(`💬 Feedback choisi : "${feedback}"`);
console.log(`🎯 Angle : ${baseAngle.toFixed(1)}°`);
console.log(`🌊 Oscillation : ${angleMin.toFixed(1)}° ↔ ${angleMax.toFixed(1)}°`);

}

window.Script354 = function()
{
  // ============================================================
// ♻️ RÉINITIALISATION — Remplace tous les 0 et 1 par "n" dans Sx_Win_Lose
// ============================================================

// -------- VARIABLES STORYLINE --------
const seqPos = getVar("0_Position_Sequence"); // ex: "1", "2", "3", "4"
const seqKey = `S${seqPos}`;                  // ex: "S1"
const varName = `${seqKey}_Win_Lose`;         // ex: "S1_Win_Lose"

// -------- RÉCUPÉRATION --------
const historique = getVar(varName) || "";     // ex: "110010"

// -------- SÉCURITÉ --------
if (!historique) {
  console.warn(`⚠️ Impossible de réinitialiser — ${varName} est vide ou non défini.`);
  return;
}

// ============================================================
// 🧮 RÉINITIALISATION DE LA CHAÎNE
// ============================================================

// Remplace tous les caractères 1 ou 0 par "n"
const resetHistorique = historique.replace(/[10]/g, "n");

// ============================================================
// 💾 MISE À JOUR STORYLINE
// ============================================================
setVar(varName, resetHistorique);

// ============================================================
// 🧾 LOGS DE CONTRÔLE
// ============================================================
console.log(`♻️ ${varName} réinitialisé :`);
console.log(`Avant : "${historique}"`);
console.log(`Après  : "${resetHistorique}"`);

}

window.Script355 = function()
{
  // ============================================================
// ♻️ RÉINITIALISATION — Remplace tous les 0 et 1 par "n" dans Sx_Win_Lose
// ============================================================

// -------- VARIABLES STORYLINE --------
const seqPos = getVar("0_Position_Sequence"); // ex: "1", "2", "3", "4"
const seqKey = `S${seqPos}`;                  // ex: "S1"
const varName = `${seqKey}_Win_Lose`;         // ex: "S1_Win_Lose"

// -------- RÉCUPÉRATION --------
const historique = getVar(varName) || "";     // ex: "110010"

// -------- SÉCURITÉ --------
if (!historique) {
  console.warn(`⚠️ Impossible de réinitialiser — ${varName} est vide ou non défini.`);
  return;
}

// ============================================================
// 🧮 RÉINITIALISATION DE LA CHAÎNE
// ============================================================

// Remplace tous les caractères 1 ou 0 par "n"
const resetHistorique = historique.replace(/[10]/g, "n");

// ============================================================
// 💾 MISE À JOUR STORYLINE
// ============================================================
setVar(varName, resetHistorique);

// ============================================================
// 🧾 LOGS DE CONTRÔLE
// ============================================================
console.log(`♻️ ${varName} réinitialisé :`);
console.log(`Avant : "${historique}"`);
console.log(`Après  : "${resetHistorique}"`);

}

window.Script356 = function()
{
  // ============================================================
// 🎯 RÉVISER — ALLER AU PREMIER EXERCICE ÉCHOUÉ ("0")
// ============================================================

// -------- VARIABLES STORYLINE --------
const seqPos = getVar("0_Position_Sequence"); // ex: "1", "2", "3", "4"
const seqKey = `S${seqPos}`;                  // ex: "S1"
const historique = getVar(`${seqKey}_Win_Lose`) || ""; // ex: "110010"

// -------- SÉCURITÉ --------
if (!seqPos || !historique) {
  console.warn("⚠️ Impossible de lancer la révision : séquence ou historique manquant.");
  return;
}

// ============================================================
// 🔍 RECHERCHE DU PREMIER ÉCHEC ("0")
// ============================================================
const firstFailIndex = historique.indexOf("0");

if (firstFailIndex === -1) {
  console.log("🎉 Aucun exercice échoué à réviser — tout est réussi !");
  return;
}

// ============================================================
// 🎯 MISE À JOUR DE LA POSITION
// ============================================================
// Les exercices sont 1-based → on ajoute +1 à l’index trouvé
const firstExercise = firstFailIndex + 1;
setVar("0_Position_Exercice", firstExercise);

// ============================================================
// 🧾 LOG DE CONTRÔLE
// ============================================================
console.log(`🔁 Révision lancée → Premier exercice échoué : EX${firstExercise}`);
console.log(`(Séquence : ${seqKey}, Historique : "${historique}")`);

}

window.Script357 = function()
{
  // --------- Lecture de la séquence courante ---------
const seqPos = getVar("0_Position_Sequence");   // ex. 1 → S1
setVar(`S${seqPos}_Exo_Current`, 0);
setVar(`0_Menu_S${seqPos}_Completed`, true);
}

window.Script358 = function()
{
  // ============================================================
// 🎯 ANIMATION DE JAUGE — Rotation + Oscillation continue + Feedback motivationnel + Indicateur visuel
// ============================================================

// -------- OBJETS STORYLINE --------
const pointer = object('6dihA7DPv6j');    // Aiguille
const success_Bars = object('5XZJ7HKLCZ3'); // Indicateur visuel (barres de succès)

// -------- PARAMÈTRES --------
const minAngle = 0;
const maxAngle = 180;
const oscillationRange = 10;
const oscillationSpeed = 1.5;

// -------- VARIABLES STORYLINE --------
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;
const historique = getVar(`${seqKey}_Win_Lose`) || "";

// ============================================================
// 🧮 CALCUL DU POURCENTAGE DE RÉUSSITE
// ============================================================
let successRate = 0;

if (historique.length > 0) {
  const total = historique.length;
  const wins = (historique.match(/1/g) || []).length;
  successRate = Math.round((wins / total) * 100);
  setVar("S0_Success_Rate", successRate);
} else {
  console.warn("⚠️ Aucune donnée trouvée dans", `${seqKey}_Win_Lose`);
}

// Clamp entre 0 et 100
successRate = Math.max(0, Math.min(100, successRate));

// ============================================================
// ⚙️ CALCULS D’ANGLES
// ============================================================
const baseAngle = (successRate / 100) * (maxAngle - minAngle) + minAngle;
const angleMin = baseAngle - oscillationRange;
const angleMax = baseAngle + oscillationRange;

const previousRate = window.lastSuccessRate ?? successRate;
window.lastSuccessRate = successRate;
const goingUp = successRate >= previousRate;
const targetAngle = goingUp ? angleMax : angleMin;

// ============================================================
// 🧹 ARRÊTE LES ANIMATIONS EXISTANTES
// ============================================================
gsap.killTweensOf(pointer);

// ============================================================
// 🚀 ANIMATION DE L’AIGUILLE
// ============================================================
gsap.to(pointer, {
  rotation: targetAngle,
  duration: 1.2,
  ease: "power2.inOut",
  onComplete: () => {
    gsap.to(pointer, {
      rotation: goingUp ? angleMin : angleMax,
      duration: oscillationSpeed,
      ease: "sine.inOut",
      yoyo: true,
      repeat: -1
    });
  }
});

// ============================================================
// 💬 FEEDBACK MOTIVATIONNEL — TON PROFESSIONNEL
// ============================================================
const feedbacks = {
  low: [
    "Poursuivez vos efforts !"
  ],
  mediumLow: [
    "C'est un début !"
  ],
  medium: [
    "Vous êtes sur la bonne voie !",
    "Continuez comme ça !"
  ],
  mediumHigh: [
    "Très bon travail !",
    "C'est super !"
  ],
  perfect: [
    "Excellent !",
    "C'est parfait !",
    "Félicitations !"
  ]
};

// -------- Sélection du bon groupe --------
let chosenList;

if (successRate < 25) {
  chosenList = feedbacks.low;
} else if (successRate < 50) {
  chosenList = feedbacks.mediumLow;
} else if (successRate < 75) {
  chosenList = feedbacks.medium;
} else if (successRate < 100) {
  chosenList = feedbacks.mediumHigh;
} else {
  chosenList = feedbacks.perfect;
}

// -------- Sélection aléatoire d’un message --------
const feedback = chosenList[Math.floor(Math.random() * chosenList.length)];

// -------- Envoi vers Storyline --------
setVar("Ex_Feedback_Motivation", feedback);

// ============================================================
// 💡 CHANGEMENT D’ÉTAT DE L’INDICATEUR VISUEL (success_Bars)
// ============================================================
if (success_Bars) {
  let state = "Failure";

  if (successRate >= 70) {
    state = "Success";
  } else if (successRate >= 40) {
    state = "Medium";
  }

  if (success_Bars.state !== state) {
    success_Bars.state = state;
    console.log(`🎨 success_Bars → état défini sur "${state}"`);
  }
}

// ============================================================
// 🧾 LOGS DE CONTRÔLE
// ============================================================
console.log(`📊 Séquence : ${seqKey}`);
console.log(`📈 Historique : "${historique}"`);
console.log(`✅ Taux de réussite : ${successRate}%`);
console.log(`💬 Feedback choisi : "${feedback}"`);
console.log(`🎯 Angle : ${baseAngle.toFixed(1)}°`);
console.log(`🌊 Oscillation : ${angleMin.toFixed(1)}° ↔ ${angleMax.toFixed(1)}°`);

}

window.Script359 = function()
{
  // ============================================================
// ♻️ RÉINITIALISATION — Remplace tous les 0 et 1 par "n" dans Sx_Win_Lose
// ============================================================

// -------- VARIABLES STORYLINE --------
const seqPos = getVar("0_Position_Sequence"); // ex: "1", "2", "3", "4"
const seqKey = `S${seqPos}`;                  // ex: "S1"
const varName = `${seqKey}_Win_Lose`;         // ex: "S1_Win_Lose"

// -------- RÉCUPÉRATION --------
const historique = getVar(varName) || "";     // ex: "110010"

// -------- SÉCURITÉ --------
if (!historique) {
  console.warn(`⚠️ Impossible de réinitialiser — ${varName} est vide ou non défini.`);
  return;
}

// ============================================================
// 🧮 RÉINITIALISATION DE LA CHAÎNE
// ============================================================

// Remplace tous les caractères 1 ou 0 par "n"
const resetHistorique = historique.replace(/[10]/g, "n");

// ============================================================
// 💾 MISE À JOUR STORYLINE
// ============================================================
setVar(varName, resetHistorique);

// ============================================================
// 🧾 LOGS DE CONTRÔLE
// ============================================================
console.log(`♻️ ${varName} réinitialisé :`);
console.log(`Avant : "${historique}"`);
console.log(`Après  : "${resetHistorique}"`);

}

window.Script360 = function()
{
  // ============================================================
// ♻️ RÉINITIALISATION — Remplace tous les 0 et 1 par "n" dans Sx_Win_Lose
// ============================================================

// -------- VARIABLES STORYLINE --------
const seqPos = getVar("0_Position_Sequence"); // ex: "1", "2", "3", "4"
const seqKey = `S${seqPos}`;                  // ex: "S1"
const varName = `${seqKey}_Win_Lose`;         // ex: "S1_Win_Lose"

// -------- RÉCUPÉRATION --------
const historique = getVar(varName) || "";     // ex: "110010"

// -------- SÉCURITÉ --------
if (!historique) {
  console.warn(`⚠️ Impossible de réinitialiser — ${varName} est vide ou non défini.`);
  return;
}

// ============================================================
// 🧮 RÉINITIALISATION DE LA CHAÎNE
// ============================================================

// Remplace tous les caractères 1 ou 0 par "n"
const resetHistorique = historique.replace(/[10]/g, "n");

// ============================================================
// 💾 MISE À JOUR STORYLINE
// ============================================================
setVar(varName, resetHistorique);

// ============================================================
// 🧾 LOGS DE CONTRÔLE
// ============================================================
console.log(`♻️ ${varName} réinitialisé :`);
console.log(`Avant : "${historique}"`);
console.log(`Après  : "${resetHistorique}"`);

}

window.Script361 = function()
{
  // ============================================================
// 🎯 RÉVISER — ALLER AU PREMIER EXERCICE ÉCHOUÉ ("0")
// ============================================================

// -------- VARIABLES STORYLINE --------
const seqPos = getVar("0_Position_Sequence"); // ex: "1", "2", "3", "4"
const seqKey = `S${seqPos}`;                  // ex: "S1"
const historique = getVar(`${seqKey}_Win_Lose`) || ""; // ex: "110010"

// -------- SÉCURITÉ --------
if (!seqPos || !historique) {
  console.warn("⚠️ Impossible de lancer la révision : séquence ou historique manquant.");
  return;
}

// ============================================================
// 🔍 RECHERCHE DU PREMIER ÉCHEC ("0")
// ============================================================
const firstFailIndex = historique.indexOf("0");

if (firstFailIndex === -1) {
  console.log("🎉 Aucun exercice échoué à réviser — tout est réussi !");
  return;
}

// ============================================================
// 🎯 MISE À JOUR DE LA POSITION
// ============================================================
// Les exercices sont 1-based → on ajoute +1 à l’index trouvé
const firstExercise = firstFailIndex + 1;
setVar("0_Position_Exercice", firstExercise);

// ============================================================
// 🧾 LOG DE CONTRÔLE
// ============================================================
console.log(`🔁 Révision lancée → Premier exercice échoué : EX${firstExercise}`);
console.log(`(Séquence : ${seqKey}, Historique : "${historique}")`);

}

window.Script362 = function()
{
  // --------- Lecture de la séquence courante ---------
const seqPos = getVar("0_Position_Sequence");   // ex. 1 → S1
setVar(`S${seqPos}_Exo_Current`, 0);
setVar(`0_Menu_S${seqPos}_Completed`, true);
}

window.Script363 = function()
{
  // ============================================================
// 🎯 ANIMATION DE JAUGE — Rotation + Oscillation continue + Feedback motivationnel + Indicateur visuel
// ============================================================

// -------- OBJETS STORYLINE --------
const pointer = object('6jeTtTsD6bw');    // Aiguille
const success_Bars = object('6mhL0xb4PHc'); // Indicateur visuel (barres de succès)

// -------- PARAMÈTRES --------
const minAngle = 0;
const maxAngle = 180;
const oscillationRange = 10;
const oscillationSpeed = 1.5;

// -------- VARIABLES STORYLINE --------
const seqPos = getVar("0_Position_Sequence");
const seqKey = `S${seqPos}`;
const historique = getVar(`${seqKey}_Win_Lose`) || "";

// ============================================================
// 🧮 CALCUL DU POURCENTAGE DE RÉUSSITE
// ============================================================
let successRate = 0;

if (historique.length > 0) {
  const total = historique.length;
  const wins = (historique.match(/1/g) || []).length;
  successRate = Math.round((wins / total) * 100);
  setVar("S0_Success_Rate", successRate);
} else {
  console.warn("⚠️ Aucune donnée trouvée dans", `${seqKey}_Win_Lose`);
}

// Clamp entre 0 et 100
successRate = Math.max(0, Math.min(100, successRate));

// ============================================================
// ⚙️ CALCULS D’ANGLES
// ============================================================
const baseAngle = (successRate / 100) * (maxAngle - minAngle) + minAngle;
const angleMin = baseAngle - oscillationRange;
const angleMax = baseAngle + oscillationRange;

const previousRate = window.lastSuccessRate ?? successRate;
window.lastSuccessRate = successRate;
const goingUp = successRate >= previousRate;
const targetAngle = goingUp ? angleMax : angleMin;

// ============================================================
// 🧹 ARRÊTE LES ANIMATIONS EXISTANTES
// ============================================================
gsap.killTweensOf(pointer);

// ============================================================
// 🚀 ANIMATION DE L’AIGUILLE
// ============================================================
gsap.to(pointer, {
  rotation: targetAngle,
  duration: 1.2,
  ease: "power2.inOut",
  onComplete: () => {
    gsap.to(pointer, {
      rotation: goingUp ? angleMin : angleMax,
      duration: oscillationSpeed,
      ease: "sine.inOut",
      yoyo: true,
      repeat: -1
    });
  }
});

// ============================================================
// 💬 FEEDBACK MOTIVATIONNEL — TON PROFESSIONNEL
// ============================================================
const feedbacks = {
  low: [
    "Poursuivez vos efforts !"
  ],
  mediumLow: [
    "C'est un début !"
  ],
  medium: [
    "Vous êtes sur la bonne voie !",
    "Continuez comme ça !"
  ],
  mediumHigh: [
    "Très bon travail !",
    "C'est super !"
  ],
  perfect: [
    "Excellent !",
    "C'est parfait !",
    "Félicitations !"
  ]
};

// -------- Sélection du bon groupe --------
let chosenList;

if (successRate < 25) {
  chosenList = feedbacks.low;
} else if (successRate < 50) {
  chosenList = feedbacks.mediumLow;
} else if (successRate < 75) {
  chosenList = feedbacks.medium;
} else if (successRate < 100) {
  chosenList = feedbacks.mediumHigh;
} else {
  chosenList = feedbacks.perfect;
}

// -------- Sélection aléatoire d’un message --------
const feedback = chosenList[Math.floor(Math.random() * chosenList.length)];

// -------- Envoi vers Storyline --------
setVar("Ex_Feedback_Motivation", feedback);

// ============================================================
// 💡 CHANGEMENT D’ÉTAT DE L’INDICATEUR VISUEL (success_Bars)
// ============================================================
if (success_Bars) {
  let state = "Failure";

  if (successRate >= 70) {
    state = "Success";
  } else if (successRate >= 40) {
    state = "Medium";
  }

  if (success_Bars.state !== state) {
    success_Bars.state = state;
    console.log(`🎨 success_Bars → état défini sur "${state}"`);
  }
}

// ============================================================
// 🧾 LOGS DE CONTRÔLE
// ============================================================
console.log(`📊 Séquence : ${seqKey}`);
console.log(`📈 Historique : "${historique}"`);
console.log(`✅ Taux de réussite : ${successRate}%`);
console.log(`💬 Feedback choisi : "${feedback}"`);
console.log(`🎯 Angle : ${baseAngle.toFixed(1)}°`);
console.log(`🌊 Oscillation : ${angleMin.toFixed(1)}° ↔ ${angleMax.toFixed(1)}°`);

}

window.Script364 = function()
{
  // ============================================================
// ♻️ RÉINITIALISATION — Remplace tous les 0 et 1 par "n" dans Sx_Win_Lose
// ============================================================

// -------- VARIABLES STORYLINE --------
const seqPos = getVar("0_Position_Sequence"); // ex: "1", "2", "3", "4"
const seqKey = `S${seqPos}`;                  // ex: "S1"
const varName = `${seqKey}_Win_Lose`;         // ex: "S1_Win_Lose"

// -------- RÉCUPÉRATION --------
const historique = getVar(varName) || "";     // ex: "110010"

// -------- SÉCURITÉ --------
if (!historique) {
  console.warn(`⚠️ Impossible de réinitialiser — ${varName} est vide ou non défini.`);
  return;
}

// ============================================================
// 🧮 RÉINITIALISATION DE LA CHAÎNE
// ============================================================

// Remplace tous les caractères 1 ou 0 par "n"
const resetHistorique = historique.replace(/[10]/g, "n");

// ============================================================
// 💾 MISE À JOUR STORYLINE
// ============================================================
setVar(varName, resetHistorique);

// ============================================================
// 🧾 LOGS DE CONTRÔLE
// ============================================================
console.log(`♻️ ${varName} réinitialisé :`);
console.log(`Avant : "${historique}"`);
console.log(`Après  : "${resetHistorique}"`);

}

window.Script365 = function()
{
  // ============================================================
// ♻️ RÉINITIALISATION — Remplace tous les 0 et 1 par "n" dans Sx_Win_Lose
// ============================================================

// -------- VARIABLES STORYLINE --------
const seqPos = getVar("0_Position_Sequence"); // ex: "1", "2", "3", "4"
const seqKey = `S${seqPos}`;                  // ex: "S1"
const varName = `${seqKey}_Win_Lose`;         // ex: "S1_Win_Lose"

// -------- RÉCUPÉRATION --------
const historique = getVar(varName) || "";     // ex: "110010"

// -------- SÉCURITÉ --------
if (!historique) {
  console.warn(`⚠️ Impossible de réinitialiser — ${varName} est vide ou non défini.`);
  return;
}

// ============================================================
// 🧮 RÉINITIALISATION DE LA CHAÎNE
// ============================================================

// Remplace tous les caractères 1 ou 0 par "n"
const resetHistorique = historique.replace(/[10]/g, "n");

// ============================================================
// 💾 MISE À JOUR STORYLINE
// ============================================================
setVar(varName, resetHistorique);

// ============================================================
// 🧾 LOGS DE CONTRÔLE
// ============================================================
console.log(`♻️ ${varName} réinitialisé :`);
console.log(`Avant : "${historique}"`);
console.log(`Après  : "${resetHistorique}"`);

}

window.Script366 = function()
{
  // ============================================================
// 🎯 RÉVISER — ALLER AU PREMIER EXERCICE ÉCHOUÉ ("0")
// ============================================================

// -------- VARIABLES STORYLINE --------
const seqPos = getVar("0_Position_Sequence"); // ex: "1", "2", "3", "4"
const seqKey = `S${seqPos}`;                  // ex: "S1"
const historique = getVar(`${seqKey}_Win_Lose`) || ""; // ex: "110010"

// -------- SÉCURITÉ --------
if (!seqPos || !historique) {
  console.warn("⚠️ Impossible de lancer la révision : séquence ou historique manquant.");
  return;
}

// ============================================================
// 🔍 RECHERCHE DU PREMIER ÉCHEC ("0")
// ============================================================
const firstFailIndex = historique.indexOf("0");

if (firstFailIndex === -1) {
  console.log("🎉 Aucun exercice échoué à réviser — tout est réussi !");
  return;
}

// ============================================================
// 🎯 MISE À JOUR DE LA POSITION
// ============================================================
// Les exercices sont 1-based → on ajoute +1 à l’index trouvé
const firstExercise = firstFailIndex + 1;
setVar("0_Position_Exercice", firstExercise);

// ============================================================
// 🧾 LOG DE CONTRÔLE
// ============================================================
console.log(`🔁 Révision lancée → Premier exercice échoué : EX${firstExercise}`);
console.log(`(Séquence : ${seqKey}, Historique : "${historique}")`);

}

window.Script367 = function()
{
  // ============================================================
// ♻️ RÉINITIALISATION — Remplace tous les 0 et 1 par "n" dans Sx_Win_Lose
// ============================================================

// -------- VARIABLES STORYLINE --------
const seqPos = getVar("0_Position_Sequence"); // ex: "1", "2", "3", "4"
const seqKey = `S${seqPos}`;                  // ex: "S1"
const varName = `${seqKey}_Win_Lose`;         // ex: "S1_Win_Lose"

// -------- RÉCUPÉRATION --------
const historique = getVar(varName) || "";     // ex: "110010"

// -------- SÉCURITÉ --------
if (!historique) {
  console.warn(`⚠️ Impossible de réinitialiser — ${varName} est vide ou non défini.`);
  return;
}

// ============================================================
// 🧮 RÉINITIALISATION DE LA CHAÎNE
// ============================================================

// Remplace tous les caractères 1 ou 0 par "n"
const resetHistorique = historique.replace(/[10]/g, "n");

// ============================================================
// 💾 MISE À JOUR STORYLINE
// ============================================================
setVar(varName, resetHistorique);

// ============================================================
// 🧾 LOGS DE CONTRÔLE
// ============================================================
console.log(`♻️ ${varName} réinitialisé :`);
console.log(`Avant : "${historique}"`);
console.log(`Après  : "${resetHistorique}"`);

}

window.Script368 = function()
{
  // ============================================================
// ♻️ RÉINITIALISATION — Remplace tous les 0 et 1 par "n" dans Sx_Win_Lose
// ============================================================

// -------- VARIABLES STORYLINE --------
const seqPos = getVar("0_Position_Sequence"); // ex: "1", "2", "3", "4"
const seqKey = `S${seqPos}`;                  // ex: "S1"
const varName = `${seqKey}_Win_Lose`;         // ex: "S1_Win_Lose"

// -------- RÉCUPÉRATION --------
const historique = getVar(varName) || "";     // ex: "110010"

// -------- SÉCURITÉ --------
if (!historique) {
  console.warn(`⚠️ Impossible de réinitialiser — ${varName} est vide ou non défini.`);
  return;
}

// ============================================================
// 🧮 RÉINITIALISATION DE LA CHAÎNE
// ============================================================

// Remplace tous les caractères 1 ou 0 par "n"
const resetHistorique = historique.replace(/[10]/g, "n");

// ============================================================
// 💾 MISE À JOUR STORYLINE
// ============================================================
setVar(varName, resetHistorique);

// ============================================================
// 🧾 LOGS DE CONTRÔLE
// ============================================================
console.log(`♻️ ${varName} réinitialisé :`);
console.log(`Avant : "${historique}"`);
console.log(`Après  : "${resetHistorique}"`);

}

window.Script369 = function()
{
  // ============================================================
// 🎯 RÉVISER — ALLER AU PREMIER EXERCICE ÉCHOUÉ ("0")
// ============================================================

// -------- VARIABLES STORYLINE --------
const seqPos = getVar("0_Position_Sequence"); // ex: "1", "2", "3", "4"
const seqKey = `S${seqPos}`;                  // ex: "S1"
const historique = getVar(`${seqKey}_Win_Lose`) || ""; // ex: "110010"

// -------- SÉCURITÉ --------
if (!seqPos || !historique) {
  console.warn("⚠️ Impossible de lancer la révision : séquence ou historique manquant.");
  return;
}

// ============================================================
// 🔍 RECHERCHE DU PREMIER ÉCHEC ("0")
// ============================================================
const firstFailIndex = historique.indexOf("0");

if (firstFailIndex === -1) {
  console.log("🎉 Aucun exercice échoué à réviser — tout est réussi !");
  return;
}

// ============================================================
// 🎯 MISE À JOUR DE LA POSITION
// ============================================================
// Les exercices sont 1-based → on ajoute +1 à l’index trouvé
const firstExercise = firstFailIndex + 1;
setVar("0_Position_Exercice", firstExercise);

// ============================================================
// 🧾 LOG DE CONTRÔLE
// ============================================================
console.log(`🔁 Révision lancée → Premier exercice échoué : EX${firstExercise}`);
console.log(`(Séquence : ${seqKey}, Historique : "${historique}")`);

}

window.Script370 = function()
{
  // ============================================================
// ♻️ RÉINITIALISATION — Remplace tous les 0 et 1 par "n" dans Sx_Win_Lose
// ============================================================

// -------- VARIABLES STORYLINE --------
const seqPos = getVar("0_Position_Sequence"); // ex: "1", "2", "3", "4"
const seqKey = `S${seqPos}`;                  // ex: "S1"
const varName = `${seqKey}_Win_Lose`;         // ex: "S1_Win_Lose"

// -------- RÉCUPÉRATION --------
const historique = getVar(varName) || "";     // ex: "110010"

// -------- SÉCURITÉ --------
if (!historique) {
  console.warn(`⚠️ Impossible de réinitialiser — ${varName} est vide ou non défini.`);
  return;
}

// ============================================================
// 🧮 RÉINITIALISATION DE LA CHAÎNE
// ============================================================

// Remplace tous les caractères 1 ou 0 par "n"
const resetHistorique = historique.replace(/[10]/g, "n");

// ============================================================
// 💾 MISE À JOUR STORYLINE
// ============================================================
setVar(varName, resetHistorique);

// ============================================================
// 🧾 LOGS DE CONTRÔLE
// ============================================================
console.log(`♻️ ${varName} réinitialisé :`);
console.log(`Avant : "${historique}"`);
console.log(`Après  : "${resetHistorique}"`);

}

window.Script371 = function()
{
  // ============================================================
// ♻️ RÉINITIALISATION — Remplace tous les 0 et 1 par "n" dans Sx_Win_Lose
// ============================================================

// -------- VARIABLES STORYLINE --------
const seqPos = getVar("0_Position_Sequence"); // ex: "1", "2", "3", "4"
const seqKey = `S${seqPos}`;                  // ex: "S1"
const varName = `${seqKey}_Win_Lose`;         // ex: "S1_Win_Lose"

// -------- RÉCUPÉRATION --------
const historique = getVar(varName) || "";     // ex: "110010"

// -------- SÉCURITÉ --------
if (!historique) {
  console.warn(`⚠️ Impossible de réinitialiser — ${varName} est vide ou non défini.`);
  return;
}

// ============================================================
// 🧮 RÉINITIALISATION DE LA CHAÎNE
// ============================================================

// Remplace tous les caractères 1 ou 0 par "n"
const resetHistorique = historique.replace(/[10]/g, "n");

// ============================================================
// 💾 MISE À JOUR STORYLINE
// ============================================================
setVar(varName, resetHistorique);

// ============================================================
// 🧾 LOGS DE CONTRÔLE
// ============================================================
console.log(`♻️ ${varName} réinitialisé :`);
console.log(`Avant : "${historique}"`);
console.log(`Après  : "${resetHistorique}"`);

}

window.Script372 = function()
{
  // ============================================================
// 🎯 RÉVISER — ALLER AU PREMIER EXERCICE ÉCHOUÉ ("0")
// ============================================================

// -------- VARIABLES STORYLINE --------
const seqPos = getVar("0_Position_Sequence"); // ex: "1", "2", "3", "4"
const seqKey = `S${seqPos}`;                  // ex: "S1"
const historique = getVar(`${seqKey}_Win_Lose`) || ""; // ex: "110010"

// -------- SÉCURITÉ --------
if (!seqPos || !historique) {
  console.warn("⚠️ Impossible de lancer la révision : séquence ou historique manquant.");
  return;
}

// ============================================================
// 🔍 RECHERCHE DU PREMIER ÉCHEC ("0")
// ============================================================
const firstFailIndex = historique.indexOf("0");

if (firstFailIndex === -1) {
  console.log("🎉 Aucun exercice échoué à réviser — tout est réussi !");
  return;
}

// ============================================================
// 🎯 MISE À JOUR DE LA POSITION
// ============================================================
// Les exercices sont 1-based → on ajoute +1 à l’index trouvé
const firstExercise = firstFailIndex + 1;
setVar("0_Position_Exercice", firstExercise);

// ============================================================
// 🧾 LOG DE CONTRÔLE
// ============================================================
console.log(`🔁 Révision lancée → Premier exercice échoué : EX${firstExercise}`);
console.log(`(Séquence : ${seqKey}, Historique : "${historique}")`);

}

window.Script373 = function()
{
  // ============================================================
// 🎯 ANIMATION DE JAUGE — Rotation + Oscillation continue (sans couleur)
// ============================================================

// -------- OBJET STORYLINE --------
const pointer = object('6ZvdYiYNisr'); // Aiguille

// -------- PARAMÈTRES --------
const varName = "Gauge_Test";   // Variable Storyline (0 → 100)
const minValue = 0;             // Valeur minimale
const maxValue = 100;           // Valeur maximale
const minAngle = 0;             // Angle à 0%
const maxAngle = 180;           // Angle à 100%
const oscillationRange = 10;    // Amplitude (°)
const oscillationSpeed = 1.5;   // Durée d’un cycle complet (s)

// ============================================================
// 🧹 ARRÊTE LES ANIMATIONS EXISTANTES
// ============================================================
gsap.killTweensOf(pointer);

// ============================================================
// ⚙️ CALCULS INITIAUX
// ============================================================
const value = parseFloat(getVar(varName)) || 0;
const clampedValue = Math.max(minValue, Math.min(maxValue, value));
const baseAngle = (clampedValue / maxValue) * (maxAngle - minAngle) + minAngle;

const angleMin = baseAngle - oscillationRange;
const angleMax = baseAngle + oscillationRange;

// Direction (si la valeur a augmenté ou diminué)
const previousValue = window.lastGaugeValue ?? clampedValue;
window.lastGaugeValue = clampedValue;
const goingUp = clampedValue >= previousValue;
const targetAngle = goingUp ? angleMax : angleMin;

// ============================================================
// 🚀 ANIMATION DE L’AIGUILLE
// ============================================================

// 1️⃣ Transition douce vers la nouvelle valeur
gsap.to(pointer, {
  rotation: targetAngle,
  duration: 1.2,
  ease: "power2.inOut",
  onComplete: () => {
    console.log("✅ Aiguille positionnée, oscillation lancée...");

    // 2️⃣ Oscillation continue autour de la position cible
    gsap.to(pointer, {
      rotation: goingUp ? angleMin : angleMax,
      duration: oscillationSpeed,
      ease: "sine.inOut",
      yoyo: true,
      repeat: -1
    });
  }
});

// ============================================================
// 🧾 LOGS (optionnels)
// ============================================================
console.log(`🧭 Gauge_Test = ${clampedValue} (prev: ${previousValue})`);
console.log(`🎯 Angle cible = ${baseAngle.toFixed(1)}°`);
console.log(`🌊 Oscillation entre ${angleMin.toFixed(1)}° ↔ ${angleMax.toFixed(1)}°`);
console.log(`📈 Mouvement = ${goingUp ? "montée → MAX" : "descente → MIN"}`);

}

window.Script374 = function()
{
  // ============================================================
// ♻️ RÉINITIALISATION — Remplace tous les 0 et 1 par "n" dans Sx_Win_Lose
// ============================================================

// -------- VARIABLES STORYLINE --------
const seqPos = getVar("0_Position_Sequence"); // ex: "1", "2", "3", "4"
const seqKey = `S${seqPos}`;                  // ex: "S1"
const varName = `${seqKey}_Win_Lose`;         // ex: "S1_Win_Lose"

// -------- RÉCUPÉRATION --------
const historique = getVar(varName) || "";     // ex: "110010"

// -------- SÉCURITÉ --------
if (!historique) {
  console.warn(`⚠️ Impossible de réinitialiser — ${varName} est vide ou non défini.`);
  return;
}

// ============================================================
// 🧮 RÉINITIALISATION DE LA CHAÎNE
// ============================================================

// Remplace tous les caractères 1 ou 0 par "n"
const resetHistorique = historique.replace(/[10]/g, "n");

// ============================================================
// 💾 MISE À JOUR STORYLINE
// ============================================================
setVar(varName, resetHistorique);

// ============================================================
// 🧾 LOGS DE CONTRÔLE
// ============================================================
console.log(`♻️ ${varName} réinitialisé :`);
console.log(`Avant : "${historique}"`);
console.log(`Après  : "${resetHistorique}"`);

}

window.Script375 = function()
{
  // ============================================================
// ♻️ RÉINITIALISATION — Remplace tous les 0 et 1 par "n" dans Sx_Win_Lose
// ============================================================

// -------- VARIABLES STORYLINE --------
const seqPos = getVar("0_Position_Sequence"); // ex: "1", "2", "3", "4"
const seqKey = `S${seqPos}`;                  // ex: "S1"
const varName = `${seqKey}_Win_Lose`;         // ex: "S1_Win_Lose"

// -------- RÉCUPÉRATION --------
const historique = getVar(varName) || "";     // ex: "110010"

// -------- SÉCURITÉ --------
if (!historique) {
  console.warn(`⚠️ Impossible de réinitialiser — ${varName} est vide ou non défini.`);
  return;
}

// ============================================================
// 🧮 RÉINITIALISATION DE LA CHAÎNE
// ============================================================

// Remplace tous les caractères 1 ou 0 par "n"
const resetHistorique = historique.replace(/[10]/g, "n");

// ============================================================
// 💾 MISE À JOUR STORYLINE
// ============================================================
setVar(varName, resetHistorique);

// ============================================================
// 🧾 LOGS DE CONTRÔLE
// ============================================================
console.log(`♻️ ${varName} réinitialisé :`);
console.log(`Avant : "${historique}"`);
console.log(`Après  : "${resetHistorique}"`);

}

window.Script376 = function()
{
  // ============================================================
// 🎯 RÉVISER — ALLER AU PREMIER EXERCICE ÉCHOUÉ ("0")
// ============================================================

// -------- VARIABLES STORYLINE --------
const seqPos = getVar("0_Position_Sequence"); // ex: "1", "2", "3", "4"
const seqKey = `S${seqPos}`;                  // ex: "S1"
const historique = getVar(`${seqKey}_Win_Lose`) || ""; // ex: "110010"

// -------- SÉCURITÉ --------
if (!seqPos || !historique) {
  console.warn("⚠️ Impossible de lancer la révision : séquence ou historique manquant.");
  return;
}

// ============================================================
// 🔍 RECHERCHE DU PREMIER ÉCHEC ("0")
// ============================================================
const firstFailIndex = historique.indexOf("0");

if (firstFailIndex === -1) {
  console.log("🎉 Aucun exercice échoué à réviser — tout est réussi !");
  return;
}

// ============================================================
// 🎯 MISE À JOUR DE LA POSITION
// ============================================================
// Les exercices sont 1-based → on ajoute +1 à l’index trouvé
const firstExercise = firstFailIndex + 1;
setVar("0_Position_Exercice", firstExercise);

// ============================================================
// 🧾 LOG DE CONTRÔLE
// ============================================================
console.log(`🔁 Révision lancée → Premier exercice échoué : EX${firstExercise}`);
console.log(`(Séquence : ${seqKey}, Historique : "${historique}")`);

}

window.Script377 = function()
{
  // ============================================================
// ♻️ RÉINITIALISATION — Remplace tous les 0 et 1 par "n" dans Sx_Win_Lose
// ============================================================

// -------- VARIABLES STORYLINE --------
const seqPos = getVar("0_Position_Sequence"); // ex: "1", "2", "3", "4"
const seqKey = `S${seqPos}`;                  // ex: "S1"
const varName = `${seqKey}_Win_Lose`;         // ex: "S1_Win_Lose"

// -------- RÉCUPÉRATION --------
const historique = getVar(varName) || "";     // ex: "110010"

// -------- SÉCURITÉ --------
if (!historique) {
  console.warn(`⚠️ Impossible de réinitialiser — ${varName} est vide ou non défini.`);
  return;
}

// ============================================================
// 🧮 RÉINITIALISATION DE LA CHAÎNE
// ============================================================

// Remplace tous les caractères 1 ou 0 par "n"
const resetHistorique = historique.replace(/[10]/g, "n");

// ============================================================
// 💾 MISE À JOUR STORYLINE
// ============================================================
setVar(varName, resetHistorique);

// ============================================================
// 🧾 LOGS DE CONTRÔLE
// ============================================================
console.log(`♻️ ${varName} réinitialisé :`);
console.log(`Avant : "${historique}"`);
console.log(`Après  : "${resetHistorique}"`);

}

window.Script378 = function()
{
  // ============================================================
// ♻️ RÉINITIALISATION — Remplace tous les 0 et 1 par "n" dans Sx_Win_Lose
// ============================================================

// -------- VARIABLES STORYLINE --------
const seqPos = getVar("0_Position_Sequence"); // ex: "1", "2", "3", "4"
const seqKey = `S${seqPos}`;                  // ex: "S1"
const varName = `${seqKey}_Win_Lose`;         // ex: "S1_Win_Lose"

// -------- RÉCUPÉRATION --------
const historique = getVar(varName) || "";     // ex: "110010"

// -------- SÉCURITÉ --------
if (!historique) {
  console.warn(`⚠️ Impossible de réinitialiser — ${varName} est vide ou non défini.`);
  return;
}

// ============================================================
// 🧮 RÉINITIALISATION DE LA CHAÎNE
// ============================================================

// Remplace tous les caractères 1 ou 0 par "n"
const resetHistorique = historique.replace(/[10]/g, "n");

// ============================================================
// 💾 MISE À JOUR STORYLINE
// ============================================================
setVar(varName, resetHistorique);

// ============================================================
// 🧾 LOGS DE CONTRÔLE
// ============================================================
console.log(`♻️ ${varName} réinitialisé :`);
console.log(`Avant : "${historique}"`);
console.log(`Après  : "${resetHistorique}"`);

}

window.Script379 = function()
{
  // ============================================================
// 🎯 RÉVISER — ALLER AU PREMIER EXERCICE ÉCHOUÉ ("0")
// ============================================================

// -------- VARIABLES STORYLINE --------
const seqPos = getVar("0_Position_Sequence"); // ex: "1", "2", "3", "4"
const seqKey = `S${seqPos}`;                  // ex: "S1"
const historique = getVar(`${seqKey}_Win_Lose`) || ""; // ex: "110010"

// -------- SÉCURITÉ --------
if (!seqPos || !historique) {
  console.warn("⚠️ Impossible de lancer la révision : séquence ou historique manquant.");
  return;
}

// ============================================================
// 🔍 RECHERCHE DU PREMIER ÉCHEC ("0")
// ============================================================
const firstFailIndex = historique.indexOf("0");

if (firstFailIndex === -1) {
  console.log("🎉 Aucun exercice échoué à réviser — tout est réussi !");
  return;
}

// ============================================================
// 🎯 MISE À JOUR DE LA POSITION
// ============================================================
// Les exercices sont 1-based → on ajoute +1 à l’index trouvé
const firstExercise = firstFailIndex + 1;
setVar("0_Position_Exercice", firstExercise);

// ============================================================
// 🧾 LOG DE CONTRÔLE
// ============================================================
console.log(`🔁 Révision lancée → Premier exercice échoué : EX${firstExercise}`);
console.log(`(Séquence : ${seqKey}, Historique : "${historique}")`);

}

};
