function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6ef9zw5PGx6":
        Script1();
        break;
      case "6Xd2o0DzDeR":
        Script2();
        break;
      case "6hdGFyGu8aK":
        Script3();
        break;
      case "6lYg885wOUJ":
        Script4();
        break;
      case "6Byigdv5jYx":
        Script5();
        break;
      case "6T6Ms06s8lB":
        Script6();
        break;
      case "5yV6JN9qz01":
        Script7();
        break;
      case "67qVP9jsFwo":
        Script8();
        break;
      case "68Be3VbGFZu":
        Script9();
        break;
      case "5cRKRXDtGrO":
        Script10();
        break;
      case "6KHkpHKn2c1":
        Script11();
        break;
      case "6EtmN4aBp4x":
        Script12();
        break;
      case "6PGKJImS7vY":
        Script13();
        break;
      case "65F8H8kbyHa":
        Script14();
        break;
      case "5wT776rCEx9":
        Script15();
        break;
      case "5vonrADsVAm":
        Script16();
        break;
      case "6gNIKYPI9SI":
        Script17();
        break;
      case "6Jfq0zvyKQ0":
        Script18();
        break;
      case "6BhyWqyFIBD":
        Script19();
        break;
      case "6BUB34Q1c0r":
        Script20();
        break;
      case "5vhiplY7jnQ":
        Script21();
        break;
      case "6pvpqpiKgh2":
        Script22();
        break;
      case "6LyIL599lts":
        Script23();
        break;
      case "6LVlB1FTddQ":
        Script24();
        break;
      case "63oQuoNPbxt":
        Script25();
        break;
      case "6UB0ZjQGAFj":
        Script26();
        break;
      case "6ZtiTNJ0Y03":
        Script27();
        break;
      case "5h9eOrZj77E":
        Script28();
        break;
      case "62Dyhcc4lMJ":
        Script29();
        break;
      case "6Aihx5N6C2S":
        Script30();
        break;
      case "67YWhUTxmMI":
        Script31();
        break;
      case "6f6KY6Zdx5r":
        Script32();
        break;
      case "6Yjvw29nu6J":
        Script33();
        break;
      case "68pGvgmPbDK":
        Script34();
        break;
      case "6YHdjPFVc0E":
        Script35();
        break;
      case "6JduQFL9GZq":
        Script36();
        break;
      case "6kOuVLPyemp":
        Script37();
        break;
      case "611rRs2iasK":
        Script38();
        break;
      case "68CxTWPn80P":
        Script39();
        break;
      case "6hEDRrwBrZD":
        Script40();
        break;
      case "5VGOk5Hq3ux":
        Script41();
        break;
      case "6WXc9S0IosD":
        Script42();
        break;
      case "63GAUT4yS9w":
        Script43();
        break;
      case "64K0AH8u1aB":
        Script44();
        break;
      case "6RdqjzAXW3k":
        Script45();
        break;
      case "5jmC7uhfuU0":
        Script46();
        break;
      case "5wYOfoE8vyt":
        Script47();
        break;
      case "5o9Pxjh9YLh":
        Script48();
        break;
      case "5baZ6CyVm08":
        Script49();
        break;
      case "6EidgWw1YsW":
        Script50();
        break;
      case "6TS7wzVeySW":
        Script51();
        break;
      case "6pYVbwcjsFi":
        Script52();
        break;
      case "65qNlCMzkwx":
        Script53();
        break;
      case "6DQo472PrC4":
        Script54();
        break;
      case "6lyUdDA2a4K":
        Script55();
        break;
      case "6DR2HVg5h9E":
        Script56();
        break;
      case "6Cjaa7EDlEZ":
        Script57();
        break;
      case "6cwbiFhCQAh":
        Script58();
        break;
      case "6VQRg6e37gR":
        Script59();
        break;
      case "6ohixNfrvsc":
        Script60();
        break;
      case "6NbGGJK57d0":
        Script61();
        break;
      case "65CAsQJW0L2":
        Script62();
        break;
      case "6Q2OMp3000o":
        Script63();
        break;
      case "6OP8cLwwZlo":
        Script64();
        break;
      case "6OCcS2ko7N6":
        Script65();
        break;
      case "60kx2MdRRae":
        Script66();
        break;
      case "6rmEbsZQJ7O":
        Script67();
        break;
      case "5j4BwKrkzr4":
        Script68();
        break;
      case "5b0Q4zu1J0N":
        Script69();
        break;
      case "5VItBCl59Xu":
        Script70();
        break;
      case "6LltYpFd2c0":
        Script71();
        break;
      case "6nVNtDCtmYX":
        Script72();
        break;
      case "6Tjaqr2jQuq":
        Script73();
        break;
      case "5YKvDhDBSoR":
        Script74();
        break;
      case "6LrETzreZFk":
        Script75();
        break;
      case "6kSl3zsnNAp":
        Script76();
        break;
      case "6edDm0CVe1i":
        Script77();
        break;
      case "69vioioUfre":
        Script78();
        break;
      case "6C17dk6yDYG":
        Script79();
        break;
      case "6CFaqIepQfK":
        Script80();
        break;
      case "6JAtbvNdtlZ":
        Script81();
        break;
      case "5vVImMIp60K":
        Script82();
        break;
      case "5qzWQncJL0X":
        Script83();
        break;
      case "6ilcTSz0rmN":
        Script84();
        break;
      case "6jRQOPeyGRT":
        Script85();
        break;
      case "6WXlApsUYPY":
        Script86();
        break;
      case "6bjKAgJ1JXk":
        Script87();
        break;
      case "5nj9xssy4vq":
        Script88();
        break;
      case "5tirkoqf5UB":
        Script89();
        break;
      case "6Tf9RGuAG5r":
        Script90();
        break;
      case "5W2iHUDjnZ4":
        Script91();
        break;
      case "5ixHCaIrXsB":
        Script92();
        break;
      case "6RSXrwwp0hL":
        Script93();
        break;
      case "60PHZ0hMQa0":
        Script94();
        break;
      case "5acP41b8VWF":
        Script95();
        break;
      case "5aq1UPcpFUz":
        Script96();
        break;
      case "5icUW4VW0TJ":
        Script97();
        break;
      case "6NfVvehunVD":
        Script98();
        break;
      case "6K7PrHRKVbg":
        Script99();
        break;
      case "6qaBsn5QxNe":
        Script100();
        break;
      case "6LFCh8HZsoO":
        Script101();
        break;
      case "5n6VUR1OGCx":
        Script102();
        break;
      case "5ziLylUBcKp":
        Script103();
        break;
      case "5sNUWdpequd":
        Script104();
        break;
      case "5WTAWBjpb3p":
        Script105();
        break;
      case "5n94noFy4av":
        Script106();
        break;
      case "6Zowyubf6UE":
        Script107();
        break;
      case "6dQMjJDSbP6":
        Script108();
        break;
      case "6WrXuvi32r4":
        Script109();
        break;
      case "6VYsAqfLADJ":
        Script110();
        break;
      case "6YcdyzbPXow":
        Script111();
        break;
      case "6MJwrM4i70s":
        Script112();
        break;
      case "5Y7njGPdH0X":
        Script113();
        break;
      case "5enwQkVhERt":
        Script114();
        break;
      case "5gqHZQlyhRM":
        Script115();
        break;
      case "6Z3HNfJ6AQW":
        Script116();
        break;
      case "5tdoWik8HXV":
        Script117();
        break;
      case "5sQ2wfkUFnZ":
        Script118();
        break;
      case "6T1uHtUFCF6":
        Script119();
        break;
      case "6Jvu0V7ravH":
        Script120();
        break;
      case "6Yzzg8N3IYf":
        Script121();
        break;
      case "6N1JYBKjS85":
        Script122();
        break;
      case "5WLK2ywaLDA":
        Script123();
        break;
      case "5oAOcgH9G8T":
        Script124();
        break;
      case "6OyRXfxgLqU":
        Script125();
        break;
      case "6SeXHLJX52P":
        Script126();
        break;
      case "6LR8rDJ64YH":
        Script127();
        break;
      case "5iv5GCLgWnJ":
        Script128();
        break;
      case "6ifPFlL6kxM":
        Script129();
        break;
      case "67iZwoJa4be":
        Script130();
        break;
      case "5nojdo6fwG7":
        Script131();
        break;
      case "6pQfVeECNJb":
        Script132();
        break;
      case "5mEREO0fjj7":
        Script133();
        break;
      case "645c8DnuyHa":
        Script134();
        break;
      case "5b9yLUC535A":
        Script135();
        break;
      case "6k5WQBkpsXx":
        Script136();
        break;
      case "65VayqzhgLu":
        Script137();
        break;
      case "5mvj90N0iht":
        Script138();
        break;
      case "6qTVwSUeNSY":
        Script139();
        break;
      case "67Mat08SsJM":
        Script140();
        break;
      case "6LlSyZMU5xS":
        Script141();
        break;
      case "64vxwN8nH9P":
        Script142();
        break;
      case "6rdFjm2w3fB":
        Script143();
        break;
      case "5w2nhc1mVS9":
        Script144();
        break;
      case "6RsRopCzSUq":
        Script145();
        break;
      case "5dUqhUuBivY":
        Script146();
        break;
      case "6933ndi1cpd":
        Script147();
        break;
      case "6QcGsFhpkuv":
        Script148();
        break;
      case "6NLyMZkZd78":
        Script149();
        break;
      case "5x5BMEgveWq":
        Script150();
        break;
      case "6pzEwvH5wod":
        Script151();
        break;
      case "6hsZDnloEJE":
        Script152();
        break;
      case "5mpz9g3Hv4Z":
        Script153();
        break;
      case "677kKJr5z46":
        Script154();
        break;
      case "64K55JQGBjb":
        Script155();
        break;
      case "6qkrEmEbl82":
        Script156();
        break;
      case "5ifYx2KNfpB":
        Script157();
        break;
      case "6PIaUXy92in":
        Script158();
        break;
      case "6hwFU65ZgDP":
        Script159();
        break;
      case "5zt1hs5174E":
        Script160();
        break;
      case "605hPcgIILQ":
        Script161();
        break;
      case "5k3DlFKO1FA":
        Script162();
        break;
      case "6MUj6iFbmdw":
        Script163();
        break;
      case "5iFzu91zekP":
        Script164();
        break;
      case "6VE4aFtymMX":
        Script165();
        break;
      case "6GPmXMKInko":
        Script166();
        break;
      case "6KmAuffdGxy":
        Script167();
        break;
      case "6knnMCIkSaz":
        Script168();
        break;
      case "6ZYP4X9Mieb":
        Script169();
        break;
      case "6bkVeK7ohOb":
        Script170();
        break;
      case "5ZCqvoer2kQ":
        Script171();
        break;
      case "5Ugs1LxtBMN":
        Script172();
        break;
      case "6XMlqd80YUI":
        Script173();
        break;
      case "6b5Q7pm8hm3":
        Script174();
        break;
      case "6ISJMmP4oFT":
        Script175();
        break;
      case "5sX8V08j6Lf":
        Script176();
        break;
      case "6laKmsHm0eE":
        Script177();
        break;
      case "5r1YisQ5Pnc":
        Script178();
        break;
      case "5kj5ZIknMjc":
        Script179();
        break;
      case "65uSwONu48J":
        Script180();
        break;
      case "6izDJPWgC0Y":
        Script181();
        break;
      case "6hPzV6IgYiU":
        Script182();
        break;
      case "6iMD2YxgoxF":
        Script183();
        break;
      case "5fDOoNT0GRp":
        Script184();
        break;
      case "5UwmLRiNueX":
        Script185();
        break;
      case "5X2IwfKu8mf":
        Script186();
        break;
      case "6Gihaqoak9z":
        Script187();
        break;
      case "6nTeqJGq3Kr":
        Script188();
        break;
      case "6R6tPhRPvwr":
        Script189();
        break;
      case "6UPTCPXZmqU":
        Script190();
        break;
      case "6iF1gWhUQlD":
        Script191();
        break;
      case "6bzvVHwRMEm":
        Script192();
        break;
      case "6jzmyMJPl8a":
        Script193();
        break;
      case "6pAGxTDmGgA":
        Script194();
        break;
      case "61xHSV5TaxH":
        Script195();
        break;
      case "5Z7LVQO5Mfu":
        Script196();
        break;
      case "5ZRV34drXUv":
        Script197();
        break;
      case "61wTLrlDW67":
        Script198();
        break;
      case "66RDPTm5H0O":
        Script199();
        break;
      case "6afL3JKP2fr":
        Script200();
        break;
      case "6CuMh1k4rGu":
        Script201();
        break;
      case "5stskSv5nGb":
        Script202();
        break;
      case "6UQNowbX6PU":
        Script203();
        break;
      case "6BKTCWpHtB8":
        Script204();
        break;
      case "5uFkNEvELsf":
        Script205();
        break;
      case "67ZCyACccEa":
        Script206();
        break;
      case "5zXH92PtGaX":
        Script207();
        break;
      case "6VBg8XtdS1G":
        Script208();
        break;
      case "5oMzHYrUETq":
        Script209();
        break;
      case "6ajkJu9NVff":
        Script210();
        break;
      case "6ZfvyFO3dQd":
        Script211();
        break;
      case "6lBT94EGtxT":
        Script212();
        break;
      case "6Re68yMvMr7":
        Script213();
        break;
      case "6IgfLYfoko4":
        Script214();
        break;
      case "6DOEPETrz2V":
        Script215();
        break;
      case "5eOEjozoVam":
        Script216();
        break;
      case "5vV08kUo8Ny":
        Script217();
        break;
      case "5sUGUheA7Tw":
        Script218();
        break;
      case "5wpIwbCZGJe":
        Script219();
        break;
      case "6C9Cs7OLhCH":
        Script220();
        break;
      case "6kVQZOeqOhW":
        Script221();
        break;
      case "5oMVaZOAEhG":
        Script222();
        break;
      case "67hQoSE8NrY":
        Script223();
        break;
      case "6MapVe7J3KY":
        Script224();
        break;
      case "6qhGZJitpBr":
        Script225();
        break;
      case "6iyS17JZIHM":
        Script226();
        break;
      case "5q7LxJPP2hp":
        Script227();
        break;
      case "5Y4Y0LY8bt1":
        Script228();
        break;
      case "61ByO4nj4vO":
        Script229();
        break;
      case "5tZWGSUe5ro":
        Script230();
        break;
      case "6AqMjSq7uUI":
        Script231();
        break;
      case "6kVgrPa6xQ4":
        Script232();
        break;
      case "6Z0XvnWsx5a":
        Script233();
        break;
      case "5xGtol3Xqvt":
        Script234();
        break;
      case "5uwIAWuXR9r":
        Script235();
        break;
      case "6Y0Ql2vcJPg":
        Script236();
        break;
      case "6etGXY50JTN":
        Script237();
        break;
      case "6Hsnv0BhlM4":
        Script238();
        break;
      case "66yFJoT1Uiy":
        Script239();
        break;
      case "67eQ6pPIAGu":
        Script240();
        break;
      case "5mS6dV98HU0":
        Script241();
        break;
      case "5whlCZfmBkc":
        Script242();
        break;
      case "6Iegh6IW1wN":
        Script243();
        break;
      case "6qn9q7B8IUQ":
        Script244();
        break;
      case "62YTNwItOmf":
        Script245();
        break;
      case "65W8PnOPl4Y":
        Script246();
        break;
      case "5z9jfYuKshO":
        Script247();
        break;
      case "5r3mNJm3Hu5":
        Script248();
        break;
      case "63xzU4cfAq2":
        Script249();
        break;
      case "6bnziHVELab":
        Script250();
        break;
      case "6RTFbFnqwlT":
        Script251();
        break;
      case "6EFwW3mV7oO":
        Script252();
        break;
      case "5YzDVanSUWL":
        Script253();
        break;
      case "6RbN3I1zt2R":
        Script254();
        break;
      case "6Ob3RAxRQhI":
        Script255();
        break;
      case "60Ea0Mk6C70":
        Script256();
        break;
      case "6DqwJKQ9f0n":
        Script257();
        break;
      case "6Ul25dENzYq":
        Script258();
        break;
      case "6bYJwvKwPJX":
        Script259();
        break;
      case "6dvH8SRn2AM":
        Script260();
        break;
      case "6kgHQGkLW68":
        Script261();
        break;
      case "5qTATndRP5B":
        Script262();
        break;
      case "6WZjcs2a1RS":
        Script263();
        break;
      case "6HzqdS8tXNM":
        Script264();
        break;
      case "6SHdQ79HRlR":
        Script265();
        break;
      case "5fPIicezBOv":
        Script266();
        break;
      case "61sEknkLsJ5":
        Script267();
        break;
      case "6HdFD9lAdM5":
        Script268();
        break;
      case "6B4qAOIcXqK":
        Script269();
        break;
      case "5l5VTjpyRkm":
        Script270();
        break;
      case "6puoNWwMn2W":
        Script271();
        break;
      case "5fEW6VFS1Mo":
        Script272();
        break;
      case "63Eesy5mw3q":
        Script273();
        break;
      case "6pI9qBHmvoN":
        Script274();
        break;
      case "5mauPSlQ7XP":
        Script275();
        break;
      case "6BJaeUoRTTg":
        Script276();
        break;
      case "5i989NrcXcc":
        Script277();
        break;
      case "6LcVBFKZJMP":
        Script278();
        break;
      case "6b4inCGxDBY":
        Script279();
        break;
      case "6UeBhly9k2A":
        Script280();
        break;
      case "6o5zmyzFq4q":
        Script281();
        break;
      case "6A6GkNvutMc":
        Script282();
        break;
      case "6c7dHDSu2S7":
        Script283();
        break;
      case "6ZlldzEZUrr":
        Script284();
        break;
      case "6HnWx4TfOb6":
        Script285();
        break;
      case "6jhCDnwfWAh":
        Script286();
        break;
      case "5ektUiC6SKB":
        Script287();
        break;
      case "61vcdW9MwKJ":
        Script288();
        break;
      case "6jfK5kny2Up":
        Script289();
        break;
      case "6j1OOyZ56Ln":
        Script290();
        break;
      case "5uia6FNpwyG":
        Script291();
        break;
      case "5uHm7piMw7i":
        Script292();
        break;
      case "5rynGM7dIbj":
        Script293();
        break;
      case "5mIyDHYMp7P":
        Script294();
        break;
      case "5p3m7bvcoNc":
        Script295();
        break;
      case "6kOM0ChPsGZ":
        Script296();
        break;
      case "60A5siHr8V7":
        Script297();
        break;
      case "5ehluVUxRBi":
        Script298();
        break;
      case "5vUYI9nm29q":
        Script299();
        break;
      case "5bl0AQ4vMlr":
        Script300();
        break;
      case "6Y9F3XuGLmi":
        Script301();
        break;
      case "68WI1rOsgkC":
        Script302();
        break;
      case "6qTR2Rz0nOH":
        Script303();
        break;
      case "60msZHrpkD8":
        Script304();
        break;
      case "659WVs9oiuU":
        Script305();
        break;
      case "5mzSYtZH2Sv":
        Script306();
        break;
      case "6rgXy7UcWUN":
        Script307();
        break;
      case "5jEVmDWvBOc":
        Script308();
        break;
      case "6cnmMyjhdLE":
        Script309();
        break;
      case "6iFSXQc55tZ":
        Script310();
        break;
      case "5VK0Ry3CkKM":
        Script311();
        break;
      case "67cED6EXwg7":
        Script312();
        break;
      case "5u9gEyK6xtw":
        Script313();
        break;
      case "5fLBM0gejhz":
        Script314();
        break;
      case "67wgXkpyeeE":
        Script315();
        break;
      case "60pfv7wNSXH":
        Script316();
        break;
      case "5eyC6yzsy40":
        Script317();
        break;
      case "6DaiZqBTWCW":
        Script318();
        break;
      case "6UM23CEp8Q6":
        Script319();
        break;
      case "6iopf3ZHvk6":
        Script320();
        break;
      case "6Tjh83Emj64":
        Script321();
        break;
      case "6moXiQJHGRz":
        Script322();
        break;
      case "5znygO2uTnZ":
        Script323();
        break;
      case "69r2Vk4AFQj":
        Script324();
        break;
      case "6Zxr4zWrE9d":
        Script325();
        break;
      case "6aO3gnHXxBW":
        Script326();
        break;
      case "64oLkZ710EN":
        Script327();
        break;
      case "6XiXZZdOG0z":
        Script328();
        break;
      case "5dTZYQJso0w":
        Script329();
        break;
      case "5bU6PZSswQA":
        Script330();
        break;
      case "6GJEKSQ6aJS":
        Script331();
        break;
      case "6R3KkeqAzvT":
        Script332();
        break;
      case "6PowBCnSBNd":
        Script333();
        break;
      case "6ImZFyQNkRU":
        Script334();
        break;
      case "6CD8tBEg45Y":
        Script335();
        break;
      case "6VyLok8U6OA":
        Script336();
        break;
      case "5nIFKteEbp9":
        Script337();
        break;
      case "6FsFdYuBvfl":
        Script338();
        break;
      case "5VRvh3SuBPu":
        Script339();
        break;
      case "6YxGWN5IlLY":
        Script340();
        break;
      case "5vSZSffBTdl":
        Script341();
        break;
      case "5a76LiqRLNs":
        Script342();
        break;
      case "6boGE0m6Fr6":
        Script343();
        break;
      case "5je7rX527zO":
        Script344();
        break;
      case "5Z1PowvJyF4":
        Script345();
        break;
      case "6nYpmVLTT82":
        Script346();
        break;
      case "6TRMcHYm3JW":
        Script347();
        break;
      case "6SSqdLuLPJd":
        Script348();
        break;
      case "5bsW40p2aDi":
        Script349();
        break;
      case "5eHZjsZBJ7D":
        Script350();
        break;
      case "6N4XCyLbSD8":
        Script351();
        break;
      case "5hgdd8NBDYn":
        Script352();
        break;
      case "60mkqT0onxq":
        Script353();
        break;
      case "6OCnir4o0lO":
        Script354();
        break;
      case "6BlkPVI0BbF":
        Script355();
        break;
      case "6Mm6u3j1o9d":
        Script356();
        break;
      case "6FyOaeUu5Xt":
        Script357();
        break;
      case "5pPQOh4Pj3t":
        Script358();
        break;
      case "5xKtCRabP6C":
        Script359();
        break;
      case "5XfngYWLHfl":
        Script360();
        break;
      case "6H15bJHQBTM":
        Script361();
        break;
      case "6c9mK2o7Iz7":
        Script362();
        break;
      case "6IjofrbwKuW":
        Script363();
        break;
      case "6nhrW1nXjvi":
        Script364();
        break;
      case "5bwk3VUErvg":
        Script365();
        break;
      case "5zKViul8kC9":
        Script366();
        break;
      case "6TWlMWiZjqJ":
        Script367();
        break;
      case "6pF18psLc2q":
        Script368();
        break;
      case "6QyOy6KWP5F":
        Script369();
        break;
      case "5WFoZOzZ4hl":
        Script370();
        break;
      case "60L98A3EKao":
        Script371();
        break;
      case "6idWGIFnQqi":
        Script372();
        break;
      case "5jI7dMI0KsD":
        Script373();
        break;
      case "6YvNkFjjKeD":
        Script374();
        break;
      case "60GXqUASUYV":
        Script375();
        break;
      case "6WyLDpcOYYr":
        Script376();
        break;
      case "5ZhDrTBx2AK":
        Script377();
        break;
      case "5ZoHellL088":
        Script378();
        break;
      case "6hOk6KfLniH":
        Script379();
        break;
  }
}

window.InitExecuteScripts = function()
{
var player = GetPlayer();
var object = player.object;
var once = player.once;
var addToTimeline = player.addToTimeline;
var setVar = player.SetVar;
var getVar = player.GetVar;
var update = player.update;
var pointerX = player.pointerX;
var pointerY = player.pointerY;
var showPointer = player.showPointer;
var hidePointer = player.hidePointer;
var slideWidth = player.slideWidth;
var slideHeight = player.slideHeight;
window.Script1 = function()
{
  const target = object('5yXtTLZgph3');
const duration = 100;
const easing = 'ease-out';
const id = '5l6dcBXJSMv';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script2 = function()
{
  const target = object('5uebGMHB5LC');
const duration = 100;
const easing = 'ease-out';
const id = '5VoyNByAKqQ';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script3 = function()
{
  const target = object('5k3SDDR2nLb');
const duration = 100;
const easing = 'ease-out';
const id = '5cMRAO1v1mx';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script4 = function()
{
  const target = object('5iQigltUZuq');
const duration = 500;
const easing = 'ease-out';
const id = '6PBn8qBZybR';
const shakeAmount = 2;
player.addForTriggers(
id,
target.animate(
[ {translate: '0 0' }, 
{translate: `-${shakeAmount}px 0` }, 
{translate: '0 0' }, 
{translate: `${shakeAmount}px 0` }, 
{translate: '0 0' }, 
{translate: `-${shakeAmount}px 0` }, 
{translate: '0 0' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script5 = function()
{
  const target = object('6dqnNZXdA7Z');
const duration = 500;
const easing = 'ease-out';
const id = '5kgeCBbqZUk';
const shakeAmount = 2;
player.addForTriggers(
id,
target.animate(
[ {translate: '0 0' }, 
{translate: `-${shakeAmount}px 0` }, 
{translate: '0 0' }, 
{translate: `${shakeAmount}px 0` }, 
{translate: '0 0' }, 
{translate: `-${shakeAmount}px 0` }, 
{translate: '0 0' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script6 = function()
{
  const target = object('5puSsmxEWCo');
const duration = 500;
const easing = 'ease-out';
const id = '6nABXU4HIo4';
const shakeAmount = 2;
player.addForTriggers(
id,
target.animate(
[ {translate: '0 0' }, 
{translate: `-${shakeAmount}px 0` }, 
{translate: '0 0' }, 
{translate: `${shakeAmount}px 0` }, 
{translate: '0 0' }, 
{translate: `-${shakeAmount}px 0` }, 
{translate: '0 0' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script7 = function()
{
  const target = object('6ABkMU9AHKl');
const duration = 500;
const easing = 'ease-out';
const id = '5xOgt9fFcBU';
const shakeAmount = 2;
player.addForTriggers(
id,
target.animate(
[ {translate: '0 0' }, 
{translate: `-${shakeAmount}px 0` }, 
{translate: '0 0' }, 
{translate: `${shakeAmount}px 0` }, 
{translate: '0 0' }, 
{translate: `-${shakeAmount}px 0` }, 
{translate: '0 0' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script8 = function()
{
  const target = object('6oPclunoyLm');
const duration = 500;
const easing = 'ease-out';
const id = '5yjLHOTL3gd';
const shakeAmount = 2;
player.addForTriggers(
id,
target.animate(
[ {translate: '0 0' }, 
{translate: `-${shakeAmount}px 0` }, 
{translate: '0 0' }, 
{translate: `${shakeAmount}px 0` }, 
{translate: '0 0' }, 
{translate: `-${shakeAmount}px 0` }, 
{translate: '0 0' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script9 = function()
{
  const target = object('6nbvK3SCa1S');
const duration = 500;
const easing = 'ease-out';
const id = '62jrCDOdy2c';
const shakeAmount = 2;
player.addForTriggers(
id,
target.animate(
[ {translate: '0 0' }, 
{translate: `-${shakeAmount}px 0` }, 
{translate: '0 0' }, 
{translate: `${shakeAmount}px 0` }, 
{translate: '0 0' }, 
{translate: `-${shakeAmount}px 0` }, 
{translate: '0 0' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script10 = function()
{
  const target = object('5ntH1siHHyE');
const duration = 500;
const easing = 'ease-out';
const id = '5fD3tHy1lEn';
const shakeAmount = 2;
player.addForTriggers(
id,
target.animate(
[ {translate: '0 0' }, 
{translate: `-${shakeAmount}px 0` }, 
{translate: '0 0' }, 
{translate: `${shakeAmount}px 0` }, 
{translate: '0 0' }, 
{translate: `-${shakeAmount}px 0` }, 
{translate: '0 0' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script11 = function()
{
  const target = object('5mrmg4WFsGx');
const duration = 500;
const easing = 'ease-out';
const id = '6jlQfwbVvxo';
const shakeAmount = 2;
player.addForTriggers(
id,
target.animate(
[ {translate: '0 0' }, 
{translate: `-${shakeAmount}px 0` }, 
{translate: '0 0' }, 
{translate: `${shakeAmount}px 0` }, 
{translate: '0 0' }, 
{translate: `-${shakeAmount}px 0` }, 
{translate: '0 0' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

};
