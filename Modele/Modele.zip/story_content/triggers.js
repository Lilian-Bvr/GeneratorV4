function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5WUw32C28kp":
        Script1();
        break;
      case "6qrpTze3aVw":
        Script2();
        break;
      case "64mPHM36cJ0":
        Script3();
        break;
      case "5km5RDMn0dA":
        Script4();
        break;
      case "5YSjjja8pme":
        Script5();
        break;
      case "68RQOYS63bx":
        Script6();
        break;
      case "5biKcm0K9Cg":
        Script7();
        break;
      case "5ZT46Dz9zhB":
        Script8();
        break;
      case "5qbeQ1nqcf9":
        Script9();
        break;
      case "6USO0MJZTC6":
        Script10();
        break;
      case "6XpJr5hjCkM":
        Script11();
        break;
      case "5hcRWRMfFF4":
        Script12();
        break;
      case "6EpmT0dfIY1":
        Script13();
        break;
      case "6HRMmSh1MBU":
        Script14();
        break;
      case "6pxOaG9TKnI":
        Script15();
        break;
      case "6dVuAjMgaj3":
        Script16();
        break;
      case "5epeXG5txN5":
        Script17();
        break;
      case "6oMBjMNU03r":
        Script18();
        break;
      case "6PGJz2oHmQj":
        Script19();
        break;
      case "5vrjd8er2w6":
        Script20();
        break;
      case "665ErAgZCCq":
        Script21();
        break;
      case "5hdICNiIECJ":
        Script22();
        break;
      case "5rNC58P2BeD":
        Script23();
        break;
      case "6F3mjWSkjfm":
        Script24();
        break;
      case "5duqXUZkbIC":
        Script25();
        break;
      case "6LSJUrL443j":
        Script26();
        break;
      case "6ceKgcU4l1G":
        Script27();
        break;
      case "5btIwqSwQoQ":
        Script28();
        break;
      case "5nTKJNuzHFf":
        Script29();
        break;
      case "5VpEck19MBI":
        Script30();
        break;
      case "68RHzxjZBkf":
        Script31();
        break;
      case "6JGQbOlLrJ3":
        Script32();
        break;
      case "5zzl1lwbKsN":
        Script33();
        break;
      case "6OyDw3SzN4R":
        Script34();
        break;
      case "5gZ9694Bv6A":
        Script35();
        break;
      case "5o2JXUWv76Y":
        Script36();
        break;
      case "5bFPxmCBerD":
        Script37();
        break;
      case "6l8MsKcuA19":
        Script38();
        break;
      case "6FaToIqKS47":
        Script39();
        break;
      case "6mCbXtZlO1k":
        Script40();
        break;
      case "6pPtmZ87pLn":
        Script41();
        break;
      case "6Ad40JvW4u5":
        Script42();
        break;
      case "6pUF8HoJPwo":
        Script43();
        break;
      case "6IfbvB5uvtj":
        Script44();
        break;
      case "5dkjDsp66Eu":
        Script45();
        break;
      case "6KjMsBBZ6BZ":
        Script46();
        break;
      case "5VzoDFqhiUt":
        Script47();
        break;
      case "6BIxzwroamn":
        Script48();
        break;
      case "68YKRdGZctT":
        Script49();
        break;
      case "6XbubkzcSsu":
        Script50();
        break;
      case "5lvy0aVMXA7":
        Script51();
        break;
      case "5YoSzhCHoDo":
        Script52();
        break;
      case "69Ldrfg32Li":
        Script53();
        break;
      case "5ahsmFJuSop":
        Script54();
        break;
      case "6pFvEftovAS":
        Script55();
        break;
      case "6nIrVuDirU0":
        Script56();
        break;
      case "6QnH2clvOC6":
        Script57();
        break;
      case "6e1RoWXCKzk":
        Script58();
        break;
      case "67ps7Vu6VqS":
        Script59();
        break;
      case "5nZGqwyMVB9":
        Script60();
        break;
      case "6FVlUGrA1nS":
        Script61();
        break;
      case "5tzrHyLXbpX":
        Script62();
        break;
      case "6UPFpI8RCZZ":
        Script63();
        break;
      case "60O3HQTaEoF":
        Script64();
        break;
      case "6KZFLCtmfoy":
        Script65();
        break;
      case "64SfjRcZsHB":
        Script66();
        break;
      case "5tgpIsnym9N":
        Script67();
        break;
      case "5evVNkLxFxk":
        Script68();
        break;
      case "6T3cMxXrN0l":
        Script69();
        break;
      case "6bKIRibNQYv":
        Script70();
        break;
      case "5vbwzO5h6ev":
        Script71();
        break;
      case "5cLaxqSngy2":
        Script72();
        break;
      case "5oNoqQa3v5X":
        Script73();
        break;
      case "6N2R0ntbw0y":
        Script74();
        break;
      case "5YjRe6pmR4A":
        Script75();
        break;
      case "5r7n3uHKPgL":
        Script76();
        break;
      case "6KqBudWete9":
        Script77();
        break;
      case "6O6ym3TK4ao":
        Script78();
        break;
      case "5je9tMfE4I9":
        Script79();
        break;
      case "6F0YIuAYdSs":
        Script80();
        break;
      case "6hrr1CfpbbT":
        Script81();
        break;
      case "5iEg0Qr544e":
        Script82();
        break;
      case "5vU1mS75Laz":
        Script83();
        break;
      case "6iXd5M48xEA":
        Script84();
        break;
      case "5iSYUKA2nXX":
        Script85();
        break;
      case "6CfxAioV4w6":
        Script86();
        break;
      case "6Sm3sQlOPhz":
        Script87();
        break;
      case "5dOGWiwmeuE":
        Script88();
        break;
      case "5z8DxnOSu2z":
        Script89();
        break;
      case "6Ctl8L2qSWn":
        Script90();
        break;
      case "6L7eVkkdFm6":
        Script91();
        break;
      case "6NOwrfj72wW":
        Script92();
        break;
      case "5YyReuF84tm":
        Script93();
        break;
      case "5dwdETalmGh":
        Script94();
        break;
      case "61QKLCIWVse":
        Script95();
        break;
      case "5sv6AVtO3jI":
        Script96();
        break;
      case "62LbqcEbIWf":
        Script97();
        break;
      case "6DIGkx7PCfw":
        Script98();
        break;
      case "6eUVfSFpRtU":
        Script99();
        break;
      case "6S8UCRCd9dq":
        Script100();
        break;
      case "6ZP0FaPMPMs":
        Script101();
        break;
      case "65mUg8aXcYG":
        Script102();
        break;
      case "6CCSoOseRcS":
        Script103();
        break;
      case "6Uq9vy4eZN8":
        Script104();
        break;
      case "5u2JyfuV4Vh":
        Script105();
        break;
      case "6QfMJMhA9qu":
        Script106();
        break;
      case "6aqr8k1QEBy":
        Script107();
        break;
      case "6BLfGM896iS":
        Script108();
        break;
      case "63w1OALRPgA":
        Script109();
        break;
      case "62PCdHfgzUc":
        Script110();
        break;
      case "6IEeadKlV3I":
        Script111();
        break;
      case "6pNxI3xRgNN":
        Script112();
        break;
      case "5WjRP6dtKcG":
        Script113();
        break;
      case "6WO2iNMNdmv":
        Script114();
        break;
      case "66zhqFhR4v1":
        Script115();
        break;
      case "5Wt5qzNtebb":
        Script116();
        break;
      case "6AcL5v7v0yx":
        Script117();
        break;
      case "6qCE7m4pSjx":
        Script118();
        break;
      case "5VjX3Z91hO6":
        Script119();
        break;
      case "5Vvt9w7Fv5T":
        Script120();
        break;
      case "6HCPiAcukM9":
        Script121();
        break;
      case "6PXaJVjkdFs":
        Script122();
        break;
      case "6M1FcTma4XY":
        Script123();
        break;
      case "5ppwfJK0Ypo":
        Script124();
        break;
      case "6b46FlWVGG5":
        Script125();
        break;
      case "675e3NocY8b":
        Script126();
        break;
      case "5XRhYMlDGk7":
        Script127();
        break;
      case "6RoajFdA34m":
        Script128();
        break;
      case "6UgP0GEEqYl":
        Script129();
        break;
      case "6qd7lJcAgY6":
        Script130();
        break;
      case "6RUBdgylr9s":
        Script131();
        break;
      case "6Nfm3BYxlkU":
        Script132();
        break;
      case "5XyqTRbV0Ug":
        Script133();
        break;
      case "5hGSOoM6v90":
        Script134();
        break;
      case "6m1RAMFdHCc":
        Script135();
        break;
      case "6HRNll5AEv0":
        Script136();
        break;
      case "6p2eGIDRsWw":
        Script137();
        break;
      case "6VBmmPoxYTV":
        Script138();
        break;
      case "6BQeoQo2fLd":
        Script139();
        break;
      case "5kroBJgLQ5Q":
        Script140();
        break;
      case "61muCMD7OLo":
        Script141();
        break;
      case "6CAR2i1ZGlP":
        Script142();
        break;
      case "6X8cVQGGadc":
        Script143();
        break;
      case "6nUCcP3s2lE":
        Script144();
        break;
      case "5gGsgpDlC1C":
        Script145();
        break;
      case "6BNgKc3AwCj":
        Script146();
        break;
      case "6KxGScsEmHe":
        Script147();
        break;
      case "6S2OcdY2y3J":
        Script148();
        break;
      case "5dKbh6k9E1w":
        Script149();
        break;
      case "64fOjjRFQWe":
        Script150();
        break;
      case "6VHVSOGjdJk":
        Script151();
        break;
      case "6C9rtTUph9s":
        Script152();
        break;
      case "6XKu5Jvv1bZ":
        Script153();
        break;
      case "5XnuPlo8tFG":
        Script154();
        break;
      case "66Fz7wttLik":
        Script155();
        break;
      case "6PUnOzGmlcV":
        Script156();
        break;
      case "5mco86TBJJL":
        Script157();
        break;
      case "5iSLZX01ZH7":
        Script158();
        break;
      case "5z6sr9nyjBl":
        Script159();
        break;
      case "6jKZzl3r3rM":
        Script160();
        break;
      case "694i2n7Mt7E":
        Script161();
        break;
      case "6osefjYJw0Q":
        Script162();
        break;
      case "5ygnI55kcb2":
        Script163();
        break;
      case "6hRk0dcaR1h":
        Script164();
        break;
      case "6ghRcAMq4kX":
        Script165();
        break;
      case "5ugiqjbeEOU":
        Script166();
        break;
      case "5yeseclSxa4":
        Script167();
        break;
      case "6SqM3e0C6Sc":
        Script168();
        break;
      case "5oy13AnrvsZ":
        Script169();
        break;
      case "66CwuN43oGP":
        Script170();
        break;
      case "5XiLmszx1dV":
        Script171();
        break;
      case "5gRRaXo3dpl":
        Script172();
        break;
      case "5wpaiQGlkPr":
        Script173();
        break;
      case "6fOlseA64Ap":
        Script174();
        break;
      case "60qpLBlcxS8":
        Script175();
        break;
      case "6Y9BlvR35GB":
        Script176();
        break;
      case "6T8XuvqyYNg":
        Script177();
        break;
      case "6OUPcHONWO3":
        Script178();
        break;
      case "5mDPUBW4MQe":
        Script179();
        break;
      case "6AGr0x4UUaH":
        Script180();
        break;
      case "6DO87YmjZgr":
        Script181();
        break;
      case "5qPgPEjVAQV":
        Script182();
        break;
      case "6a8tLejnt5h":
        Script183();
        break;
      case "5VA9na4VbN0":
        Script184();
        break;
      case "5b5UYZdNTZs":
        Script185();
        break;
      case "61OCmTuL0ZY":
        Script186();
        break;
      case "6bAoCdl2K5a":
        Script187();
        break;
      case "6U0Dv1iWkdS":
        Script188();
        break;
      case "68exfIkybyT":
        Script189();
        break;
      case "6Trf4g6Q7xD":
        Script190();
        break;
      case "5mXnskBY6KB":
        Script191();
        break;
      case "5fhE7y3czOA":
        Script192();
        break;
      case "5pXNSdgCtoO":
        Script193();
        break;
      case "6Zz0SvsS6Q2":
        Script194();
        break;
      case "67Kw8PNWGB0":
        Script195();
        break;
      case "5rR7mZPfB9n":
        Script196();
        break;
      case "6FZiAsD5j2a":
        Script197();
        break;
      case "6GUT5PyxHQL":
        Script198();
        break;
      case "6dHYiRMv0ob":
        Script199();
        break;
      case "68qa7qh4BRK":
        Script200();
        break;
      case "6d7m49iYB0w":
        Script201();
        break;
      case "6rEJgtLNeJp":
        Script202();
        break;
      case "5ZECUDsK7UC":
        Script203();
        break;
      case "5jFPgrWXjHA":
        Script204();
        break;
      case "5jTwYyZ4isi":
        Script205();
        break;
      case "6MuXVgIu7xO":
        Script206();
        break;
      case "5rW3riRmn8s":
        Script207();
        break;
      case "6fOB7bToQ3D":
        Script208();
        break;
      case "674VCGByIKQ":
        Script209();
        break;
      case "6aKSpev4kGD":
        Script210();
        break;
      case "6YyjAuTJ5Ec":
        Script211();
        break;
      case "6esTXB0Dbn2":
        Script212();
        break;
      case "5leLV4SaMhc":
        Script213();
        break;
      case "5h8rdFGR8mD":
        Script214();
        break;
      case "64mKRYTjXnW":
        Script215();
        break;
      case "6IfxgxPW0vn":
        Script216();
        break;
      case "5qQf5EpcVr9":
        Script217();
        break;
      case "6eTZMAYi44P":
        Script218();
        break;
      case "5ZTwGGIcEbm":
        Script219();
        break;
      case "5vR4T13U0OF":
        Script220();
        break;
      case "6iMPOtQ1kUn":
        Script221();
        break;
      case "65OTb5fREmM":
        Script222();
        break;
      case "5YSFO88Ai4z":
        Script223();
        break;
      case "6BjbLhCZAvW":
        Script224();
        break;
      case "6paL4ePHA3w":
        Script225();
        break;
      case "5i1vT7B454x":
        Script226();
        break;
      case "5vFqFpX7weS":
        Script227();
        break;
      case "6inb2G2i7wz":
        Script228();
        break;
      case "6MBIGpQYyK4":
        Script229();
        break;
      case "5eV3Q7zesTI":
        Script230();
        break;
      case "66HBwtmwuVI":
        Script231();
        break;
      case "6grjWI6eaZQ":
        Script232();
        break;
      case "6RzOOgsRstr":
        Script233();
        break;
      case "5q8SOAKFx2a":
        Script234();
        break;
      case "5e2TmLEDJaX":
        Script235();
        break;
      case "6E9ERxmTnO4":
        Script236();
        break;
      case "64xOuLNcmoj":
        Script237();
        break;
      case "6QqGzXHFCBW":
        Script238();
        break;
      case "5VJ5TiqxREU":
        Script239();
        break;
      case "6RLDUk0dlCl":
        Script240();
        break;
      case "6YaBAievk7l":
        Script241();
        break;
      case "5nOk6beKi4c":
        Script242();
        break;
      case "62N1bWthvdt":
        Script243();
        break;
      case "67RSvAiFGJ1":
        Script244();
        break;
      case "6kcit8cs8g1":
        Script245();
        break;
      case "5logwbLM230":
        Script246();
        break;
      case "67xPavnvNIi":
        Script247();
        break;
      case "5pgK77PTJnP":
        Script248();
        break;
      case "5ZmwAqPfBrd":
        Script249();
        break;
      case "5YE7C6S0PBM":
        Script250();
        break;
      case "6lopmUcQ7zY":
        Script251();
        break;
      case "5wEGEMlNdoy":
        Script252();
        break;
      case "6KAW7RhLtB7":
        Script253();
        break;
      case "5YQZmcMjkNY":
        Script254();
        break;
      case "5lzh5T3Ra3s":
        Script255();
        break;
      case "5f6veJyCBAo":
        Script256();
        break;
      case "6OVRDb11GYq":
        Script257();
        break;
      case "6i9wBDs9HjU":
        Script258();
        break;
      case "6mP4y7yknht":
        Script259();
        break;
      case "6GmV9MhPSBa":
        Script260();
        break;
      case "5VfnPJD7GhE":
        Script261();
        break;
      case "5nuZrYeP0Yw":
        Script262();
        break;
      case "6BPKfXonjZV":
        Script263();
        break;
      case "65pPBLD7iXH":
        Script264();
        break;
      case "5lDRDYImQOZ":
        Script265();
        break;
      case "6GgbikyEDte":
        Script266();
        break;
      case "6n01gSvLekw":
        Script267();
        break;
      case "5vZyZ7cJBQP":
        Script268();
        break;
      case "5dMQLhuiYbk":
        Script269();
        break;
      case "5jTAayv4YXf":
        Script270();
        break;
      case "6gJsuCfMM4K":
        Script271();
        break;
      case "6qwUu1BCnU6":
        Script272();
        break;
      case "5iMkp9NBlw4":
        Script273();
        break;
      case "6X4yR1cfly0":
        Script274();
        break;
      case "6pM1vKlPkbW":
        Script275();
        break;
      case "5v74AQfXBl0":
        Script276();
        break;
      case "5cBkGw6zzfu":
        Script277();
        break;
      case "5pI8HLQgxUM":
        Script278();
        break;
      case "5vsjEPJnx5t":
        Script279();
        break;
      case "6Wud9Vjwgy9":
        Script280();
        break;
      case "6ZlqeRaj0L5":
        Script281();
        break;
      case "6XLLeNRptOt":
        Script282();
        break;
      case "5dTZUcndKnj":
        Script283();
        break;
      case "6pjqMGnrYk6":
        Script284();
        break;
      case "6XlXdpQROYk":
        Script285();
        break;
      case "6nz9Jcjmwjv":
        Script286();
        break;
      case "5rkPzNxb70N":
        Script287();
        break;
      case "69t9eS4Lnvi":
        Script288();
        break;
      case "6lLJwIW0wnh":
        Script289();
        break;
      case "6N8uisyNCFd":
        Script290();
        break;
      case "6AbQZzMg0Mc":
        Script291();
        break;
      case "6LMcdBuTI6X":
        Script292();
        break;
      case "6fvbJfXmE5U":
        Script293();
        break;
      case "6TeH3Pop65c":
        Script294();
        break;
      case "5b68ODtDW6t":
        Script295();
        break;
      case "5vYgm0EUIb0":
        Script296();
        break;
      case "6TCZzAImF02":
        Script297();
        break;
      case "6JPAEHbXdly":
        Script298();
        break;
      case "6fJh2WU5pk8":
        Script299();
        break;
      case "6VCt2B6abWH":
        Script300();
        break;
      case "6kIjVih9uUY":
        Script301();
        break;
      case "5wo6OXT2smV":
        Script302();
        break;
      case "5g6GJMJ9iou":
        Script303();
        break;
      case "5hinYEhMKHC":
        Script304();
        break;
      case "5c0MNcPVgOH":
        Script305();
        break;
      case "6Pb2yQ48Ise":
        Script306();
        break;
      case "5iJxGHGK57q":
        Script307();
        break;
      case "5q8y3Mgm0bN":
        Script308();
        break;
      case "6k4HRMwufXD":
        Script309();
        break;
      case "5d7WVZzDNt6":
        Script310();
        break;
      case "6FEatXL6wTV":
        Script311();
        break;
      case "5bqs1V6fy5n":
        Script312();
        break;
      case "66k3WOIDiNl":
        Script313();
        break;
      case "5vdcqUCDwaM":
        Script314();
        break;
      case "6rAj0Syu2FN":
        Script315();
        break;
      case "5thPkCTLbvT":
        Script316();
        break;
      case "5hgtQyDMpqA":
        Script317();
        break;
      case "6mEIEMfzeQu":
        Script318();
        break;
      case "5pxE0BkX6U9":
        Script319();
        break;
      case "5ZXZ8kK2ueN":
        Script320();
        break;
      case "6jvRPblwsmp":
        Script321();
        break;
      case "6GzcdPIewnq":
        Script322();
        break;
      case "5trKj3i3Whz":
        Script323();
        break;
      case "5VErMbeatFR":
        Script324();
        break;
      case "68mA4grsh0l":
        Script325();
        break;
      case "5dhjxbbvhmN":
        Script326();
        break;
      case "6T7Ve1EVTUW":
        Script327();
        break;
      case "5oHQjCRaUht":
        Script328();
        break;
      case "6Ol2ByjYBmx":
        Script329();
        break;
      case "5qumEfRr5VL":
        Script330();
        break;
      case "5uWtZZjnUxq":
        Script331();
        break;
      case "5mdH3dPe2Ys":
        Script332();
        break;
      case "5bvs2K7gfuk":
        Script333();
        break;
      case "6UsBwcxx3LT":
        Script334();
        break;
      case "5hXmswX9VY6":
        Script335();
        break;
      case "69cw7uF2uYa":
        Script336();
        break;
      case "5e9LlzmJ4K7":
        Script337();
        break;
      case "6rJGTmgn84O":
        Script338();
        break;
      case "6Sz3uhLgANu":
        Script339();
        break;
      case "5ghKUl0weXS":
        Script340();
        break;
      case "6r75rGL8M6k":
        Script341();
        break;
      case "5wPChMcXguk":
        Script342();
        break;
      case "6JqElJpR3gk":
        Script343();
        break;
      case "5gCpTTUMoE0":
        Script344();
        break;
      case "6p6T3bclGkM":
        Script345();
        break;
      case "5ycgLAW1gTW":
        Script346();
        break;
      case "5qgN3c0ggXu":
        Script347();
        break;
      case "6HBSAefgXMY":
        Script348();
        break;
      case "5bcgtMsWZlX":
        Script349();
        break;
      case "5a6Z9fmxHtN":
        Script350();
        break;
      case "6aZ3pmXEH0I":
        Script351();
        break;
      case "6jU5Up8ClKb":
        Script352();
        break;
      case "6GtysPEyRH5":
        Script353();
        break;
      case "61VwFaovaGH":
        Script354();
        break;
      case "6gjeBbTUes1":
        Script355();
        break;
      case "6psIsVO5jla":
        Script356();
        break;
      case "6DBtkM9Xcw6":
        Script357();
        break;
      case "5kELjI9mLu2":
        Script358();
        break;
      case "5chqVuyWvVQ":
        Script359();
        break;
      case "6C5uJjK2S15":
        Script360();
        break;
      case "5Y9kY84KIEM":
        Script361();
        break;
      case "6bgVXPrDguE":
        Script362();
        break;
      case "5VjYeuBcSU9":
        Script363();
        break;
      case "668ASdmNGSa":
        Script364();
        break;
      case "6aoA22fVv0y":
        Script365();
        break;
      case "6EtKFEbmMCp":
        Script366();
        break;
      case "6DcU5RJ6ofq":
        Script367();
        break;
      case "68rE1k6Am1n":
        Script368();
        break;
      case "5xHDLs1mbqF":
        Script369();
        break;
      case "5jZpXzAvDWQ":
        Script370();
        break;
      case "5hn8ILeuQBo":
        Script371();
        break;
      case "5irKv27RbEq":
        Script372();
        break;
      case "6c2OOyX3bIe":
        Script373();
        break;
      case "6XkIOQJyrXT":
        Script374();
        break;
      case "6PhXucRamv1":
        Script375();
        break;
      case "6NUvcjhOQni":
        Script376();
        break;
      case "64o8gyeGz8B":
        Script377();
        break;
      case "6klYcbbBQaV":
        Script378();
        break;
      case "5e39fKDb5nw":
        Script379();
        break;
  }
}

window.InitExecuteScripts = function()
{
var player = GetPlayer();
var object = player.object;
var once = player.once;
var addToTimeline = player.addToTimeline;
var setVar = player.SetVar;
var getVar = player.GetVar;
var update = player.update;
var pointerX = player.pointerX;
var pointerY = player.pointerY;
var showPointer = player.showPointer;
var hidePointer = player.hidePointer;
var slideWidth = player.slideWidth;
var slideHeight = player.slideHeight;
window.Script1 = function()
{
  const target = object('5yXtTLZgph3');
const duration = 100;
const easing = 'ease-out';
const id = '5l6dcBXJSMv';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script2 = function()
{
  const target = object('5uebGMHB5LC');
const duration = 100;
const easing = 'ease-out';
const id = '5VoyNByAKqQ';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script3 = function()
{
  const target = object('5k3SDDR2nLb');
const duration = 100;
const easing = 'ease-out';
const id = '5cMRAO1v1mx';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script4 = function()
{
  const target = object('5iQigltUZuq');
const duration = 500;
const easing = 'ease-out';
const id = '6PBn8qBZybR';
const shakeAmount = 2;
player.addForTriggers(
id,
target.animate(
[ {translate: '0 0' }, 
{translate: `-${shakeAmount}px 0` }, 
{translate: '0 0' }, 
{translate: `${shakeAmount}px 0` }, 
{translate: '0 0' }, 
{translate: `-${shakeAmount}px 0` }, 
{translate: '0 0' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script5 = function()
{
  const target = object('6dqnNZXdA7Z');
const duration = 500;
const easing = 'ease-out';
const id = '5kgeCBbqZUk';
const shakeAmount = 2;
player.addForTriggers(
id,
target.animate(
[ {translate: '0 0' }, 
{translate: `-${shakeAmount}px 0` }, 
{translate: '0 0' }, 
{translate: `${shakeAmount}px 0` }, 
{translate: '0 0' }, 
{translate: `-${shakeAmount}px 0` }, 
{translate: '0 0' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script6 = function()
{
  const target = object('5puSsmxEWCo');
const duration = 500;
const easing = 'ease-out';
const id = '6nABXU4HIo4';
const shakeAmount = 2;
player.addForTriggers(
id,
target.animate(
[ {translate: '0 0' }, 
{translate: `-${shakeAmount}px 0` }, 
{translate: '0 0' }, 
{translate: `${shakeAmount}px 0` }, 
{translate: '0 0' }, 
{translate: `-${shakeAmount}px 0` }, 
{translate: '0 0' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script7 = function()
{
  const target = object('6ABkMU9AHKl');
const duration = 500;
const easing = 'ease-out';
const id = '5xOgt9fFcBU';
const shakeAmount = 2;
player.addForTriggers(
id,
target.animate(
[ {translate: '0 0' }, 
{translate: `-${shakeAmount}px 0` }, 
{translate: '0 0' }, 
{translate: `${shakeAmount}px 0` }, 
{translate: '0 0' }, 
{translate: `-${shakeAmount}px 0` }, 
{translate: '0 0' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script8 = function()
{
  const target = object('6oPclunoyLm');
const duration = 500;
const easing = 'ease-out';
const id = '5yjLHOTL3gd';
const shakeAmount = 2;
player.addForTriggers(
id,
target.animate(
[ {translate: '0 0' }, 
{translate: `-${shakeAmount}px 0` }, 
{translate: '0 0' }, 
{translate: `${shakeAmount}px 0` }, 
{translate: '0 0' }, 
{translate: `-${shakeAmount}px 0` }, 
{translate: '0 0' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script9 = function()
{
  const target = object('6nbvK3SCa1S');
const duration = 500;
const easing = 'ease-out';
const id = '62jrCDOdy2c';
const shakeAmount = 2;
player.addForTriggers(
id,
target.animate(
[ {translate: '0 0' }, 
{translate: `-${shakeAmount}px 0` }, 
{translate: '0 0' }, 
{translate: `${shakeAmount}px 0` }, 
{translate: '0 0' }, 
{translate: `-${shakeAmount}px 0` }, 
{translate: '0 0' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script10 = function()
{
  const target = object('5ntH1siHHyE');
const duration = 500;
const easing = 'ease-out';
const id = '5fD3tHy1lEn';
const shakeAmount = 2;
player.addForTriggers(
id,
target.animate(
[ {translate: '0 0' }, 
{translate: `-${shakeAmount}px 0` }, 
{translate: '0 0' }, 
{translate: `${shakeAmount}px 0` }, 
{translate: '0 0' }, 
{translate: `-${shakeAmount}px 0` }, 
{translate: '0 0' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script11 = function()
{
  const target = object('5mrmg4WFsGx');
const duration = 500;
const easing = 'ease-out';
const id = '6jlQfwbVvxo';
const shakeAmount = 2;
player.addForTriggers(
id,
target.animate(
[ {translate: '0 0' }, 
{translate: `-${shakeAmount}px 0` }, 
{translate: '0 0' }, 
{translate: `${shakeAmount}px 0` }, 
{translate: '0 0' }, 
{translate: `-${shakeAmount}px 0` }, 
{translate: '0 0' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

};
