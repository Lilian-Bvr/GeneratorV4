function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5vhFtDj1msn":
        Script1();
        break;
      case "5nxkQS2QTud":
        Script2();
        break;
      case "67KPZmIZCzD":
        Script3();
        break;
      case "6jVqQGV3NE8":
        Script4();
        break;
      case "65u5NGN2F19":
        Script5();
        break;
      case "5sCHmy0ueJI":
        Script6();
        break;
      case "610n6IkVzS9":
        Script7();
        break;
      case "6SCaDW7BSdl":
        Script8();
        break;
      case "6CBZWp7bNa4":
        Script9();
        break;
      case "6GoM0oYtXuX":
        Script10();
        break;
      case "6b8tVW7FvzQ":
        Script11();
        break;
      case "5X9pBRNsAKt":
        Script12();
        break;
      case "6pJbIbpcGTM":
        Script13();
        break;
      case "6XAbFr2Wa20":
        Script14();
        break;
      case "6lfTdt1cXMC":
        Script15();
        break;
      case "6V3PE4AdXH8":
        Script16();
        break;
      case "6VwOKVTLetz":
        Script17();
        break;
      case "5VavYryFrKK":
        Script18();
        break;
      case "6dE5hczEFrc":
        Script19();
        break;
      case "6GqyfSHY8WS":
        Script20();
        break;
      case "5vDEriKv29w":
        Script21();
        break;
      case "5xmhutW6R5e":
        Script22();
        break;
      case "68WYp0FQHmf":
        Script23();
        break;
      case "6fwBP8oHg5z":
        Script24();
        break;
      case "6mWiAr28PiX":
        Script25();
        break;
      case "5wLG1HrO0yF":
        Script26();
        break;
      case "67S3KXFLEr7":
        Script27();
        break;
      case "5xdoN6eRfBe":
        Script28();
        break;
      case "6dxl5tD0v2R":
        Script29();
        break;
      case "6NcbEG90fLV":
        Script30();
        break;
      case "5YegBU5gN2Z":
        Script31();
        break;
      case "6eoPSqisPyY":
        Script32();
        break;
      case "6887oDoHtaG":
        Script33();
        break;
      case "5pSMfKhCAWf":
        Script34();
        break;
      case "6kXepL5Wo13":
        Script35();
        break;
      case "6M5fwQMYh79":
        Script36();
        break;
      case "6FS9pLAzlCh":
        Script37();
        break;
      case "6iLEW0SBQnd":
        Script38();
        break;
      case "6od6vUL7ser":
        Script39();
        break;
      case "5xvMkMtEEb3":
        Script40();
        break;
      case "6ebwxgD7JiV":
        Script41();
        break;
      case "6Xj6MDingy2":
        Script42();
        break;
      case "5eFb6cw40de":
        Script43();
        break;
      case "5WXZF2PzUsQ":
        Script44();
        break;
      case "6hzaQ5yKs4y":
        Script45();
        break;
      case "5sgYoZETJrj":
        Script46();
        break;
      case "6ZTy4Hpz4RB":
        Script47();
        break;
      case "5xRDpAyz9NA":
        Script48();
        break;
      case "6frgJm4Tob0":
        Script49();
        break;
      case "6Z916XLzEvC":
        Script50();
        break;
      case "5ij8Y39VuKp":
        Script51();
        break;
      case "5d8vnRFoyeB":
        Script52();
        break;
      case "6F844zMr8cb":
        Script53();
        break;
      case "64UeUxO8vTn":
        Script54();
        break;
      case "6jMAYjN78dQ":
        Script55();
        break;
      case "6WrIp6Sw1UC":
        Script56();
        break;
      case "6g8IBFIJuGZ":
        Script57();
        break;
      case "6RE3Z533iL1":
        Script58();
        break;
      case "5n96EvyYceq":
        Script59();
        break;
      case "5YcDONKmxmO":
        Script60();
        break;
      case "6A4rK7q7nFY":
        Script61();
        break;
      case "6VcomtacZhZ":
        Script62();
        break;
      case "6AA7GB9aY1L":
        Script63();
        break;
      case "6R1KGI2NaV5":
        Script64();
        break;
      case "5lYSU15Gpqf":
        Script65();
        break;
      case "6Ozf8jHUEGl":
        Script66();
        break;
      case "6JBSPTs8APi":
        Script67();
        break;
      case "6aXZUA4hQsc":
        Script68();
        break;
      case "6fG50WL2CKh":
        Script69();
        break;
      case "5qgt8LtaKhr":
        Script70();
        break;
      case "5qp03c0pOjZ":
        Script71();
        break;
      case "6qBVAaekb4b":
        Script72();
        break;
      case "61QQNRQtSue":
        Script73();
        break;
      case "5ZZZjSrPp3V":
        Script74();
        break;
      case "5ahzerZiHSe":
        Script75();
        break;
      case "6ZHYSjqCqmW":
        Script76();
        break;
      case "60tVyMR2H3T":
        Script77();
        break;
      case "6ZMm9NDVk6i":
        Script78();
        break;
      case "6Ba0q6kxPHJ":
        Script79();
        break;
      case "6NzOJCENkal":
        Script80();
        break;
      case "6cB7FLgq3pS":
        Script81();
        break;
      case "66ZiWRKWDrL":
        Script82();
        break;
      case "6Sb4ATPTD4Q":
        Script83();
        break;
      case "5pAXfLT72Wf":
        Script84();
        break;
      case "5lyCMyTDzkL":
        Script85();
        break;
      case "6jBVg8rx5gy":
        Script86();
        break;
      case "5q1PSXbtreJ":
        Script87();
        break;
      case "6JfCZp70Ux6":
        Script88();
        break;
      case "6H0RFsKtlJA":
        Script89();
        break;
      case "5a8JRd5eTJ0":
        Script90();
        break;
      case "5vndYMIhQhP":
        Script91();
        break;
      case "6Y0HUGrZyCj":
        Script92();
        break;
      case "62AVh5qW8h5":
        Script93();
        break;
      case "6ZDlTB16tEl":
        Script94();
        break;
      case "6qwsitCj7aP":
        Script95();
        break;
      case "6aNWcjahiaL":
        Script96();
        break;
      case "5j8La4Bl5qX":
        Script97();
        break;
      case "6gRe05yhLA1":
        Script98();
        break;
      case "6XLfKMwmACK":
        Script99();
        break;
      case "6rJ6xrgYINh":
        Script100();
        break;
      case "6K4UCZa3UUt":
        Script101();
        break;
      case "5sNjrpgbz4C":
        Script102();
        break;
      case "5qg54dxc1TD":
        Script103();
        break;
      case "683SOGuI0DA":
        Script104();
        break;
      case "6cnNHvGQdFF":
        Script105();
        break;
      case "5xBHTuo5iSF":
        Script106();
        break;
      case "5lLE7ozCsp8":
        Script107();
        break;
      case "6e7m0afsYUi":
        Script108();
        break;
      case "6mSinAh5UtP":
        Script109();
        break;
      case "5WJ8Z5ma4nC":
        Script110();
        break;
      case "6dyageL61Is":
        Script111();
        break;
      case "6aydhHHLBfg":
        Script112();
        break;
      case "61RqhP9hjnj":
        Script113();
        break;
      case "6GSLW7b5VVG":
        Script114();
        break;
      case "5lKGeMwzVuu":
        Script115();
        break;
      case "6eylN9cP3ZC":
        Script116();
        break;
      case "6KK9v4JzLhI":
        Script117();
        break;
      case "6KcUsqIKWok":
        Script118();
        break;
      case "6pv3iECv7B8":
        Script119();
        break;
      case "6gHUVeMb7S3":
        Script120();
        break;
      case "6IBGTMQWErC":
        Script121();
        break;
      case "6Dp67E6YiMV":
        Script122();
        break;
      case "6UA6vgtldoR":
        Script123();
        break;
      case "65LukPE2gAe":
        Script124();
        break;
      case "6X8g0aGlQTz":
        Script125();
        break;
      case "5uFMLcEZF3A":
        Script126();
        break;
      case "5Yd1y0I4vk6":
        Script127();
        break;
      case "5ksqAcw8p5f":
        Script128();
        break;
      case "6WN19kDCgST":
        Script129();
        break;
      case "6UeyX6dPchv":
        Script130();
        break;
      case "6SQ0XCa7AeW":
        Script131();
        break;
      case "69EljhWMTaE":
        Script132();
        break;
      case "6ey4xDvKM05":
        Script133();
        break;
      case "5eO9ZNi8dhv":
        Script134();
        break;
      case "66NZ5ufgldx":
        Script135();
        break;
      case "6aeVIuMNVpe":
        Script136();
        break;
      case "6ZBQAkvi1Ly":
        Script137();
        break;
      case "5zvcbuEMJ4h":
        Script138();
        break;
      case "66osOJnjdkg":
        Script139();
        break;
      case "6ni2PfoanNc":
        Script140();
        break;
      case "5fQ2zBhkvqV":
        Script141();
        break;
      case "5bZwlamKzXH":
        Script142();
        break;
      case "6VVIl9CYXlX":
        Script143();
        break;
      case "5dG8VCUVsdo":
        Script144();
        break;
      case "6X6YmjiGEsw":
        Script145();
        break;
      case "5gjX7xJ1Vvq":
        Script146();
        break;
      case "5v3KJDifqql":
        Script147();
        break;
      case "5cGnm5VwWlE":
        Script148();
        break;
      case "6IJmR0h6vj1":
        Script149();
        break;
      case "5zdfDIDgSrK":
        Script150();
        break;
      case "5xdsWzi8kqt":
        Script151();
        break;
      case "65JVs5eiSTt":
        Script152();
        break;
      case "6VjzqyZeY0z":
        Script153();
        break;
      case "5YLJFaCaD5D":
        Script154();
        break;
      case "5uxObIVW9F2":
        Script155();
        break;
      case "6UipmDdnkza":
        Script156();
        break;
      case "5nVgedZRx1t":
        Script157();
        break;
      case "5mTyRRYHLem":
        Script158();
        break;
      case "6Jr6lUydZp1":
        Script159();
        break;
      case "5wHC6GZpsxM":
        Script160();
        break;
      case "5eRRe1etIZt":
        Script161();
        break;
      case "63Hd8lOAqlO":
        Script162();
        break;
      case "5uWB88waFll":
        Script163();
        break;
      case "6F8ERiPHQij":
        Script164();
        break;
      case "5UgYO3QNPY4":
        Script165();
        break;
      case "5tyF7nWu6no":
        Script166();
        break;
      case "6HrN0lUVID9":
        Script167();
        break;
      case "6bFBpF2mUgo":
        Script168();
        break;
      case "6kpHQFowZFU":
        Script169();
        break;
      case "5jB0iVtb1LX":
        Script170();
        break;
      case "5motHvb5Yyg":
        Script171();
        break;
      case "5Zmfbvu2S5V":
        Script172();
        break;
      case "6pp1KT5gzsB":
        Script173();
        break;
      case "5wdN9mYZj86":
        Script174();
        break;
      case "6AwFMhh8Vfu":
        Script175();
        break;
      case "6J5vsIIFpTy":
        Script176();
        break;
      case "63uqBDZTBJk":
        Script177();
        break;
      case "6q0bl7PmAqK":
        Script178();
        break;
      case "6Vl8GPiuuLh":
        Script179();
        break;
      case "6Td0EJpezhN":
        Script180();
        break;
      case "62lUCl9dYcc":
        Script181();
        break;
      case "6JX2skLa4pq":
        Script182();
        break;
      case "5iMoVxYm4HM":
        Script183();
        break;
      case "6CmI7B3j9kG":
        Script184();
        break;
      case "60C754FxLOC":
        Script185();
        break;
      case "5mkU585WmQz":
        Script186();
        break;
      case "6OGBNdndBZF":
        Script187();
        break;
      case "6SUTHRpo57b":
        Script188();
        break;
      case "5tFYl7MhFbl":
        Script189();
        break;
      case "6bSbGTvXRek":
        Script190();
        break;
      case "6r6qsBIamlw":
        Script191();
        break;
      case "6JlFTlqenQf":
        Script192();
        break;
      case "6QUgi4WEOQ4":
        Script193();
        break;
      case "6g8SbjgSd7L":
        Script194();
        break;
      case "5ewOhn1RbJn":
        Script195();
        break;
      case "61w6M6o8qQx":
        Script196();
        break;
      case "6ajKPiLjdKS":
        Script197();
        break;
      case "5ghD2euJF6q":
        Script198();
        break;
      case "6g9SOooTnEj":
        Script199();
        break;
      case "6Yhjb9wJwaO":
        Script200();
        break;
      case "6j3YESbqbM0":
        Script201();
        break;
      case "5b5S5lnmsHL":
        Script202();
        break;
      case "6d1XodlLhgn":
        Script203();
        break;
      case "6rHBu7KYSFb":
        Script204();
        break;
      case "5WedVof4VCd":
        Script205();
        break;
      case "5mikW56Nt6N":
        Script206();
        break;
      case "5ks8UiiVaBp":
        Script207();
        break;
      case "5mjAYqpUwdb":
        Script208();
        break;
      case "6Vf0NlcdcuL":
        Script209();
        break;
      case "6QNRDeCyTOa":
        Script210();
        break;
      case "6Xd5hz66JW3":
        Script211();
        break;
      case "5rUknggf7nU":
        Script212();
        break;
      case "5YfuaWP0jE9":
        Script213();
        break;
      case "5ueMbXzJOHQ":
        Script214();
        break;
      case "5s71lvgM5Bt":
        Script215();
        break;
      case "5zR1BBgtcwK":
        Script216();
        break;
      case "6Mvb3KpobZj":
        Script217();
        break;
      case "5eO3LKj1kYC":
        Script218();
        break;
      case "6VzqEueDGo5":
        Script219();
        break;
      case "6j5tqwmuYg5":
        Script220();
        break;
      case "65msOlqLIwH":
        Script221();
        break;
      case "64SDziLJWe0":
        Script222();
        break;
      case "5aPrVre8AA8":
        Script223();
        break;
      case "5jvktFHN1lB":
        Script224();
        break;
      case "6Ob6sO9eqsO":
        Script225();
        break;
      case "5l5fKcraiig":
        Script226();
        break;
      case "6g73qw93ZmQ":
        Script227();
        break;
      case "5e5OiukR6F4":
        Script228();
        break;
      case "5wRMeKZLtOb":
        Script229();
        break;
      case "5q6xtX1wpZC":
        Script230();
        break;
      case "6CAZwf59XM7":
        Script231();
        break;
      case "6V4vFvDgHEm":
        Script232();
        break;
      case "6pB4tDrEv21":
        Script233();
        break;
      case "63mRhcsLnwA":
        Script234();
        break;
      case "6hIEbKsobz2":
        Script235();
        break;
      case "6My3gYgBSR9":
        Script236();
        break;
      case "5xDVQGQic2j":
        Script237();
        break;
      case "5eXUPFYDOas":
        Script238();
        break;
      case "6P5U4EJcBty":
        Script239();
        break;
      case "67Sl6TLBvHw":
        Script240();
        break;
      case "5fbl7Iw5Bot":
        Script241();
        break;
      case "6qcSU3qIHZi":
        Script242();
        break;
      case "5ksiRHFbNkf":
        Script243();
        break;
      case "5thCNFwKbap":
        Script244();
        break;
      case "6Xu0VJmApy0":
        Script245();
        break;
      case "5weJetnVnPO":
        Script246();
        break;
      case "6WJjeUcTw0C":
        Script247();
        break;
      case "609Dr8kEo9e":
        Script248();
        break;
      case "6HGxVbBHc7q":
        Script249();
        break;
      case "5zMu62hshO0":
        Script250();
        break;
      case "6TPvZbfbLlY":
        Script251();
        break;
      case "6RooN6Ph26Q":
        Script252();
        break;
      case "605l2jY9fjD":
        Script253();
        break;
      case "6CuFbbVISbs":
        Script254();
        break;
      case "6I7b4Pv62oG":
        Script255();
        break;
      case "6HrLDSJzhiE":
        Script256();
        break;
      case "643l5SuW49D":
        Script257();
        break;
      case "6DcXb8xDKok":
        Script258();
        break;
      case "6BFwZnmn4zj":
        Script259();
        break;
      case "5pR0EVlmKGn":
        Script260();
        break;
      case "5y2UgCM8G1z":
        Script261();
        break;
      case "6pIaBa1Vu2i":
        Script262();
        break;
      case "64R78CoBAYY":
        Script263();
        break;
      case "6mu30Or34hh":
        Script264();
        break;
      case "6RLnoFmxGoM":
        Script265();
        break;
      case "5kc0GrbvCvy":
        Script266();
        break;
      case "5eBG62RRFpC":
        Script267();
        break;
      case "6RxSnnYX5Dp":
        Script268();
        break;
      case "5bmB9xgS7Nu":
        Script269();
        break;
      case "5bo2DBzKZbx":
        Script270();
        break;
      case "6Zqu7xhjev8":
        Script271();
        break;
      case "5wVYrEuijL7":
        Script272();
        break;
      case "6ElZfrvaVVG":
        Script273();
        break;
      case "6OtSWjGj4je":
        Script274();
        break;
      case "5v9zcqUF3xZ":
        Script275();
        break;
      case "5pVI1ulQL84":
        Script276();
        break;
      case "5r6DKTFYVKV":
        Script277();
        break;
      case "5ca9wQ1dfdb":
        Script278();
        break;
      case "6ktcWJS8Ji8":
        Script279();
        break;
      case "5VuvaSz3rzq":
        Script280();
        break;
      case "65TDk39Em1f":
        Script281();
        break;
      case "6N0hB7Sj6FP":
        Script282();
        break;
      case "6m2Kl4TnoNa":
        Script283();
        break;
      case "6G8bc6JSVdj":
        Script284();
        break;
      case "6hf8EMyRi7w":
        Script285();
        break;
      case "6MVM77H4Wvv":
        Script286();
        break;
      case "5vk5pha5rsC":
        Script287();
        break;
      case "66EXL8LhWfI":
        Script288();
        break;
      case "6Kzq966dxKO":
        Script289();
        break;
      case "5q1mwu4adNJ":
        Script290();
        break;
      case "5eNx94OmNQu":
        Script291();
        break;
      case "6GeLMRbL9cP":
        Script292();
        break;
      case "5WPSnAp2rah":
        Script293();
        break;
      case "5eDpfBWHg3n":
        Script294();
        break;
      case "6WbsFlKcfBP":
        Script295();
        break;
      case "6Eg5zVE5RH6":
        Script296();
        break;
      case "68NHM1phsnc":
        Script297();
        break;
      case "5tkSTfc28ak":
        Script298();
        break;
      case "5Z6GtNn3Y7R":
        Script299();
        break;
      case "6S8qKJCGKNH":
        Script300();
        break;
      case "5cibtWUrtBe":
        Script301();
        break;
      case "6DoUA1S8rVm":
        Script302();
        break;
      case "6mMO6bVEdTy":
        Script303();
        break;
      case "66NnMokWLEQ":
        Script304();
        break;
      case "6Q82UzjSese":
        Script305();
        break;
      case "6nqhJDxveMh":
        Script306();
        break;
      case "5h3dwswz7Fw":
        Script307();
        break;
      case "6V9EMr0zh2x":
        Script308();
        break;
      case "6KJQCsYUIYh":
        Script309();
        break;
      case "6bApUgNMqRH":
        Script310();
        break;
      case "6d4CReYT4do":
        Script311();
        break;
      case "61jRgEiq4j7":
        Script312();
        break;
      case "6IPvKhR5Hap":
        Script313();
        break;
      case "6pSRpnDP3MW":
        Script314();
        break;
      case "6PU3ajt7wWP":
        Script315();
        break;
      case "5hwVhqB5seA":
        Script316();
        break;
      case "5fwM0H1YINP":
        Script317();
        break;
      case "5Y3gHa5Pt6n":
        Script318();
        break;
      case "5UtJq0U0g4d":
        Script319();
        break;
      case "5rhksIoN5KY":
        Script320();
        break;
      case "6mJzyrImCYX":
        Script321();
        break;
      case "6msqe017bCb":
        Script322();
        break;
      case "6lsk7A0vDpU":
        Script323();
        break;
      case "5pqhwmRTR51":
        Script324();
        break;
      case "5ta2mHbEXPY":
        Script325();
        break;
      case "6NSVzBJbYlh":
        Script326();
        break;
      case "6faVKbhz1GT":
        Script327();
        break;
      case "6jYOv5ovFe2":
        Script328();
        break;
      case "6lKFcDpgHkx":
        Script329();
        break;
      case "5Wg4nwrXHP2":
        Script330();
        break;
      case "6njBDihdiAd":
        Script331();
        break;
      case "66Bo5Iwus35":
        Script332();
        break;
      case "6nprtDLREcu":
        Script333();
        break;
      case "6oeiXpUVMV0":
        Script334();
        break;
      case "6bKke0YLF2B":
        Script335();
        break;
      case "5zTsnHteKNg":
        Script336();
        break;
      case "6MQYwOxAawQ":
        Script337();
        break;
      case "5te2IFsOisU":
        Script338();
        break;
      case "6rLii803kgF":
        Script339();
        break;
      case "6W2OVnlrf9V":
        Script340();
        break;
      case "6aHYRZYKjhC":
        Script341();
        break;
      case "6pgQl5Ju6s2":
        Script342();
        break;
      case "6nTOCUVWnUO":
        Script343();
        break;
      case "5sFJXF5fc6W":
        Script344();
        break;
      case "5ycVnZ5S2yP":
        Script345();
        break;
      case "64o8npqQsGX":
        Script346();
        break;
      case "6m25YGPsjNJ":
        Script347();
        break;
      case "6EAEehBoUUY":
        Script348();
        break;
      case "6EV2sWqtqwR":
        Script349();
        break;
      case "5z0I2pr0cOW":
        Script350();
        break;
      case "6QuRQ1sD8CJ":
        Script351();
        break;
      case "5aFHuKv0oHe":
        Script352();
        break;
      case "5jV1PbgS1GS":
        Script353();
        break;
      case "6is5ZdWC2BX":
        Script354();
        break;
      case "6AQrZzWsq6c":
        Script355();
        break;
      case "6oOE5eIsPh4":
        Script356();
        break;
      case "67aOZBBB5w1":
        Script357();
        break;
      case "66xpuVWXP7U":
        Script358();
        break;
      case "6aIrzFtVHsp":
        Script359();
        break;
      case "6r5KhbKMRdJ":
        Script360();
        break;
      case "5hKquZ8yW7u":
        Script361();
        break;
      case "5tcKN2yhXDC":
        Script362();
        break;
      case "6aCJ1hQGejj":
        Script363();
        break;
      case "6iqqDqgou9j":
        Script364();
        break;
      case "6QhjsSBnCOP":
        Script365();
        break;
      case "5X1fYKEAfI2":
        Script366();
        break;
      case "5rANKQPedI6":
        Script367();
        break;
      case "6cqWQhzkjvt":
        Script368();
        break;
      case "6U36cBuyHmP":
        Script369();
        break;
      case "5acDOkevdDi":
        Script370();
        break;
      case "5yufMVLjbFA":
        Script371();
        break;
      case "68AMKiEKXXG":
        Script372();
        break;
      case "6HqG7G9OrT7":
        Script373();
        break;
      case "6ZeLghIog6m":
        Script374();
        break;
      case "6ZFCQVWFSFp":
        Script375();
        break;
      case "5uv26pY4Vv8":
        Script376();
        break;
      case "6WZs9QAAqoY":
        Script377();
        break;
      case "6NgFrV0GLQY":
        Script378();
        break;
      case "5a8PK8gfJT4":
        Script379();
        break;
  }
}

window.InitExecuteScripts = function()
{
var player = GetPlayer();
var object = player.object;
var once = player.once;
var addToTimeline = player.addToTimeline;
var setVar = player.SetVar;
var getVar = player.GetVar;
var update = player.update;
var pointerX = player.pointerX;
var pointerY = player.pointerY;
var showPointer = player.showPointer;
var hidePointer = player.hidePointer;
var slideWidth = player.slideWidth;
var slideHeight = player.slideHeight;
window.Script1 = function()
{
  const target = object('5yXtTLZgph3');
const duration = 100;
const easing = 'ease-out';
const id = '5l6dcBXJSMv';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script2 = function()
{
  const target = object('5uebGMHB5LC');
const duration = 100;
const easing = 'ease-out';
const id = '5VoyNByAKqQ';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script3 = function()
{
  const target = object('5k3SDDR2nLb');
const duration = 100;
const easing = 'ease-out';
const id = '5cMRAO1v1mx';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script4 = function()
{
  const target = object('5iQigltUZuq');
const duration = 500;
const easing = 'ease-out';
const id = '6PBn8qBZybR';
const shakeAmount = 2;
player.addForTriggers(
id,
target.animate(
[ {translate: '0 0' }, 
{translate: `-${shakeAmount}px 0` }, 
{translate: '0 0' }, 
{translate: `${shakeAmount}px 0` }, 
{translate: '0 0' }, 
{translate: `-${shakeAmount}px 0` }, 
{translate: '0 0' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script5 = function()
{
  const target = object('6dqnNZXdA7Z');
const duration = 500;
const easing = 'ease-out';
const id = '5kgeCBbqZUk';
const shakeAmount = 2;
player.addForTriggers(
id,
target.animate(
[ {translate: '0 0' }, 
{translate: `-${shakeAmount}px 0` }, 
{translate: '0 0' }, 
{translate: `${shakeAmount}px 0` }, 
{translate: '0 0' }, 
{translate: `-${shakeAmount}px 0` }, 
{translate: '0 0' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script6 = function()
{
  const target = object('5puSsmxEWCo');
const duration = 500;
const easing = 'ease-out';
const id = '6nABXU4HIo4';
const shakeAmount = 2;
player.addForTriggers(
id,
target.animate(
[ {translate: '0 0' }, 
{translate: `-${shakeAmount}px 0` }, 
{translate: '0 0' }, 
{translate: `${shakeAmount}px 0` }, 
{translate: '0 0' }, 
{translate: `-${shakeAmount}px 0` }, 
{translate: '0 0' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script7 = function()
{
  const target = object('6ABkMU9AHKl');
const duration = 500;
const easing = 'ease-out';
const id = '5xOgt9fFcBU';
const shakeAmount = 2;
player.addForTriggers(
id,
target.animate(
[ {translate: '0 0' }, 
{translate: `-${shakeAmount}px 0` }, 
{translate: '0 0' }, 
{translate: `${shakeAmount}px 0` }, 
{translate: '0 0' }, 
{translate: `-${shakeAmount}px 0` }, 
{translate: '0 0' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script8 = function()
{
  const target = object('6oPclunoyLm');
const duration = 500;
const easing = 'ease-out';
const id = '5yjLHOTL3gd';
const shakeAmount = 2;
player.addForTriggers(
id,
target.animate(
[ {translate: '0 0' }, 
{translate: `-${shakeAmount}px 0` }, 
{translate: '0 0' }, 
{translate: `${shakeAmount}px 0` }, 
{translate: '0 0' }, 
{translate: `-${shakeAmount}px 0` }, 
{translate: '0 0' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script9 = function()
{
  const target = object('6nbvK3SCa1S');
const duration = 500;
const easing = 'ease-out';
const id = '62jrCDOdy2c';
const shakeAmount = 2;
player.addForTriggers(
id,
target.animate(
[ {translate: '0 0' }, 
{translate: `-${shakeAmount}px 0` }, 
{translate: '0 0' }, 
{translate: `${shakeAmount}px 0` }, 
{translate: '0 0' }, 
{translate: `-${shakeAmount}px 0` }, 
{translate: '0 0' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script10 = function()
{
  const target = object('5ntH1siHHyE');
const duration = 500;
const easing = 'ease-out';
const id = '5fD3tHy1lEn';
const shakeAmount = 2;
player.addForTriggers(
id,
target.animate(
[ {translate: '0 0' }, 
{translate: `-${shakeAmount}px 0` }, 
{translate: '0 0' }, 
{translate: `${shakeAmount}px 0` }, 
{translate: '0 0' }, 
{translate: `-${shakeAmount}px 0` }, 
{translate: '0 0' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script11 = function()
{
  const target = object('5mrmg4WFsGx');
const duration = 500;
const easing = 'ease-out';
const id = '6jlQfwbVvxo';
const shakeAmount = 2;
player.addForTriggers(
id,
target.animate(
[ {translate: '0 0' }, 
{translate: `-${shakeAmount}px 0` }, 
{translate: '0 0' }, 
{translate: `${shakeAmount}px 0` }, 
{translate: '0 0' }, 
{translate: `-${shakeAmount}px 0` }, 
{translate: '0 0' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

};
