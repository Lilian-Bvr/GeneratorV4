function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5szOfalrmvh":
        Script1();
        break;
      case "6NYu2BtNuyb":
        Script2();
        break;
      case "5WUWGiX1P8b":
        Script3();
        break;
      case "681nNa0awt1":
        Script4();
        break;
      case "6kdkCN4W2lU":
        Script5();
        break;
      case "5oZagmI2xmx":
        Script6();
        break;
      case "6FZZTPSNXXM":
        Script7();
        break;
      case "6edZKDKbdDJ":
        Script8();
        break;
      case "5W33VWV59hP":
        Script9();
        break;
      case "6DcWLElkFQ9":
        Script10();
        break;
      case "6FnSaonZzzJ":
        Script11();
        break;
      case "60P2FaqjLwB":
        Script12();
        break;
      case "6hoBc34xS8I":
        Script13();
        break;
      case "6WddwmHOA5w":
        Script14();
        break;
      case "6g5f1MRrdJW":
        Script15();
        break;
      case "5apMfdrYdd2":
        Script16();
        break;
      case "5blL0fjoI3J":
        Script17();
        break;
      case "6CfxSsoEJuU":
        Script18();
        break;
      case "6U9bCZtezeU":
        Script19();
        break;
      case "6Sv7RIyysGN":
        Script20();
        break;
      case "6ifB4ohxtPc":
        Script21();
        break;
      case "5gh4fuX6Iiq":
        Script22();
        break;
      case "6di5yo8eXPj":
        Script23();
        break;
      case "65Q6CK0FflY":
        Script24();
        break;
      case "5ZSAOZtBRfl":
        Script25();
        break;
      case "5YUQNAXZLo2":
        Script26();
        break;
      case "6erx2mC6O1f":
        Script27();
        break;
      case "61oyIjnDHUN":
        Script28();
        break;
      case "6lWvAD6Tdgo":
        Script29();
        break;
      case "6J3P83ayuEb":
        Script30();
        break;
      case "63tk6bTxJsn":
        Script31();
        break;
      case "6QL6JN1zUaA":
        Script32();
        break;
      case "5vZ9zT8p8WK":
        Script33();
        break;
      case "6js9mKVtCHT":
        Script34();
        break;
      case "5pgv16bHsnD":
        Script35();
        break;
      case "5YaVEGdCLMw":
        Script36();
        break;
      case "5jzsP3fwZAs":
        Script37();
        break;
      case "69Kj2qBzi4u":
        Script38();
        break;
      case "5VfoU0ELDKL":
        Script39();
        break;
      case "6rQ08u8a9aa":
        Script40();
        break;
      case "5mvIhCBLcyn":
        Script41();
        break;
      case "6EjbvuEdOqM":
        Script42();
        break;
      case "6ZTFBDzpLhn":
        Script43();
        break;
      case "6cDUTBJPIJ8":
        Script44();
        break;
      case "6ltAsJpC5Oe":
        Script45();
        break;
      case "5sax6XQTUpl":
        Script46();
        break;
      case "6eBTWh8eo2B":
        Script47();
        break;
      case "6C03YMhdOsw":
        Script48();
        break;
      case "5ZThislW7zS":
        Script49();
        break;
      case "5d0he0B08lZ":
        Script50();
        break;
      case "6kYManJPtFR":
        Script51();
        break;
      case "6MtdJXlvMxl":
        Script52();
        break;
      case "6KMakj7JcMH":
        Script53();
        break;
      case "6nZDU6sWDar":
        Script54();
        break;
      case "6TYhig7SK8k":
        Script55();
        break;
      case "5qKtNQZflP9":
        Script56();
        break;
      case "5Wz4g9pqTmS":
        Script57();
        break;
      case "6rhDS4LqjPd":
        Script58();
        break;
      case "62DeTK6mt3h":
        Script59();
        break;
      case "5WgU31gbomk":
        Script60();
        break;
      case "5hurdvu8KDc":
        Script61();
        break;
      case "6LQxaUuIFoy":
        Script62();
        break;
      case "6Wh09Bwe4IF":
        Script63();
        break;
      case "674uV9tTVfR":
        Script64();
        break;
      case "5j6vYNpcOb8":
        Script65();
        break;
      case "5dv1Z2DFBLe":
        Script66();
        break;
      case "6eAc0JgIjRC":
        Script67();
        break;
      case "5bYSU16APLQ":
        Script68();
        break;
      case "6ND6R02rDGW":
        Script69();
        break;
      case "61r8sw84Uar":
        Script70();
        break;
      case "5sWrONdU4tL":
        Script71();
        break;
      case "6UknNMQrQoh":
        Script72();
        break;
      case "68EFQVsHs3T":
        Script73();
        break;
      case "67rXYs7G006":
        Script74();
        break;
      case "5lTo5USrRwp":
        Script75();
        break;
      case "5mTf2lC8cpJ":
        Script76();
        break;
      case "6XUubEcGipH":
        Script77();
        break;
      case "6Zwq4yvtJa6":
        Script78();
        break;
      case "6GRt7RmEQsP":
        Script79();
        break;
      case "6eSCJ8vU6C2":
        Script80();
        break;
      case "6BBB7jJWSsv":
        Script81();
        break;
      case "5vLZ01Gzbfw":
        Script82();
        break;
      case "6OBtvVGTCQe":
        Script83();
        break;
      case "6BeLl2mmsnH":
        Script84();
        break;
      case "6Sc2ZRL3eYR":
        Script85();
        break;
      case "64g893MHDhR":
        Script86();
        break;
      case "62x4gdbSiHi":
        Script87();
        break;
      case "5gUF3rfY4Aq":
        Script88();
        break;
      case "6hrIyG0wJ5u":
        Script89();
        break;
      case "6PZF7ASGlMU":
        Script90();
        break;
      case "6Eyg5iTZ83h":
        Script91();
        break;
      case "6d6hzD4NyIp":
        Script92();
        break;
      case "5uynt7amXOT":
        Script93();
        break;
      case "5gNIQJ94p9o":
        Script94();
        break;
      case "66bOLrUDFwT":
        Script95();
        break;
      case "634sIa6z0zu":
        Script96();
        break;
      case "6DkwuRP9wx7":
        Script97();
        break;
      case "5ab7aEI8Ugv":
        Script98();
        break;
      case "6K01W9Iebzh":
        Script99();
        break;
      case "6N4wxknm4d0":
        Script100();
        break;
      case "61FCk2gh0mK":
        Script101();
        break;
      case "6PutbIuGcXe":
        Script102();
        break;
      case "5iY6QYXqUIq":
        Script103();
        break;
      case "5rEZMzcmAK8":
        Script104();
        break;
      case "6MgCqYOgkf1":
        Script105();
        break;
      case "5vWHLuk7yQc":
        Script106();
        break;
      case "6AdPoATMj35":
        Script107();
        break;
      case "5yx1xo6qGdo":
        Script108();
        break;
      case "6ZvD9rjTSoH":
        Script109();
        break;
      case "5sy0MaJd6mQ":
        Script110();
        break;
      case "6OfHxNgj2wO":
        Script111();
        break;
      case "6mQUnYCbv2C":
        Script112();
        break;
      case "5vzl2YqPEI4":
        Script113();
        break;
      case "68zyp84x4Ed":
        Script114();
        break;
      case "5coPBaXQcyn":
        Script115();
        break;
      case "5rPB7sIKuJt":
        Script116();
        break;
      case "69f8of97Xqj":
        Script117();
        break;
      case "6g1mkICmq4r":
        Script118();
        break;
      case "5topo09Xqb0":
        Script119();
        break;
      case "6GpOLN7cLgd":
        Script120();
        break;
      case "6but8lo2L1J":
        Script121();
        break;
      case "6eyLGi0XcUH":
        Script122();
        break;
      case "5yvTe5GEcPy":
        Script123();
        break;
      case "5gUBYN7shg6":
        Script124();
        break;
      case "6FL7pt2xTkm":
        Script125();
        break;
      case "5zmgCng7bCR":
        Script126();
        break;
      case "66XfAzGZ5GB":
        Script127();
        break;
      case "5UmCdl8rd7Y":
        Script128();
        break;
      case "5Vv1IfN8NOo":
        Script129();
        break;
      case "5Yi4rPaJUsJ":
        Script130();
        break;
      case "6Ggx9RLZSZ7":
        Script131();
        break;
      case "6InrBFHkvWS":
        Script132();
        break;
      case "5qia4YL2MoT":
        Script133();
        break;
      case "5WJ37tYIPYE":
        Script134();
        break;
      case "6BXModOt72L":
        Script135();
        break;
      case "5uLyLdyyyOt":
        Script136();
        break;
      case "6dBSEnc8l1i":
        Script137();
        break;
      case "63QSWKzUtlO":
        Script138();
        break;
      case "5tpxGi8mYNE":
        Script139();
        break;
      case "6RYf7xEKp14":
        Script140();
        break;
      case "5kPNYR8cmum":
        Script141();
        break;
      case "6ETAbq7oYfE":
        Script142();
        break;
      case "5sQVHhxzF86":
        Script143();
        break;
      case "6YC390WxAi1":
        Script144();
        break;
      case "5dBfzq4qhiV":
        Script145();
        break;
      case "5vNIQRtZ1Uu":
        Script146();
        break;
      case "6QQQzPva9tg":
        Script147();
        break;
      case "67VbGTp02Xw":
        Script148();
        break;
      case "6ENtzqoQJvL":
        Script149();
        break;
      case "6jpUGO9CeHH":
        Script150();
        break;
      case "6FTU5YroDrO":
        Script151();
        break;
      case "5r6WQKR0UNf":
        Script152();
        break;
      case "6OSdmm4uOSq":
        Script153();
        break;
      case "5XjOSrKMPzu":
        Script154();
        break;
      case "6fVIyC6SuNq":
        Script155();
        break;
      case "6EEgakTPjnK":
        Script156();
        break;
      case "5rcHDdyc7dU":
        Script157();
        break;
      case "69DXmqiXMIV":
        Script158();
        break;
      case "6nGLzovjm2c":
        Script159();
        break;
      case "6E5opsfQbtN":
        Script160();
        break;
      case "5VTw1F99u38":
        Script161();
        break;
      case "6iYOjZFAgiy":
        Script162();
        break;
      case "5W38OMzpmwV":
        Script163();
        break;
      case "5ebC5UXRW7G":
        Script164();
        break;
      case "5ezlqk9lOGA":
        Script165();
        break;
      case "6BQxOho4BHJ":
        Script166();
        break;
      case "6fFpxXA3CXA":
        Script167();
        break;
      case "6TYFs8tl3lM":
        Script168();
        break;
      case "5ios38g5kQi":
        Script169();
        break;
      case "6i03Qq0NZAr":
        Script170();
        break;
      case "6Swa005Jro2":
        Script171();
        break;
      case "5m7IDfwlEGr":
        Script172();
        break;
      case "64LrKOc8klb":
        Script173();
        break;
      case "6IhzR1cLCJA":
        Script174();
        break;
      case "6mw0dvOhVNE":
        Script175();
        break;
      case "5l0cfM4Lmmy":
        Script176();
        break;
      case "6bpXOvWxCjk":
        Script177();
        break;
      case "5ttTzXnwbLI":
        Script178();
        break;
      case "6Kr3lHgzm1C":
        Script179();
        break;
      case "6ETrir07qIw":
        Script180();
        break;
      case "66H03ZkecKk":
        Script181();
        break;
      case "5oWKC0RlGHO":
        Script182();
        break;
      case "6RFbwuZRYnN":
        Script183();
        break;
      case "6K2f3xRXyfl":
        Script184();
        break;
      case "5j5jIRaS11S":
        Script185();
        break;
      case "67Wf7CylXbQ":
        Script186();
        break;
      case "66yocPKtC4s":
        Script187();
        break;
      case "5j0cVDimjRp":
        Script188();
        break;
      case "6OkD71uFHya":
        Script189();
        break;
      case "6fPjicJ3QZn":
        Script190();
        break;
      case "5uRoMA8Fx6p":
        Script191();
        break;
      case "630QHXUPzmZ":
        Script192();
        break;
      case "6Jv1eCs2Ira":
        Script193();
        break;
      case "5zZ6TXCjQC7":
        Script194();
        break;
      case "6mL98hb2COp":
        Script195();
        break;
      case "5nTvPiLYFZC":
        Script196();
        break;
      case "68CRF0Z7zPL":
        Script197();
        break;
      case "63zQry01FP8":
        Script198();
        break;
      case "6EcHytcAEbr":
        Script199();
        break;
      case "6EawkiB0osm":
        Script200();
        break;
      case "63kQVEvEyZN":
        Script201();
        break;
      case "62uCEvOGjXL":
        Script202();
        break;
      case "5twFSJII9yG":
        Script203();
        break;
      case "5a218uIHkys":
        Script204();
        break;
      case "6izrUFn3BmP":
        Script205();
        break;
      case "5xmOlAKBQnZ":
        Script206();
        break;
      case "6o1jL1vKO3j":
        Script207();
        break;
      case "5rI2oNxplit":
        Script208();
        break;
      case "63xflC99Zry":
        Script209();
        break;
      case "5rmdbtWlig5":
        Script210();
        break;
      case "5uc7X64svoc":
        Script211();
        break;
      case "62zETsszehm":
        Script212();
        break;
      case "6D1h8I7oD6q":
        Script213();
        break;
      case "6DWrn3DlURz":
        Script214();
        break;
      case "5wU9sdfNzL9":
        Script215();
        break;
      case "5WBzoQI4xb2":
        Script216();
        break;
      case "6UMCqAVzvB9":
        Script217();
        break;
      case "5eM6N1dHX3q":
        Script218();
        break;
      case "6c0ABNhHrn2":
        Script219();
        break;
      case "5hEsw7jexJp":
        Script220();
        break;
      case "6HzFQiEi0CX":
        Script221();
        break;
      case "6VMivbLaQzi":
        Script222();
        break;
      case "6f7vGbJocJK":
        Script223();
        break;
      case "6gcYENgnBPX":
        Script224();
        break;
      case "5ddnYLJeIa6":
        Script225();
        break;
      case "5VZg6A4emyp":
        Script226();
        break;
      case "5wTf5C7cPU5":
        Script227();
        break;
      case "68apSHQLjG3":
        Script228();
        break;
      case "6LUdMQhtLom":
        Script229();
        break;
      case "62lJ06PxPtV":
        Script230();
        break;
      case "5aXKrd5GHd6":
        Script231();
        break;
      case "5XRznOxQEbu":
        Script232();
        break;
      case "6aags0IjCfW":
        Script233();
        break;
      case "6etYeGpml3V":
        Script234();
        break;
      case "67ECcITo2ed":
        Script235();
        break;
      case "6UJdEhXX8mx":
        Script236();
        break;
      case "5tjvtV2Zn0P":
        Script237();
        break;
      case "6FPbnioQwiP":
        Script238();
        break;
      case "5YMnpMAdXpe":
        Script239();
        break;
      case "5VJLtnDdCnI":
        Script240();
        break;
      case "6ZcS0yL4hv2":
        Script241();
        break;
      case "6Uy2FRMyZp3":
        Script242();
        break;
      case "6XyDRBThPD1":
        Script243();
        break;
      case "66BhYqhhA8I":
        Script244();
        break;
      case "6Yu0PioAtVT":
        Script245();
        break;
      case "6pfaalHd8KO":
        Script246();
        break;
      case "5xlRJt8Wsdo":
        Script247();
        break;
      case "61w2o5GGKi1":
        Script248();
        break;
      case "6bDltE91H4L":
        Script249();
        break;
      case "5mtiDKUIvOb":
        Script250();
        break;
      case "6Lrn0YkDtDv":
        Script251();
        break;
      case "6KLsRBYwsDS":
        Script252();
        break;
      case "5VXPcTEfJPJ":
        Script253();
        break;
      case "6rEA2hmhIDh":
        Script254();
        break;
      case "5sOohNwLRKm":
        Script255();
        break;
      case "6ePrANhh5Oj":
        Script256();
        break;
      case "5zO5wItzXIe":
        Script257();
        break;
      case "6d2fFzqjfAy":
        Script258();
        break;
      case "5e5GmsVL4gD":
        Script259();
        break;
      case "6fKR0jAxm6Q":
        Script260();
        break;
      case "6Yb2Arnd8Ty":
        Script261();
        break;
      case "6FyCO3BwGcj":
        Script262();
        break;
      case "5iahvcdwouW":
        Script263();
        break;
      case "67UwF1Xy2M3":
        Script264();
        break;
      case "6MtnVMALO8V":
        Script265();
        break;
      case "6fvGwRpsqRp":
        Script266();
        break;
      case "65Zffzl40EG":
        Script267();
        break;
      case "6XfGDNyAISw":
        Script268();
        break;
      case "5Y3o4Hu5cRf":
        Script269();
        break;
      case "5ZJW1qKxdEW":
        Script270();
        break;
      case "5qrSulR3AYe":
        Script271();
        break;
      case "5Vvap4u6iPl":
        Script272();
        break;
      case "6VhgBAmdePn":
        Script273();
        break;
      case "5n52hyaYO6f":
        Script274();
        break;
      case "6IcWJhkH7uK":
        Script275();
        break;
      case "6FKznq7TE2b":
        Script276();
        break;
      case "62un0FLDkOI":
        Script277();
        break;
      case "5UhN0rCspce":
        Script278();
        break;
      case "6gF8yAK9Jti":
        Script279();
        break;
      case "5vLy1KsX57C":
        Script280();
        break;
      case "6QgRCV32Yar":
        Script281();
        break;
      case "5UiqbnrzRtC":
        Script282();
        break;
      case "6DSFS6RfOAO":
        Script283();
        break;
      case "6C3DdyqgY5g":
        Script284();
        break;
      case "6YvKSZSyZKu":
        Script285();
        break;
      case "5t0LbcicCtr":
        Script286();
        break;
      case "5f8NhBNsUPg":
        Script287();
        break;
      case "6LLWrlwN2Kr":
        Script288();
        break;
      case "6q38f2IgVHV":
        Script289();
        break;
      case "5Y8gYSWIyBS":
        Script290();
        break;
      case "6kKtvYap8Yo":
        Script291();
        break;
      case "6h9PnjLo460":
        Script292();
        break;
      case "5ikWdFJlG5G":
        Script293();
        break;
      case "5tcZNc2gimQ":
        Script294();
        break;
      case "64wRJFmIo7l":
        Script295();
        break;
      case "65IMNvbws2Z":
        Script296();
        break;
      case "6mCrowCJYrI":
        Script297();
        break;
      case "6niqndlVd7L":
        Script298();
        break;
      case "5a7cJdjupOi":
        Script299();
        break;
      case "6Wx3IgbG9TT":
        Script300();
        break;
      case "6bLsbCiPj8P":
        Script301();
        break;
      case "6ljnvCXLjpC":
        Script302();
        break;
      case "6hhKOWpgdLo":
        Script303();
        break;
      case "5kEKzWLIHnP":
        Script304();
        break;
      case "6lJvE1HtZ8U":
        Script305();
        break;
      case "5xPPKvzy8j4":
        Script306();
        break;
      case "6V3AZGfZtxG":
        Script307();
        break;
      case "6iSlli5AYjr":
        Script308();
        break;
      case "6os1D6hwJtz":
        Script309();
        break;
      case "6ZPa10Pf3Qv":
        Script310();
        break;
      case "61RWJuT2So1":
        Script311();
        break;
      case "6ItWJfwvumW":
        Script312();
        break;
      case "5vD6oe34uBz":
        Script313();
        break;
      case "6INMX4CTHJV":
        Script314();
        break;
      case "6qSOIDlOXOt":
        Script315();
        break;
      case "5tdOIAmbEo0":
        Script316();
        break;
      case "5ad1ZYYEYRE":
        Script317();
        break;
      case "6M2ON8ZL6s7":
        Script318();
        break;
      case "6hQqk7BhVPF":
        Script319();
        break;
      case "5XC05WhCR0p":
        Script320();
        break;
      case "6U8nWFBVdeM":
        Script321();
        break;
      case "5mA5hx0XcPe":
        Script322();
        break;
      case "6I59ZTeSDne":
        Script323();
        break;
      case "65fKocLddUJ":
        Script324();
        break;
      case "6c5opaWkrbC":
        Script325();
        break;
      case "6YyGv8PRINj":
        Script326();
        break;
      case "5iJZTMPwbA4":
        Script327();
        break;
      case "5ZoFtzTU8JQ":
        Script328();
        break;
      case "5sdOJtgGXcD":
        Script329();
        break;
      case "6ownvi472UK":
        Script330();
        break;
      case "6NwUX4afu2Y":
        Script331();
        break;
      case "6TYZq7dSEuk":
        Script332();
        break;
      case "6c63xWfEbbX":
        Script333();
        break;
      case "6NoC2jKJNq6":
        Script334();
        break;
      case "6LEBEOo4B2H":
        Script335();
        break;
      case "5ktu1jddLfI":
        Script336();
        break;
      case "6qaU1U3xd9A":
        Script337();
        break;
      case "6ao55ccDRZr":
        Script338();
        break;
      case "5eozJT0GQyJ":
        Script339();
        break;
      case "5jAeFEDM8uo":
        Script340();
        break;
      case "6DS6Dwy4vwd":
        Script341();
        break;
      case "6SNkRdZBlup":
        Script342();
        break;
      case "67RqtJXbOAR":
        Script343();
        break;
      case "5lkFTt6TCdv":
        Script344();
        break;
      case "6K8uHkH4HtW":
        Script345();
        break;
      case "5wAVRJUnusz":
        Script346();
        break;
      case "5fdBNRPYLYj":
        Script347();
        break;
      case "5ry5B8yuBKZ":
        Script348();
        break;
      case "5XuUoZnrYIn":
        Script349();
        break;
      case "6oid6mQr6rt":
        Script350();
        break;
      case "6hJwGTWOFO1":
        Script351();
        break;
      case "65swcKD9NQ4":
        Script352();
        break;
      case "6bfGZFSeApf":
        Script353();
        break;
      case "68s9g3O667c":
        Script354();
        break;
      case "6csXb4CLCUu":
        Script355();
        break;
      case "5mV2bfsH4tB":
        Script356();
        break;
      case "68otgzL2YJj":
        Script357();
        break;
      case "5waZ6k05cuV":
        Script358();
        break;
      case "6oCIfM0ME77":
        Script359();
        break;
      case "6ZaYkTtvvM8":
        Script360();
        break;
      case "5vMKuUgE2TV":
        Script361();
        break;
      case "6KQTu4GnRjf":
        Script362();
        break;
      case "6aHnyZ34xb8":
        Script363();
        break;
      case "6VYa9tN6Sc3":
        Script364();
        break;
      case "5d2H6sZ8biD":
        Script365();
        break;
      case "62B6NGdSzhW":
        Script366();
        break;
      case "6k5eqbNXQEU":
        Script367();
        break;
      case "6GEXlumgEnB":
        Script368();
        break;
      case "68VjPk7IXjh":
        Script369();
        break;
      case "68M8kr4idiw":
        Script370();
        break;
      case "6f3xUryhJl0":
        Script371();
        break;
      case "6H74DNUCDWE":
        Script372();
        break;
      case "6ixdLUhuQ3n":
        Script373();
        break;
      case "6hJIZh5A7vW":
        Script374();
        break;
      case "6GZIoKQDNEx":
        Script375();
        break;
      case "6XBpk5CjhhH":
        Script376();
        break;
      case "6RE9w75Kft8":
        Script377();
        break;
      case "5ud6pll6kU0":
        Script378();
        break;
      case "6JlYHoq82Ty":
        Script379();
        break;
  }
}

window.InitExecuteScripts = function()
{
var player = GetPlayer();
var object = player.object;
var once = player.once;
var addToTimeline = player.addToTimeline;
var setVar = player.SetVar;
var getVar = player.GetVar;
var update = player.update;
var pointerX = player.pointerX;
var pointerY = player.pointerY;
var showPointer = player.showPointer;
var hidePointer = player.hidePointer;
var slideWidth = player.slideWidth;
var slideHeight = player.slideHeight;
window.Script1 = function()
{
  const target = object('5yXtTLZgph3');
const duration = 100;
const easing = 'ease-out';
const id = '5l6dcBXJSMv';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script2 = function()
{
  const target = object('5uebGMHB5LC');
const duration = 100;
const easing = 'ease-out';
const id = '5VoyNByAKqQ';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script3 = function()
{
  const target = object('5k3SDDR2nLb');
const duration = 100;
const easing = 'ease-out';
const id = '5cMRAO1v1mx';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script4 = function()
{
  const target = object('5iQigltUZuq');
const duration = 500;
const easing = 'ease-out';
const id = '6PBn8qBZybR';
const shakeAmount = 2;
player.addForTriggers(
id,
target.animate(
[ {translate: '0 0' }, 
{translate: `-${shakeAmount}px 0` }, 
{translate: '0 0' }, 
{translate: `${shakeAmount}px 0` }, 
{translate: '0 0' }, 
{translate: `-${shakeAmount}px 0` }, 
{translate: '0 0' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script5 = function()
{
  const target = object('6dqnNZXdA7Z');
const duration = 500;
const easing = 'ease-out';
const id = '5kgeCBbqZUk';
const shakeAmount = 2;
player.addForTriggers(
id,
target.animate(
[ {translate: '0 0' }, 
{translate: `-${shakeAmount}px 0` }, 
{translate: '0 0' }, 
{translate: `${shakeAmount}px 0` }, 
{translate: '0 0' }, 
{translate: `-${shakeAmount}px 0` }, 
{translate: '0 0' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script6 = function()
{
  const target = object('5puSsmxEWCo');
const duration = 500;
const easing = 'ease-out';
const id = '6nABXU4HIo4';
const shakeAmount = 2;
player.addForTriggers(
id,
target.animate(
[ {translate: '0 0' }, 
{translate: `-${shakeAmount}px 0` }, 
{translate: '0 0' }, 
{translate: `${shakeAmount}px 0` }, 
{translate: '0 0' }, 
{translate: `-${shakeAmount}px 0` }, 
{translate: '0 0' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script7 = function()
{
  const target = object('6ABkMU9AHKl');
const duration = 500;
const easing = 'ease-out';
const id = '5xOgt9fFcBU';
const shakeAmount = 2;
player.addForTriggers(
id,
target.animate(
[ {translate: '0 0' }, 
{translate: `-${shakeAmount}px 0` }, 
{translate: '0 0' }, 
{translate: `${shakeAmount}px 0` }, 
{translate: '0 0' }, 
{translate: `-${shakeAmount}px 0` }, 
{translate: '0 0' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script8 = function()
{
  const target = object('6oPclunoyLm');
const duration = 500;
const easing = 'ease-out';
const id = '5yjLHOTL3gd';
const shakeAmount = 2;
player.addForTriggers(
id,
target.animate(
[ {translate: '0 0' }, 
{translate: `-${shakeAmount}px 0` }, 
{translate: '0 0' }, 
{translate: `${shakeAmount}px 0` }, 
{translate: '0 0' }, 
{translate: `-${shakeAmount}px 0` }, 
{translate: '0 0' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script9 = function()
{
  const target = object('6nbvK3SCa1S');
const duration = 500;
const easing = 'ease-out';
const id = '62jrCDOdy2c';
const shakeAmount = 2;
player.addForTriggers(
id,
target.animate(
[ {translate: '0 0' }, 
{translate: `-${shakeAmount}px 0` }, 
{translate: '0 0' }, 
{translate: `${shakeAmount}px 0` }, 
{translate: '0 0' }, 
{translate: `-${shakeAmount}px 0` }, 
{translate: '0 0' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script10 = function()
{
  const target = object('5ntH1siHHyE');
const duration = 500;
const easing = 'ease-out';
const id = '5fD3tHy1lEn';
const shakeAmount = 2;
player.addForTriggers(
id,
target.animate(
[ {translate: '0 0' }, 
{translate: `-${shakeAmount}px 0` }, 
{translate: '0 0' }, 
{translate: `${shakeAmount}px 0` }, 
{translate: '0 0' }, 
{translate: `-${shakeAmount}px 0` }, 
{translate: '0 0' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script11 = function()
{
  const target = object('5mrmg4WFsGx');
const duration = 500;
const easing = 'ease-out';
const id = '6jlQfwbVvxo';
const shakeAmount = 2;
player.addForTriggers(
id,
target.animate(
[ {translate: '0 0' }, 
{translate: `-${shakeAmount}px 0` }, 
{translate: '0 0' }, 
{translate: `${shakeAmount}px 0` }, 
{translate: '0 0' }, 
{translate: `-${shakeAmount}px 0` }, 
{translate: '0 0' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

};
